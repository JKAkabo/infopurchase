CREATE VIEW [dbo].[AttendanceDoctorsView]

AS

SELECT Distinct Doctor, Users.UserID FROM Users Inner Join dbo.Consultations On UserNo=Consultations.Doctor where Consultations.Archived='No'

Union

Select Distinct DoctorID as Doctor, Users.UserID From Users Inner Join Admissions On UserNo=DoctorID where Admissions.Archived='No' and DoctorID NOT IN 
(SELECT Distinct Doctor FROM Users Inner Join dbo.Consultations On UserNo=Consultations.Doctor where Consultations.Archived='No')
go

