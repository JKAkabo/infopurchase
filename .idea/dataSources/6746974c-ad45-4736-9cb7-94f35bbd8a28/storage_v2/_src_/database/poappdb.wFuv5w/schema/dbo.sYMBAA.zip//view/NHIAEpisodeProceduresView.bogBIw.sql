CREATE VIEW [dbo].[NHIAEpisodeProceduresView]

AS

SELECT Distinct Left(SERVICETYPE,100) As ServiceDescription, Service_Requests.ServiceCode, ServiceTypeCode, PmtTypeCode, 'PROCEDURE(S)' As ServicePlace, Service_Fee as UnitFee, ServiceQty, ReqDate, GDRG_Code As GDRDCode, EpisodeID, RequestType, OPDNo, Issued As ServiceIssued, Service_Requests.StatusCode As PatStatus, ServiceDate, DirectID,SponsorNo, ReqDate As EpiEndDate FROM Service_Types Inner Join Service_Requests On Service_Types.ServiceCode=Service_Requests.ServiceCode Where EpisodeID<>0 and ServiceTypeCode=3 and Archived='No' and Refunded='No' and PmtTypeCode<>1 and BillCategoryCode IN (4,11)  and SponsorNo<>''
go

