
CREATE VIEW [dbo].[DebtorsView]

AS

Select PBOut, PatientID, OPDNo, Surname, LastName, MiddleName, Gender, PatStatus, PatientAge, LastPmtDate, CellPhoneNo, 
IsNull((Select SUM((RequestedQty-PaidQty) * UnitFee) From ServicesRevenueView where OPDNo=PatientID and PmtTypeCode=1 
and SponsorNo='' and PaidQty<RequestedQty And BillCategoryCode=1),0) As ServicesTotal From PatientInfoView


go

