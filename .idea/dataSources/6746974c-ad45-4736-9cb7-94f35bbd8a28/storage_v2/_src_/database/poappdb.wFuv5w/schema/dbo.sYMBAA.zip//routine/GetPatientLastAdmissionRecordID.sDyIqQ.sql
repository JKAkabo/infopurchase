

CREATE FUNCTION [dbo].[GetPatientLastAdmissionRecordID]

(@OPDNo AS NVARCHAR(15),@RecordID Numeric(18,0)) RETURNS Numeric(18,0)

AS

BEGIN

Declare @AdmissionRecordID Numeric(18,0)=0,@OldAdmRecordID Numeric(18,0)=0,@NewAdmRecordID Numeric(18,0),@admDate date

Select Top 1 @OldAdmRecordID=IsNull(OldAdmRecordID,0), @admDate=AdmDate, @NewAdmRecordID=IsNull(NewAdmRecordID,0) From Admissions Inner Join WardTransfers On Admissions.RecordID=OldAdmRecordID Where Admissions.OPDNo=@OPDNo And Admissions.Archived='No' And oldAdmRecordID=@RecordID Order By OldAdmRecordID Desc, NewAdmRecordID Desc, AdmDate Desc
If @@rowcount<=0
   Select Top 1 @AdmissionRecordID=IsNull(RecordID,0) From Admissions Where Admissions.OPDNo=@OPDNo And Admissions.Archived='No' And RecordID=@RecordID 

else
   BEGIN
      Set @AdmissionRecordID=@NewAdmRecordID
      
      While  @NewAdmRecordID<>0
      
       BEGIN
          
          Select Top 1 @OldAdmRecordID=IsNull(OldAdmRecordID,0), @NewAdmRecordID=IsNull(NewAdmRecordID,0),@admDate=AdmDate From Admissions Inner Join WardTransfers On Admissions.RecordID=OldAdmRecordID Where Admissions.OPDNo=@OPDNo And Admissions.Archived='No' And oldAdmRecordID=@NewAdmRecordID  Order By OldAdmRecordID, NewAdmRecordID, AdmDate
          
          if @@rowcount>0
             Set @AdmissionRecordID=IsNull(@NewAdmRecordID,0)     
               
          else
          
            set @NewAdmRecordID=0
          
       END
   
   END
   
   
RETURN @AdmissionRecordID

END



go

