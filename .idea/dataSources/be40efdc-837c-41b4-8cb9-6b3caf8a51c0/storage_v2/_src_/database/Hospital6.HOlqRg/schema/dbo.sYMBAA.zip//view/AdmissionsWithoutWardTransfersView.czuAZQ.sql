


CREATE VIEW [dbo].[AdmissionsWithoutWardTransfersView]
AS

SELECT DischargeStatusCode, DoctorID, Admissions.AdmAge, Admissions.DisAge ,Admissions.BedNo, BedType, Admissions.DisAuthouriser As DisDoctor , Admissions.OPDNo, Pat_No, ClinicCode, 
AdmDate, AdmTime, WardID, DisDate, DisTime, PatCategoryCode,RecordID,Discharged  FROM dbo.Admissions where Transfered='No' And Admissions.Archived='No' and 
RecordID Not In (Select Distinct RecordID from WardTransfersIDsView)



go

