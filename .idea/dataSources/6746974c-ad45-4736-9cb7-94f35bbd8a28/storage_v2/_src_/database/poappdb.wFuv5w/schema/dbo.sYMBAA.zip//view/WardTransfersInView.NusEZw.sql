CREATE VIEW [dbo].[WardTransfersInView]
AS

SELECT  RecordID, Admissions.OPDNo, Pat_No, ClinicCode, 3 As PatStatus, AdmDate As FromDate, DisDate As ToDate, DischargeStatusCode as OutCome
FROM    dbo.Admissions Inner Join WardTransfers on RecordID=NewAdmRecordID where Admissions.Archived='No' and Transfered='No' and WardTransfers.Archived='No'
go

