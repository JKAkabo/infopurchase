


CREATE FUNCTION [dbo].[GetWardRealBedsNo]

(@WardID AS NVARCHAR(15)) RETURNS numeric(18,0)

AS


BEGIN

Declare @RealBedsNo Numeric(18,0)

Select @RealBedsNo=IsNull(Count(BedNo),0) from Wards Inner Join Beds On Wards.WardID=Beds.WardID Where Wards.WardID=@WardID and BedType='REAL'

RETURN @RealBedsNo;

END



go

