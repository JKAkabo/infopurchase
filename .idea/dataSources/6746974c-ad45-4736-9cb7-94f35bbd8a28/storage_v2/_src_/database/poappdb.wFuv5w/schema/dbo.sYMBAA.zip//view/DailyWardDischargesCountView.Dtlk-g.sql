CREATE VIEW [dbo].[DailyWardDischargesCountView]
AS

SELECT  Isnull(Count(OPDNo),0) As DisCount, DisDate As AdmDate, WardID From AllAdmissionsView
 where RecordSerialNo=3  Group By WardID, DisDate
go

