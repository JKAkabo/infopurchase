CREATE VIEW [dbo].[WardsView]

AS

SELECT  Description, Code, GenderCode, AgeGroupCode,InitialBedState,WardType,NoOfBeds,SetupDate,RBTotal,VBTotal,ARBTotal,AVBTotal FROM Wards inner join Service_Places on WardID=Code Where Status='Yes'
go

