CREATE VIEW [dbo].[QBPostingActivityTypesView]

AS

SELECT PostMsg, RecordID As ActivityID, TypeID, 1 As DebitPostCode,  2 As CreditPostCode, Description, DebitAcctCatID, DebitAcctSubCatID, DebitAccoutNo, DebitAcctQuery, CreditAcctCatID, CreditAcctSubCatID, CreditAccoutNo, CreditAcctQuery,
(Select Description From AccountPostingType Where Code=1) As DebitPostDesc,(Select Description From AccountPostingType Where Code=2) As CreditPostDesc,(Select TOP 1 TypeID From AccountCategories Where ID=DebitAcctCatID) As DebitTypeID 
,(Select TOP 1 TypeID From AccountCategories Where ID=CreditAcctCatID) As CreditTypeID, (Select TOP 1 AccountTypes.Description From AccountTypes Inner Join AccountCategories On AccountTypes.ID=TypeID Where AccountCategories.ID=DebitAcctCatID) As DebitTypeDesc,
 (Select TOP 1 AccountTypes.Description From AccountTypes Inner Join AccountCategories On AccountTypes.ID=TypeID Where AccountCategories.ID=CreditAcctCatID) As CreditTypeDesc,GroupCode FROM AccountQBPostingActivity Where IsActive='Yes'
go

