CREATE VIEW [dbo].[AnesthesiaTypesView]

AS

SELECT Description, Code FROM dbo.AnesthesiaPlans

Union

Select '' As Description, 0 as Code from Hosp_Info
go

