--SET ANSI_PADDING ON
--SET ANSI_WARNINGS ON
--SET CONCAT_NULL_YIELDS_NULL ON
--SET NUMERIC_ROUNDABORT OFF
--SET QUOTED_IDENTIFIER ON
--SET ARITHABORT ON
--SET ANSI_NULLS ON

--GO

CREATE VIEW [dbo].[IntakeFluidsView] 

AS

SELECT Distinct left(dbo.Items.Description,100) As Description, dbo.Items.ItemID, 'DRUG' As Type, Disabled  FROM dbo.Items Where dbo.Items.ItemID<>'' 

UNION

SELECT Distinct left(dbo.NonDrugFluidsSetup.Description,100) As Description, Convert(Nvarchar(15),dbo.NonDrugFluidsSetup.ID), 'NON-DRUG' As Type, IsActive  FROM dbo.NonDrugFluidsSetup
go

