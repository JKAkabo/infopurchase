

CREATE VIEW [dbo].[DailyWardRemainedPreviousNightCountView]
AS

SELECT  DailyWardAdmissionsCountView.AdmCount, DailyWardDischargesCountView.DisCount, DailyWardAdmissionsCountView.WardID,DailyWardAdmissionsCountView.AdmDate, DailyWardDischargesCountView.AdmDate As DisDate From DailyWardAdmissionsCountView 
 inner Join DailyWardDischargesCountView On DailyWardAdmissionsCountView.WardID=DailyWardDischargesCountView.WardID 
 
 --DailyWardAdmissionsCountView.AdmDate , DailyWardDischargesCountView.AdmDate
 -- where  ((SetupDate Is Not Null And SetupDate<DailyWardAdmissionsCountView.AdmDate And SetupDate<DailyWardDischargesCountView.AdmDate) OR SetupDate Is Null)


go

