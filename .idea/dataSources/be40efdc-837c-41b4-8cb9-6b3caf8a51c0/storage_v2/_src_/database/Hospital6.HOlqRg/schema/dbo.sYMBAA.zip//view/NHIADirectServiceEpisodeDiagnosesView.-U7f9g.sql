
CREATE VIEW [dbo].[NHIADirectServiceEpisodeDiagnosesView]

AS

SELECT Distinct Left(Diseases.DisDescription,100) As DisDescription, DisCode , PmtTypeCode, ReqDate, IsNull(Diseases.ICDCode,'') As ICDCOde, Service_Requests.EpisodeID, Service_Requests.OPDNo, ServiceDate, Service_Requests.DirectID, Service_Requests.SponsorNo, IsNull(GDRGCodeA,'') As GDRGCodeA,IsNull(GDRGCodeC,'') As GDRGCodeC, PmtType, Service_Requests.ReqTime, Diseases.MainDiseaseCode As MDiscode FROM Diseases Inner Join (Service_Requests Inner Join PatientLabSpecimens On  Service_Requests.RecordID=ReqID) On Diseases.DisCode=DiseaseCode Where Service_Requests.EpisodeID<>0 and Service_Requests.Archived='No' and PatientLabSpecimens.Archived='No' and BillCategoryCode IN (4,11) and AttType=2 and RequestType='INTERNAL' and PmtTypeCode=2 and Diseases.ICDCode<>'' and Diseases.ICDCode Is Not Null

Union

SELECT Distinct Left(Diseases.DisDescription,100) As DisDescription, DisCode , PmtTypeCode, Service_Requests.ReqDate, IsNull(Diseases.ICDCode,'') As ICDCOde, Service_Requests.EpisodeID, Service_Requests.OPDNo, ServiceDate, Service_Requests.DirectID, Service_Requests.SponsorNo, IsNull(GDRGCodeA,'') As GDRGCodeA,IsNull(GDRGCodeC,'') As GDRGCodeC,PmtType, Service_Requests.ReqTime, Diseases.MainDiseaseCode As MDiscode FROM Diseases Inner Join (Service_Requests Inner Join XrayTests On  Service_Requests.RecordID=XrayTests.RecordID) On Diseases.DisCode=DiseaseCode Where Service_Requests.EpisodeID<>0 and Service_Requests.Archived='No' and XrayTests.Archived='No' and BillCategoryCode IN (4,11) and AttType=2 and RequestType='INTERNAL' and PmtTypeCode=2 and Diseases.ICDCode<>'' and Diseases.ICDCode Is Not Null

Union

SELECT Distinct Left(Diseases.DisDescription,100) As DisDescription, DisCode , PmtTypeCode, Service_Requests.ReqDate, IsNull(Diseases.ICDCode,'') As ICDCOde, Service_Requests.EpisodeID, Service_Requests.OPDNo, ServiceDate, Service_Requests.DirectID, Service_Requests.SponsorNo, IsNull(GDRGCodeA,'') As GDRGCodeA,IsNull(GDRGCodeC,'') As GDRGCodeC,PmtType, Service_Requests.ReqTime, Diseases.MainDiseaseCode As MDiscode FROM Diseases Inner Join (Service_Requests Inner Join UltrasoundScan On  Service_Requests.RecordID=UltrasoundScan.RecordID) On Diseases.DisCode=DiseaseCode Where Service_Requests.EpisodeID<>0 and Service_Requests.Archived='No' and UltrasoundScan.Archived='No' and BillCategoryCode IN (4,11) and AttType=2 and RequestType='INTERNAL' and PmtTypeCode=2 and Diseases.ICDCode<>'' and Diseases.ICDCode Is Not Null

go

