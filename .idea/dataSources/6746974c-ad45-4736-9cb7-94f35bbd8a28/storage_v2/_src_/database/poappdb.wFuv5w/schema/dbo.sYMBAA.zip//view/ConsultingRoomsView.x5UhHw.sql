CREATE VIEW [dbo].[ConsultingRoomsView]

AS

SELECT Description, Code, IsActive FROM dbo.ConsultingRooms

Union

Select '' As Description, 0 as Code,'No' from Hosp_Info
go

