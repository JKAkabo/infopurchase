CREATE VIEW [dbo].[PatientsDiagnosesView]

AS

SELECT Distinct Doctor, Consultations.ConDate As AttDate, Consultations.ConTime As AttTime, DisDescription, ClinicCode, 2 as PatStatus, Consultations.OPDNo, ConsultationTypes.Description As ConType, ConsultationDiagnoses.DiaType, ConOutCome, Consultations.DoctorRemarks, isnUll(Diseases.ICDCode,'') AS ICDCode,'OUT' AS RecType, Diseases.DisCode As DiagnosisCode, ConsultationDiagnoses.DiaManagement, Principal, DiaCatID, DiaOutcome FROM ConsultationTypes Inner Join (Consultations Inner Join  (Diseases Inner Join ConsultationDiagnoses On Diseases.DisCode=ConsultationDiagnoses.DisCode) On Consultations.ConID=ConsultationDiagnoses.ConID) On ConsultationTypes.Code=Consultations.ConType Where Consultations.Archived='No' and Cancelled='No'

Union

SELECT Distinct A.Doctor, A.AdmDate As AttDate, A.AdmTime As AttTime, DisDescription, ClinicCode, 3 as PatStatus,I.OPDNo, 'NEW' As ConType, DiaType, DischargeStatusCode As ConOutCome, DoctorRemarks, isnUll(Diseases.ICDCode,'') AS ICDCode,'IN' AS RecType, Diseases.DisCode As DiagnosisCode, DiaManagement, Principal, DiaCatID, DiaOutcome FROM InPatientConsultations I, Diseases, AdmissionCauses A, admissions where Diseases.DisCode=A.DisCode And Admissions.OPDNo=A.OPDNo And Admissions.RecordID=A.AdmRecordID and I.AdmID=Admissions.RecordID And Admissions.Archived='No' and Cancelled='No' 

union

SELECT Distinct Referrals.ReferredDoctorID As Doctor, Referrals.RefDate As AttDate, Referrals.RefTime As AttTime, DisDescription, Referrals.ReferredClinicID As ClinicCode, Referrals.StatusCode as PatStatus, Referrals.OPDNo, 'NEW' As ConType, 1 As DiaType, 1 As ConOutCome,'' As DoctorRemarks, isnUll(Diseases.ICDCode,'') AS ICDCode,'REF' AS RecType, Diseases.DisCode As DiagnosisCode,DiaManagement, Principal, DiaCatID, DiaOutcome FROM Referrals Inner Join  (Diseases Inner Join ReferralCauses On Diseases.DisCode=ReferralCauses.DisCode) On Referrals.RecordID=ReferralCauses.RefID where Referrals.Archived='No' and RefType IN (11,12) and Cancelled='No'

union

SELECT Distinct Deaths.DoctorID As Doctor, Deaths.DeathDate As AttDate, Deaths.DeathTime As AttTime, DisDescription, Deaths.ClinicCode As ClinicCode, Deaths.StatusCode as PatStatus, Deaths.OPDNo, 'NEW' As ConType, 1 As DiaType, 1 As ConOutCome,'' As DoctorRemarks, isnUll(Diseases.ICDCode,'') AS ICDCode,'DEA' AS RecType, Diseases.DisCode As DiagnosisCode, DiaManagement, Principal, DiaCatID, DiaOutcome FROM Deaths Inner Join  (Diseases Inner Join DeathCauses On Diseases.DisCode=DeathCauses.DisCode) On Deaths.OPDNo=DeathCauses.OPDNo where Deaths.Archived='No' and DiedInHospital='No' and Cancelled='No'
go

