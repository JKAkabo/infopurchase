CREATE PROCEDURE [dbo].[uspGenerateInPatientMortalityReportData] 

	@WardID nvarchar(15)='',@frmDate datetime,@toDate datetime,@user_ID nvarchar(10),@ReportDate datetime
	
AS

DECLARE @Specialty nvarchar(15),@RecordID numeric(18,0),@OPDNo nvarchar(15),@PatGender nvarchar(15),@PatInsured nvarchar(3),@TreatmentCost numeric(18,4),@PatAge int,@admDate datetime,@DisDate datetime,@PatWardID nvarchar(250);

DECLARE @PDiagnosis nvarchar(max),@ADiagnosis nvarchar(max),@SProcedure nvarchar(max),@PatOccupation nvarchar(100),@PatName nvarchar(250),@PatEducation nvarchar(100),@DischargedOutcome nvarchar(250),@ActualAdmDate datetime;

DECLARE @BillCategoryCode tinyint,@EpisodeID numeric(18,0),@Pat_No nvarchar(15),@SurName nvarchar(100),@MiddleName nvarchar(100),@FirstName nvarchar(100),@TDOB nvarchar(100), @PatAddress nvarchar(max);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
 
 Delete From GHSInPatientMortalityMorbidityData Where FromDate>=@frmDate And FromDate<=@toDate

 if @WardID='' 
	   DECLARE DischargedRecords CURSOR FAST_FORWARD FOR SELECT A.BillCategoryCode, A.OPDNo, DisAge AS patAge, AdmDate, DisDate,DisRecID AS RecordID, EpisodeID, Pat_No, SurName, LastName, MiddleName, TDOB, EducationLevel, A.Insured, ConsultationOutComesSetup.Description As DischargeStatus, OccupationsView.Description As OccupDesc, EducationalLevelsView.Description As EducDesc, UPPER(GenderGroups.Description) As Gender, UPPER(ServicePlacesView.Description) As ServicePlace From ConsultationOutComesSetup inner join (ServicePlacesView Inner Join 
	   (GenderGroups Inner Join (EducationalLevelsView Inner Join (OccupationsView Inner Join (PatientsInfo inner Join AdmissionDischrgesView A On PatientsInfo.OPDNo=A.OPDNo) On OccupationsView.Code=OccupationID) On EducationalLevelsView.ID=EducationLevel) On GenderGroups.Code=GenderCode) On (ServicePlacesView.Code=WardID Or ServicePlacesView.Code=DisWardID)) On ConsultationOutComesSetup.Code=DischargeStatusCode Where DisDate >= @frmDate And DisDate <= @toDate 
 else
	   DECLARE DischargedRecords CURSOR FAST_FORWARD FOR SELECT A.BillCategoryCode, A.OPDNo, DisAge AS patAge, AdmDate, DisDate, DisRecID AS RecordID, EpisodeID, Pat_No, SurName, LastName, MiddleName, TDOB, EducationLevel, A.Insured, ConsultationOutComesSetup.Description As DischargeStatus, OccupationsView.Description As OccupDesc, EducationalLevelsView.Description As EducDesc, UPPER(GenderGroups.Description) As Gender, UPPER(ServicePlacesView.Description) As ServicePlace From ConsultationOutComesSetup Inner Join (ServicePlacesView Inner Join 
	   (GenderGroups Inner Join (EducationalLevelsView Inner Join (OccupationsView Inner Join (PatientsInfo inner Join AdmissionDischrgesView A On PatientsInfo.OPDNo=A.OPDNo) On OccupationsView.Code=OccupationID) On EducationalLevelsView.ID=EducationLevel) On GenderGroups.Code=GenderCode) On (ServicePlacesView.Code=WardID Or ServicePlacesView.Code=DisWardID)) On ConsultationOutComesSetup.Code=DischargeStatusCode Where DisDate >= @frmDate And DisDate <= @toDate And (WardID=@WardID OR DisWardID=@WardID)

 OPEN DischargedRecords

 FETCH NEXT FROM DischargedRecords INTO @BillCategoryCode,@OPDNo,@PatAge,@admDate,@DisDate,@RecordID,@EpisodeID,@Pat_No, @SurName, @FirstName, @MiddleName, @TDOB, @PatEducation, @PatInsured, @DischargedOutcome,@PatOccupation,@PatEducation,@PatGender,@Specialty;

	WHILE @@fetch_status = 0

	  BEGIN 
	  	       
	       set @SProcedure=dbo.GetServicesRequested(@OPDNo,@admDate,@DisDate,3)
	       
	       set @PDiagnosis=dbo.GetPatientDiagnoses(@OPDNo,@admDate,@DisDate,'Yes')
	       
	       set @ADiagnosis=dbo.GetPatientDiagnoses(@OPDNo,@admDate,@DisDate,'No')
	       
	       set @TreatmentCost=dbo.GetPatientBill(@OPDNo,@admDate,@DisDate,@BillCategoryCode,3,@EpisodeID)
	       	       
	       set @PatAddress=dbo.GetPatientAddress(@OPDNo)
	       
	       if @MiddleName<>'' 
	      set @PatName=@FirstName + ' ' + @MiddleName + ' ' + @SurName
	          
	       else
	          set @PatName=@FirstName + ' ' + @SurName
	          
        Delete From GHSInPatientMortalityMorbidityData Where OPDNo=@OPDNo and AdmDate>=@admDate And DisDate<=@DisDate
        

		Insert into GHSInPatientMortalityMorbidityData(RecordID,PDiagnosis,ADiagnosis,SProcedure,Specialty,TreatmentCost,FromDate,ToDate,UserID,ReportDate,PatAddress,AdmDate,DisDate,PatAge,OPDNo,PatName,PatOccupation,PatEducation,PatInsured,DischargedOutcome,PatGender)values 
		(@RecordID, @PDiagnosis, @ADiagnosis,@SProcedure,@Specialty,@TreatmentCost, @frmDate, @toDate, @user_ID,@ReportDate,@PatAddress,@AdmDate,@DisDate,@PatAge,@Pat_No,@PatName,@PatOccupation,@PatEducation,@PatInsured,@DischargedOutcome,@PatGender)
      
         FETCH NEXT FROM DischargedRecords INTO @BillCategoryCode,@OPDNo,@PatAge,@admDate,@DisDate,@RecordID,@EpisodeID,@Pat_No, @SurName, @FirstName, @MiddleName, @TDOB, @PatEducation, @PatInsured, @DischargedOutcome,@PatOccupation,@PatEducation,@PatGender,@Specialty;

   END

	CLOSE DischargedRecords;

	DEALLOCATE DischargedRecords;

END
go

