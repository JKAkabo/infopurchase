
CREATE VIEW [dbo].[TransferedAdmissionsView]

AS

SELECT AdmDate, AdmTime, RecordID, a.OPDNo, Pat_No, WardID FROM Admissions A , WardTransfers W where A.OPDNo=W.OPDNo and A.RecordID=W.OldAdmRecordID and A.Archived='No' and Transfered='Yes' and NewAdmRecordID NoT IN (select OldAdmRecordID From WardTransfers where Archived='No')


go

