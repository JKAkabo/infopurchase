CREATE PROCEDURE [dbo].[uspUpdatePatientEyeExamsConsultationIDs] 
	
AS

DECLARE @OPDNo nvarchar(15),@VFResults nvarchar(max),@VAPlan nvarchar(max),
@VAPlan1 nvarchar(max),@ExamID numeric(18,0), @ConID numeric(18,0), @LensPresType tinyint;

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;

  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct C.ConID, E.RecordID, C.OPDNo, E.VFResults , LensPresType  From Consultations C, PatientEyeExams E, ClinicsView V 
where  C.OPDNo=E.OPDNo and C.Pat_No=E.Pat_No And (C.ConDate=E.ExamDate Or C.ReqDate=E.ReqDate) and C.ClinicCode=V.SPCode And V.Type=7 and C.Archived='No' Order by E.RecordID Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO @ConID, @ExamID, @OPDNo, @VFResults,@LensPresType;

  WHILE @@fetch_status = 0
    BEGIN       
       
	
	if @LensPresType=3 
	   set @LensPresType=4
       
    else if @LensPresType=4 
       set @LensPresType=3
       
    else if @LensPresType=0 
       begin
       
       set @LensPresType=2
       update PatientEyeExams Set LensPresType=@LensPresType Where RecordID=@ExamID 
       
       end
       update PatientEyeExamVA Set ExamID=@ConID Where ExamID=@ExamID 
       
       update PatientEyeExamPlans Set ExamID=@ConID Where ExamID=@ExamID
       
       update PatientEyeExams Set OucomeID=@LensPresType Where RecordID=@ExamID 

       update Consultations Set VFResults=@VFResults Where ConID=@ConID 
       
       Set @VAPlan1=''
       
	  DECLARE D CURSOR FAST_FORWARD FOR SELECT DISTINCT E.Description From PatientEyeExamPlans P, EyeExamPlans E Where E.Code=P.PlanID AND P.Archived='No' and ExamID=@ConID Order By E.Description
	  
	  OPEN D
	  
	  FETCH NEXT FROM D INTO @VAPlan;

	  WHILE @@fetch_status = 0
		BEGIN
           
           Set @VAPlan1=@VAPlan1 + ',' + @VAPlan

	              
		   FETCH NEXT FROM D INTO @VAPlan;

		END
	    
		CLOSE D;

		DEALLOCATE D;       
       
       update Consultations Set EyeExamsPlans=@VAPlan1 Where ConID=@ConID

       FETCH NEXT FROM C INTO @ConID, @ExamID, @OPDNo, @VFResults,@LensPresType;

	END

	CLOSE C;
	
    DEALLOCATE C;
    
END
go

