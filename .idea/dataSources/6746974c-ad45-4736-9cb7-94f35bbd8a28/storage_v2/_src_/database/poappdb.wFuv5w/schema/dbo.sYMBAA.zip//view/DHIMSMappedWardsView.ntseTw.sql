CREATE VIEW [dbo].[DHIMSMappedWardsView]

AS

SELECT  upper (WardTypesView.Description) DHIMSWard, DHIMSMappedDataElementsView.ElementID, HAMSCode ,MappedCode, ParameterID, WardTypesView.GenderCode As WardGender  FROM WardTypesView Inner Join ( DHIMSMappedDataElementsView inner join DHIMS_MAPPED_BEDS_UTILIZATION_PARAMETERS  On HAMSCode=DHIMS_MAPPED_BEDS_UTILIZATION_PARAMETERS.ElementID) ON WardTypesView.Code=MappedCode
go

