CREATE VIEW [dbo].[QBCombinedPostingActivityTypesView]

AS

SELECT CombinedAccountQBPostingActivity.Description,CombinedAccountQBPostingActivity.code ,IncludeAcctCategoy,AccountQBPostingActivity.RecordID ,GroupCode  FROM AccountQBPostingActivity Inner Join CombinedAccountQBPostingActivity on AccountQBPostingActivity.GroupCode=CombinedAccountQBPostingActivity.Code  Where AccountQBPostingActivity.IsActive='Yes'
go

