CREATE VIEW [dbo].[AllSystemicEnquiriesView]

AS

SELECT Distinct LTRIM(LTRIM(Complaints)) AS Complaints,  LTRIM(LTRIM(MedHistory)) As MedHistory , RTRIM(LTRIM(SysEnquiry)) AS SysEnquiry, Consultations.Doctor, Consultations.OPDNo, Consultations.Pat_No, ClinicCode, 2 As PatStatus, Consultations.ConDate As AttDate, Consultations.ConTime As AttTime, Consultations.ConID As RecordID, RecordID As EnqID, ConsultationEnquiriesComplaints.UserID
FROM Consultations Inner Join ConsultationEnquiriesComplaints on Consultations.ConID=ConsultationEnquiriesComplaints.ConID  Where Cancelled='No' and Archived='No' 

Union ALL

SELECT Distinct  LTRIM(LTRIM(Complaints)) AS Complaints, LTRIM(LTRIM(MedHistory)) AS MedHistory, LTRIM(LTRIM(SysEnquiry)) AS SysEnquiry, I.Doctor, I.OPDNo, I.Pat_No, A.ClinicCode, 3 As PatStatus, I.ConDate As AttDate, I.ConTime As AttTime, I.RecordID, P.RecordID As EnqID, P.UserID
FROM InPatientConsultations I, InPatientEnquiriesComplaints P, Admissions A  Where I.AdmID=A.RecordID And I.OPDNo=A.OPDNo And I.AdmID=P.AdmID And I.ServerTime=P.ServerTime And Cancelled='No' and I.Archived='No' -- and (Isnumeric(Complaints)=0 or Isnumeric(MedHistory)=0 or Isnumeric(SysEnquiry)=0)


--SELECT  Complaints, MedHistory, SysEnquiry, Admissions.DoctorID As Doctor, Admissions.OPDNo, Admissions.Pat_No, ClinicCode, 3 As PatStatus, Admissions.AdmDate As AttDate, Admissions.AdmTime As AttTime, Admissions.RecordID, InPatientEnquiriesComplaints.RecordID As EnqID, InPatientEnquiriesComplaints.UserID
--FROM Admissions Inner Join InPatientEnquiriesComplaints on Admissions.RecordID=InPatientEnquiriesComplaints.AdmID Where Cancelled='No' and Archived='No' -- and (Isnumeric(Complaints)=0 or Isnumeric(MedHistory)=0 or Isnumeric(SysEnquiry)=0)
go

