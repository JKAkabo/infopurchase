CREATE VIEW [dbo].InventoryApprovalLevelsView

AS

SELECT  Description, Code FROM dbo.ApprovalLevels

Union

SELECT  '' As Description, 0 As Code FROM dbo.Hosp_Info
go

