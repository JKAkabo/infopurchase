-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[uspGetPatientBasicInfo]
	-- Add the parameters for the stored procedure here
	@pType nvarchar(3), @opd_No nvarchar(15), @patID nvarchar(15)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	If @pType = 'P' 
       Select PatientsInfo.*,PatNo from PatientsInfo Inner Join OPD_Nos On PatientsInfo.Opdno = OPD_Nos.Opdno where PatNo = @opd_No And Terminated='No'
   
    Else
       
       Select * from PatientsInfo where PatientsInfo.OPDNo =@patID And Terminated='No'


END
go

