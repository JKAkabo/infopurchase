



CREATE VIEW [dbo].[PaymentTypessView]

AS

SELECT Distinct upper(Description) As Description, Code FROM dbo.PaymentTypes

Union

SELECT  '' As Description, 0 As Code FROM dbo.Hosp_Info



go

