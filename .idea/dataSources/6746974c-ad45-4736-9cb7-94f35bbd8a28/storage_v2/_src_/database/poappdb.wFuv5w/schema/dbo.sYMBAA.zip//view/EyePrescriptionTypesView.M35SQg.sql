CREATE VIEW [dbo].[EyePrescriptionTypesView]

AS

Select Code, Description, IsActive  From EyePrescriptionTypes 

Union ALL

Select TOP 1 0, '' , 'No' From Hosp_Info
go

