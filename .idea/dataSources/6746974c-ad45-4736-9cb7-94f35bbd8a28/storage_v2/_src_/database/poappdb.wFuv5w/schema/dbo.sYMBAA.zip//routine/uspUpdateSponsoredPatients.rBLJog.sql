CREATE PROCEDURE [dbo].[uspUpdateSponsoredPatients] 
	
AS

DECLARE @OPDNo nvarchar(15),@SponsorNo nvarchar(15),@regDate datetime,@regtime datetime,
        @patno nvarchar(15),@userid nvarchar(10),@SponsorType tinyint,@patCategory tinyint,
        @sPriority int,@pType nvarchar(50),@pNo nvarchar(25),@IDNo nvarchar(25),@HiNo nvarchar(25),
        @CommID nvarchar(25),@UnNo nvarchar(25),@pStatus nvarchar(25),@Bens nvarchar(50),
        @SchContact nvarchar(50),@Insured nvarchar(3),@dateFrom datetime,@DateTo datetime

BEGIN


Delete from SponsoredPatients

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct OPDNo,SponsoredPatients1.SponsorNo,RegDate,RegTime,Pat_No,SponsoredPatients1.UserID,sPriority,pType,pNo,IDNo,HiNo,CommID,UnNo,pStatus,Bens,SchContact,Insured,dateFrom,DateTo,SponsorTypeCode From Sponsors Inner Join SponsoredPatients1 On Sponsors.sponsorNo= SponsoredPatients1.SponsorNo Where SponsoredPatients1.Archived='No' Order by OPDNo
        
            
  OPEN C
  
  FETCH NEXT FROM C INTO @OPDNo,@SponsorNo,@RegDate,@RegTime,@PatNo,@UserID,@sPriority,@pType,@pNo,@IDNo,@HiNo,@CommID,@UnNo,@pStatus,@Bens,@SchContact,@Insured,@dateFrom,@DateTo,@SponsorType          

  WHILE @@fetch_status = 0
    BEGIN
       if @SponsorType=2
          set @patCategory=4

       else
          set @patCategory=2

       insert into SponsoredPatients (OPDNo,SponsorNo,RegDate,RegTime,Pat_No,UserID,sPriority,pType,pNo,IDNo,HiNo,CommID,UnNo,pStatus,Bens,SchContact,Insured,dateFrom,DateTo,patCategoryCode) Values 
       (@OPDNo,@SponsorNo,@RegDate,@RegTime,@PatNo,@UserID,@sPriority,@pType,@pNo,@IDNo,@HiNo,@CommID,@UnNo,@pStatus,@Bens,@SchContact,@Insured,@dateFrom,@DateTo,@patCategory)

       update PatientsInfo Set SponsorTypeCode= @SponsorType,PatCatID=@patCategory,PmtTypeCode=2,PmtModeCode=2,BillCategoryCode=@patCategory Where OPDNo=@OPDNo

       FETCH NEXT FROM C INTO @OPDNo,@SponsorNo,@RegDate,@RegTime,@PatNo,@UserID,@sPriority,@pType,@pNo,@IDNo,@HiNo,@CommID,@UnNo,@pStatus,@Bens,@SchContact,@Insured,@dateFrom,@DateTo,@SponsorType         

	END

	CLOSE C;

	DEALLOCATE C;

END
go

