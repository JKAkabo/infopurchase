
CREATE VIEW [dbo].[TestElementValuesView]

AS

SELECT Distinct LTypeID, UTypeID, AgeGroupValuesView.ageGroupCode,GenderCode,TestElementsValuesRatings.ElementID,TestElementsValuesRatings.LowerValue,TestElementsValuesRatings.UpperValue,TextTag,ColourTag,TestElementsValuesRatings.RecordID,RatingID ,LabTestElementRatingTypesViews.Description As RatingDesc, UnitMeasure, (TestElementsValuesRatings.LowerValue + ' - ' + TestElementsValuesRatings.UpperValue) AS ValueRange, TestElements.ResultValueType, AgeGroupValuesView.RecordID As AgeGroupID,ValDesc From TestElements Inner Join ( LabTestElementRatingTypesViews Inner Join (AgeGroupValuesView Inner Join TestElementsValuesRatings On AgeGroupValuesView.RecordID=TestElementsValuesRatings.AgeGroupCode) On LabTestElementRatingTypesViews.Code=RatingID) On TestElements.Code=TestElementsValuesRatings.ElementID Where  ResultValueType=1

Union

SELECT Distinct LTypeID, UTypeID, AgeGroupValuesView.ageGroupCode,GenderCode,TestElementsValuesRatings.ElementID,TestElementsValuesRatings.LowerValue,TestElementsValuesRatings.UpperValue,TextTag,ColourTag,TestElementsValuesRatings.RecordID,RatingID ,LabTestElementRatingTypesViews.Description As RatingDesc, UnitMeasure, (TestElementsValuesRatings.LowerValue + ' - ' + TestElementsValuesRatings.UpperValue) AS ValueRange, TestElements.ResultValueType, AgeGroupValuesView.RecordID As AgeGroupID,ValDesc From TestElements Inner Join ( LabTestElementRatingTypesViews Inner Join (AgeGroupValuesView Inner Join TestElementsValuesRatings On AgeGroupValuesView.RecordID=TestElementsValuesRatings.AgeGroupCode) On LabTestElementRatingTypesViews.Code=RatingID) On TestElements.Code=TestElementsValuesRatings.ElementID Where  ResultValueType=2


go

