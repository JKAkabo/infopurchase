
CREATE VIEW [dbo].[AccountsChartServiceMappingView]

AS

SELECT Distinct AccountChartCode, AccountTypeID,RecordID, AcctCode, A.CategoryID, ServiceTypeID, V.Description As ServiceDescription, ServiceID,V.AcctsDrugsMapID As AcctsMapType, C.Description As AcctDescription, SubCategoryID FROM AccountChartServicesMapping A, AccountMapTypesView V, AccountChatsView C Where A.ServiceID=V.ServiceMapID And AccountChartCode=C.Code And AcctCode=ID and A.AccountTypeID=C.TypeID  and A.CategoryID= C.CategoryID And ServiceTypeID=ServiceMapType


--SELECT Distinct AccountChartCode, AccountTypeID,RecordID, AcctCode, A.CategoryID, ServiceTypeID, V.Description As ServiceDescription, ServiceID,V.AcctsDrugsMapID As AcctsMapType FROM AccountChartServicesMapping A, AccountMapTypesView V Where A.ServiceID=V.ServiceMapID And ServiceTypeID=ServiceMapType


go

