CREATE VIEW [dbo].[AccountChatsView]

AS

SELECT AccountChartSetup.IsActive, AccountChartSetup.CategoryID, AccountChartSetup.Code,AccountChartSetup.Description,AccountChartSetup.ID,AccountChartSetup.SubCategoryID,
AccountChartSetup.Linkable,AccountChartSetup.LinkedServicesQuery,AccountTypesView.Description As TypeDescription, AccountSubCategoriesView.Description As SubCatDescription,AccountPostingType.Description As PostType, 
AccountCategoriesView.Description As CatDescription, CatLinkedServicesQuery, SubLinkedServicesQuery, AccountCategoriesView.TypeID, AccountChartSetup.AcctTypeID,QBAccountTypes.PostType As PostTypeID FROM 
AccountTypesView, AccountCategoriesView, AccountSubCategoriesView, AccountChartSetup, QBAccountTypes, AccountPostingType Where AccountChartSetup.AcctTypeID=AccountTypesView.ID
And AccountSubCategoriesView.ID= SubCategoryID And CategoryID=AccountCategoriesView.ID and QBAccountTypes.HamsTypeID = AccountChartSetup.AcctTypeID And AccountPostingType.Code=QBAccountTypes.PostType
go

