CREATE VIEW [dbo].[AccountClassView]
AS
SELECT     dbo.AccountClass.RecordID  As ClassID, dbo.AccountClass.Description, dbo.AccountClass.Code, dbo.AccountSubClass.Description AS SubClassDescription, 
                      dbo.AccountSubClass.Code AS SubClassCode, dbo.AccountSubClass.RecordID, 
                      dbo.AccountClass.Code + '-' + dbo.AccountClass.Description + ':' + dbo.AccountSubClass.Code + '-' + dbo.AccountSubClass.Description AS Overseer
FROM         dbo.AccountClass INNER  JOIN
                      dbo.AccountSubClass ON dbo.AccountClass.RecordID = dbo.AccountSubClass.ClassID
WHERE     (dbo.AccountClass.IsActive = N'Yes') AND (dbo.AccountSubClass.IsActive = N'Yes')
and  (dbo.AccountClass.Archived  = N'No') AND (dbo.AccountSubClass.Archived = N'No')

UNION ALL

SELECT     RecordID As ClassID, dbo.AccountClass.Description, dbo.AccountClass.Code, dbo.AccountClass.Description As SubClassDescription, 
                      dbo.AccountClass.Code AS SubClassCode,  RecordID, 
                      dbo.AccountClass.Code + '-' + dbo.AccountClass.Description  AS Overseer
FROM         dbo.AccountClass  
                     
WHERE     (dbo.AccountClass.IsActive = N'Yes') and  (dbo.AccountClass.Archived  = N'No') AND 
(AccountClass.RecordID NOT IN (SELECT ClassID From AccountSubClass))


UNION 

SELECT  TOP 1 0 As ClassID, '' AS Description, '' AS Code, '' As SubClassDescription, 
'' AS SubClassCode, 0 As RecordID,'' AS Overseer FROM dbo.hosp_info
go

