CREATE VIEW [dbo].[PregnancyPresentationView]

AS

SELECT  Description, Code FROM dbo.PregnancyPresentation

Union

SELECT  '', 0  FROM dbo.Hosp_Info
go

