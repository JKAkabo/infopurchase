
CREATE VIEW [dbo].[DHIMSLabsView]

AS

Select Convert(NVARCHAR(5),  PatientsInfo.GenderCode) As GenderCode, TestDate As AttDate, TDOB, LabTestResultsView.OPDNo, Convert(NVARCHAR(25),  ElementCode) As ElementCode, TestCode, LabTestResultsView.RatingDesc From PatientsInfo Inner Join LabTestResultsView On PatientsInfo.OPDNo=LabTestResultsView.OPDNo

go

