CREATE VIEW [dbo].[EyeLensTypesView]

AS

Select Code, Description  From EyeLensTypes 

Union ALL

Select TOP 1 0, ''  From Hosp_Info
go

