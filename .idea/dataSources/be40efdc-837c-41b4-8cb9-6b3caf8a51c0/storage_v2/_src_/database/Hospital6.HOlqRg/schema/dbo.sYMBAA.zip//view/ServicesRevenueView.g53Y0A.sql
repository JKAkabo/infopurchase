CREATE VIEW [dbo].[ServicesRevenueView]

AS

SELECT AttServiceID,BillCycleDuration,billMethodCode,PmtModeCode,episodeID,attType,episodeType,ItemCode As GDRG_Code,Issued,Description, DrugCode As ServiceCode, 1 As ServiceTypeCode, PmtTypeCode, StoresID As SerPlaceCode ,UnitPrice AS UnitFee, QtyPrescribed As RequestedQty, 
CASE WHEN QtyGiven<>0 and QtyGiven>QtyPrescribed THEN QtyPrescribed WHEN QtyGiven<>0 and QtyGiven<=QtyPrescribed THEN QtyGiven WHEN (ReturnedQty=0 and QtyGiven=0) THEN QtyPrescribed WHEN (ReturnedQty<>0 and QtyGiven=0) THEN 0  END As ServiceQty, Prescriptions.PresDate As ReqDate, Prescriptions.PresTime As Reqtime, PresType As RequestType, OPDNo, StatusCode, 
DirectID, '**' As CapID, ServerTime, Pat_No, ClinicCode, PatAge, BillCategoryCode, UserID, SponsorNo, 'No' As CoPayed, ReqDate As AttDate, RecordID,PaidQty,Prescriber As RequesterID, PaymentCode,exrate, AllSetUpServicesView.PmtType, ReceiptNo, PresAmt As ServiceAmt,
PresDate As ServiceDate, PresTime As ServiceTime FROM AllSetUpServicesView Inner Join Prescriptions On ItemID=DrugCode Where DrugFlag='0' and Archived='No' and PresType='INTERNAL' and ((ReturnedQty=0 and QtyGiven=0) Or QtyGiven<>0)

UNION ALL

SELECT AttServiceID,BillCycleDuration,billMethodCode,PmtModeCode,episodeID,attType,episodeType,GDRG_Code,Issued,Description, ServiceCode, ServiceTypeCode, PmtTypeCode, SerPlaceCode , Service_Fee,  ServiceQty, ServiceQty, ReqDate, ReqTime, RequestType, OPDNo, StatusCode, DirectID, '**' As CapID, ServerTime, Pat_No, ClinicCode, PatAge, BillCategoryCode,Service_Requests.UserID, SponsorNo, 'No' As CoPayed, ReqDate As AttDate, RecordID,PaidQty,RequesterID,PaymentCode,exrate, AllSetUpServicesView.PmtType, ReceiptNo, ServiceAmt,ReqDate,ReqDate  FROM AllSetUpServicesView Inner Join Service_Requests On ItemID=Service_Requests.ServiceCode Where Archived='No' And RequestType='INTERNAL'

UNION ALL

SELECT AttServiceID,CoPayBillCycleDuration,CoPayBillMethodCode,CoPayPmtModeCode,episodeID,attType,episodeType,GDRG_Code,Issued,Description, DrugCode As ServiceCode, 1 As ServiceTypeCode, CoPayPmtTypeCode, StoresID As SerPlaceCode , (CoPayFee - UnitPrice) AS UnitFee, QtyPrescribed As ServiceQty, 
CASE WHEN QtyGiven<>0 and QtyGiven>QtyPrescribed THEN QtyPrescribed WHEN QtyGiven<>0 and QtyGiven<=QtyPrescribed THEN QtyGiven WHEN (ReturnedQty=0 and QtyGiven=0) THEN QtyPrescribed WHEN (ReturnedQty<>0 and QtyGiven=0) THEN 0  END As ServiceQty, Prescriptions.PresDate As ReqDate, Prescriptions.PresTime As Reqtime, PresType As RequestType, 
OPDNo, StatusCode, DirectID, '**' As CapID, ServerTime, Pat_No, ClinicCode, PatAge, CoPayBillCategoryCode, UserID, CoPaySponsorNo, 'Yes' As CoPayed, ReqDate As AttDate, RecordID,PaidQty,Prescriber As RequesterID,PaymentCode,exrate, AllSetUpServicesView.PmtType, ReceiptNo, (CoPayAmt - PresAmt),PresDate,PresTime
FROM AllSetUpServicesView Inner Join Prescriptions On ItemID=DrugCode Where DrugFlag='0' and Archived='No' and CoPayBillCategoryCode<>0 and CoPayPmtTypeCode<>0  and CoPayFee>UnitPrice and PresType='INTERNAL'  and ((ReturnedQty=0 and QtyGiven=0) Or QtyGiven<>0)

UNION  ALL

SELECT AttServiceID,CoPayBillCycleDuration,CoPayBillMethodCode,CoPayPmtModeCode,episodeID,attType,episodeType,GDRG_Code,Issued,Description, ServiceCode, ServiceTypeCode, CoPayPmtTypeCode, SerPlaceCode , (CoPayFee - Service_Fee) AS Service_Fee,  ServiceQty, ServiceQty, ReqDate, ReqTime, RequestType, OPDNo, StatusCode, DirectID, '**' As CapID, ServerTime, Pat_No, ClinicCode, PatAge, CoPayBillCategoryCode,UserID, CoPaySponsorNo, 'Yes' As CoPayed, ReqDate As AttDate, RecordID,PaidQty,RequesterID,PaymentCode,exrate, AllSetUpServicesView.PmtType, ReceiptNo, (CoPayAmt-ServiceAmt),ReqDate,ReqTime  FROM AllSetUpServicesView Inner Join Service_Requests On ItemID=Service_Requests.ServiceCode Where Archived='No' And RequestType='INTERNAL' and CoPayBillCategoryCode<>0 and CoPayPmtTypeCode<>0  and CoPayFee>Service_Fee
go

