

CREATE VIEW [dbo].[DHIMSMappedDataElementsView]

AS

SELECT  DHIMSDataElements.HAMSCode, DHIMSDataElements.ElementID, DHIMSDataElements.DataSetID, Description, PatientType, GenderCode, AgeGroupCode, HamsDesc,
ElementOrder AS OrderNo, CategoryCode, AgeRangeCode, ServiceTypeID,IsDummy, DHIMS_MAPPED_ELEMENTS.HamsCode As MappedCode,SummaryType,BaseCountOn,CaseType, MapType FROM 
DHIMSDataElements inner join DHIMS_MAPPED_ELEMENTS On DHIMSDataElements.HAMSCode=DHIMS_MAPPED_ELEMENTS.ElementID  Where IsActive='Yes'



go

