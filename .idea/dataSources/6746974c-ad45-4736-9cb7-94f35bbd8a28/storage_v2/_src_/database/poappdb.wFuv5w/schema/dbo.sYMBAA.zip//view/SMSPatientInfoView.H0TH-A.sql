CREATE VIEW [dbo].[SMSPatientInfoView]

AS

Select OPDNo, LastName,  MiddleName,  Surname, GenderGroups.Description As Gender, Title, GenderCode, CONVERT(Date, TDOB) AS DOB, StatusCode, ExpiryAlert,ReligionID,left(Nationality,100) As Nationality,PatCatID,BillCategoryCode,PBOut,OccupationID,HomeRegionID,HomeDistrictID,HomeTownID,MarritalStatus,LEFT(HomeStreet,100) As HomeStreet,PatPhoto,left(EmailAddrs,100) as EmailAddrs,
CASE WHEN (LEN(RTRIM(ltrim(CellPhoneNo)))=10 OR ((LEN(RTRIM(ltrim(CellPhoneNo)))=13 OR LEN(RTRIM(ltrim(CellPhoneNo)))=12) And LEFT(RTRIM(ltrim(CellPhoneNo)),3)='233' )) THEN '233' + RIGHT(RTRIM(ltrim(CellPhoneNo)),9) WHEN LEN(RTRIM(ltrim(CellPhoneNo)))=13 THEN  RTRIM(ltrim(CellPhoneNo)) ELSE '' END As CellPhoneNo,IDType,IDNo,langPreferred,EducationLevel
From GenderGroups Inner Join PatientsInfo On GenderGroups.Code=PatientsInfo.GenderCode
where Upper(Terminated)='NO' And Upper(Died)='NO' And Rtrim(Ltrim(CellPhoneNo))<>'' And CellPhoneNo Is Not Null And (Len(Rtrim(Ltrim(CellPhoneNo)))=10 Or Len(Rtrim(Ltrim(CellPhoneNo)))=12 Or Len(Rtrim(Ltrim(CellPhoneNo)))=13)
go

