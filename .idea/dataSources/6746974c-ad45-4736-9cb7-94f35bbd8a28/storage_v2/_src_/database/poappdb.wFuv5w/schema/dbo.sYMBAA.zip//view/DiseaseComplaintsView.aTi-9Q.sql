create VIEW [dbo].[DiseaseComplaintsView]

AS

SELECT Distinct Diseases.*, Complaints.Description, Complaints.CompID FROM dbo.Diseases Inner Join (Complaints Inner Join DiseaseComplaints On Complaints.CompID=DiseaseComplaints.CompID) On Diseases.DisCode=DiseaseComplaints.DisCode Where Diseases.Disabled='No' And Complaints.Disabled='No'
go

