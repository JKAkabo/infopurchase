CREATE PROCEDURE [dbo].[uspUpdateArchivedFolders] 
	
AS

DECLARE @OPDNo nvarchar(15),@patno nvarchar(15)

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct OPD_Nos.OPDNo,PatNo From OPD_Nos Inner Join PatientArchivedFolderLines On OPD_Nos.PatNo = PatientArchivedFolderLines.Pat_No Order by OPD_Nos.OPDNo
            
  OPEN C
  
  FETCH NEXT FROM C INTO @OPDNo,@PatNo        

  WHILE @@fetch_status = 0
    BEGIN

   update PatientArchivedFolderLines set OPDNo=@OPDNo Where Pat_No=@patno
   
  FETCH NEXT FROM C INTO @OPDNo,@PatNo        

	END

	CLOSE C;

	DEALLOCATE C;

END
go

