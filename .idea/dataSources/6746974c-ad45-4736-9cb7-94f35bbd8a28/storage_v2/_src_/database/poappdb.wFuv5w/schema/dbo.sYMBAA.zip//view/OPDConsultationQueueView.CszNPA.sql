CREATE VIEW [dbo].[OPDConsultationQueueView]

AS

SELECT  ReqTime, S.OPDNo, Pat_No, A.Description, ClinicCode, IsNull((Select UserNo From UsersView Where UserNo= RequesterID and UserCategory IN 
('DOCTORS','MEDICAL ASSISTANTS','PHYSICIAN ASSISTANTS','MEDICAL ASSISTANT','PHYSICIAN ASSISTANT','LOCUM DOCTORS','MIDWIVES')),'') As DoctorID, S.RecordID, 
0 As ConsulRoomID, Gender, DOB, Surname, MiddleName, LastName, Weight, PatAge, CASE WHEN C.QueueTimeBasedOn='SERVICE REQUEST' THEN 1 ELSE 2 END AS OrderNo,  
IsNull((Select TOP 1 Description From PatientCategoryTypes Where Code=S.BillCategoryCode),'') As PatientCategory, S.UserID,'REQ' AS RecType, 1 As ConState 
From Service_Requests S, AllSetUpServicesView A, PatientInfoView, ClinicsView C where ServiceCode=ItemID and PatientInfoView.StatusCode=2 And PatientInfoView.PatientID=S.OPDNo And PatientInfoView.OPDNo=S.Pat_No
And C.SPCode=S.ClinicCode And S.Archived='No' and ServiceTypeCode=5 And S.Issued='No'  and S.ReqDate=CONVERT(Date,Getdate()) and S.OPDNo + CONVERT(NVARCHAR(25),reqDate) NOT IN 
(Select P.OPDNo + CONVERT(NVARCHAR(25),P.RegDate) From PatientConsultingRoomAssignments P Where P.Archived='No')

UNION ALL

SELECT Distinct S.RegTime, S.OPDNo, S.Pat_No, IsNull((Select TOP 1 P.ServiceDescription From ServiceRequestsView P Where  P.Archived='No' And S.OPDNo=P.OPDNo And S.RegDate=P.ReqDate and ServiceTypeCode=5 Order By P.ReqTime),''),
S.ClinicCode, S.DoctorID, S.RecordID, ConRoomID, Gender, DOB, Surname, MiddleName, LastName, Weight, S.PatAge, 2, PatientCategory, S.UserID,'VIT', ConState From 
PatientConsultingRoomAssignments S, PatientInfoView, ClinicsView C  where PatientInfoView.StatusCode=2 And PatientInfoView.PatientID=S.OPDNo And S.Archived='No' And C.SPCode=S.ClinicCode And C.QueueTimeBasedOn<>'SERVICE REQUEST'  And PatientInfoView.OPDNo=S.Pat_No  And C.QueueTimeBasedOn<>'' 
and ConState =1 and S.RegDate=CONVERT(Date,Getdate())  And S.OPDNo + CONVERT(NVARCHAR(25),S.RegDate) IN (Select P.OPDNo + CONVERT(NVARCHAR(25),P.ReqDate) From ServiceRequestsView P, ClinicsView D Where D.SPCode=P.ClinicCode And P.Archived='No' and ServiceTypeCode=5 And D.QueueTimeBasedOn<>'SERVICE REQUEST'  And D.QueueTimeBasedOn<>'')
go

