CREATE VIEW [dbo].[MentalStateElementAnswersView]

AS

SELECT V.ValueOrderNo, V.Description As Answer, V.ID  As AnswerID, V.IsActive As AnswerIsActive, ValueType, E.* 
FROM dbo.MentalStateElementsView E, MentalStateGroupElementValues V where V.ElementID=E.ElementID and E.IsActive='Yes'
go

