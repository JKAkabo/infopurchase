CREATE VIEW [dbo].[EyeExamTreatmentTypesView]

AS

Select Code, Description  From EyeExamsTreatmentTypes 

Union ALL

Select TOP 1 0, ''  From Hosp_Info
go

