



CREATE VIEW [dbo].[AgeGroupCategoriesView]

AS

SELECT Distinct Description, Code FROM dbo.AgeGroupCategories

Union

SELECT  '' As Description, 0 As Code FROM dbo.Hosp_Info



go

