CREATE VIEW [dbo].[AccountCategoriesView]

AS

SELECT  AccountCategories.Description, AccountCategories.Code, AccountCategories.ID, TypeID,AccountTypes.Description As TypeDescription, LinkedServicesQuery FROM AccountTypes Inner Join dbo.AccountCategories On AccountTypes.ID=TypeID Where Archived='No'

Union

SELECT  '' As Description, '' As Code,0 As ID,0 as TypeID, '' As TypeDesc, '' As LinkedServicesQuery FROM dbo.Hosp_Info
go

