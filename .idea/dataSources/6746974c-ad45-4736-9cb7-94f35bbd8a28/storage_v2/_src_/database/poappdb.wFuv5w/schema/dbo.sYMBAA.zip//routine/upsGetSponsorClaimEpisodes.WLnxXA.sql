-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[upsGetSponsorClaimEpisodes] 
	-- Add the parameters for the stored procedure here

	@SponsorNo nvarchar(15) ,@patStatus nvarchar(3),@epiEndDateFrom datetime,@epiEndDateTo datetime
	
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
 If @patStatus <> '' 
    Select  * From Episode Where SponsorNo=@SponsorNo And [Status]=@patStatus And EndEpisode>=@epiEndDateFrom And EndEpisode<=@epiEndDateTo Order By BeginEpisode Asc

Else
    Select  * From Episode Where SponsorNo=@SponsorNo And EndEpisode>=@epiEndDateFrom And EndEpisode<=@epiEndDateTo Order By BeginEpisode Asc




END
go

