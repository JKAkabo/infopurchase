

CREATE VIEW [dbo].[PurchaseOrdersApprovedPendingReceivalView]

AS

Select DISTINCT R.OrderType,I.Description As OrderStore,R.OrderStoreID,R.SupplierID,R.OrderDate,R.InvoiceNo,S.ContactName As Supplier, 
R.AwardNo, R.OrderID As PONo,R.Discount, R.LinesTotal, R.OrderComments, R.VAT, R.ProformaNo, R.OrderNo, R.TotalValue 
From ServicePlacesView I, PurchaseOrderApprovals A, OrderLines D, PurchaseOrderLines P, Orders R, Suppliers S  Where ((IssuedOrderQty<OrderQty)) and ((D.OrderQtyReceived<P.ApprovedQty)) 
and I.Code = R.OrderStoreID and S.SupplierID = R.SupplierID and A.ApproveID =P.ApproveID And D.OrderLineID = P.OrderLineID and R.OrderNo=D.OrderID and R.ApprovalStatus=R.ApprovalLevel and R.OrderNo=A.OrderNo And OrderLineStatus IN (1,2,14)
and A.ApprovalNo=R.ApprovalLevel and R.Archived='No' and A.Archived='No' and D.Archived='No' and P.Archived='No' and R.Archived='No' and R.OrderType=2


go

