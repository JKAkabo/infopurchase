CREATE VIEW [dbo].[AccountsChartSetUpServicesView]

AS

SELECT Distinct left(Description,100) As Description, ITEMS.ItemID, 1 As ServiceTypeCode, 2 As PmtType, OrderID As ServicePlaceCode , CashPrice AS CashFee, CreditPrice AS CreditFee, NGPrice AS NGFee,NHISPrice AS NHISFee, FFee, NHISCode as ItemCode, NHISCode as AdultCode, NHISCode as ChildCode,NHIS,'No' AS IsMorgue,1 As MinDay,1 As MaxDay, 6 As FeeFreq, Disabled, ItemTypeCode FROM ITEMS inner Join Packs on Items.ItemID=Packs.ItemID Where ITEMS.ItemID<>''  and Description<>''

UNION ALL

SELECT Distinct left(FeeType,100) As Description, FEEID, 6 As ServiceTypeCode, PmtType, MorID  As ServicePlaceCode, CashFee, CreditFee, NGFee, NHISFee, FFee, ServiceCode as ItemCode, ServiceCode as AdultCode, ServiceCode as ChildCode,NHIS,'Yes' AS IsMorgue,MinDay,MaxDay, PmtFreq,Disabled,0 as ItemTypeCode FROM MORTUARYFEES Where FEEID<>'' and FEETYPE<>''

UNION ALL

SELECT Distinct left(FeeType,100) As Description, FEEID, ServiceTypeCode,PmtType, WardID  As ServicePlaceCode,  CashFee, CreditFee, NGFee, NHISFee, FFee, ServiceCode as ItemCode, ServiceCode as AdultCode, ServiceCode as ChildCode,NHIS,'No' AS IsMorgue,1 As MinDay,1 As MaxDay, PmtFreq,Disabled,0 as ItemTypeCode FROM WARDFEES Where FEEID<>'' and FEETYPE<>''

UNION ALL

SELECT Distinct left(SERVICETYPE,100) As Description, SERVICECODE, ServiceTypeCode, PmtType, ServicePlaceCode ,CashPrice AS CashFee, CreditPrice AS CreditFee,  NGFee, NHISPrice As NHISFee, FFee, IsNull(Fee_Category,'') as ItemCode, ISNULL(GDRGCodeA,'') as AdultCode, ISNULL(GDRGCodeC,'') as ChildCode, NHIS,'No' AS IsMorgue,1 As MinDay,1 As MaxDay,6 As FeeFreq, Disabled,0 as ItemTypeCode FROM Service_Types Where SERVICECODE<>'' and SERVICETYPE<>''


UNION ALL

SELECT Distinct left(DisDescription,100) As Description, DisCode, 2 As ServiceTypeCode, PmtType, '' AS ServicePlaceCode ,0  AS CashFee, 0 AS CreditFee, 0 As NGFee, 0  As NHISFee, 0 As FFee, '' as ItemCode, ISNULL(GDRGCodeA,'') as AdultCode, ISNULL(GDRGCodeC,'') as ChildCode, NHIACovered As NHIS,'No' AS IsMorgue,1 As MinDay,1 As MaxDay,6 As FeeFreq,Disabled , 0 as ItemTypeCode FROM Diseases Where DisCode<>'' 


UNION ALL

SELECT TOP 1 '' As Description, '' As SERVICECODE, 4 As ServiceTypeCode, 2 As PmtType, '' As ServicePlaceCode ,0 AS CashFee, 0 AS CreditFee, 0 As NGFee, 0 As NHISFee, 0 As FFee, '' as ItemCode, '' as AdultCode, '' as ChildCode, NHIS,'No' AS IsMorgue,1 As MinDay,1 As MaxDay, 6 As FeeFreq, 'Yes' As Disabled,0 as ItemTypeCode FROM Service_Types Where SERVICECODE<>'' and SERVICETYPE<>''
go

