CREATE VIEW [dbo].[AccountCashServicesView]

AS

--SERVICES CASH SALE
SELECT
	
S.ServiceCode,S.Service_Fee *S.PaidQty as TransAmt,S.PmtDate As TransDate,J.TransTypeID, J.AcctCodeJE As CreditAcctCode,UPPER(A.Description) as CreditAcctName,
UPPER(T.Description) as CreditPostType,UPPER(P.Description) as ClientName, M.ServiceTypeID, '' As TransID,A.TypeDescription,A.AcctTypeID,P.Code As ClientID,

ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitPostType
      	
FROM 
	
ServicePlacesView P,Service_Types R,AccountChartServicesMapping M, AccountChatsView A,AccountPostingType T,
ServiceLinePayments S, AccountsChartJournalMapping J, ServicesConfigurationSetupView V
	
WHERE 

M.ServiceTypeID=2 And S.Service_Fee>0 And S.PmtTypeCode =1 And S.Archived ='No' AND R.ServiceCode=S.ServiceCode AND P.Code =R.ServicePlaceCode AND J.TransTypeID=1 And A.Code=J.AcctCodeJE And 
T.Code=J.AcctJEPostType And J.TransTypeID=M.PostingType And J.AcctCodeJE=M.AccountChartCode  AND S.PmtTypeCode=1 and S.SponsorNo='' AND M.ServiceTypeID=2
And A.Code=M.AccountChartCode And J.AcctJEPostType=2  And ((V.AcctsServicesMapID=4 and M.ServiceID = R.ServicePlaceCode And M.ServiceTypeID=2) OR
(V.AcctsServicesMapID=3 and M.ServiceID = R.ServiceTypeCode And M.ServiceTypeID=2) OR (V.AcctsServicesMapID=2 and M.ServiceID = R.ServiceCode And M.ServiceTypeID=2))
go

