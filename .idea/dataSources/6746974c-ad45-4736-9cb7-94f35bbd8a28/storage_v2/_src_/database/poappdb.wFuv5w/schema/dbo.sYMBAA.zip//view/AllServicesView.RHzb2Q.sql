CREATE VIEW [dbo].[AllServicesView]
AS

SELECT Distinct left(items.Description,100) as Description, ITEMS.ItemID, 1 As ServiceTypeCode, 2 As PmtType, OrderID As ServicePlaceCode , CashPrice AS CashFee, CreditPrice AS CreditFee, NGPrice AS NGFee,NHISPrice AS NHISFee, FFee, NHISCode as ItemCode, NHISCode as AdultCode, NHISCode as ChildCode, ItemTypeCode As ServiceBillType, ItemTypeCode As CatID, ItemClassCode as SubCatID, 0 As NHIACoPayFee,ItemStockType.Description AS DeliveryType FROM ITEMS, ItemStockType, Packs Where ItemStockType.Code=StockType and Items.ItemID=Packs.ItemID and   ITEMS.ItemID<>'' and Items.Description<>'' and Disabled='No'
UNION

SELECT Distinct left(FEETYPE,100) as Description, FEEID, 6 As ServiceTypeCode, PmtType, MorID  As ServicePlaceCode, CashFee, CreditFee, NGFee, NHISFee, FFee, ServiceCode as ItemCode, ServiceCode as AdultCode, ServiceCode as ChildCode, 2 As ServiceBillType, 0 As CatID, 0 as SubCatID, 0 As NHIACoPayFee,'INTERNAL' AS DeliveryType FROM MORTUARYFEES Where FEEID<>'' and FEETYPE<>'' and Disabled='No'

UNION

SELECT Distinct left(FEETYPE,100) as Description, FEEID, ServiceTypeCode,PmtType, WardID  As ServicePlaceCode,  CashFee, CreditFee, NGFee, NHISFee, FFee, ServiceCode as ItemCode, ServiceCode as AdultCode, ServiceCode as ChildCode, 2 As ServiceBillType, 0 As CatID, 0 as SubCatID, 0 As NHIACoPayFee,'INTERNAL' AS DeliveryType  FROM WARDFEES Where FEEID<>'' and FEETYPE<>'' and Disabled='No'

UNION

SELECT Distinct left(SERVICETYPE,100) as Description, SERVICECODE, ServiceTypeCode, PmtType, ServicePlaceCode ,CashPrice AS CashFee, CreditPrice AS CreditFee,  NGFee, NHISPrice NHISFee, FFee, IsNull(Fee_Category,'') as ItemCode, ISNULL(GDRGCodeA,'') as AdultCode, ISNULL(GDRGCodeC,'') as ChildCode, 2 As ServiceBillType, CatID, SubCatID,NHIACoPayFee,DeliveryType  FROM Service_Types Where SERVICECODE<>'' and SERVICETYPE<>'' and Disabled='No'

UNION

SELECT Distinct left(DisDescription,100) As Description, DisCode, 2 As ServiceTypeCode, PmtType, '' AS ServicePlaceCode ,0  AS CashFee, 0 AS CreditFee, 0 As NGFee, 0  As NHISFee, 0 As FFee, '' as ItemCode, ISNULL(GDRGCodeA,'') as AdultCode, ISNULL(GDRGCodeC,'') as ChildCode, 2 As ServiceBillType, 0 As CatID, 0 as SubCatID, 0 As NHIACoPayFee,'INTERNAL' AS DeliveryType  FROM Diseases Where DisCode<>'' and Disabled='No'
go

