-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[upsGetPrescriptionItems] 
	-- Add the parameters for the stored procedure here

	@ItemDescription nvarchar(250) ,@itemStore nvarchar(15)='',@itemType tinyint =0,
	@AgeGroupCode tinyint=3,@GenderCode tinyint=1,@PatientType tinyint=1
AS

declare @allAgeGroupCode tinyint,@allGenderCode tinyint,@allPatientType tinyint;

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

 set @allAgeGroupCode =3
 set @allGenderCode =1
 set @allPatientType =1

 if @itemType<>0
    if @itemStore<>''
							Select Distinct Sum(StockLevel) As StockLevel, StockType, AgeGroupCode,GenderCode, IssueUnitCode, UnitMeasures.Description As Unit_Name, Items.Description, IssueUnitQuantity,PresUnitQuantity,PresUnitCode,AllowCoPay,
										PresQuanityPerIssueUnit,PresSpecType,IsNull(AveUnitCost,0) as UnitCost, Items.ItemID, ItemTypeCode, ManufacturerCode, PresentationCode,Expirable,Items.DefaultMethodCode, PresLevel, MinPresQty, MaxPresQty,DeterminePresQty From UnitMeasures Inner Join 
										(Items Inner Join StockedItems On Items.ItemID = StockedItems.ItemID ) On UnitMeasures.Code = Items.IssueUnitCode Where Items.Description Like  @ItemDescription + '%' And StockType=1 And 
										(AgeGroupCode =@AgeGroupCode Or AgeGroupCode =@allAgeGroupCode) And (GenderCode=@GenderCode Or GenderCode=@allGenderCode) And (PatientType=@PatientType Or PatientType=@allPatientType) And StockedItems.StoreID =@itemStore  
										And Items.Disabled ='No' And ItemTypeCode =@itemType  Group By Items.ItemID,Items.Description,PresentationCode,ManufacturerCode,ItemTypeCode, IssueUnitCode,UnitMeasures.Description,IssueUnitQuantity,AveUnitCost,Expirable,
										IssueUnitQuantity,PresUnitQuantity,PresUnitCode,PresQuanityPerIssueUnit,PresSpecType,Items.DefaultMethodCode, AgeGroupCode,GenderCode,StockType, PresLevel, AllowCoPay, MinPresQty, MaxPresQty,DeterminePresQty  Order by Items.Description Asc
     
     else
							Select Distinct Sum(StockLevel) As StockLevel, StockType, AgeGroupCode,GenderCode, IssueUnitCode, UnitMeasures.Description As Unit_Name, Items.Description, IssueUnitQuantity,PresUnitQuantity,PresUnitCode,AllowCoPay,
										PresQuanityPerIssueUnit,PresSpecType,IsNull(AveUnitCost,0) as UnitCost, Items.ItemID, ItemTypeCode, ManufacturerCode, PresentationCode,Expirable,Items.DefaultMethodCode, PresLevel, MinPresQty, MaxPresQty,DeterminePresQty  From UnitMeasures Inner Join 
										(Items Inner Join StockedItems On Items.ItemID = StockedItems.ItemID ) On UnitMeasures.Code = Items.IssueUnitCode Where (PatientType=@PatientType Or PatientType=@allPatientType) And Items.Description 
										Like  @ItemDescription + '%' And StockType=1 And (AgeGroupCode =@AgeGroupCode Or AgeGroupCode =@allAgeGroupCode) And (GenderCode=@GenderCode Or GenderCode=@allGenderCode) And Items.Disabled ='No' And ItemTypeCode =@itemType  Group By 
										Items.ItemID,Items.Description,PresentationCode,ManufacturerCode,ItemTypeCode, IssueUnitCode,UnitMeasures.Description,IssueUnitQuantity,AveUnitCost,Expirable,
										IssueUnitQuantity,PresUnitQuantity,PresUnitCode,PresQuanityPerIssueUnit,PresSpecType,Items.DefaultMethodCode, AgeGroupCode,GenderCode,StockType, PresLevel, AllowCoPay, MinPresQty, MaxPresQty,DeterminePresQty  Order by Items.Description Asc
     
else
    if @itemStore<>''
							Select Distinct Sum(StockLevel) As StockLevel, StockType, IssueUnitCode, UnitMeasures.Description As Unit_Name, Items.Description, AgeGroupCode,GenderCode, IssueUnitQuantity, IssueUnitQuantity,PresUnitQuantity,PresUnitCode,AllowCoPay,
							PresQuanityPerIssueUnit,PresSpecType,IsNull(AveUnitCost,0) as UnitCost, Items.ItemID, ItemTypeCode, ManufacturerCode, PresentationCode,Expirable,Items.DefaultMethodCode, PresLevel, MinPresQty, MaxPresQty,DeterminePresQty  From UnitMeasures Inner Join 
							(Items Inner Join StockedItems On Items.ItemID = StockedItems.ItemID ) On UnitMeasures.Code = Items.IssueUnitCode Where (PatientType=@PatientType Or PatientType=@allPatientType) And Items.Description 
							Like  @ItemDescription + '%' And StockType=1  And  (AgeGroupCode =@AgeGroupCode Or AgeGroupCode =@allAgeGroupCode) And (GenderCode=@GenderCode Or GenderCode=@allGenderCode) And StockedItems.StoreID =@itemStore And Items.Disabled ='No'  Group By 
							Items.ItemID,Items.Description,PresentationCode,ManufacturerCode,ItemTypeCode, IssueUnitCode,UnitMeasures.Description,IssueUnitQuantity,AveUnitCost,Expirable,
							IssueUnitQuantity,PresUnitQuantity,PresUnitCode,PresQuanityPerIssueUnit,PresSpecType,Items.DefaultMethodCode, AgeGroupCode, GenderCode, StockType, PresLevel, AllowCoPay, MinPresQty, MaxPresQty,DeterminePresQty  Order by Items.Description Asc
    
    else
							Select Distinct Sum(StockLevel) As StockLevel, StockType, IssueUnitCode, UnitMeasures.Description As Unit_Name, Items.Description, AgeGroupCode,GenderCode, IssueUnitQuantity, IssueUnitQuantity,PresUnitQuantity,PresUnitCode,AllowCoPay,
							PresQuanityPerIssueUnit,PresSpecType,IsNull(AveUnitCost,0) as UnitCost, Items.ItemID, ItemTypeCode, ManufacturerCode, PresentationCode,Expirable,Items.DefaultMethodCode, PresLevel, MinPresQty, MaxPresQty,DeterminePresQty  From UnitMeasures Inner Join 
							(Items Inner Join StockedItems On Items.ItemID = StockedItems.ItemID ) On UnitMeasures.Code = Items.IssueUnitCode Where(PatientType=@PatientType Or PatientType=@allPatientType) And Items.Description 
							Like  @ItemDescription + '%' And StockType=1  And  (AgeGroupCode =@AgeGroupCode Or AgeGroupCode =@allAgeGroupCode) And (GenderCode=@GenderCode Or GenderCode=@allGenderCode) And Items.Disabled ='No'  Group By 
							Items.ItemID,Items.Description,PresentationCode,ManufacturerCode,ItemTypeCode, IssueUnitCode,UnitMeasures.Description,IssueUnitQuantity,AveUnitCost,Expirable,
							IssueUnitQuantity,PresUnitQuantity,PresUnitCode,PresQuanityPerIssueUnit,PresSpecType,Items.DefaultMethodCode, AgeGroupCode, GenderCode, StockType, PresLevel, AllowCoPay, MinPresQty, MaxPresQty,DeterminePresQty  Order by Items.Description Asc
    
END
go

