CREATE VIEW [dbo].[AccountServiceSalesView]

AS


---ALL CASH SERVICES 
	SELECT Distinct 
              ServiceLinePayments.RecordID As TransID, ServiceLinePayments.ServiceCode,
              ServiceLinePayments.Service_Fee *ServiceLinePayments.PaidQty  as   PaidAmt    ,ServiceLinePayments.PmtDate As TransDate,
              Service_Requests.SerPlaceCode as IssuerID  
	      	 ,ServiceLinePayments.PmtTypeCode , Service_Requests.SponsorNo As ReceiverID
	      	 ,AllSetUpServicesView.Description As ServiceDescription
	      	 ,UPPER(Service_Places.Description) as ClientName
	      	 ,'Cash' as SaleType
	         ,ServiceLinePayments.Pat_ID As OPDNo 
	         ,'SERVICE CASH SALE' As MoveType
	FROM 
	         Service_Places Inner Join(
	         AllSetUpServicesView inner join
			 (Service_Requests  Inner Join ServiceLinePayments 
			 On Service_Requests.ServiceCode=ServiceLinePayments.ServiceCode 
			 And Service_Requests.RecordID=ServiceLinePayments.ServiceID)
			 ON AllSetUpServicesView.ItemID =ServiceLinePayments.ServiceCode )
			 on Service_Places.Code =Service_Requests.SerPlaceCode 
	
	WHERE 
			ServiceLinePayments.PmtTypeCode =1 
			--And ServiceLinePayments.Refunded ='No' 
			And ServiceLinePayments.Archived ='No'
			

	UNION ALL
	---ALL NHIA SERVICES EXCEPT DIRECT SERVICE
	SELECT DISTINCT
	            Episode.EpisodeID,Service_Code,
	            Episode.ServiceFee As PaidAmt,EndEpisode as PmtDate ,
	            Service_Requests.SerPlaceCode as ServicePlaceCode ,
		        EpisodePmtType, Episode.SponsorNo 
		       ,AllSetUpServicesView.Description 
	      	   ,UPPER(Sponsors.SponsorName ) as ClientName
		        ,'NHIS-BUNDLE' as SaleType 
		        ,Service_Requests.OPDNo  
		        ,'Service Credit Sale' As MoveType
	FROM 
                Sponsors  Inner Join(
                AllSetUpServicesView Inner Join(
			    Episode Inner Join Service_Requests
			    On Episode.EpisodeID =Service_Requests.EpisodeID  
			    And Episode.Service_Code =Service_Requests.ServiceCode)
			    ON AllSetUpServicesView.ItemID =Service_Requests.ServiceCode)
			    on Sponsors.SponsorNo  =Service_Requests.SponsorNo   
				  
	WHERE 
				 --Service_Requests.Archived ='No' And
				 Episode.AttType  <>2 
				 AND EndEpisode IS NOT NULL
				 --And Sponsors.AcctsBlocked ='No'
				 And NoofVisit>0 
				 --And Service_Requests.Refunded ='No'
				 And Episode.EpisodePmtType =2
    UNION ALL
      
	---ALL PRIVATE SPONSORED SERVICES
	
	SELECT DISTINCT
		    RecordID,Service_Requests.ServiceCode 
		   ,PaidAmt=Service_Requests.ServiceQty *Service_Requests.Service_Fee 
		   ,ReqDate AS PmtDate,Service_Requests.SerPlaceCode as ServicePlaceCode  
		   ,Service_Requests.PmtTypeCode ,Service_Requests.SponsorNo 
		   ,AllSetUpServicesView.Description 
	       ,UPPER(SponsorName ) as ClientName
		   , 'COPORATE' AS RecType
		   ,Service_Requests.OPDNo
		   ,'Service Credit Sale' As MoveType
	FROM 
		   Sponsors Inner Join(
		   AllSetUpServicesView
		   Inner Join Service_Requests
		   ON AllSetUpServicesView.ItemID =Service_Requests.ServiceCode )
		   on Sponsors.SponsorNo  =Service_Requests.SponsorNo  
	WHERE 
	    --Service_Requests.Archived ='No' And
		Service_Requests.PmtTypeCode NOT IN (0,1) 
	    AND BillCategoryCode NOT IN (4,11) 
		AND ServiceQty >0 And Service_Requests.SponsorNo<>''
		And UPPER(RequestType)='INTERNAL'
				--and Archived ='No' and Refunded ='No'
		


	
	UNION ALL
	
	---ALL NHIA DIRECT SERVICES
	
	SELECT DISTINCT 
		   RecordID,Service_Requests.ServiceCode 
		  ,Service_Requests.ServiceQty *Service_Requests.Service_Fee as PaidAmt
		  ,ReqDate  AS PmtDate,Service_Requests.SerPlaceCode as ServicePlaceCode 
          ,Service_Requests.PmtTypeCode ,Service_Requests.SponsorNo 
          ,AllSetUpServicesView.Description 
          ,UPPER(SponsorName ) as ClientName
          ,'NHIS-DIRECT SERVICE' AS RecType 
          ,Service_Requests.OPDNo 
          ,'Service Credit Sale' As MoveType 
	FROM
	      Sponsors  Inner Join
		  (AllSetUpServicesView 
		  Inner Join Service_Requests
		  ON AllSetUpServicesView.ItemID =Service_Requests.ServiceCode)
		  on Sponsors.SponsorNo  =Service_Requests.SponsorNo 

	WHERE 
		  Service_Requests.PmtTypeCode <>1
		  AND BillCategoryCode  IN (4,11) 
		  --AND Archived ='No' 
		  and ServiceQty >0 
		  AND AttType =2
		  --and Refunded ='No'
		  --And Sponsors.AcctsBlocked  ='No'
	 
	 UNION ALL
	
	--CAPITATION EXEMPTED SERVICES
	SELECT
		  Service_Requests.RecordID  
		 ,Service_Requests.ServiceCode 
		 ,Service_Requests.Service_Fee as Amount 
		 ,Service_Requests.ReqDate  
		 ,Service_Types.ServicePlaceCode 
		 ,Service_Requests.PmtTypeCode  
		 ,Service_Requests.SponsorNo
		 ,Service_Types.ServiceType  
	     ,UPPER(Sponsors.SponsorName ) as ClientName
		 ,'CAPITATION EXEMPTED SERVICES' as RecType
         ,Service_Requests.OPDNo 
         ,'Service Credit Sale' As MoveType 
    FROM 
        Sponsors  INNER JOIN(
        Service_Types INNER JOIN (
        Episode INNER JOIN Service_Requests  
		ON Episode.OPDNo =Service_Requests.OPDNo 
		AND Episode.EpisodeID =Service_Requests.EpisodeID)
		ON Service_Types.ServiceCode =Service_Requests.ServiceCode)
		ON Sponsors.SponsorNo  =Service_Requests.SponsorNo     
	WHERE 
	    Episode.EpisodePmtType =3 
	    AND Service_Requests.PmtTypeCode  =2
		AND Service_Types.ServiceTypeCode IN (11,12,13,14,15)
		--AND Service_Requests.Archived ='No'
		--And Sponsors.AcctsBlocked  ='No'
go

