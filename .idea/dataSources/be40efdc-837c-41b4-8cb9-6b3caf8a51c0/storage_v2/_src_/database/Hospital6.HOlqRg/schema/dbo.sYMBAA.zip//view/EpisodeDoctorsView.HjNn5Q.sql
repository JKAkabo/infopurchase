CREATE VIEW [dbo].[EpisodeDoctorsView]

AS

SELECT Distinct Doctor, Users.UserID, 2 as PatStatus, Consultations.EpisodeID As DiaEpisodeID, Consultations.OPDNo FROM Users Inner Join (PatientNHIAActiveEpisodesView Inner Join dbo.Consultations On PatientNHIAActiveEpisodesView.EpisodeID=Consultations.EpisodeID And PatientNHIAActiveEpisodesView.OPDNo=Consultations.OPDNo) On UserNo=Consultations.Doctor Where Consultations.Archived='No' and Consultations.StatusCode=2

Union

Select Distinct DoctorID as Doctor, Users.UserID, 3 as PatStatus, Admissions.EpisodeID As DiaEpisodeID, Admissions.OPDNo From Users Inner Join (PatientNHIAActiveEpisodesView Inner Join dbo.Admissions On PatientNHIAActiveEpisodesView.EpisodeID=Admissions.EpisodeID And PatientNHIAActiveEpisodesView.OPDNo=Admissions.OPDNo) On UserNo=DoctorID Where Admissions.Archived='No'

Union

Select Distinct '' as Doctor, '' As UserID, 2 as PatStatus, PatientNHIAActiveEpisodesView.EpisodeID As DiaEpisodeID, PatientNHIAActiveEpisodesView.OPDNo From PatientNHIAActiveEpisodesView Where PatientNHIAActiveEpisodesView.AttType=2 and PatientNHIAActiveEpisodesView.EpisodeType=6 and PatientNHIAActiveEpisodesView.EpisodeStatus=2

Union

SELECT Distinct '' As Doctor, '' As UserID, PatientNHIAActiveEpisodesView.EpisodeStatus as PatStatus, PatientNHIAActiveEpisodesView.EpisodeID As DiaEpisodeID, PatientNHIAActiveEpisodesView.OPDNo FROM PatientNHIAActiveEpisodesView Where PatientNHIAActiveEpisodesView.EpisodeID Not IN (Select Distinct EpisodeID From Consultations Where Consultations.Archived='No' And Consultations.StatusCode=2 And EpisodeID<>0
Union Select Distinct EpisodeID From Admissions Where Admissions.Archived='No' And EpisodeID<>0)
go

