CREATE VIEW [dbo].[PregnancyDescentView]

AS

SELECT  Description, Code FROM dbo.PregnancyDescent

Union

SELECT  '', 0  FROM dbo.Hosp_Info
go

