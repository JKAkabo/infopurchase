CREATE VIEW [dbo].[PatientInvoiceServicesView]

AS

Select Distinct 'SERVICE' As PaymentType, ServiceLinePayments.ServiceCode, ServiceLinePayments.RecordID, ServiceLinePayments.ReceiptNo As InvoiceNo,  ServiceLinePayments.PaidAmt, AllSetUpServicesView.Description As ServiceDescription, Service_Requests.DirectID, ServicePlacesView.Description As ServicePlace, ClinicsView.Description As ServicePoint, DirectoratesView.Description As Directorate, ServiceLinePayments.Service_Fee As UnitFee, ServiceLinePayments.PaidQty As ServiceQty From ServicePlacesView Inner Join (DirectoratesView Inner Join (ClinicsView Inner Join ( AllSetUpServicesView Inner Join (Service_Requests Inner Join ServiceLinePayments On (Service_Requests.ServiceCode=ServiceLinePayments.ServiceCode And Service_Requests.RecordID=ServiceLinePayments.ServiceID)) On AllSetUpServicesView.ItemID = Service_Requests.ServiceCode) On SPCode=ClinicCode) On DirectoratesView.ID=Service_Requests.DirectID) On ServicePlacesView.Code=SerPlaceCode Where ServiceTypeCode<>1 and ServiceLinePayments.Archived='No'

Union

Select Distinct 'DRUG' As PaymentType, ServiceLinePayments.ServiceCode,ServiceLinePayments.RecordID, ServiceLinePayments.ReceiptNo As InvoiceNo,  ServiceLinePayments.PaidAmt, AllSetUpServicesView.Description As ServiceDescription, Prescriptions.DirectID, ServicePlacesView.Description As ServicePlace, ClinicsView.Description As ServicePoint, DirectoratesView.Description As Directorate, ServiceLinePayments.Service_Fee, ServiceLinePayments.PaidQty From ServicePlacesView Inner Join (DirectoratesView Inner Join (ClinicsView Inner Join ( AllSetUpServicesView Inner Join (Prescriptions Inner Join ServiceLinePayments On (DrugCode=ServiceLinePayments.ServiceCode And Prescriptions.RecordID=ServiceLinePayments.ServiceID)) On AllSetUpServicesView.ItemID = DrugCode) On SPCode=ClinicCode) On DirectoratesView.ID=Prescriptions.DirectID) On ServicePlacesView.Code=StoresID  Where ServiceTypeCode=1 and ServiceLinePayments.Archived='No'
go

