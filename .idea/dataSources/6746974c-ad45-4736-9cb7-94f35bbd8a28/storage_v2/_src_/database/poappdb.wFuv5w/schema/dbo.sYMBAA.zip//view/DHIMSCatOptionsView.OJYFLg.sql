CREATE VIEW [dbo].[DHIMSCatOptionsView]

AS

SELECT  Description, HamsLinkID, CatOptionCode, LowerLimit, UpperLimit, OptonType As OptionType FROM dbo.DHIMSCategoryOptionElements inner join DHIMSCategoryOptions on RecordID=ElementID where IsActive='Yes'
go

