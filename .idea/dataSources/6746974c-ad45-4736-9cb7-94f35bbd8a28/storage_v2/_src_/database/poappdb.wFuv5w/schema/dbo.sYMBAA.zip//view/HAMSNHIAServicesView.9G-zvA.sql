CREATE VIEW [dbo].[HAMSNHIAServicesView]

AS

Select Upper(U.Description) As Description,Upper(S.Description) As ServiceType,ServiceTypeCode,U.ItemID As ServiceCode, 
IsNull((Select TOP 1 N.GDRGCode From NHIAGDRGSecialties N Where N.GDRGCode=U.AdultCode And N.IsActive='Yes'  And RIGHT(U.AdultCode,1)<>'C'),'') As AdultCode,
IsNull((Select TOP 1 N.GDRGCode From NHIAGDRGSecialties N Where N.GDRGCode=U.ChildCode And N.IsActive='Yes'  And RIGHT(U.ChildCode,1)<>'A'),'') As ChildCode, 
IsNull((Select TOP 1 Upper(N.Description) From NHIAGDRGSecialties N Where N.GDRGCode=U.AdultCode And N.IsActive='Yes' And RIGHT(U.AdultCode,1)<>'C'),'') As AdultDescription,
IsNull((Select TOP 1 Upper(N.Description) From NHIAGDRGSecialties N Where N.GDRGCode=U.ChildCode And N.IsActive='Yes' And RIGHT(U.ChildCode,1)<>'A'),'') As ChildDescription 
From AllSetUpServicesView U, ServiceTypes S Where U.Disabled='No' And ServiceTypeCode IN (2,3,5,11,12,13,14)  And U.NHIS='Yes' And S.Code=ServiceTypeCode
go

