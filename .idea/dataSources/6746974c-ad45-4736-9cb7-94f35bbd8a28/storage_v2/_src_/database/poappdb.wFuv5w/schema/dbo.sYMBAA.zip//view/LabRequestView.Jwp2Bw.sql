CREATE VIEW [dbo].[LabRequestView]

AS

Select U.UserID As RequesterBy, S.OPDNo, S.Pat_No, ReqTime, ReqDate, S.BillCategoryCode,S.ClinicCode,S.SerPlaceCode,S.PmtTypeCode, S.SponsorNo,S.ServerTime,
Title,LastName + ' ' + MiddleName + ' ' + Surname As PatName ,G.Description As Gender, Issued As Tested,S.RequesterID,RequestType,AttServiceID,T.CatID,S.EpisodeID,
CONVERT(nvarchar(10),S.PatAge) As PatAge,S.ServiceCode,S.RecordID,T.ServiceType As ServiceDescription,S.UserID, V.UserID As RequestEntredBy,S.AttType,S.FacAttType,
S.PaidQty,S.PaidAmt,S.DirectID,T.ServiceTypeCode,S.ReqRemarks,S.Service_Fee,S.StatusCode,S.BillCycleDuration,CoPayFee,CoPayAmt,CoPayBillCategoryCode,CoPayPmtTypeCode,CoPaySponsorNo,
IsNull((Select TOP 1 Description From PatientCategoryView Where PatientCategoryView.Code=S.BillCategoryCode),'') As BillCategory, P.GenderCode, PBOut,
IsNull((Select TOP 1 Description From ServicePlacesView Where Code=S.SerPlaceCode),'') As ServicePlace,Nationality,TDOB,CellPhoneNo,P.StatusCode As CurrentStatus,
IsNull((Select TOP 1 Description From PaymentTypessView Where Code=S.PmtTypeCode),'') As PaymentType, LastName, MiddleName, Surname,
IsNull((Select TOP 1 Description From ClinicsView Where SPCode=S.ClinicCode),'') As Clinic,
IsNull((Select TOP 1 SponsorName From SponsorsView Where SponsorsView.SponsorNo=S.SponsorNo),'') As Sponsor,
IsNull((Select TOP 1 Description From PatientStatusView Where Code=S.StatusCode),'') As PatStatus,
IsNull((Select TOP 1 M.RecordID From PatientLabSpecimens M Where M.Archived='No' And M.ReqID=S.RecordID),0) As SpecimenColledtedID,
IsNull((Select TOP 1 E.IDNo As MemberID From SponsoredPatients E, Sponsors R Where R.SponsorNo=E.SponsorNo And R.AcctsBlocked='No' And E.OPDNo=P.OPDNo and E.Archived='No' And SponsorTypeCode=2),'') As MemberID,
IsNull((Select TOP 1 E.IDNo As MemberID From SponsoredPatients E, Sponsors R Where R.SponsorNo=E.SponsorNo And R.AcctsBlocked='No' And E.OPDNo=P.OPDNo and E.Archived='No' And SponsorTypeCode NOT IN (1,2)),'') As StaffID,
IsNull((Select TOP 1 UPPER(Description) From Admissions, ServicePlacesView Where Admissions.OPDNo=P.OPDNo and Admissions.Archived='No' And ServicePlacesView.Code=Admissions.WardID and Admissions.Discharged='No' and Admissions.DisDate Is Null),'') As AdmissionWard,
CASE WHEN Year(CONVERT(Date, TDOB))=Year(getdate()) Then 0 WHEN Month(getdate())>Month(CONVERT(Date, TDOB)) Or (Month(getdate())=Month(CONVERT(Date, TDOB)) 
And day(getdate())>=day(CONVERT(Date, TDOB))) Then DateDiff(M,  CONVERT(Date, TDOB), getdate())/12 Else DateDiff(YYYY,  CONVERT(Date, TDOB), getdate()) - 1 END As PatientAge
From GenderGroups G, PatientsInfo P, Service_Types T, UsersView U, Service_Requests S, UsersView V Where 
U.UserNo=S.RequesterID And V.UserNo=S.UserID And T.ServiceCode=S.ServiceCode And P.OPDNo=S.OPDNo And 
G.Code=P.GenderCode And ServiceTypeCode=11 and S.Archived='No' and T.Disabled='No'
go

