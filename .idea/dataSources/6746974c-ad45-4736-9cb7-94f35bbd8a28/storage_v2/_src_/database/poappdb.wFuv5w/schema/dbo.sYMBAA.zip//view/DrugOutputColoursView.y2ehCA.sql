CREATE VIEW [dbo].[DrugOutputColoursView]

AS

SELECT  Description, Code, Result, TypeCode FROM dbo.DrugOutputElements D

Union

SELECT  '' As Description, 0 As Code, '' As Result, 0 As TypeCode FROM dbo.Hosp_Info
go

