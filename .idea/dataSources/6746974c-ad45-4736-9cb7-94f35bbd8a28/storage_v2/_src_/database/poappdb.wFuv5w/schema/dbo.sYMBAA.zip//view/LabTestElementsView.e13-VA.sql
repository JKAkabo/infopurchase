







CREATE VIEW [dbo].[LabTestElementsView]

AS

SELECT Distinct IsActive, Description, Code From TestElements 

Union


SELECT TOP 1 'Yes' As IsActive,'' As Description, 0 As Code From Hosp_Info



go

