CREATE VIEW [dbo].[QBReturnedPrescriptionsLinesView]

AS

Select ReturnedPrescriptions.RecordID As TransID, ReturnedPrescriptions.UnitCost, ReturnedPrescriptions.ReturnedQty As MoveQty, Items.ItemID, ReturnedPrescriptions.ReturnedDate As TransDate, OPDNo As IssuerID, StoreID As ReceiverID,'Prescriptions Returns' As MoveType,UPPER(Service_Places.Description) As ClientName, Items.Description As ServiceDescription, Items.ItemID As ServiceCode, Convert(Nvarchar(15),ItemClassCode) As ItemClassCode 
,ReturnedPrescriptions.UnitPrice From Service_Places Inner Join (Prescriptions Inner Join (Items Inner Join ReturnedPrescriptions On Items.ItemID=ReturnedPrescriptions.ItemID) ON Prescriptions.RecordID=PresID) On Service_Places.Code=ReturnedPrescriptions.StoreID Where ReturnedPrescriptions.ItemID IN 
(Select Items.ItemID From Items Inner Join QBAcctsMappingView ON Convert(Nvarchar(15),ItemClassCode)=ServiceID)
go

