CREATE VIEW [dbo].[WardTransfersIDsView]

AS

SELECT OldAdmRecordID As RecordID  FROM  WardTransfers where WardTransfers.Archived='No' 

Union

SELECT NewAdmRecordID As RecordID  FROM  WardTransfers where WardTransfers.Archived='No'
go

