CREATE VIEW [dbo].[MOHDiseaseView]

AS

SELECT     left(Description,100) Description, DisCode, MOHCatCode FROM dbo.GHSReportsDiseasesProcedures

Union

SELECT  TOP 1 '' As Description,  '' As DisCode, 0 AS MOHCatCode FROM Hosp_Info

Union

SELECT  TOP 1 'TOTAL NEW CASES' As Description,  '-000000003' As DisCode, -2 MOHCatCode FROM Hosp_Info

Union

SELECT  TOP 1 'RE-ATTENDANCE' As Description,  '-000000001' As DisCode, -1 as MOHCatCode FROM Hosp_Info

Union

SELECT  TOP 1 'REFERRALS' As Description,  '-000000002' As DisCode, -1 MOHCatCode FROM Hosp_Info
go

