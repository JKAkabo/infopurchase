
CREATE VIEW [dbo].[ClinicaQuestionnaireQuestionsView]

AS

SELECT  T.OrderNo As TypeOrderNo,T.Code As TypeCode, T.ID As TypeID, Scalable,GroupID,T.Description As Type, AnswerEntryType,AnswerValueType,
Q.Description As Question, Q.ID As QuestionID, Q.OrderNo As QuestionOrderNo, Q.GenderCode As QuestionGenderCode,Q.Title As QuestionTitle,
A.Description As Answer, A.Score, A.ValueOrderNo As AnswerOrderNo,A.Title As AnswerTitle,A.ValueType As AnsValueType, A.ID AnswerID FROM 
 ClinicalQuestionnaireAnswers A, ClinicalQuestionaireTypes T,ClinicalQuestionnaireQuestions Q where 
 T.ID=Q.TypeID and A.TypeID=T.ID and T.IsActive='Yes' and Q.IsActive='Yes' and A.IsActive='Yes' and Q.ID NOT IN 
(Select QuestionID from ClinicalQuestionnaireQuestionsAnswers )

UNION ALL 

SELECT  T.OrderNo As TypeOrderNo,T.Code As TypeCode, T.ID As TypeID, Scalable,GroupID,T.Description As Type, AnswerEntryType,AnswerValueType,
Q.Description As Question, Q.ID As QuestionID, Q.OrderNo As QuestionOrderNo, Q.GenderCode As QuestionGenderCode,Q.Title As QuestionTitle,
A.Description As Answer, R.Score, A.ValueOrderNo As AnswerOrderNo,A.Title As AnswerTitle,A.ValueType As AnsValueType, A.ID AnswerID FROM 
 ClinicalQuestionnaireAnswers A, ClinicalQuestionaireTypes T,ClinicalQuestionnaireQuestions Q, ClinicalQuestionnaireQuestionsAnswers R where 
 T.ID=Q.TypeID and A.TypeID=T.ID and T.IsActive='Yes' and Q.IsActive='Yes' and A.IsActive='Yes' and Q.ID=R.QuestionID  and A.ID=R.AnswerID



go

