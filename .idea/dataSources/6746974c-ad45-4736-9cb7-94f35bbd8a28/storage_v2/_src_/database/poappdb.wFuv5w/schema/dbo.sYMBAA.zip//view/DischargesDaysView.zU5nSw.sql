
CREATE VIEW [dbo].[DischargesDaysView]
AS
SELECT     RecordID, CAP_ID, DATEDIFF(hour, AdmTime, DisTime) AS StayHours, AdmTime, DisTime FROM Admissions
WHERE     (Discharged = 'Yes') AND (DisTime IS NOT NULL) AND (DisDate IS NOT NULL) AND (Archived = 'No')

go

