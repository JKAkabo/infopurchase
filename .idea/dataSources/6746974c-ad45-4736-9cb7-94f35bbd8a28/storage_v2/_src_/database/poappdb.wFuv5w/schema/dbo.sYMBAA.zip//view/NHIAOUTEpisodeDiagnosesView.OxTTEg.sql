CREATE VIEW [dbo].[NHIAOUTEpisodeDiagnosesView]

AS

SELECT Distinct Left(Diseases.DisDescription,100) As ServiceDescription, ConsultationDiagnoses.DisCode As ServiceCode, PmtTypeCode, 'DIAGNOSIS(ES)' As ServicePlace, DiaFee as UnitFee, 1 As ServiceQty, 
Consultations.ReqDate, CASE WHEN Consultations.PatAge>=12 THEN IsNull(Diseases.GDRGCodeA,'') ELSE IsNull(Diseases.GDRGCodeC,'') END AS GDRGCode, IsNull(Diseases.ICDCode,'') As ICDCOde, Consultations.EpisodeID, Consultations.OPDNo,  2 As PatStatus, Principal As IsPrincipal, 
Consultations.ConDate As ServiceDate, Consultations.DirectID, Consultations.SponsorNo, IsNull(GDRGCodeA,'') As GDRGCodeA,IsNull(GDRGCodeC,'') As GDRGCodeC FROM Diseases Inner Join 
(Episode Inner Join (Consultations Inner Join ConsultationDiagnoses On  Consultations.ConID=ConsultationDiagnoses.ConID) On (Episode.EpisodeID=Consultations.EpisodeID  and Episode.OPDNo=Consultations.OPDNo)) 
On Diseases.DisCode=ConsultationDiagnoses.DisCode Where Consultations.EpisodeID<>0 and Consultations.Archived='No' and Episode.Archived='No' and BillCategoryCode IN (4,11) and Consultations.StatusCode=2 and Episode.StatusCode=2 and 
PmtTypeCode NOT IN (0,1)  and Cancelled='No'
go

