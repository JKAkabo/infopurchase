


CREATE PROCEDURE [dbo].[uspGeneratePatientRefundReceiptServices] 

	@receiptNo nvarchar(15)
	
AS

DECLARE @serDesc nvarchar(250),@ItemID nvarchar(15),@PaidQty numeric(18,2),@UnitPrice numeric(18,6),@PmtTypeCode Tinyint,@SponsorNo nvarchar(15);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
DELETE FROM PatientReceiptServices WHERE ReceiptNo= @receiptNo

INSERT INTO PatientReceiptServices (SerDesc, SerID, PaidQty, UnitFee, PmtTypeCode, SponsorNo,ReceiptNo) SELECT AllSetUpServicesView.Description,RefundServiceLines.ServiceCode,RefundQty,Service_Fee,RefundServiceLines.PmtTypeCode,RefundServiceLines.SponsorNo,RefundReceiptNo FROM AllSetUpServicesView Inner Join RefundServiceLines
ON AllSetUpServicesView.ItemID =RefundServiceLines.ServiceCode WHERE RefundReceiptNo = @receiptNo
  
END

go

