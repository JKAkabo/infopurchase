

CREATE VIEW [dbo].[QBInitialStocksView]

AS

Select RecordID As TransID, UnitCost, StockLevel As MoveQty, InitialStocks.ItemID, Convert(Date,InitialStocks.ServerDate) As TransDate, StoreID As ReceiverID, InitialStocks.UserID As IssuerID,'Initial Stocks' As MoveType,UPPER(Service_Places.Description) As ClientName, Items.Description As ServiceDescription, Items.ItemID As ServiceCode, Convert(Nvarchar(15),ItemClassCode) As ItemClassCode 
From Service_Places Inner Join (Items Inner Join InitialStocks On Items.ItemID=InitialStocks.ItemID) On Code=StoreID Where UPPER(Service_Places.Status)='YES' And InitialStocks.ItemID IN 
(Select Items.ItemID From Items Inner Join QBAcctsMappingView ON Convert(Nvarchar(15),ItemClassCode)=ServiceID)



go

