CREATE VIEW [dbo].[PrescriptionsSponsorsView]
AS
SELECT  Distinct Sponsors.SponsorName + '(' + SponsorTypes.Description + ')' As SponsorName, Sponsors.SponsorNo, Sponsors.SponsorTypeCode
FROM SponsorTypes Inner Join  (dbo.Sponsors Inner Join Prescriptions On Sponsors.SponsorNo=Prescriptions.SponsorNo) on Code=SponsorTypeCode Where Archived='No' and LTRIM(rtrim(Prescriptions.SponsorNo))<>''  and SponsorTypeCode<>2

Union

Select Upper (surname + ' ' + Lastname + ' - ' + Pat_No) + '(PRIVATE CASH)' As SponsorName, Prescriptions.OPDNo as SponsorNo, 1 As SponsorTypeCode From PatientsInfo  Inner Join Prescriptions On PatientsInfo.OPDNo=Prescriptions.OPDNo Where Archived='No' And LTRIM(rtrim(Prescriptions.SponsorNo))=''

Union

SELECT TOP 1 'GOVERNMENT(NHIA)' As SponsorName, '0001NHIA' As SponsorNo, Sponsors.SponsorTypeCode
FROM SponsorTypes Inner Join  (dbo.Sponsors Inner Join Prescriptions On Sponsors.SponsorNo=Prescriptions.SponsorNo) on Code=SponsorTypeCode Where Archived='No' and LTRIM(rtrim(Prescriptions.SponsorNo))<>''  and SponsorTypeCode=2
go

