CREATE VIEW [dbo].[NHIAPatientsAttendanceView]

AS

SELECT Distinct Daily_Attendance.ClaimPrinted,Daily_Attendance.StatusCode,Daily_Attendance.RecordID,Daily_Attendance.ClaimDataProcessed,Daily_Attendance.ClaimPrintDate, Daily_Attendance.ClaimPrintedBy, Service_Requests.DirectID, Service_Requests.BillCategoryCode, Service_Requests.SponsorNo, Service_Requests.OPDNo, Daily_Attendance.ClinicCode, ReqDate As AttDate, CoPaySponsorNo, CoPayBillCategoryCode, Daily_Attendance.AttAge,Daily_Attendance.Pat_No FROM Daily_Attendance inner join Service_Requests On (Daily_Attendance.OPDNo=Service_Requests.OPDNo and Daily_Attendance.AttDate=Service_Requests.ReqDate) Where Archived='No' and Service_Requests.StatusCode=2 and BillCategoryCode IN (4,11) and Service_Requests.SponsorNo<>''
go

