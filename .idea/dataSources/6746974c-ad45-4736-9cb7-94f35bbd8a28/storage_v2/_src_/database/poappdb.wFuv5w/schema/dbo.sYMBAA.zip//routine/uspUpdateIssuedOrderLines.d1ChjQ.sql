CREATE PROCEDURE [dbo].[uspUpdateIssuedOrderLines] 
	
AS

DECLARE @issuedID numeric(18,0),@issuedLineID numeric(18,0),@IssuedDate datetime,@IssuedTime datetime;

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR Select Distinct O.IssuedID, I.IssuedLineID, O.IssuedDate, O.IssuedTime from IssuedOrderLines I, IssuedOrders O where I.ServerTime=O.ServerTime and I.UserID=O.UserID and I.OrderNo=O.OrderNo and I.IssuedID<>O.IssuedID  and O.IssuedDate<='2017-08-17' ORDER bY O.IssuedDate, O.IssuedTime
  
  OPEN C
  
  FETCH NEXT FROM C INTO @issuedID, @issuedLineID, @IssuedDate, @IssuedTime;

  WHILE @@fetch_status = 0
  
    BEGIN
       
       update IssuedOrderLines Set IssuedID=@issuedID, IssuedDate=@IssuedDate,IssuedTime=@IssuedTime where IssuedLineID = @issuedLineID

       FETCH NEXT FROM C INTO @issuedID, @issuedLineID, @IssuedDate, @IssuedTime;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

