CREATE PROCEDURE [dbo].[uspUpdateVMCPatientInfo] 
	
AS

DECLARE @surname nvarchar(100),@lastname nvarchar(100),@middlename nvarchar(100),@nationality nvarchar(100),
        @maritalstatus nvarchar(50),@TDOB nvarchar(100),@DOB datetime,@Title nvarchar(50),
        @OPDNo nvarchar(15),@homeaddrs nvarchar(100),@workaddrs nvarchar(100),@homeTel nvarchar(50),
        @worktel nvarchar(50),@emailaddrs nvarchar(100),@regStatus nvarchar(3)='OLD',@regDate datetime,
        @regtime datetime,@servertime datetime,@serverdate datetime,@insured nvarchar(3),@absconded nvarchar(3),
        @sex nvarchar(50),@userid nvarchar(10),@ClinicCode nvarchar(10)='01',@PatNo nvarchar(10),@CardNo nvarchar(50),
        @PatCatID tinyint, @Religion nvarchar(50),@OccupationID bigint,@CellPhoneNo nvarchar(50),@CardExpiryDate datetime,
        @BillCategoryCode tinyint,@educationLevelID tinyint, @OldoPDNo nvarchar(15),@MemberNo nvarchar(15),@Died Nvarchar(3),
        @NOKName nvarchar(100),@NOKAddress nvarchar(100),@NOKTel nvarchar(100),@Occup nvarchar(100),@DeathDate datetime,
        @ReligionID Numeric(18,0),@educationLevel nvarchar(150)
BEGIN

Delete from PatientsInfo

Delete from SponsoredPatients

Delete from Kins

Delete from OPD_Nos

Declare @genderCode tinyint,@RegionID tinyint =10

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct rtrim(ltrim(Surname)) As surname,rtrim(ltrim(FirstName)) as lastname,'' As middlename,
       rtrim(ltrim(Nationality)) As nationality,IsNull(rtrim(ltrim(MaritalStatus)),'') As marritalstatus,CONVERT(nvarchar,DBirth,106) As TDOB,DBirth As DOB,'' As Title,Right(FoldNo,5) + '/' + left(FoldNo,2),
       IsNull(rtrim(ltrim(Address)),'') As homeaddrs,IsNull(rtrim(ltrim(Address)),'') As workaddrs,IsNull(rtrim(ltrim(Phone)),'') As homeTelNo,IsNull(rtrim(ltrim(Phone)),'') As worktelNo,
       IsNull(rtrim(ltrim(Email)),'') As emailaddrs,'OLD',DatCreate As DatCreate,DatCreate As DatCreateTime,Getdate(),Getdate(),'No','No',rtrim(ltrim(sex)) As sex,'00001', 
       Right(FoldNo,5) + '/' + left(FoldNo,2) As PatNo,  IsNull(Religion,'') As Religion, IsNull(InsNum,'') As InsNum, IsNull(CardSN,'') As CardSN,
       IsNull(EducationalLevel,'') As EducationalLevel, DDied ,IsNull(Occup,'') As Occup, NextExpDate,IsNull(FoldNo,'') As OldFolderNo, 
       IsNull(NOKName,'') As NOKName,IsNull(NOKAddress,'') As NOKAddress,IsNull(NOKTel,'') As NOKTel From VirtualHDB.dbo.Folders Order by DatCreate Desc, PatNo  Desc
       
  OPEN C
  
  FETCH NEXT FROM C INTO @surname ,@lastname,@middlename,@nationality,@maritalstatus,@TDOB,@DOB,@Title,@OPDNo,@homeaddrs,@workaddrs,@homeTel,        
        @worktel,@emailaddrs,@regStatus,@regDate,@regtime,@servertime,@serverdate,@insured,@absconded,@sex,@userid,@PatNo,@Religion, @MemberNo,
        @CardNo,@educationLevel,@DeathDate,@Occup,@CardExpiryDate,@OldoPDNo,@NOKName,@NOKAddress,@NOKTel;
        
        

  WHILE @@fetch_status = 0
    BEGIN
       
       SET @ReligionID=0
       SET @OccupationID=0
       SET @educationLevelID=0

       select @ReligionID=isnull(Code,0) from Religions where upper(left(ltrim(Description),1)) =  upper(left(ltrim(@Religion),1)) 
       
       select @OccupationID=isnull(Code,0) from Occupations where upper(ltrim(Description)) Like '%' + upper(ltrim(@Occup)) + '%'
              
       select @educationLevelID=isnull(EducationalLevels.ID,0) from EducationalLevels where upper(left(ltrim(Description),2)) =  upper(left(ltrim(@educationLevel),2)) 
       
       if @DeathDate<>null 
          set @Died='Yes'
          
       else
          set @Died='No'
                 
       if upper(@sex)='MALE'
          set @gendercode=2

       else
          set @gendercode=3
           
       if rtrim(LTRIM(@CardNo))='0'
          set @CardNo=''
          
          
       if @MemberNo='' 
          set @PatCatID=1
         
       else
          if DATEDIFF(MONTH,@DOB,GETDATE())<=3
             set @PatCatID=11
          
          else
             set @PatCatID=4
       
       insert into PatientsInfo (surname ,lastname,middlename,nationality,marritalstatus,TDOB,DOB,Title,OPDNo,HomeStreet,WorkStreet,homeTelNo,        
        worktelNo,emailaddrs,regStatus,regDate,regtime,servertime,serverdate,insured,absconded,GenderCode,userid, PatCatID, ReligionID,OccupationID,
        CellPhoneNo,BillCategoryCode,educationLevel, NationalID, Died, HomeRegionID,HomeDistrictID,HomeTownID,WorkRegionID,WorkDistrictID,WorkTownID)Values 
        (@surname ,@lastname,@middlename,@nationality,@maritalstatus,@TDOB,@DOB,@Title,@OPDNo,@homeaddrs,@workaddrs,@homeTel,        
        @worktel,@emailaddrs,'OLD',@regDate,@regtime,GETDATE(),GETDATE(),@insured,@absconded,@gendercode,'00001', @PatCatID,@ReligionID,@OccupationID,@worktel,
        @PatCatID,@educationLevelID,@OldoPDNo,@Died,@RegionID,0,0,@RegionID,0,0)

       insert into OPD_Nos (OPDNo,ClinicCode,RegDate,RegTime,ServerTime,ServerDate,PatNo,UserID,DirectID) Values 
       (@OPDNo,@ClinicCode,@RegDate,@RegTime,GETDATE(),GETDATE(),@PatNo,@UserID,1)
       
       if @CardExpiryDate is not Null and rtrim(ltrim(@MemberNo))<>'' 
		  insert into SponsoredPatients (RelationCode,PatCategoryCode,Insured,SponsorNo,OPDNo,pNo,Pat_No,RegDate,RegTime,UserID,sPriority,UnNo,IDNo,pStatus,DateFrom,DateTo,DeptID,EmpNo,ServerTime,ExpiryAlert,CoPayAmt,AllowCoPay,CommID,InsurePolicyNo,companyID)
		  values(1,@PatCatID,'Yes','000268',@OPDNo,@PatNo,@PatNo,@regDate,@regtime,'00001',1,@CardNo,@MemberNo,'PERMANENT',DATEADD(YYYY,-1,@CardExpiryDate),@CardExpiryDate,'','',GETDATE(),'No',0,'Yes','',0,'')
  
       if ltrim(@NOKName)<>''
		   Insert into Kins([OPDNo],[ContactName],[Relation],[HomeAddrs],[WorkAddrs],[HomeTelNo],[WorkTelNo],[EmailAddrs])
		   values (@OPDNo,@NOKName,'',@NOKAddress,@NOKAddress,@NOKTel,@NOKTel,'')
       
  FETCH NEXT FROM C INTO @surname ,@lastname,@middlename,@nationality,@maritalstatus,@TDOB,@DOB,@Title,@OPDNo,@homeaddrs,@workaddrs,@homeTel,        
        @worktel,@emailaddrs,@regStatus,@regDate,@regtime,@servertime,@serverdate,@insured,@absconded,@sex,@userid,@PatNo,@Religion, @MemberNo,
        @CardNo,@educationLevel,@DeathDate,@Occup,@CardExpiryDate,@OldoPDNo,@NOKName,@NOKAddress,@NOKTel;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

