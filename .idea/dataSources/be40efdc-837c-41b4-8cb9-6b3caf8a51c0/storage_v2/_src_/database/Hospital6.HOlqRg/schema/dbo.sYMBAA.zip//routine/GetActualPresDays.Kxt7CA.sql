create FUNCTION GetActualPresDays

(@PresDays AS NVARCHAR(4000)) RETURNS NVARCHAR(4000)

AS

BEGIN

DECLARE @strg nVARCHAR(4000),@y int,@x int,@w int,@strg1 nVARCHAR(30);

set @strg1='ABCDEFGHIJKLMNOPQRSTUVWXYZ';

set @strg = Upper(rtrim(lTrim(@PresDays)));

If @strg = '' 
   BEGIN
    
    SET @strg = '1'
    
    RETURN @strg
    
   END 
      

set @y = Len(@strg)

set @x = 0

while @x < @y
  begin
	   If charindex(substring(@strg, @x + 1, 1), @strg1, @x+1)<>0
		  begin
		      set @w = charindex(substring(@strg, @x + 1, 1), @strg1, @x+1)
		      
		      set @strg = replace(@strg,substring(@strg1, @w, 1),' ')
			 
		  end

	   set @x = @x+1
	   
  end

RETURN rtrim(lTrim(@strg));

END
go

