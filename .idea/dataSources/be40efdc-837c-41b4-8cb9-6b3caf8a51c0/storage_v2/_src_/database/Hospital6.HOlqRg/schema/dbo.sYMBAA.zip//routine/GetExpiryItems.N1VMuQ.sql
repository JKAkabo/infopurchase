-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetExpiryItems] 
	-- Add the parameters for the stored procedure here

	@selectionCriteria nvarchar(4000)=''
	
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

 if @selectionCriteria<>''
    set @selectionCriteria ='Select Distinct Items.itemID,StockedItems.StoreID, BatchNo,ExpiryDate,Items.Description, IssueUnitQuantity As No_Per_BaseUnit,UnitMeasures.Description As Unit_Name, Sum(StockedItems.StockLevel) as Quantity,' + 
    'StockedItems.UnitCost From UnitMeasures Inner Join (Items Inner Join StockedItems On Items.ItemID = StockedItems.ItemID) On UnitMeasures.Code =Items.IssueUnitCode  ' +
     @selectionCriteria + '  Group By Items.ItemID,Items.Description,BatchNo,ExpiryDate,StockedItems.StoreID,UnitMeasures.Description,IssueUnitQuantity,StockedItems.UnitCost ' +
    'Order by Items.Description Asc'
    
    --exec (@selectionCriteria)

else
	set @selectionCriteria='Select Distinct Items.itemID,StockedItems.StoreID, BatchNo,ExpiryDate,Items.Description, IssueUnitQuantity As No_Per_BaseUnit,UnitMeasures.Description As Unit_Name, Sum(StockedItems.StockLevel) as Quantity,' + 
    'StockedItems.UnitCost From UnitMeasures Inner Join (Items Inner Join StockedItems On Items.ItemID = StockedItems.ItemID) On UnitMeasures.Code =Items.IssueUnitCode ' +  
	' Where Items.Disabled =''No'' and Year(ExpiryDate)<=Year(GetDate()) and Month(ExpiryDate)<=Month(GetDate()) and StockLevel >0  ' +
    'Group By Items.ItemID,Items.Description,BatchNo,ExpiryDate,StockedItems.StoreID,UnitMeasures.Description,IssueUnitQuantity,StockedItems.UnitCost Order by Items.Description Asc'


exec (@selectionCriteria)
	  
END
go

