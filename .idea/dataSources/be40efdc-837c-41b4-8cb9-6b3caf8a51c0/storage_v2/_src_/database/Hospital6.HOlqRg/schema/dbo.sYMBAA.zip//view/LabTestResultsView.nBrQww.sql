



CREATE VIEW [dbo].[LabTestResultsView]
AS

Select StatusCode as PatStatus, LabTechID As UserID, Pat_No, OPDNo, LabTests.TestCode, RequestID, Voluntary, TestRange, Results, LabTestResults.Comments As ResultComment, TestDate, TestTime, LabTests.Comments, TestElements.Description As TestElement, TestElements.UnitMeasure, LabTestResults.ResultsTag As TextTag, LabTestElementRatingTypesViews.Description As RatingDesc, LabTestResults.ElementID As ElementCode From LabTestElementRatingTypesViews Inner Join (TestElements Inner Join ( LabTestElements Inner Join (LabTests  Inner Join LabTestResults On LabTests.RecordID=LabTestResults.TestID) On (LabTestElements.Code=LabTestResults.ElementID And LabTestElements.TestID =LabTestResults.SerID) ) On TestElements.Code= LabTestElements.Code) On LabTestElementRatingTypesViews.Code=LabTestResults.ResultID Where LabTests.Archived='No' AND LabTestResults.Archived='No'

--Select StatusCode as PatStatus, LabTechID As UserID, Pat_No, OPDNo, LabTests.TestCode, RequestID, Voluntary, TestRange, Results, LabTestResults.Comments As ResultComment, TestDate, TestTime, LabTests.Comments, TestElements.Description As TestElement, TestElements.UnitMeasure, LabTestResults.ResultsTag As TextTag, LabTestElementRatingTypesViews.Description As RatingDesc From LabTestElementRatingTypesViews Inner Join (TestElements Inner Join ( LabTests Inner Join (LabTestResults Inner Join LabTestElements On (LabTestResults.ElementID=LabTestElements.Code And LabTestResults.SerID=LabTestElements.TestID)) On LabTests.RecordID=LabTestResults.TestID) On TestElements.Code= LabTestResults.ElementID) On LabTestElementRatingTypesViews.Code=LabTestResults.ResultID Where LabTests.Archived='No'


go

