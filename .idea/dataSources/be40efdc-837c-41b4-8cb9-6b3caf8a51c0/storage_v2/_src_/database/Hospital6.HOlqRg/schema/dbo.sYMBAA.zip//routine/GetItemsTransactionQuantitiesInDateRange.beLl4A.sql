-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetItemsTransactionQuantitiesInDateRange] 
	-- Add the parameters for the stored procedure here

	@itemStore nvarchar(15),@itemID nvarchar(15) ='',@FromDate datetime,
    @ToDate datetime,@TransType nvarchar(15),@itemClass int =0,@ItemUnitType tinyint=1
	
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

if @ItemUnitType=0 
   SET @ItemUnitType=1

if @TransType='ISSUES'
   if @itemID<>''
      if @ItemUnitType=1 
         Select IsNull(Sum(abs(AdjustQty)),0) As MoveQty, ItemID From STOCKMOVEMENT Where IssuerID =@itemStore and itemID=@itemID and ServerDate >=@FromDate and ServerDate <=@ToDate and MoveType IN ('Requisitions','Prescriptions','Return Inwards','Return Outward','Internal Item Usage')  Group By ItemID Order By ItemID
     
      else
         Select IsNull(Sum(abs(convert(Numeric(18,6),AdjustQty/BaseQty))),0) As MoveQty, ItemID From STOCKMOVEMENT Where IssuerID =@itemStore and itemID=@itemID and ServerDate >=@FromDate and ServerDate <=@ToDate and MoveType IN ('Requisitions','Prescriptions','Return Inwards','Return Outward','Internal Item Usage')  Group By ItemID Order By ItemID
      
   else
      if @itemClass=0
         if @ItemUnitType=1 
            Select IsNull(Sum(abs(AdjustQty)),0) As MoveQty, ItemID From STOCKMOVEMENT Where IssuerID =@itemStore and ServerDate >=@FromDate and ServerDate <=@ToDate and MoveType IN ('Requisitions','Prescriptions','Return Inwards','Return Outward','Internal Item Usage')  Group By ItemID Order By ItemID
         
         else
            Select IsNull(Sum(abs(convert(Numeric(18,6),AdjustQty/BaseQty))),0) As MoveQty, ItemID From STOCKMOVEMENT Where IssuerID =@itemStore and ServerDate >=@FromDate and ServerDate <=@ToDate and MoveType IN ('Requisitions','Prescriptions','Return Inwards','Return Outward','Internal Item Usage')  Group By ItemID Order By ItemID
         
      else
         if @ItemUnitType=1 
            Select IsNull(Sum(abs(AdjustQty)),0) As MoveQty, STOCKMOVEMENT.ItemID From Items Inner Join STOCKMOVEMENT On Items.ItemID=STOCKMOVEMENT.ItemID Where ItemClassCode=@itemClass And IssuerID =@itemStore and STOCKMOVEMENT.ServerDate >=@FromDate and STOCKMOVEMENT.ServerDate <=@ToDate and MoveType IN ('Requisitions','Prescriptions','Return Inwards','Return Outward','Internal Item Usage')  Group By STOCKMOVEMENT.ItemID Order By STOCKMOVEMENT.ItemID
         
         else
            Select IsNull(Sum(abs(convert(Numeric(18,6),AdjustQty/BaseQty))),0) As MoveQty, STOCKMOVEMENT.ItemID From Items Inner Join STOCKMOVEMENT On Items.ItemID=STOCKMOVEMENT.ItemID Where ItemClassCode=@itemClass And IssuerID =@itemStore and STOCKMOVEMENT.ServerDate >=@FromDate and STOCKMOVEMENT.ServerDate <=@ToDate and MoveType IN ('Requisitions','Prescriptions','Return Inwards','Return Outward','Internal Item Usage')  Group By STOCKMOVEMENT.ItemID Order By STOCKMOVEMENT.ItemID
         
if @TransType='RECEIPTS'
   if @itemID<>''
      if @ItemUnitType=1 
         Select IsNull(Sum(abs(AdjustQty)),0) As MoveQty, ItemID From STOCKMOVEMENT Where ReceiverID= @itemStore and itemID=@itemID  and ServerDate >=@FromDate and ServerDate <=@ToDate and MoveType IN ('Orders','Requisitions','Return Inwards','Prescription Returns') Group By ItemID Order By ItemID
      
      else
         Select IsNull(Sum(abs(convert(Numeric(18,6),AdjustQty/BaseQty))),0) As MoveQty, ItemID From STOCKMOVEMENT Where ReceiverID= @itemStore and itemID=@itemID  and ServerDate >=@FromDate and ServerDate <=@ToDate and MoveType IN ('Orders','Requisitions','Return Inwards','Prescription Returns') Group By ItemID Order By ItemID
      
   else
      if @itemClass=0
         if @ItemUnitType=1 
    Select IsNull(Sum(abs(AdjustQty)),0) As MoveQty, ItemID From STOCKMOVEMENT Where ReceiverID =@itemStore and ServerDate >=@FromDate and ServerDate <=@ToDate and MoveType IN ('Orders','Requisitions','Return Inwards','Prescription Returns')  Group By ItemID Order By ItemID
         
         else
            Select IsNull(Sum(abs(convert(Numeric(18,6),AdjustQty/BaseQty))),0) As MoveQty, ItemID From STOCKMOVEMENT Where ReceiverID =@itemStore and ServerDate >=@FromDate and ServerDate <=@ToDate and MoveType IN ('Orders','Requisitions','Return Inwards','Prescription Returns')  Group By ItemID Order By ItemID
         
      else
         if @ItemUnitType=1 
            Select IsNull(Sum(abs(AdjustQty)),0) As MoveQty, STOCKMOVEMENT.ItemID From Items Inner Join STOCKMOVEMENT On Items.ItemID=STOCKMOVEMENT.ItemID Where ItemClassCode=@itemClass And ReceiverID =@itemStore and STOCKMOVEMENT.ServerDate >=@FromDate and STOCKMOVEMENT.ServerDate <=@ToDate and MoveType IN ('Orders','Requisitions','Return Inwards','Prescription Returns')  Group By STOCKMOVEMENT.ItemID Order By STOCKMOVEMENT.ItemID
         
         else
            Select IsNull(Sum(abs(convert(Numeric(18,6),AdjustQty/BaseQty))),0) As MoveQty, STOCKMOVEMENT.ItemID From Items Inner Join STOCKMOVEMENT On Items.ItemID=STOCKMOVEMENT.ItemID Where ItemClassCode=@itemClass And ReceiverID =@itemStore and STOCKMOVEMENT.ServerDate >=@FromDate and STOCKMOVEMENT.ServerDate <=@ToDate and MoveType IN ('Orders','Requisitions','Return Inwards','Prescription Returns')  Group By STOCKMOVEMENT.ItemID Order By STOCKMOVEMENT.ItemID
         
if @TransType='ADJUSTMENTS'
   if @itemID<>''
      if @ItemUnitType=1 
         Select IsNull(Sum(AdjustQty),0) As MoveQty, ItemID From STOCKMOVEMENT Where ReceiverID= @itemStore and itemID=@itemID  and ServerDate >=@FromDate and ServerDate <=@ToDate and MoveType IN ('StockAdjustments','Initial Stocks','Expired Stocks','Obsolete Stocks') Group By ItemID Order By ItemID
      
      else
         Select IsNull(Sum(convert(Numeric(18,6),AdjustQty/BaseQty)),0) As MoveQty, ItemID From STOCKMOVEMENT Where ReceiverID= @itemStore and itemID=@itemID  and ServerDate >=@FromDate and ServerDate <=@ToDate and MoveType IN ('StockAdjustments','Initial Stocks','Expired Stocks','Obsolete Stocks') Group By ItemID Order By ItemID
      
   else
      if @itemClass=0
         if @ItemUnitType=1 
            Select IsNull(Sum(AdjustQty),0) As MoveQty, ItemID From STOCKMOVEMENT Where ReceiverID =@itemStore and ServerDate >=@FromDate and ServerDate <=@ToDate and MoveType IN ('StockAdjustments','Initial Stocks','Expired Stocks','Obsolete Stocks')  Group By ItemID Order By ItemID
         
         else
            Select IsNull(Sum(convert(Numeric(18,6),AdjustQty/BaseQty)),0) As MoveQty, ItemID From STOCKMOVEMENT Where ReceiverID =@itemStore and ServerDate >=@FromDate and ServerDate <=@ToDate and MoveType IN ('StockAdjustments','Initial Stocks','Expired Stocks','Obsolete Stocks')  Group By ItemID Order By ItemID
         
      else
         if @ItemUnitType=1 
            Select IsNull(Sum(AdjustQty),0) As MoveQty, STOCKMOVEMENT.ItemID From Items Inner Join STOCKMOVEMENT On Items.ItemID=STOCKMOVEMENT.ItemID Where ItemClassCode=@itemClass And ReceiverID =@itemStore and STOCKMOVEMENT.ServerDate >=@FromDate and STOCKMOVEMENT.ServerDate <=@ToDate and MoveType IN ('StockAdjustments','Initial Stocks','Expired Stocks','Obsolete Stocks')  Group By STOCKMOVEMENT.ItemID Order By STOCKMOVEMENT.ItemID
	        
	        else
            Select IsNull(Sum(convert(Numeric(18,6),AdjustQty/BaseQty)),0) As MoveQty, STOCKMOVEMENT.ItemID From Items Inner Join STOCKMOVEMENT On Items.ItemID=STOCKMOVEMENT.ItemID Where ItemClassCode=@itemClass And ReceiverID =@itemStore and STOCKMOVEMENT.ServerDate >=@FromDate and STOCKMOVEMENT.ServerDate <=@ToDate and MoveType IN ('StockAdjustments','Initial Stocks','Expired Stocks','Obsolete Stocks')  Group By STOCKMOVEMENT.ItemID Order By STOCKMOVEMENT.ItemID
	        


END
go

