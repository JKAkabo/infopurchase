CREATE VIEW [dbo].[TriageParameterValuesView]

AS

SELECT Distinct LTypeID, UTypeID, TriageScore AS TestID, AgeGroupCode,GenderCode,ParameterID,LowerValue,UpperValue,CONVERT(nvarchar(5),TriageScore) As TextTag,ColourTag,RecordID,RatingID ,LabTestElementRatingTypes.Description As RatingDesc, ParamUnit, (LowerValue + ' - ' + UpperValue) AS ValueRange, ValueTypeID From TriageParametersSetup Inner Join ( LabTestElementRatingTypes Inner Join TriageParamterValues On LabTestElementRatingTypes.Code=RatingID) On TriageParametersSetup.Code=ParameterID Where  ValueTypeID=1

Union

SELECT Distinct  LTypeID, LTypeID As UTypeID, TriageScore AS TestID, AgeGroupCode,GenderCode,ParameterID,LowerValue, LowerValue As UpperValue, CONVERT(nvarchar(5),TriageScore) AS TextTag,ColourTag,RecordID,RatingID ,LabTestElementRatingTypes.Description As RatingDesc, ParamUnit, LowerValue AS ValueRange, ValueTypeID From TriageParametersSetup Inner Join ( LabTestElementRatingTypes Inner Join TriageParamterValues On LabTestElementRatingTypes.Code=RatingID) On TriageParametersSetup.Code=ParameterID Where ValueTypeID=2
go

