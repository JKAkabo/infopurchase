CREATE PROCEDURE [dbo].[uspUpdateEpisodesIssuedDrugsFlags] 

@StartDate datetime,@EndDate Datetime
	
AS

DECLARE @OPDNo nvarchar(15),@EpisodeID numeric(18,0),@RecordID numeric(18,0),@PresQty numeric(18,0),@GivenQty numeric(18,0),@RTQty numeric(18,0)

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct  Episode.OPDNo, Episode.episodeID From Episode Inner Join Prescriptions on  Episode.OPDNo=Prescriptions.OPDNo And Episode.EpisodeID=Prescriptions.EpisodeID Where Prescriptions.Archived='No'  And Episode.Archived='No'  And Prescriptions.EpisodeID<>0 And Prescriptions.ReqDate>=@StartDate and  Prescriptions.ReqDate<=@EndDate And ReturnedQty=0 And DrugFlag='0' And UPPER(PresType)='INTERNAL' Order by Episode.episodeID
            
  OPEN C
  
  FETCH NEXT FROM C INTO @OPDNo, @EpisodeID       

  WHILE @@fetch_status = 0
    BEGIN
   
     DECLARE D CURSOR FAST_FORWARD FOR SELECT IsNull(Sum(QtyGiven),0) As QtyGiven From Prescriptions Where EpisodeID=@EpisodeID And OPDNo=@OPDNo And DrugFlag='0' And UPPER(PresType)='INTERNAL' And Prescriptions.Archived='No' And ReturnedQty=0
     
     OPEN D
     
     FETCH NEXT FROM D INTO @GivenQty
     
     WHILE @@fetch_status = 0
     
		 BEGIN
		     if @GivenQty=0
			    update Episode Set DrugUnIssued='Yes', DrugIssued='No' Where EpisodeID=@EpisodeID and OPDNo=@OPDNo
		     
		     else
			    update Episode Set DrugUnIssued='No', DrugIssued='Yes' Where EpisodeID=@EpisodeID and OPDNo=@OPDNo
		     
			 FETCH NEXT FROM D INTO @GivenQty
	     
		 END
	     
	 CLOSE D;
     
     DEALLOCATE D;
     
  FETCH NEXT FROM C INTO @OPDNo, @EpisodeID        

	END

	CLOSE C;

	DEALLOCATE C;
	


END
go

