CREATE VIEW [dbo].[ServicesPaidAdjustments]

AS
-- And PmtModeCode IN (1,2,7)
SELECT SUM(ServiceLinePayments.PaidAmt) As PaidAmt, MMAmt, BillsPaid.PmtModeCode, BillsPaid.ReceiptNo,BillsPaid.AmtPaid,BillsPaid.BillOut,BillsPaid.RefAmtRequested,DepAmtUsed,SUM(ServiceLinePayments.PaidAmt)- AmtPaid As BillTotal, DepAmt, 'DEPTSER' As UsedDepositCode, 'DEPTSER' As UsedDepositPlaceCode, 'DEPTSER' As UsedDepositClinicCode,

'' As SponsorNo,1 As BillCategoryCode,1 As PmtTypeCode,BillsPaid.OPDNo,BillsPaid.PmtDate,BillsPaid.PmtTime,BillsPaid.Pat_No,BillsPaid.PatAge,BillsPaid.UserID,CASE WHEN DepAmt=0 THEN 0 WHEN BillOut=0 AND DepAmt<=SUM(ServiceLinePayments.PaidAmt) THEN -DepAmt WHEN BillOut=0 AND DepAmt>SUM(ServiceLinePayments.PaidAmt) THEN -SUM(ServiceLinePayments.PaidAmt)

WHEN BillOut>0 AND DepAmt-BillOut>=SUM(ServiceLinePayments.PaidAmt) THEN -(DepAmt-BillOut) WHEN BillOut>0 AND DepAmt-BillOut<SUM(ServiceLinePayments.PaidAmt) THEN -(DepAmt-BillOut) WHEN BillOut<0 AND abs(BillOut)>=SUM(ServiceLinePayments.PaidAmt) THEN 0

WHEN BillOut<0 AND abs(BillOut) + DepAmt <=SUM(ServiceLinePayments.PaidAmt) THEN -DepAmt WHEN BillOut<0 AND abs(BillOut) + DepAmt >SUM(ServiceLinePayments.PaidAmt) THEN -(abs(DepAmt-(SUM(ServiceLinePayments.PaidAmt) - abs(BillOut)))) ELse 0 End As UsedDeposit

,CASE WHEN BillOut>=0 and abs(BillOut)<=SUM(ServiceLinePayments.PaidAmt) THEN BillOut WHEN BillOut>=0 and abs(BillOut)>SUM(ServiceLinePayments.PaidAmt) THEN SUM(ServiceLinePayments.PaidAmt) ELSE 0 End As OutBill, 'OUTBILLPMT' As OutBillCode, 'OUTBILLPMT' As OutBillPlaceCode, 'OUTBILLPMT' As OutBillClinicCode

,CASE WHEN AmtPaid>0 And AmtPaid> SUM(ServiceLinePayments.PaidAmt) + BillOut + IOUAmt - (DepAmt +DisAmt) THEN AmtPaid-((SUM(ServiceLinePayments.PaidAmt) + BillOut + IOUAmt) - (DepAmt +DisAmt)) ELSE 0 End As BillApproxi, 'BILLAPPR' As BillApprCode, 'BILLAPPR' As BillApprCodePlaceCode, 'BILLAPPR' As BillApprCodeClinicCode

FROM BillsPaid, ServiceLinePayments Where BillsPaid.ReceiptNo =ServiceLinePayments.ReceiptNo And Pat_ID=BillsPaid.OPDNo and ServiceLinePayments.PmtTypeCode=1 and ServiceLinePayments.BillCategoryCode=1  

Group By BillsPaid.ReceiptNo,BillsPaid.OPDNo,BillsPaid.Pat_No,BillsPaid.PmtModeCode,BillsPaid.PatAge,BillsPaid.UserID,BillsPaid.AmtPaid,BillsPaid.BillOut,BillsPaid.RefAmtRequested,DepAmtUsed,DepAmt,BillsPaid.PmtDate,BillsPaid.PmtTime, IOUAmt, DisAmt, MMAmt

--UNION ALL

--SELECT SUM(ServiceLinePayments.PaidAmt) As PaidAmt,BillsPaid.ReceiptNo,BillsPaid.AmtPaid,BillsPaid.BillOut,BillsPaid.RefAmtRequested,DepAmtUsed,TBill As BillTotal, DepAmt, 'OUTBILLPMT' As AdjustCode, 'OUTBILLPMT' As AdjustPlaceCode, 'OUTBILLPMT' As AdjustClinicCode,

--'' As SponsorNo,1 As BillCategoryCode,1 As PmtTypeCode,BillsPaid.OPDNo,BillsPaid.PmtDate,BillsPaid.PmtTime,BillsPaid.Pat_No,BillsPaid.PatAge,BillsPaid.UserID,CASE WHEN BillOut<=0 and abs(BillOut)<=SUM(ServiceLinePayments.PaidAmt) THEN BillOut 
--WHEN BillOut<=0 and abs(BillOut)>SUM(ServiceLinePayments.PaidAmt) THEN SUM(ServiceLinePayments.PaidAmt) ELSE 0 End As AdjustBill
 

--FROM BillsPaid, ServiceLinePayments Where BillsPaid.ReceiptNo =ServiceLinePayments.ReceiptNo And Pat_ID=BillsPaid.OPDNo and ServiceLinePayments.PmtTypeCode=1 and ServiceLinePayments.BillCategoryCode=1  

--Group By BillsPaid.ReceiptNo,BillsPaid.OPDNo,BillsPaid.Pat_No,BillsPaid.PatAge,BillsPaid.UserID,BillsPaid.AmtPaid,BillsPaid.BillOut,BillsPaid.RefAmtRequested,DepAmtUsed,DepAmt,BillsPaid.PmtDate,BillsPaid.PmtTime, IOUAmt, DisAmt

--UNION ALL

--SELECT AmtPaid As PaidAmt,BillsPaid.ReceiptNo,BillsPaid.AmtPaid,BillsPaid.BillOut,BillsPaid.RefAmtRequested,DepAmtUsed, TBill, DepAmt, 'DEPTSER' 'DEPTSER', 'DEPTSER' ,

--'' As SponsorNo,1 As BillCategoryCode,1 As PmtTypeCode,BillsPaid.OPDNo,BillsPaid.PmtDate,BillsPaid.PmtTime,BillsPaid.Pat_No,BillsPaid.PatAge,BillsPaid.UserID, BillsPaid.DepAmtUsed, 0 FROM BillsPaid Where ReceiptNo + OPDNo IN (Select ReceiptNo + Pat_ID From ServiceLinePayments)


--UNION ALL

--SELECT AmtPaid As PaidAmt,BillsPaid.ReceiptNo,BillsPaid.AmtPaid,BillsPaid.BillOut,BillsPaid.RefAmtRequested,DepAmtUsed, TBill, DepAmt, 'BILLAPPR', 'BILLAPPR', 'BILLAPPR',

--'' As SponsorNo,1 As BillCategoryCode,1 As PmtTypeCode,BillsPaid.OPDNo,BillsPaid.PmtDate,BillsPaid.PmtTime,BillsPaid.Pat_No,BillsPaid.PatAge,BillsPaid.UserID, BillsPaid.DepAmtUsed, 0, 'BILLAPPR', 'BILLAPPR', 'BILLAPPR', 
--BillApprox, 'BILLAPPR', 'BILLAPPR', 'BILLAPPR' FROM BillsPaid Where ReceiptNo + OPDNo IN (Select ReceiptNo + Pat_ID From ServiceLinePayments)
go

