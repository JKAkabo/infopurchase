CREATE VIEW [dbo].[LabTestVerifiersView]

AS

SELECT Distinct LEFT(Users.UserID,100) As UserID, LabResultAcceptanceTests.AcceptID,dbo.LabResultAcceptance.AcceptDate FROM Users, LabResultAcceptance, dbo.LabResultAcceptanceTests  Where Users.UserNo=LabResultAcceptanceTests.UserID And LabResultAcceptance.RecordID=LabResultAcceptanceTests.AcceptID And LabResultAcceptanceTests.Archived='No' And LabResultAcceptance.Archived='No'

Union

SELECT '' As UserID, 0 As  AcceptID, GETDATE() FROM dbo.Hosp_Info
go

