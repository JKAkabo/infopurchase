CREATE PROCEDURE [dbo].[uspUpdateHAMSDiagnoses] 
	
AS

DECLARE @DisCatCode nvarchar(15),@ReqProcedure nvarchar(15),@Diagnostic nvarchar(15),@DisCatCode3 nvarchar(15),@DisCatCode2 nvarchar(15),
@GenderID tinyint,@DisCount1 int,@IsChronic nvarchar(15),@DiaDesc nvarchar(250),@PatTypeID tinyint,@AgeGrpID tinyint ;

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct Code, ReqProcedure, Diagnostic, Gender, IsChronic from TempWHODiseases W where RTRIM(LTRIM(Code))<>'' order By Code
  
  OPEN C
  
  FETCH NEXT FROM C INTO @DisCatCode, @ReqProcedure,@Diagnostic,@DisCatCode3,@IsChronic;

  WHILE @@fetch_status = 0
    BEGIN
    
       if UPPER(ltrim(rtrim(@ReqProcedure)))='N'   
          set @ReqProcedure= 'No'
          
       else
          set @ReqProcedure= 'Yes'
          
       if UPPER(ltrim(rtrim(@Diagnostic)))='N'   
          set @Diagnostic= 'No'
          
       else
          set @Diagnostic= 'Yes'
       
       if UPPER(ltrim(rtrim(@IsChronic)))='N'   
          set @IsChronic= 'No'
          
       else
          set @IsChronic= 'Yes'
  
       if UPPER(ltrim(rtrim(@DisCatCode3)))='M/F'   
          set @GenderID= 1
       
       else if UPPER(ltrim(rtrim(@DisCatCode3)))='M' 
          set @GenderID= 2
          
       else
          set @GenderID= 3
  
       update WHODiseases Set GenderCode=@GenderID,AgeGroupCode=3, PatientType=1,IsChronic=@IsChronic 
       ,Diagnostic=@Diagnostic, ReqProcedure=@ReqProcedure Where Code=@DisCatCode

       FETCH NEXT FROM C INTO @DisCatCode, @ReqProcedure,@Diagnostic,@DisCatCode3,@IsChronic;

	END

	CLOSE C;

	DEALLOCATE C;

  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct DisCode, Code, W.IsChronic, ReqProcedure, Diagnostic,W.GenderCode,UPPER(Ltrim(Rtrim(Disease))) from Diseases D, WHODiseases W 
  where ICDCode <> Code and RTRIM(LTRIM(Code))<>'' and UPPER(Ltrim(Rtrim(Disease)))=UPPER(Ltrim(Rtrim(DisDescription))) order By DisCode
  
  OPEN C
  
  FETCH NEXT FROM C INTO @DisCatCode, @DisCatCode3, @IsChronic, @ReqProcedure, @Diagnostic, @GenderID,@DiaDesc;

  WHILE @@fetch_status = 0
    BEGIN
       
       if @GenderID=0                           
          update Diseases Set ICDCode=@DisCatCode3, WHODescription=@DiaDesc where DisCode=@DisCatCode
       
       else
          update Diseases Set ICDCode=@DisCatCode3, GenderCode=@GenderID, IsChronic=@IsChronic  
          ,RequiresInves=@Diagnostic, RequiresSurgery=@ReqProcedure, WHODescription=@DiaDesc Where DisCode=@DisCatCode
       
       FETCH NEXT FROM C INTO @DisCatCode, @DisCatCode3, @IsChronic, @ReqProcedure, @Diagnostic, @GenderID, @DiaDesc;

	END

	CLOSE C;

	DEALLOCATE C;
	   
 DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct UPPER(Ltrim(Rtrim(Disease))), Code, W.IsChronic, ReqProcedure, Diagnostic, W.GenderCode,PatientType,AgeGroupCode From WHODiseases W 
  Where Code NOT IN (Select ICDCode From Diseases) and RTRIM(LTRIM(Code))<>'' and UPPER(Ltrim(Rtrim(Disease)))<>'' order By Code
  
  OPEN C
  
  FETCH NEXT FROM C INTO @DiaDesc, @DisCatCode3, @IsChronic, @ReqProcedure, @Diagnostic, @GenderID, @PatTypeID, @AgeGrpID;

  WHILE @@fetch_status = 0
    BEGIN
       
	   SELECT TOP 1 @DisCatCode=DisCode, @DisCount1=CONVERT(int, DisCode) + 1, @DisCatCode2=rtrim(ltrim(str(CONVERT(int, DisCode) + 1))) From Diseases order By DisCode Desc
		 
	   set @DisCatCode=REPLICATE('0',LEN(@DisCatCode) - Len(rtrim(ltrim(str(@DisCount1))))) + @DisCatCode2;
       
       INSERT INTO Diseases (DisCode,MainDiseaseCode,DisDescription,ClassCode,CategoryCode,AdultFee,ChildFee,ICDGroup,RequiresSurgery,
       ICDCode,AgeGroupCode,GenderCode,IsChronic,UserID,DataDate,NHIACovered,RequiresInves,PmtType,GDRGCode, GDRGCodeA, GDRGCodeC, 
       DrgSpecCode, PresUnitCode, ComplaintsMinNo,WHODescription)Values(@DisCatCode,@DisCatCode,UPPER(RTRIM(LTRIM(@DiaDesc))),0,0,0,0,LEFT(@DisCatCode3,3),@ReqProcedure,@DisCatCode3,
       @AgeGrpID,@GenderID,@IsChronic,'00001',GETDATE(),'No',@Diagnostic,2,'','','',0,0,1,UPPER(RTRIM(LTRIM(@DiaDesc))))
       
       FETCH NEXT FROM C INTO @DiaDesc, @DisCatCode3, @IsChronic, @ReqProcedure, @Diagnostic, @GenderID, @PatTypeID, @AgeGrpID;

	END

	CLOSE C;

	DEALLOCATE C;
	    
    update Diseases Set CategoryCode=(Select CategoryCode From Diseases D Where Left(D.ICDCode,3)=Left(Diseases.ICDCode,3) And D.CategoryCode<>0) 
    Where CategoryCode=0 

    update Diseases Set ClassCode=(Select ClassCode From Diseases D Where Left(D.ICDCode,3)=Left(Diseases.ICDCode,3) And D.ClassCode<>0) 
    Where ClassCode=0 

    update Diseases Set GenderCode=1, AgeGroupCode=3 Where AgeGroupCode=0

	--Select Distinct DiseaseGroupCode from WHODiseases order By DiseaseGroupCode Asc

	--Select Distinct BlockCode from WHODiseases order By BlockCode Asc

	--Select Distinct Disease, Code from WHODiseases where Code<>DiseaseGroupCode order By Code Asc

	--Select Distinct * from Diseases where DisDescription Like '%Cholera%' or ICDCode Like '%A0%'

	--Select Distinct Disease,DisDescription  from Diseases D, WHODiseases W where ICDCode = Code and UPPER(Ltrim(Rtrim(Disease)))<>UPPER(Ltrim(Rtrim(DisDescription)))

	--Select Distinct Code, DisCode from Diseases D, WHODiseases W where ICDCode <> Code and UPPER(Ltrim(Rtrim(Disease)))=UPPER(Ltrim(Rtrim(DisDescription)))

	--Select Distinct Disease, Code from WHODiseases where len(Disease)=200  order By Code Asc

	--Select Distinct Disease, Code from WHODiseases where code='L04.9'  order By Code Asc

	--Select  D.* from Diseases D, WHODiseases W 
	--where UPPER(Ltrim(Rtrim(Disease)))=UPPER(Ltrim(Rtrim(DisDescription))) and Code NOT IN (Select Code from WHODiseases)

	--Update Diseases Set ICDCode =Isnull((Select TOP 1 Code from WHODiseases W 
	--where Diseases.ICDCode <> Code  and UPPER(Ltrim(Rtrim(Disease)))=UPPER(Ltrim(Rtrim(Diseases.DisDescription)))),'') 

	--Select Distinct Code, DisCode, D.DisDescription,W.Disease from Diseases D, WHODiseases W where 
	--ICDCode = Code and UPPER(Ltrim(Rtrim(Disease)))<>UPPER(Ltrim(Rtrim(DisDescription)))


	--Select  D.* from Diseases D, WHODiseases W 
	--where ICDCode = Code and UPPER(Ltrim(Rtrim(DisDescription))) NOT IN (Select UPPER(Ltrim(Rtrim(Disease))) from WHODiseases)

END
go

