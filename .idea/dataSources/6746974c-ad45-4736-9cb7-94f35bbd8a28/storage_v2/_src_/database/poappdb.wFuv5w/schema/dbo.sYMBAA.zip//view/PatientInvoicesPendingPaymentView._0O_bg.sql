CREATE VIEW [dbo].[PatientInvoicesPendingPaymentView]

AS

SELECT  DOB,GenderCode,Surname,LastName,MiddleName,Title,P.StatusCode,P.PatStatus,Gender,P.PatientCategory,PatientAge,B.OPDNo,B.Pat_No, 
B.AmtPaid,ReceiptNo,B.PmtDate,B.PmtTime,B.TBill,B.UserID As BillerID,U.UserID As Biller, B.PmtModeCode, M.Description As PaymentMode,MMNetwork,MMWalletNo,
ISNULL((Select TOP 1 InvoiceNo From HAMSBANKPAYMENTS where InvoiceNo=B.ReceiptNo and Cancelled='No'),'') As InvoiceNo,B.MMAmt,MMTransID,MMTken 
FROM PatientInfoView P, BillsPaid B, Users U,PaymentModes M, ServicesConfigurationSetupView S 
Where P.OPDNo=B.Pat_No and P.PatientID=B.OPDNo and B.Archived='No' and U.UserNo=B.UserID and M.Code=B.PmtModeCode And S.CAPID=B.CAP_ID
and ((S.OnSiteBankInterfaced =1 And B.PmtModeCode IN (1,6,7)) OR (S.OnSiteBankInterfaced =0 And B.PmtModeCode IN (6,7)) )
go

