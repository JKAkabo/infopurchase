CREATE VIEW [dbo].[DirectoratesView]

AS

SELECT  Description, ID, DirectAttType FROM dbo.Directorates

Union

SELECT  '' As Description, 0 As ID, 1 as DirectAttType  FROM dbo.Hosp_Info
go

