CREATE VIEW [dbo].[AccountNHIATransactionsView]

AS

--Diagnoses and Investigative Services
SELECT
 
S.ServiceCode As ServiceCode, S.ServiceFee * S.RequiredQty As TransAmt, E.EndEpisode As TransDate,J.TransTypeID, J.AcctCode AS CreditAcctCode,
UPPER(A.Description) as CreditAcctName,UPPER(T.Description) as CreditPostType,
ISNULL((Select TOP 1 UPPER(N.Description) From AccountCustomersVendors N Where P.SponsorNo=N.MappedCode and N.TypeID=9),'') As Debtor,
P.SponsorNo As ClientID, M.ServiceTypeID,P.SponsorTypeCode,

ISNULL((Select TOP 1 B.AcctCode From AccountChartSetup G,AccountPostingType K,AccountsChartJournalMapping B, AccountChartServicesMapping X  
Where B.TransTypeID=13 AND B.AcctTypeID=9 And G.Code=B.AcctCode And B.TransTypeID=J.TransTypeID AND B.AcctTypeIDJE=J.AcctTypeID And X.ServiceTypeID=4 AND 
B.AcctCodeJE=J.AcctCode And B.AcctCode=X.AccountChartCode And X.PostingType=13 AND X.ServiceID=P.SponsorNo AND K.Code=B.AcctPostType And B.AcctPostType=1),'') As DebitAcctCode, 

ISNULL((Select TOP 1 UPPER(G.Description) From AccountChartSetup G,AccountPostingType K,AccountsChartJournalMapping B, AccountChartServicesMapping X  
Where B.TransTypeID=13 AND B.AcctTypeID=9 And G.Code=B.AcctCode And B.TransTypeID=J.TransTypeID AND B.AcctTypeIDJE=J.AcctTypeID And X.ServiceTypeID=4 AND 
B.AcctCodeJE=J.AcctCode And B.AcctCode=X.AccountChartCode And X.PostingType=13 AND X.ServiceID=P.SponsorNo AND K.Code=B.AcctPostType And B.AcctPostType=1),'') As DebitAcctName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup G,AccountPostingType K,AccountsChartJournalMapping B , AccountChartServicesMapping X 
Where B.TransTypeID=13 AND B.AcctTypeID=9 And G.Code=B.AcctCode And B.TransTypeID=J.TransTypeID AND B.AcctTypeIDJE=J.AcctTypeID And X.ServiceTypeID=4 AND 
B.AcctCodeJE=J.AcctCode And B.AcctCode=X.AccountChartCode And X.PostingType=13 AND X.ServiceID=P.SponsorNo AND K.Code=B.AcctPostType And B.AcctPostType=1),'') As DebitPostType

, CASE WHEN RTrim(LTrim(E.EpisodeAllBatchNo)) NOT IN ('','None') THEN 'NH' + REPLACE(RIGHT(E.EpisodeAllBatchNo,10),'/','') ELSE '' END AS TransID, S.ServicePlaceID

FROM 

Sponsors P, Episode E, NHIAEpisodeServices S,AccountChartServicesMapping M, AccountChartSetup A,AccountPostingType T,  
AccountsChartJournalMappingView J, ServicesConfigurationSetupView V

WHERE 

M.ServiceTypeID=2 And S.ServiceTypeCode IN (2,11,12,13,14) AND J.AcctTypeID=1 And E.EpisodeID=S.EpisodeID And P.SponsorNo =E.SponsorNo AND J.TransTypeID=13 And A.Code=J.AcctCode And 
T.Code=J.AcctPostType And J.TransTypeID=M.PostingType And J.AcctCode=M.AccountChartCode  And P.SponsorTypeCode=2
And A.Code=M.AccountChartCode And J.AcctPostType=2  And (((V.AcctsServicesMapID=4 and M.ServiceID = S.ServicePlaceID AND M.ServiceTypeID=2 And S.ServiceTypeCode IN (2,11,12,13,14)) OR
(V.AcctsServicesMapID=3 and M.ServiceID = S.ServiceTypeCode AND M.ServiceTypeID=2 And S.ServiceTypeCode IN (2,11,12,13,14)) OR (V.AcctsServicesMapID=2 and M.ServiceID = S.ServiceCode AND M.ServiceTypeID=2 And S.ServiceTypeCode IN (2,11,12,13,14))))

And

E.EpisodeID=S.EpisodeID And E.OPDNo=S.OPDNo And P.SponsorNo=E.SponsorNo And E.Archived='No' and NoOfVisit>0 And S.ServiceFee>0  
and  UPPER(S.RequestType)='INTERNAL' And E.IsDuplicate='No' And E.ClaimDataProcessed='Yes' And E.EpisodeSpecialityCode<>'' 
And ((E.EpisodePrinted='Yes' OR (E.EclaimProcessed='Yes' And E.EpisodeAllBatchNo<>'')) And (E.EpisodeBatchNo<>'' And E.EpisodeBatchNo<>'None')) 
And ((AttType<>2 And E.ClaimGDRGCode<>'' And E.ServiceType IN (2) And E.Service_Code=S.ServiceCode) OR ((AttType=2 OR E.EpisodePmtType=3) And DiagnosticFee>0 And S.ServiceTypeCode IN (11,12,13,14))) 
And E.EpisodeSpecialityCode IN (Select Code From NHIAMDCS) 

UNION ALL

--Consultation, Surgery, Detention and Referral Services
SELECT
 
E.Service_Code As ServiceCode, E.ServiceFee As TransAmt, E.EndEpisode As TransDate,J.TransTypeID, J.AcctCode AS CreditAcctCode,
UPPER(A.Description) as CreditAcctName,UPPER(T.Description) as CreditPostType,
ISNULL((Select TOP 1 UPPER(N.Description) From AccountCustomersVendors N Where P.SponsorNo=N.MappedCode and N.TypeID=9),'') As Debtor,
P.SponsorNo As ClientID, M.ServiceTypeID,P.SponsorTypeCode,

ISNULL((Select TOP 1 B.AcctCode From AccountChartSetup G,AccountPostingType K,AccountsChartJournalMapping B, AccountChartServicesMapping X  
Where B.TransTypeID=13 AND B.AcctTypeID=9 And G.Code=B.AcctCode And B.TransTypeID=J.TransTypeID AND B.AcctTypeIDJE=J.AcctTypeID And X.ServiceTypeID=4 AND 
B.AcctCodeJE=J.AcctCode And B.AcctCode=X.AccountChartCode And X.PostingType=13 AND X.ServiceID=P.SponsorNo AND K.Code=B.AcctPostType And B.AcctPostType=1),'') As DebitAcctCode, 

ISNULL((Select TOP 1 UPPER(G.Description) From AccountChartSetup G,AccountPostingType K,AccountsChartJournalMapping B, AccountChartServicesMapping X  
Where B.TransTypeID=13 AND B.AcctTypeID=9 And G.Code=B.AcctCode And B.TransTypeID=J.TransTypeID AND B.AcctTypeIDJE=J.AcctTypeID And X.ServiceTypeID=4 AND 
B.AcctCodeJE=J.AcctCode And B.AcctCode=X.AccountChartCode And X.PostingType=13 AND X.ServiceID=P.SponsorNo AND K.Code=B.AcctPostType And B.AcctPostType=1),'') As DebitAcctName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup G,AccountPostingType K,AccountsChartJournalMapping B , AccountChartServicesMapping X 
Where B.TransTypeID=13 AND B.AcctTypeID=9 And G.Code=B.AcctCode And B.TransTypeID=J.TransTypeID AND B.AcctTypeIDJE=J.AcctTypeID And X.ServiceTypeID=4 AND 
B.AcctCodeJE=J.AcctCode And B.AcctCode=X.AccountChartCode And X.PostingType=13 AND X.ServiceID=P.SponsorNo AND K.Code=B.AcctPostType And B.AcctPostType=1),'') As DebitPostType

, CASE WHEN RTrim(LTrim(E.EpisodeAllBatchNo)) NOT IN ('','None') THEN 'NH' + REPLACE(RIGHT(E.EpisodeAllBatchNo,10),'/','') ELSE '' END AS TransID, R.ServicePlaceCode

FROM 

Sponsors P, Episode E,AccountChartServicesMapping M, AccountChartSetup A,AccountPostingType T,  
AccountsChartJournalMappingView J, ServicesConfigurationSetupView V, Service_Types R

WHERE 

M.ServiceTypeID=2 And E.ServiceType IN (3,5,16,17) AND J.AcctTypeID=1 And E.Service_Code=R.ServiceCode And P.SponsorNo =E.SponsorNo AND J.TransTypeID=13 And A.Code=J.AcctCode And 
T.Code=J.AcctPostType And J.TransTypeID=M.PostingType And J.AcctCode=M.AccountChartCode  And P.SponsorTypeCode=2
And A.Code=M.AccountChartCode And J.AcctPostType=2  And (((V.AcctsServicesMapID=4 and M.ServiceID = R.ServicePlaceCode AND M.ServiceTypeID=2 And E.ServiceType IN (3,5,16,17) ) OR
(V.AcctsServicesMapID=3 and M.ServiceID = E.ServiceType AND M.ServiceTypeID=2 And E.ServiceType IN (3,5,16,17)) OR (V.AcctsServicesMapID=2 and M.ServiceID =E.Service_Code AND M.ServiceTypeID=2 And E.ServiceType IN (3,5,16,17) )))

And

E.Service_Code=R.ServiceCode And P.SponsorNo=E.SponsorNo And E.Archived='No' and NoOfVisit>0 And E.ServiceFee>0  
and E.IsDuplicate='No' And E.ClaimDataProcessed='Yes' And E.EpisodeSpecialityCode<>'' 
And ((E.EpisodePrinted='Yes' OR (E.EclaimProcessed='Yes' And E.EpisodeAllBatchNo<>'')) And (E.EpisodeBatchNo<>'' And E.EpisodeBatchNo<>'None')) 
And AttType<>2 And E.ClaimGDRGCode<>'' And E.ServiceType IN (3,5,16,17) And E.EpisodeSpecialityCode IN (Select Code From NHIAMDCS) 

UNION ALL

--Drugs
SELECT
 
S.ServiceCode As ServiceCode, S.ServiceFee * S.RequiredQty As TransAmt, E.EndEpisode As TransDate,J.TransTypeID, J.AcctCode AS CreditAcctCode,
UPPER(A.Description) as CreditAcctName,UPPER(T.Description) as CreditPostType,
ISNULL((Select TOP 1 UPPER(N.Description) From AccountCustomersVendors N Where P.SponsorNo=N.MappedCode and N.TypeID=9),'') As Debtor,
P.SponsorNo As ClientID, M.ServiceTypeID,P.SponsorTypeCode,

ISNULL((Select TOP 1 B.AcctCode From AccountChartSetup G,AccountPostingType K,AccountsChartJournalMapping B, AccountChartServicesMapping X  
Where B.TransTypeID=13 AND B.AcctTypeID=9 And G.Code=B.AcctCode And B.TransTypeID=J.TransTypeID AND B.AcctTypeIDJE=J.AcctTypeID And X.ServiceTypeID=4 AND 
B.AcctCodeJE=J.AcctCode And B.AcctCode=X.AccountChartCode And X.PostingType=13 AND X.ServiceID=P.SponsorNo AND K.Code=B.AcctPostType And B.AcctPostType=1),'') As DebitAcctCode, 

ISNULL((Select TOP 1 UPPER(G.Description) From AccountChartSetup G,AccountPostingType K,AccountsChartJournalMapping B, AccountChartServicesMapping X  
Where B.TransTypeID=13 AND B.AcctTypeID=9 And G.Code=B.AcctCode And B.TransTypeID=J.TransTypeID AND B.AcctTypeIDJE=J.AcctTypeID And X.ServiceTypeID=4 AND 
B.AcctCodeJE=J.AcctCode And B.AcctCode=X.AccountChartCode And X.PostingType=13 AND X.ServiceID=P.SponsorNo AND K.Code=B.AcctPostType And B.AcctPostType=1),'') As DebitAcctName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup G,AccountPostingType K,AccountsChartJournalMapping B , AccountChartServicesMapping X 
Where B.TransTypeID=13 AND B.AcctTypeID=9 And G.Code=B.AcctCode And B.TransTypeID=J.TransTypeID AND B.AcctTypeIDJE=J.AcctTypeID And X.ServiceTypeID=4 AND 
B.AcctCodeJE=J.AcctCode And B.AcctCode=X.AccountChartCode And X.PostingType=13 AND X.ServiceID=P.SponsorNo AND K.Code=B.AcctPostType And B.AcctPostType=1),'') As DebitPostType

, CASE WHEN RTrim(LTrim(E.EpisodeAllBatchNo)) NOT IN ('','None') THEN 'NH' + REPLACE(RIGHT(E.EpisodeAllBatchNo,10),'/','') ELSE '' END AS TransID, S.ServicePlaceID

FROM 

Sponsors P, Episode E, NHIAEpisodeServices S,AccountChartServicesMapping M, AccountChartSetup A,AccountPostingType T,  
AccountsChartJournalMappingView J, ServicesConfigurationSetupView V, Items R

WHERE 

M.ServiceTypeID=1 And R.ItemID=S.ServiceCode and S.ServiceTypeCode=1 AND J.AcctTypeID=1 And E.EpisodeID=S.EpisodeID And P.SponsorNo =E.SponsorNo AND J.TransTypeID=13 And A.Code=J.AcctCode And 
T.Code=J.AcctPostType And J.TransTypeID=M.PostingType And J.AcctCode=M.AccountChartCode  And P.SponsorTypeCode=2
And A.Code=M.AccountChartCode And J.AcctPostType=2  And (((V.AcctsDrugsMapID=4 and M.ServiceID = S.ServicePlaceID  AND M.ServiceTypeID=1 and S.ServiceTypeCode=1 ) OR
(V.AcctsDrugsMapID=3 and M.ServiceID = 1 AND M.ServiceTypeID=1 and S.ServiceTypeCode=1 ) OR (V.AcctsDrugsMapID=2 and M.ServiceID = R.ItemID  AND M.ServiceTypeID=1 and S.ServiceTypeCode=1 ) 
 OR (V.AcctsDrugsMapID=5 and M.ServiceID = CONVERT(NVarchar(15),R.ItemClassCode) AND M.ServiceTypeID=1 and S.ServiceTypeCode=1 ) OR (V.AcctsDrugsMapID=6 and M.ServiceID = CONVERT(NVarchar(15),R.ItemTypeCode) AND M.ServiceTypeID=1  and S.ServiceTypeCode=1 ))) 
And S.ServiceFee>0  

And

R.ItemID=S.ServiceCode And E.EpisodeID=S.EpisodeID And P.SponsorNo=E.SponsorNo And E.Archived='No' and NoOfVisit>0  
and  UPPER(S.RequestType)='INTERNAL' And E.IsDuplicate='No' And E.ClaimDataProcessed='Yes' And E.EpisodeSpecialityCode<>'' 
And ((E.EpisodePrinted='Yes' OR (E.EclaimProcessed='Yes' And E.EpisodeAllBatchNo<>'')) And (E.EpisodeBatchNo<>'' And 
E.EpisodeBatchNo<>'None')) and E.EpisodeSpecialityCode IN (Select Code From NHIAMDCS) And AttType<>2 And E.ClaimGDRGCode<>''
go

