

CREATE FUNCTION [dbo].[GetDHIMS_PatientDays]

(@ElementID AS NVARCHAR(50),@DateFrom DateTime,@DateTo DateTime) RETURNS numeric(18,0)

AS

BEGIN

Declare @RemainedPrevNightCount Numeric(18,0),@RemainedPrevNightCount1 Numeric(18,0),@WardState Numeric(18,0),
@PatDays Numeric(18,0),@StateDate DateTime,@StateWardID nvarchar(15)

Set @PatDays=0

set @WardState=0

set @RemainedPrevNightCount=0

set @RemainedPrevNightCount1=0


DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct DHIMSBedsUntilizationView.WardID From DHIMSBedsUntilizationView Where ElementID=@ElementID

OPEN C

FETCH NEXT FROM C INTO @StateWardID;

WHILE @@fetch_status = 0

	BEGIN
	
	   Select @RemainedPrevNightCount=IsNull(Count(OPDNo),0) From DHIMS_MAPPED_BEDS_UTILIZATION_PARAMETERS Inner Join DHIMSBedsUntilizationView On (DHIMS_MAPPED_BEDS_UTILIZATION_PARAMETERS.ElementID = DHIMSBedsUntilizationView.HamsCode And ParameterID=RecordSerialNo) Where AdmDate>=@DateFrom And AdmDate<=@Dateto And RecordSerialNo In (1,2) And DHIMSBedsUntilizationView.ElementID=@ElementID

	   Select @RemainedPrevNightCount1=IsNull(Count(OPDNo),0) From DHIMS_MAPPED_BEDS_UTILIZATION_PARAMETERS Inner Join DHIMSBedsUntilizationView On (DHIMS_MAPPED_BEDS_UTILIZATION_PARAMETERS.ElementID = DHIMSBedsUntilizationView.HamsCode And ParameterID=RecordSerialNo) Where DisDate>=@DateFrom And DisDate<=@Dateto And RecordSerialNo In (3,4) And DHIMSBedsUntilizationView.ElementID=@ElementID
       
    Set @WardState=dbo.GetWardRemainedPrevNightCount(@StateWardID,@DateFrom)
              
				Set @PatDays=@PatDays + @WardState + @RemainedPrevNightCount - @RemainedPrevNightCount1
								
	  FETCH NEXT FROM C INTO @StateWardID;
	       
	END    
                      
    CLOSE C;

	DEALLOCATE C;		  


RETURN @PatDays

END


go

