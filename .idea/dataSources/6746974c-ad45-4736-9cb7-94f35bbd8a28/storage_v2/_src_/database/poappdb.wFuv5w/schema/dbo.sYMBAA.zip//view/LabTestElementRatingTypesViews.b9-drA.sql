CREATE VIEW [dbo].[LabTestElementRatingTypesViews]

AS

SELECT Description, Code FROM dbo.LabTestElementRatingTypes

UNION

SELECT '-' AS Description, 0 AS Code
go

