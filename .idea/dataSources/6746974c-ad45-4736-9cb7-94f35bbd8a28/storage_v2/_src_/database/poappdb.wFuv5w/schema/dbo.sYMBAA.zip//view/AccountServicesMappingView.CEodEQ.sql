CREATE VIEW [dbo].[AccountServicesMappingView]

AS

SELECT left(V.Description,100) As ServiceDescription, V.AcctsDrugsMapID As AcctsMapType,V.ItemID As ServiceCode,V.ServiceMapType,ServiceMapID, H.PostingTypeID,H.AcctTypeID,
ISNULL((Select TOP 1 A.AccountChartCode From AccountChartServicesMapping A Where A.ServiceID=V.ServiceMapID And A.ServiceTypeID=V.ServiceMapType And A.PostingType=H.PostingTypeID And A.AccountTypeID=H.AcctTypeID),'') As AcctCode,
ISNULL((Select TOP 1 A.AcctCode From AccountChartServicesMapping A Where A.ServiceID=V.ServiceMapID And A.ServiceTypeID=V.ServiceMapType And A.PostingType=H.PostingTypeID And A.AccountTypeID=H.AcctTypeID),0) As AcctID,
ISNULL((Select TOP 1 A.RecordID From AccountChartServicesMapping A Where A.ServiceID=V.ServiceMapID And A.ServiceTypeID=V.ServiceMapType And A.PostingType=H.PostingTypeID And A.AccountTypeID=H.AcctTypeID),0) As MappedRecordID,
ISNULL((Select TOP 1 A.AccountTypeID From AccountChartServicesMapping A Where A.ServiceID=V.ServiceMapID And A.ServiceTypeID=V.ServiceMapType And A.PostingType=H.PostingTypeID And A.AccountTypeID=H.AcctTypeID),0) As AccountTypeID,
ISNULL((Select TOP 1 left(C.Description,100) From AccountChartServicesMapping A, AccountChatsView C Where A.AccountChartCode=C.Code And A.ServiceID=V.ServiceMapID And A.ServiceTypeID=V.ServiceMapType And A.PostingType=H.PostingTypeID And A.AccountTypeID=H.AcctTypeID),'') As AcctDescription

FROM AccountMapTypesView V , HamsQBMappedAcctTypes T, AccountsChartServicesMappingTypes H Where V.AcctsDrugsMapID=T.MapTypeID And V.ServiceMapType=T.MapElementType And V.ServiceMapType=H.ElementType And
T.MapElementType=H.ElementType And T.AccTypeID=H.AcctTypeID
go

