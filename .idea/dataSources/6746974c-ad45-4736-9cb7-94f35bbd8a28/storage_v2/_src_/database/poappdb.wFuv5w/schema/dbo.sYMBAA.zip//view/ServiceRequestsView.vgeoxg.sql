

CREATE VIEW [dbo].[ServiceRequestsView]

AS

SELECT Distinct Service_Requests.*, Description as ServiceDescription, ServiceTypeCode, CatID, SubCatID,'**' As CAPID From AllSetUpServicesView Inner Join Service_Requests On ItemID=ServiceCode Where Archived='No'


go

