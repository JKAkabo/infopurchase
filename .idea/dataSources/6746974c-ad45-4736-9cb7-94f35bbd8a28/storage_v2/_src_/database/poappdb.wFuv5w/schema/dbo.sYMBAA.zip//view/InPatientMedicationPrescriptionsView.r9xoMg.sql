CREATE VIEW [dbo].[InPatientMedicationPrescriptionsView]

AS

Select Pat_No, Prescriptions.OPDNo, DefaultMethodCode, DispensedPrescriptions.DispensedTime, DispensedPrescriptions.DispensedDate, DispensedPrescriptions.RecordID, Description, DrugCode ,DispensedPrescriptions.DispensedQty - DispensedPrescriptions.ReturnedQty As IssuedQty, BeginDate, EndDate, DispensedPrescriptions.Dosage, DispensedPrescriptions.Frequency, Duration, StockLevel, Prescriptions.Remarks,PharmacistRemarks,PresQuanityPerIssueUnit, GivenAll,  
     DispensedPrescriptions.DeptID, DispensedPrescriptions.EmpNo,Prescriptions.Presentation, PresType, DispensedPrescriptions.DispenserID,Prescriptions.BillCategoryCode,Prescriptions.PatCategoryCode,Prescriptions.PmtTypeCode, PmtModeCode, mediStatus, (DispensedPrescriptions.DispensedQty - DispensedPrescriptions.ReturnedQty)*PresQuanityPerIssueUnit As MediTotal,Isnull((Select Isnull(Sum(DosageQty),0) From InPatientMedications Where DispensedPrescriptions.RecordID=DisRecordID And Archived='No'),0) As TotalGiven 
     From Items Inner Join (Prescriptions Inner Join DispensedPrescriptions On Prescriptions.RecordID = DispensedPrescriptions.PresID) On Items.ItemID = Prescriptions.DrugCode Where 
    (DispensedPrescriptions.DispensedQty - DispensedPrescriptions.ReturnedQty)*PresQuanityPerIssueUnit>(Select Isnull(Sum(DosageQty),0) From InPatientMedications Where DispensedPrescriptions.RecordID=DisRecordID And Archived='No') AND Prescriptions.Archived='No'

Union

Select Pat_No, Prescriptions.OPDNo, DefaultMethodCode, Prescriptions.PresTime AS DispensedTime, Prescriptions.PresDate As DispensedDate, Prescriptions.RecordID, Description, DrugCode ,Prescriptions.QtyPrescribed IssuedQty, Prescriptions.StartDate As BeginDate, Prescriptions.FinishDate As EndDate, Prescriptions.Units As Dosage, Prescriptions.Dosage As Frequency, Prescriptions.PresDays As Duration, QtyGiven As StockLevel, 
    Prescriptions.Remarks, '' As PharmacistRemarks,PresQuanityPerIssueUnit,RefundReceiptNo As GivenAll, Prescriptions.DeptID, Prescriptions.EmpNo, Prescriptions.Presentation, PresType, Prescriber As DispenserID,Prescriptions.BillCategoryCode,Prescriptions.PatCategoryCode,Prescriptions.PmtTypeCode, PmtModeCode, mediStatus,QtyPrescribed*PresQuanityPerIssueUnit,Isnull((Select Isnull(Sum(DosageQty),0) From InPatientMedications Where Prescriptions.RecordID=DisRecordID And Archived='No'),0) From Items Inner Join Prescriptions On Items.ItemID = Prescriptions.DrugCode
    Where QtyPrescribed*PresQuanityPerIssueUnit>(Select Isnull(Sum(DosageQty),0) From InPatientMedications Where Prescriptions.RecordID=DisRecordID And Archived='No') And Upper(PresType)<>'INTERNAL' AND Prescriptions.Archived='No'
go

