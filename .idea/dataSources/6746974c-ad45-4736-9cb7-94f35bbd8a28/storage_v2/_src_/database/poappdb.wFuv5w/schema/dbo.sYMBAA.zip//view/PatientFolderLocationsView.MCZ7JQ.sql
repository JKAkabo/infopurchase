CREATE VIEW [dbo].[PatientFolderLocationsView]

AS

SELECT Distinct LastActivityCode, Archived, ServerDate, ServerTime, UserID, OPDNo, Pat_No, LocationClinic, LastAccessedDate, LastAccessedTime, StateCode, StatusCode, LocationNo FROM PatientFolder

union

SELECT Distinct 5 As LastActivityCode, 'No' AS Archived, ServerDate, ServerTime, UserID, OPDNo, Pat_No, PatientArchivedFolders.ArchivedClinicCode, ServerDate As LastAccessedDate, ServerTime As LastAccessedTime, StateCode, StatusCode, ArchivedLocationCode As LocationNo FROM PatientArchivedFolders Inner Join PatientArchivedFolderLines On PatientArchivedFolders.RecordID=ArchivedID
go

