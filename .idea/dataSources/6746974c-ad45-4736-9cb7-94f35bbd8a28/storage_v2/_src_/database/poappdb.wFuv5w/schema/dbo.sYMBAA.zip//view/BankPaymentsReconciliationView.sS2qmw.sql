CREATE VIEW [dbo].[BankPaymentsReconciliationView]
AS
SELECT ReceiptNo As InvoiceNo, B.PmtDate As InvoiceDate, B.PmtTime As InvoiceTime, TAmtPaid As InvoiceAmt, B.UserID  As InvoicedBy, OPDNo, Pat_No, TBill, CAP_ID, MMAmt,B.MMNetwork,B.MMTken,B.MMWalletNo,B.MMTransID,B.PmtModeCode,B.UserID,P.Description As PmtMode, Case When PmtModeCode IN(6,7,9,10)Then Left(U.UserID,100) Else Left(TellerName,100) End As TellerName, 
PmtAmt,Convert(NVARCHAR(106),H.PmtDate) As PmtDate, Convert(NVARCHAR(113),H.PmtTime) As PmtTime, PmtReceiptNo As ReceiptNo, 'Yes' As Paid FROM dbo.BillsPaid B, HAMSBANKPAYMENTS H, PaymentModes P, UsersView U Where U.UserNo=B.UserID And P.Code=B.PmtModeCode And B.Archived='No' and TAmtPaid>0 and ReceiptNo=H.InvoiceNo and Pat_No=PatNo and Cancelled='No'

Union

SELECT ReceiptNo As InvoiceNo, B.PmtDate As InvoiceDate, B.PmtTime As InvoiceTime, TAmtPaid As InvoiceAmt, B.UserID  As InvoicedBy, OPDNo, Pat_No, TBill, CAP_ID, MMAmt,MMNetwork,MMTken,MMWalletNo,MMTransID,B.PmtModeCode,B.UserID,P.Description As PmtMode, 
Case When PmtModeCode IN(1,2,7)Then Left(U.UserID,100) Else '' End As TellerName,0 As PmtAmt,'' As PmtDate,'' As PmtTime, '' As ReceiptNo, 'No' As Paid FROM dbo.BillsPaid B, PaymentModes P, UsersView U Where  U.UserNo=B.UserID And P.Code=B.PmtModeCode And B.Archived='No' and TAmtPaid>0 and ReceiptNo NOT IN (Select InvoiceNo From HAMSBANKPAYMENTS Where Cancelled='No')
go

