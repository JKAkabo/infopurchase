CREATE VIEW [dbo].[PregnancyConjunctivaView]

AS

SELECT  Description, Code FROM dbo.PregnancyConjunctiva

Union

SELECT  '', 0  FROM dbo.Hosp_Info
go

