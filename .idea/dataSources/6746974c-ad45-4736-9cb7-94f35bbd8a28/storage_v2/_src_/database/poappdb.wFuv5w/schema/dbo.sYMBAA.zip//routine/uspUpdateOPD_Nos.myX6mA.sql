CREATE PROCEDURE [dbo].[uspUpdateOPD_Nos] 
	
AS

DECLARE @OPDNo nvarchar(15),@ClinicCode nvarchar(10),@regDate datetime,@regtime datetime,
        @servertime datetime,@serverdate datetime,@patno nvarchar(15),@userid nvarchar(10)

BEGIN

Delete from OPD_Nos

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct OPDNo,SPCode,RegDate,RegTime,OPD_Nos1.ServerTime,OPD_Nos1.ServerDate,PatNo,UserID From Service_Points Inner Join OPD_Nos1 On Service_Points.SPCode=OPD_Nos1.ClinicCode Order by OPDNo
        
        
        
  OPEN C
  
  FETCH NEXT FROM C INTO @OPDNo,@ClinicCode,@RegDate,@RegTime,@ServerTime,@ServerDate,@PatNo,@UserID           

  WHILE @@fetch_status = 0
    BEGIN

       insert into OPD_Nos (OPDNo,ClinicCode,RegDate,RegTime,ServerTime,ServerDate,PatNo,UserID) Values (@OPDNo,@ClinicCode,@RegDate,@RegTime,@ServerTime,@ServerDate,@PatNo,@UserID)

  FETCH NEXT FROM C INTO @OPDNo,@ClinicCode,@RegDate,@RegTime,@ServerTime,@ServerDate,@PatNo,@UserID        

	END

	CLOSE C;

	DEALLOCATE C;

END
go

