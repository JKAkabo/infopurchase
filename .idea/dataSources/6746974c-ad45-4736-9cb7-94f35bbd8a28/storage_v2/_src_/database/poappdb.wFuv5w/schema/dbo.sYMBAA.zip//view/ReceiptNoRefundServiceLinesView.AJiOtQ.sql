CREATE VIEW [dbo].[ReceiptNoRefundServiceLinesView]

AS

SELECT SUM(R.Service_Fee*R.RefundQty) As RefundAmt, R.RefundReceiptNo 
FROM RefundServiceLines R Where R.PmtTypeCode=1 and R.BillCategoryCode=1 Group By R.RefundReceiptNo
go

