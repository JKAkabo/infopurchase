
CREATE PROCEDURE [dbo].[uspDeleteStalePrivateClaims] 
	
AS

DECLARE @ClaimID nvarchar(50);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;

  DECLARE C CURSOR FAST_FORWARD FOR Select DISTINCT PrivateClaimsDetail.ClaimEventID from PrivateClaimsDetail, PrivateClaimsServices,AllSetUpServicesView where ServiceTypeCode<>2 and
PrivateClaimsDetail.ClaimEventID=PrivateClaimsServices.ClaimEventID and ItemID=ServiceCode and PrivateClaimsDetail.ClaimEventID  NOT IN 
(Select ClaimEventID From PrivateClaimsServices P, ServicesRevenueView S where S.ServiceCode = P.ServiceCode
and RequestID=RecordID)
  
  OPEN C
  
  FETCH NEXT FROM C INTO @ClaimID;

  WHILE @@fetch_status = 0
  
    BEGIN
       
       INSERT INTO PrivateClaimsDetailLogs SELECT *,'DELETE',GETDATE(),'00001' FROM  PrivateClaimsDetail Where ClaimEventID=@ClaimID
       
       INSERT INTO PrivateClaimsServicesLogs SELECT *,'DELETE',GETDATE(),'00001' FROM  PrivateClaimsServices Where ClaimEventID=@ClaimID
       
       DELETE  FROM  PrivateClaimsDetail Where ClaimEventID=@ClaimID
       
       DELETE  FROM  PrivateClaimsServices Where ClaimEventID=@ClaimID
       
       FETCH NEXT FROM C INTO @ClaimID;

	END

	CLOSE C;

	DEALLOCATE C;

END

go

