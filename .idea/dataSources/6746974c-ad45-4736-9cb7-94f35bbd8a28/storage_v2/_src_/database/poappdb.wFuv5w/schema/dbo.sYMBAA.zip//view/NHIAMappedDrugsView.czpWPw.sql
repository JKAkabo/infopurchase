CREATE VIEW [dbo].[NHIAMappedDrugsView]

AS

Select Left(Upper(I.Description),100) as Description, Upper(U.Description) AS UOM,I.ItemID,Upper(N.Description) As NHIADescription,N.NHISCode,
N.PresLevel, N.IsActive,Upper(P.PriceUnit) As PriceUnit,P.UOMFactor,P.Price,P.EffectiveDate From UnitMeasuresView U, Items I, NHIAMedicinesPriceList P, NHIADrugsSetup N 
Where I.NHISCode=N.NHISCODE And N.NHISCode=P.MedicineCode And U.Code=I.IssueUnitCode and I.Disabled='No' and U.IsActive='Yes' and ItemTypeCode=1
go

