CREATE VIEW [dbo].[QBCashServicesView]

AS

SELECT Distinct ServiceLinePayments.RecordID As TransID,ServiceLinePayments.Service_Fee *ServiceLinePayments.PaidQty AS PaidAmt,ServiceLinePayments.PmtDate As TransDate,
Service_Requests.SerPlaceCode as IssuerID,ServiceLinePayments.PmtTypeCode , Service_Requests.SponsorNo As ReceiverID,ServiceLinePayments.ServiceCode
,AllSetUpServicesView.Description As ServiceDescription,UPPER(Service_Places.Description) as ClientName,ServiceLinePayments.Pat_ID As OPDNo 
,'Service Cash Sale' As MoveType FROM Service_Places Inner Join (AllSetUpServicesView inner join (Service_Requests  Inner Join ServiceLinePayments 
On Service_Requests.ServiceCode=ServiceLinePayments.ServiceCode And Service_Requests.RecordID=ServiceLinePayments.ServiceID)
ON AllSetUpServicesView.ItemID =ServiceLinePayments.ServiceCode) ON Service_Places.Code =Service_Requests.SerPlaceCode WHERE ServiceLinePayments.PmtTypeCode =1
go

