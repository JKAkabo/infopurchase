CREATE VIEW [dbo].[ViewTowns]
AS
SELECT     left(TwnName,100) As TwnName,Code,TwnID,IsActive,DistrictID
FROM         dbo.Towns

Union

Select 'NOT AVAILABLE' As TwnName, '' as Code, 0 As TwnID ,'Yes' As IsActive, 0 as DistrictID from Hosp_Info
go

