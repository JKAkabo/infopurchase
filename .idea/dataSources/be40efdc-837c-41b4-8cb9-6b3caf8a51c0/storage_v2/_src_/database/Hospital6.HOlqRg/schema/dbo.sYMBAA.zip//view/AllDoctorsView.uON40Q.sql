CREATE VIEW [dbo].[AllDoctorsView]

AS

SELECT Distinct DoctorName + '(' + HosName + ')' As DoctorName, ExternalDoctors.Code As DoctorID FROM ReferralClinics Inner Join ExternalDoctors On HosID=ClinicCode Where ExternalDoctors.Archived='No'

Union

SELECT Distinct Users.UserID As DoctorName, UserNo As DoctorID FROM UserCategories Inner Join (Users Inner Join UserClinics On UserCode=UserNo) On UserCategories.CatID=Users.CatID Where Users.Archived='No' And Description In ('DOCTORS','MEDICAL ASSISTANTS','SENIOR NURSES','LOCUM DOCTORS','MIDWIFES')
go

