CREATE VIEW [dbo].[QBUsedDepositView]
AS
SELECT    
           PmtRecordID As TransID
          ,BillsPaid.OPDNo As ServiceCode
          ,DepAmtUsed  AS PaidAmt
          ,PmtDate As TransDate
          ,'0104' as IssuerID
          ,BillsPaid.Pat_No As ReceiverID
          ,BillsPaid.Pat_No +' '+'Cash Deposit Used' As ServiceDescription
          ,Surname+' '+LastName As ClientName 
          ,'Cash Deposit Used' As MoveType
FROM        
           dbo.BillsPaid Inner Join
           PatientsInfo 
           On BillsPaid.OPDNo =PatientsInfo.OPDNo 
WHERE    
          (DepAmtUsed   > 0) AND (Archived = 'No')
go

