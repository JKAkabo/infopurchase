CREATE VIEW [dbo].[ViewHamsActiveUsers]
AS
SELECT       Log_Trail.LogInDate,Log_Trail.LogInTime, Log_Trail.Terminal_IP,Log_Trail.Terminal_Name,Log_Trail.UserNo, Log_Trail.CAP_ID
FROM         dbo.Log_Trail where LogOutDate Is Null
go

