

CREATE VIEW [dbo].[AdmissionDischrgesView]

AS

SELECT  Adms.ClaimPrinted,Adms.ClaimDataProcessed,Adms.ClaimPrintTime,Adms.ClaimPrintedBy,Adms.ClaimDataProcessedDate,Adms.ClaimDataProcessedBy,Adms.RecordID As AdmRecID, Dischs.RecordID As DisRecID,Adms.OPDNo, Dischs.Pat_No, Adms.AdmDate, Adms.AdmTime, Dischs.DisDate, Dischs.DisTime, Adms.AdmAge,Dischs.DisAge, Dischs.PatCategoryCode,Dischs.Insured, Adms.DoctorID, Dischs.DisAuthouriser, Adms.WardID, Adms.BedNo, Adms.BedType, Dischs.WardID As DisWardID,Dischs.ClinicCode, Dischs.PmtModeCode,Dischs.PmtTypeCode,Dischs.BillMethodCode,Dischs.BillCycleDuration, 
Dischs.DirectID,Dischs.BedNo AS DisBedNo,Dischs.ServerTime, Dischs.BedType As DisBedType,Dischs.DischargeStatusCode,Dischs.EpisodeID,Dischs.BillCategoryCode, Dischs.SponsorNo, IsNull(Dischs.HFAC,'') As HFAC, (Select TOP 1 ReviewTime From ConsultationReviews C where Cancelled='No' And (C.ConID=Dischs.RecordID Or C.ConID=Adms.RecordID) And StatusCode=3 Order By ReviewTime Desc) As ReviewDate, (Select TOP 1 DoctorRemarks From InPatientConsultations C where Archived='No' And (C.AdmID=Dischs.RecordID Or C.AdmID=Adms.RecordID) ORDER BY ServerTime) As DoctorRemarks, 
(Select TOP 1 TreatmentPlan From InPatientConsultations C where Archived='No' And (C.AdmID=Dischs.RecordID Or C.AdmID=Adms.RecordID) ORDER BY ServerTime) As TreatmentPlan, Adms.FirstAdmissionID, Dischs.LastDischargeID FROM  Admissions Adms Inner Join Admissions Dischs On (Adms.FirstAdmissionID=Dischs.FirstAdmissionID And Adms.OPDNo=Dischs.OPDNo And Adms.LastDischargeID=Dischs.LastDischargeID) 
where Adms.Archived='No' and Dischs.Archived='No' and Dischs.DisDate Is Not Null and Dischs.Discharged='Yes' and Dischs.LastDischargeID<>0 and Adms.Discharged='Yes' and Adms.DisDate Is Not Null and Dischs.RecordID NOT IN (select OldAdmRecordID from WardTransfers where Archived='No') and Adms.RecordID NOT IN (select NewAdmRecordID from WardTransfers where Archived='No')


go

