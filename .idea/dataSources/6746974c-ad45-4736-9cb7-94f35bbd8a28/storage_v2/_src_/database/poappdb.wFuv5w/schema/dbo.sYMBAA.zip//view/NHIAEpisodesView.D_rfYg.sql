CREATE VIEW [dbo].[NHIAEpisodesView]

AS

SELECT Distinct  OPDNo As PatID, EpisodeID As EpiID , EpisodeID As ActiveEpiID, Clinic_Code From PatientNHIAActiveEpisodesView

Union

SELECT Distinct  OPDNo As PatID, EpisodeID As EpiID , ActiveEpiID, '' As Clinic_Code From PatientNHIAInActiveEpisodesView
go

