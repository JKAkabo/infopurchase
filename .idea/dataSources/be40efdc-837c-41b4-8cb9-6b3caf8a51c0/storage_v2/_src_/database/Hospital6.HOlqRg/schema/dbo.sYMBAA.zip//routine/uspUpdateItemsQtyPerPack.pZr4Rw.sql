CREATE PROCEDURE [dbo].[uspUpdateItemsQtyPerPack] 
	
AS

DECLARE @itemID nvarchar(15),@Qpp numeric(18,0);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct ItemID,Qpp From PacksUpdate Order by ItemID Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO @itemID, @Qpp;

  WHILE @@fetch_status = 0
    BEGIN

       --set @DisCategory=dbo.ItemDesc(@DisCategory);
       
       update ItemUOMS Set IssueUnitQuantity=@Qpp Where ItemCode=@itemID 
       update Items Set QPP=@Qpp Where ItemID=@itemID 
       
       FETCH NEXT FROM C INTO @itemID, @Qpp;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

