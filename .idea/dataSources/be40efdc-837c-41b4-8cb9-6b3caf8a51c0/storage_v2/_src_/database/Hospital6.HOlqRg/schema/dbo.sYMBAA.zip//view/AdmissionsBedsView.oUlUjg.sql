CREATE VIEW [dbo].[AdmissionsBedsView]
AS
--
SELECT 'REAL' AS BedTypeTest, WardID, BedNo, BedType FROM dbo.Admissions where Archived='No' And Discharged='No' And BedType=1 And DisDate Is Null

UNION

SELECT 'VIRTUAL' AS BedTypeTest, WardID, BedNo, BedType FROM dbo.Admissions where Archived='No' And Discharged='No' And BedType=2 And DisDate Is Null
go

