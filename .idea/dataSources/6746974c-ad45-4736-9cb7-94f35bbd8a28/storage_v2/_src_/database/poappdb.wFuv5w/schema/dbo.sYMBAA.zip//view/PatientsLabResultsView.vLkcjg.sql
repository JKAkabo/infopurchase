CREATE VIEW [dbo].[PatientsLabResultsView]

AS

Select Distinct LabTestResultsView.*, RequestType As DeliveryType, Service_Requests.ReqDate As AttDate, Service_Requests.ReqTime As AttTime, ServiceType, Service_Places.Description As ServicePlace,PmtTypeCode As PmtCode,BillCategoryCode As BillCat,SponsorNo As BillSponsor, RequesterID From Service_Places Inner Join (Service_Types Inner Join (Service_Requests Inner Join LabTestResultsView On Service_Requests.RecordID = LabTestResultsView.RequestID) On Service_Types.ServiceCode= Service_Requests.ServiceCode) On Service_Places.Code = Service_Types.ServicePlaceCode Where Service_Requests.Archived='No' and ServiceTypeCode=11
go

