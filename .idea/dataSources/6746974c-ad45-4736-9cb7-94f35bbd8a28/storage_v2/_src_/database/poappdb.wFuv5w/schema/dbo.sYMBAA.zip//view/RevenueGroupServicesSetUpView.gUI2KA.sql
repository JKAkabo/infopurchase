CREATE VIEW [dbo].[RevenueGroupServicesSetUpView]

AS

SELECT Distinct Description, ItemID As ServiceCode, 1 As ServiceTypeCode, CAPID FROM AllSetUpServicesView Where Disabled='No' and ServiceTypeCode=1 and CatID IN (1,2) and LTRIM(rtrim(Description))<>''

UNION

SELECT Distinct Description, ItemID As ServiceCode, 2 As ServiceTypeCode, CAPID FROM AllSetUpServicesView Where Disabled='No' and ServiceTypeCode NOT IN (1) and LTRIM(rtrim(Description))<>''

UNION

SELECT Distinct Description, Convert(nvarchar(15),Code) As Code,3  As ServiceTypeCode, '**' As CAPID FROM  ServiceTypesView where LTRIM(rtrim(Description))<>''
UNION

SELECT Distinct Description, Code, 4 As ServiceTypeCode, '**' As CAPID FROM ServicePlacesView Where Status='Yes' and LTRIM(rtrim(Description))<>''
go

