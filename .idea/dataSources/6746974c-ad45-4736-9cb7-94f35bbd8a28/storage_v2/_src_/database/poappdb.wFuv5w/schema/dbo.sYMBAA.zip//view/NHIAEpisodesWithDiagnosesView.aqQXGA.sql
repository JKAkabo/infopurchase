--NHIAOUTEpisodeDiagnosesView

CREATE VIEW [dbo].[NHIAEpisodesWithDiagnosesView]

AS

SELECT Distinct ActiveEpiID FROM NHIAEpisodesView Inner Join NHIAOUTEpisodeDiagnosesView On(EpiID=NHIAOUTEpisodeDiagnosesView.EpisodeID And PatID=NHIAOUTEpisodeDiagnosesView.OPDNo) 

Union

SELECT Distinct ActiveEpiID FROM NHIAEpisodesView Inner Join NHIAINEpisodeDiagnosesView On(EpiID=NHIAINEpisodeDiagnosesView.EpisodeID And PatID=NHIAINEpisodeDiagnosesView.OPDNo)
go

