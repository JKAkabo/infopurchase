CREATE PROCEDURE [dbo].[uspFreeUnOccupiedBeds] 
	
AS

DECLARE @BedNo nvarchar(15),@WardID nvarchar(15), @OPDNo nvarchar(15), @AdmID numeric(18,0);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;

  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct admissions.BedNo, admissions.WardID, PatientsInfo.OPDNo, admissions.RecordID from PatientsInfo inner join (Beds Inner Join Admissions On Beds.BedNo=Admissions.BedNo and Beds.WardID=Admissions.WardID) on PatientsInfo.OPDNo=Admissions.OPDNo where Admissions.Archived='No'  and Admissions.Discharged='No'  and DisDate is Null and PatientsInfo.StatusCode=2 order by PatientsInfo.OPDNo

  
  OPEN C
  
  FETCH NEXT FROM C INTO @BedNo, @WardID, @OPDNo, @AdmID;

  WHILE @@fetch_status = 0
    BEGIN
       
       
     update Admissions Set DisDate=AdmDate,DisTime=AdmTime,Discharged='Yes', DisAuthouriser=DoctorID, DischargeStatus='DISCHARGED SATISFACTORILY', DischargeStatusCode=1, DisAge=AdmAge, DisAgeClassCode=AdmAgeClassCode  where  Admissions.RecordID=@AdmID 
     
     update Beds set BedCondition='Free' Where WardID=@WardID and BedNo=@BedNo

     FETCH NEXT FROM C INTO @BedNo, @WardID, @OPDNo,@AdmID;

	END

	CLOSE C;
	
	DEALLOCATE C;
	
	DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct AdmissionsBedsView.BedNo, AdmissionsBedsView.WardID, AdmissionsBedsView.BedTypeTest from Beds inner join AdmissionsBedsView On (Beds.BedNo=AdmissionsBedsView.BedNo and Beds.WardID=AdmissionsBedsView.WardID And Beds.BedType=AdmissionsBedsView.BedTypeTest) Where Beds.BedCondition='Free' Order By AdmissionsBedsView.BedNo

  OPEN C
  
  FETCH NEXT FROM C INTO @BedNo, @WardID, @OPDNo;

  WHILE @@fetch_status = 0
    BEGIN
             
     update Beds set BedCondition='Occupied' Where WardID=@WardID and BedNo=@BedNo and BedType=@OPDNo and BedCondition='Free'

     FETCH NEXT FROM C INTO @BedNo, @WardID, @OPDNo;

	END

	CLOSE C;

	DEALLOCATE C;
	
	DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct PatientsInfo.OPDNo from PatientsInfo Where StatusCode=3 And (OPDNo NOT IN (SELECT Distinct OPDNo from Admissions Where Admissions.Archived='No' and Discharged='No' And DisDate Is Null Union SELECT Distinct OPDNo from MortuaryAdmission Where Archived='No' and Discharged='No' And DisDate Is Null) Or OPDNo NOT IN (SELECT Distinct OPDNo from Admissions Where Admissions.Archived='No' Union SELECT Distinct OPDNo from MortuaryAdmission Where Archived='No')) order by PatientsInfo.OPDNo ASC

  OPEN C
  
  FETCH NEXT FROM C INTO @OPDNo;

  WHILE @@fetch_status = 0
    BEGIN
   	       
     update PatientsInfo Set StatusCode=2  where  OPDNo=@OPDNo 
     
     FETCH NEXT FROM C INTO @OPDNo;

	END

	CLOSE C;
	
	DEALLOCATE C;
	
	DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct BedNo, WardID, BedType from beds Where BedCondition='Free' And BedStatus='OPERATIONAL' and (RTRIM(LTRIM(AdmOPDNo))<>'' OR AdmissionRecordID<>0) order By BedNo

  OPEN C
  
  FETCH NEXT FROM C INTO @BedNo,@WardID,@OPDNo;

  WHILE @@fetch_status = 0
    BEGIN
   	       
     update Beds Set AdmOPDNo='',AdmissionRecordID=0  where  BedNo=@BedNo AND WardID=@WardID AND BedType=@OPDNo
     
     FETCH NEXT FROM C INTO @BedNo,@WardID,@OPDNo;

	END

	CLOSE C;
	
	DEALLOCATE C;	

END
go

