




CREATE VIEW [dbo].[ItemsReOrderLevelsView]

AS

Select Distinct I.ItemDescription, ItemCode, UnitBaseCost, UOM, ServicePlaceCode As StoreID,
IsNull((Select Sum(ConsumptionAmt) From ItemsConsumptionView P Where ((P.ServerDate Is Null And MoveType='') Or (P.ServerDate Is Not Null And (C.DrugConsumption='DISPENSED DRUGS' And MoveType<>'PrescriptionsOnly') OR (MoveType<>'DispensedDrugsOnly'))) And P.StoreID=I.ServicePlaceCode And ItemCode=P.ItemID) ,0) As MaxStock, 
Isnull((Select sum(StockLevel) From StockedItemsView Where TypeCode=1 And ItemCode=I.ItemCode
And (((IsDate(ExpiryDate)=1 And ItemExpirable ='Yes') And ((Year(ExpiryDate)> Year(Getdate())) OR 
(Year(ExpiryDate)= Year(Getdate()) And Month(ExpiryDate)>= Month(Getdate())))) Or 
(IsDate(ExpiryDate)=0 OR ItemExpirable ='No')) Group By ItemCode),0) As StockLevel, 
Isnull((Select sum(StockLevel) From StockedItemsView Where TypeCode=1 And ItemCode=I.ItemCode And 
ServicePlaceCode=I.ServicePlaceCode And (((IsDate(ExpiryDate)=1 And ItemExpirable ='Yes') And 
((Year(ExpiryDate)> Year(Getdate())) OR (Year(ExpiryDate)= Year(Getdate()) And 
Month(ExpiryDate)>= Month(Getdate())))) Or (IsDate(ExpiryDate)=0 OR ItemExpirable ='No')) Group By ServicePlaceCode),0) As StoreItemStockLevel , 
IsNull((Select TOP 1 MinLevel From StocksView P Where ItemCode=ItemID And I.ServicePlaceCode=P.StoreID) ,0) As MinLevel, 
IsNull((Select TOP 1 MaxLevel From StocksView P Where ItemCode=ItemID And I.ServicePlaceCode=P.StoreID) ,0) As MaxLevel, 
IsNull((Select TOP 1 UnitCost From OrderLinesReceived Where ItemID=ItemCode And Archived='No' Order By ReceivedTime Desc) ,0) As LIP,
IsNull((Select TOP 1 ReceivedQty From OrderLinesReceived Where ItemID=ItemCode And Archived='No' Order By ReceivedTime Desc) ,0) As LPOQty, 
IsNull((Select TOP 1 InvoiceNo From OrderLinesReceived O, ReceivedOrders R Where ItemID=ItemCode And R.ReceivedID=O.ReceivedID And R.Archived='No' Order By R.ReceivedTime) ,'') As InvoiceNo,
IsNull((Select TOP 1 S.Description From OrderLinesReceived O, ReceivedOrders R, SuppliersView S Where ItemID=ItemCode And S.SupplierID=R.SupplierID And R.ReceivedID=O.ReceivedID And R.Archived='No' Order By R.ReceivedTime) ,'') As Supplier, 
'**' As Cap_ID,(Select TOP 1 ConverT(Date,StartDate) As StartDate From ItemsConsumptionView) As StartDate,(Select TOP 1 ConverT(Date,EndDate) From ItemsConsumptionView ) As EndDate
From StockedItemsView I, OrdersConfigurationSetup C



go

