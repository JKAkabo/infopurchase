CREATE VIEW [dbo].[FirstAdmissionWardTransfersView]
AS

SELECT  RecordID, Admissions.OPDNo, Pat_No, ClinicCode, AdmDate, AdmTime, WardID, DoctorID, PatCategoryCode, BedNo, BedType,AdmAge,DischargeStatusCode,DisAuthouriser AS DisDoctor FROM dbo.Admissions Inner Join WardTransfers on RecordID=OldAdmRecordID 
where Transfered='Yes' And Admissions.Archived='No' and WardTransfers.Archived='No' and DisDate Is Not Null and OldAdmRecordID Not In (Select Distinct NewAdmRecordID from WardTransfers Where Archived='No')
go

