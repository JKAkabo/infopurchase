CREATE VIEW [dbo].[NHIADrugsSetupView]

AS

SELECT  Left(Description,100) As Description, N.NHISCODE,N.PresLevel,N.Price,N.PriceUOMFac,N.PricingUnit, IsActive FROM NHIADrugsSetup N
go

