
CREATE VIEW [dbo].[HAMS_DHIMS_ELEMENTS_MAPPINGS_View]

AS

SELECT  HamsCode, ElementID As DHIMSCode, DataSetID As DataSet_ID, Description, ElementOrder, PatientType, GenderCode, AgeGroupCode, ElementOrder As OrderNo, CategoryCode, AgeRangeCode, ServiceTypeID,IsDummy FROM DHIMSDataElements Where IsActive='Yes'

Union

SELECT  'DISMALARIA1' As HamsCode,'uomhoUlyARe' As DHIMSCode,'JHP0HrrFcPn' As DataSet_ID, 'MALARIA' AS Description, 0 As ElementOrder, 1 As PatientType, 1 As GenderCode, 16 As AgeGroupCode, 0 As OrderNo, 0 As CategoryCode, 0 As AgeRangeCode, 10 As ServiceTypeID, 'No' As IsDummy  FROM dbo.Hosp_Info

go

