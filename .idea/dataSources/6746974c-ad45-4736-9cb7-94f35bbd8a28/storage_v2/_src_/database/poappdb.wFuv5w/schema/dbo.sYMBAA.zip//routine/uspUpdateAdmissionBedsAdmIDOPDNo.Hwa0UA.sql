CREATE PROCEDURE [dbo].[uspUpdateAdmissionBedsAdmIDOPDNo] 
	
AS

DECLARE @OPDNo nvarchar(15),@WardID nvarchar(15), @AdmID numeric(18,0),@BedType Tinyint,@BedNo nvarchar(15);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets fromt
	-- interfering with SELECT statements.
SET NOCOUNT ON;

  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct  RecordID , WardID, OPDNo, BedType, BedNo From Admissions Where DisDate Is Null And  DisTime Is Null And Discharged='No' And Archived='No' Order by RecordID Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO @AdmID, @WardID, @OPDNo, @BedType, @BedNo;

  WHILE @@fetch_status = 0
    BEGIN       
       
       if @BedType=1 
          update Beds Set admissionrecordID=@AdmID, AdmOPDNo=@OPDNo Where WardID=@WardID And BedNo=@BedNo And BedType='REAL' And UPPER(BedCondition)='OCCUPIED'
       
       else
          update Beds Set admissionrecordID=@AdmID, AdmOPDNo=@OPDNo Where WardID=@WardID And BedNo=@BedNo And BedType='VIRTUAL' And UPPER(BedCondition)='OCCUPIED'
       
       FETCH NEXT FROM C INTO @AdmID, @WardID, @OPDNo, @BedType, @BedNo;

	END

	CLOSE C;
	
    DEALLOCATE C;

END
go

