CREATE VIEW [dbo].[FoldersDueForArchiveView]

AS

SELECT Distinct OPDNo, Pat_No, ClinicCode, AttDate, AttTime, UPPER('Attendance Date') As BasedOn FROM Service_Points Inner Join Daily_Attendance As PatAttTable On LocationClinicCode=ClinicCode Where EXISTS 
(Select TOP 1 OPDNo, Pat_No, ClinicCode, AttDate, AttTime, UPPER('Attendance Date') As BasedOn From Daily_Attendance Where Daily_Attendance.RecordID= PatAttTable.RecordID Order By Daily_Attendance.AttTime Desc )

Union

Select Distinct OPDNo, Pat_No, ClinicCode, DisDate As AttDate, DisTime As AttTime, UPPER('Attendance Date') As BasedOn From  Service_Points Inner Join Admissions  As PatAttTable On LocationClinicCode=ClinicCode  
Where PatAttTable.Archived='No' And Discharged='Yes' And DisDate Is Not Null and EXISTS (Select TOP 1 OPDNo, Pat_No, ClinicCode, DisDate As AttDate, DisTime As AttTime, UPPER('Attendance Date') As BasedOn From Admissions 
Where Admissions.RecordID= PatAttTable.RecordID and Admissions.Archived='No' And Discharged='Yes' And Admissions.DisDate Is Not Null And RecordID Not IN (Select Distinct OldAdmRecordID from WardTransfers) Order By DisTime Desc )

Union

Select Distinct OPDNo, Pat_No, ClinicCode, AdmDate As AttDate, AdmTime As AttTime, UPPER('Attendance Date') As BasedOn From  Service_Points Inner Join Admissions  As PatAttTable On LocationClinicCode=ClinicCode  
Where PatAttTable.Archived='No' And Discharged='No' And DisDate Is Null and EXISTS (Select TOP 1 OPDNo, Pat_No, ClinicCode, DisDate As AttDate, AdmTime As AttTime, UPPER('Attendance Date') As BasedOn From Admissions 
Where Admissions.RecordID= PatAttTable.RecordID and Admissions.Archived='No' And Discharged='No' And DisDate Is Null)

Union

SELECT Distinct OPDNo, Pat_No, ClinicCode, DeathDate As AttDate, DeathTime As AttTime, 'DEATH DATE' As BasedOn FROM Service_Points Inner Join Deaths On LocationClinicCode=ClinicCode Where Archived='No'
go

