CREATE VIEW [dbo].[ServicePlacesPaidServicesView]

AS

SELECT Distinct ServiceLinePayments.PaidQty,ServiceLinePayments.Service_Fee,ServiceLinePayments.RecordID,ServiceLinePayments.ServiceCode,ServiceLinePayments.PmtDate, ServiceLinePayments.PmtTime, StoresID As SerPlaceCode , ServiceLinePayments.PaidAmt, '**' As CapID, ServiceLinePayments.ReceiptNo, ServiceLinePayments.UserID FROM Prescriptions Inner Join ServiceLinePayments On (DrugCode=ServiceCode and Prescriptions.RecordID=ServiceID) Where ServiceLinePayments.Archived='No'

UNION

SELECT Distinct ServiceLinePayments.PaidQty,ServiceLinePayments.Service_Fee,ServiceLinePayments.RecordID,ServiceLinePayments.ServiceCode,ServiceLinePayments.PmtDate, ServiceLinePayments.PmtTime, SerPlaceCode ,ServiceLinePayments.PaidAmt, '**' As CapID, ServiceLinePayments.ReceiptNo, ServiceLinePayments.UserID FROM Service_Requests Inner Join ServiceLinePayments On (Service_Requests.ServiceCode=ServiceLinePayments.ServiceCode and Service_Requests.RecordID=ServiceID) Where ServiceLinePayments.Archived='No'
go

