CREATE VIEW [dbo].[AccountSubCategoriesView]

AS

SELECT  AccountSubCategories.Description, AccountSubCategories.Code, AccountSubCategories.ID, TypeID, TypeDescription, AccountCategoriesView.ID As CatID, AccountCategoriesView.Description As CatDescription, AccountCategoriesView.LinkedServicesQuery As CatLinkedServicesQuery, AccountSubCategories.LinkedServicesQuery As SubLinkedServicesQuery FROM AccountCategoriesView Inner Join dbo.AccountSubCategories On AccountCategoriesView.ID=CategoryID Where AccountSubCategories.Archived='No'

Union

SELECT  '' As Description, '' As Code,0 As ID,0 as TypeID, '' As TypeDesc,0 as CatID, '' As CatDesc,'' As CatLinkedServicesQuery, ''  As SubLinkedServicesQuery FROM dbo.Hosp_Info
go

