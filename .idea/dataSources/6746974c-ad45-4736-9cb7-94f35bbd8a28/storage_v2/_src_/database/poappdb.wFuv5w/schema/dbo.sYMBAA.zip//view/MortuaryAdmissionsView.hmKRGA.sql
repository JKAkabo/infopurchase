create VIEW [dbo].[MortuaryAdmissionsView]

AS

Select Distinct MortuaryAdmission.UserID as Doctor, UsersView.UserID, AdmDate, DisDate, OPDNo, User_Locked, UsersView.CatID, UserCategories.Description From UserCategories Inner Join ( UsersView Inner Join MortuaryAdmission On UserNo=MortuaryAdmission.UserID) On UserCategories.CatID=UsersView.CatID where MortuaryAdmission.Archived='No'
go

