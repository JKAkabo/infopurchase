CREATE PROCEDURE [dbo].[uspUpdateAdmissionRecords] 
	
AS

DECLARE @OPDNo nvarchar(15),@Archived Nvarchar(3), @AdmID numeric(18,0),@AdmID1 numeric(18,0),@AdmID2 numeric(18,0),@AdmDate date;

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;

  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct  RecordID, OPDNo From Admissions Where Archived='No' and FirstAdmissionID=0 And LastDischargeID=0 Order by RecordID, OPDNo
  
  OPEN C
  
  FETCH NEXT FROM C INTO @AdmID, @OPDNo;

  WHILE @@fetch_status = 0
    BEGIN       
       
       BEGIN
												Set @AdmID1=0
												Set @AdmID2=0
       
            select TOP 1 @Archived=Archived from WardTransfers Where WardTransfers.Archived='No' And NewAdmRecordID=@AdmID
            if @@ROWCOUNT=0
               Begin
               
               set @AdmID1=@AdmID
               
												   set @AdmID2=dbo.GetPatientLastAdmissionRecordID(@OPDNo,@AdmID)
               
												   --set @AdmID1=dbo.GetPatientFirstAdmissionRecordID(@OPDNo,@AdmID)
												   
												   end
												   
												else
												
															select TOP 1 @Archived=Archived from WardTransfers Where WardTransfers.Archived='No' And OldAdmRecordID=@AdmID
															if @@ROWCOUNT=0
																		Begin
			               
																		set @AdmID2=@AdmID
			               
																		set @AdmID1=dbo.GetPatientFirstAdmissionRecordID(@OPDNo,@AdmID)
			               
																		--set @AdmID1=dbo.GetPatientFirstAdmissionRecordID(@OPDNo,@AdmID)
															   
																		end
												   												
												update Admissions Set FirstAdmissionID=@AdmID1,LastDischargeID=@AdmID2 Where RecordID=@AdmID And OPDNo=@OPDNo
			         												
          END
          
       FETCH NEXT FROM C INTO @AdmID, @OPDNo;

	END

	CLOSE C;
	
    DEALLOCATE C;
    

END
go

