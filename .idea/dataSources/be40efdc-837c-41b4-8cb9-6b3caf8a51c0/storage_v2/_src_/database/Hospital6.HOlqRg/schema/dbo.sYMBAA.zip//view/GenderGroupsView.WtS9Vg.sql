
CREATE VIEW [dbo].[GenderGroupsView]

AS

SELECT Description, Code FROM dbo.GenderGroups

Union

Select '-' As Description, 0 as Code from Hosp_Info

go

