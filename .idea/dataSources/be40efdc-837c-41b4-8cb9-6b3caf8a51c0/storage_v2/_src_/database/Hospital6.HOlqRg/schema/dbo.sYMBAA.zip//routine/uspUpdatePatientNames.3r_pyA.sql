CREATE PROCEDURE [dbo].[uspUpdatePatientNames] 
	
AS

DECLARE @numberStrg nvarchar(10),@numPos tinyint
        

BEGIN

set @numberStrg='0123456789'
set @numPos=1

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
        
  WHILE @numPos <= 10
  
    BEGIN
       if SUBSTRING(@numberStrg,@numpos,1)='0'  
          begin
          
          Update PatientsInfo set surname =REPLACE(Surname, '0','O')
          
          Update PatientsInfo set LastName =REPLACE(LastName, '0','O')
          
          Update PatientsInfo set MiddleName =REPLACE(MiddleName, '0','O')
          
          end
          
       else
          begin
          Update PatientsInfo set surname =REPLACE(Surname, SUBSTRING(@numberStrg,@numpos,1),'')
          
          Update PatientsInfo set LastName =REPLACE(LastName, SUBSTRING(@numberStrg,@numpos,1),'')
          
          Update PatientsInfo set MiddleName =REPLACE(MiddleName, SUBSTRING(@numberStrg,@numpos,1),'')
          
          end
          
       set @numPos=@numPos+1      
       
    END
    
END
go

