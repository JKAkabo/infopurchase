CREATE VIEW [dbo].[PatientIDTypesView]

AS

SELECT Description, ID, IsActive FROM dbo.PatientIDTypes

Union

Select 'NONE' As Description, 0 as ID, 'Yes' As IsActive from Hosp_Info
go

