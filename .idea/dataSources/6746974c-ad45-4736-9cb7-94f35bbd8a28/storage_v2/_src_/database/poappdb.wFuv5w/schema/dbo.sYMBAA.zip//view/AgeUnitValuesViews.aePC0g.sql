CREATE VIEW [dbo].[AgeUnitValuesViews]

AS

SELECT Description, Code, DescriptionTag, VbConvertionFactor FROM dbo.AgeUnitValues

UNION

SELECT '' AS Description, 0 AS Code, '' As DescriptionTag, '' As VbConvertionFactor
go

