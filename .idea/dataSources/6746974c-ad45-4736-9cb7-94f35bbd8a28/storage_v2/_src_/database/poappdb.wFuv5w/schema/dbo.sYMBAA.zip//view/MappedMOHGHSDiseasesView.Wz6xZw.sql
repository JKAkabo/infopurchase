CREATE VIEW [dbo].[MappedMOHGHSDiseasesView]

AS

Select Distinct HAMS_DHIMS_ELEMENTS_MAPPINGS_View.Description, GHSMOHDataSetID, HAMS_DHIMS_ELEMENTS_MAPPINGS_View.AgeGroupCode, HAMS_DHIMS_ELEMENTS_MAPPINGS_View.GenderCode, ServiceCode, GHSMOHCode As DisCode, ElementOrder As DisOrder, DHIMSCode, ReportID, RINDIAG,ROUDIAG,NEWDIAG,REVDIAG From HAMSReports Inner Join ( DHISDataSets Inner Join (HAMS_DHIMS_ELEMENTS_MAPPINGS_View Inner Join MOH_And_HospitalServices On (HamsCode=GHSMOHCode And DataSet_ID=GHSMOHDataSetID)) On DHISCode = DataSet_ID) On DataSetCode=DHISCode
go

