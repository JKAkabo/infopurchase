





CREATE VIEW [dbo].[EyeFramesView]

AS

Select EyeFrameDesigns.Description As DesignDesc, EyeFrameDesigns.Code As DesignCode, EyeFrameMaterials.Code As MaterialCode, EyeFrameMaterials.Description  As MaterialDesc, EyeFrameShapes.Code As ShapeCode, EyeFrameShapes.Description As ShapeDesc, EyeFrameRims.Code As RimCode, EyeFrameRims.Description As RimDesc, EyeFrameColours.Code As ColourCode, EyeFrameColours.Description As ColourDesc  From EyeFrameMaterials Inner Join (EyeFrameShapes Inner Join (EyeFrameRims Inner Join (EyeFrameColours Inner Join EyeFrameDesigns On EyeFrameColours.Code=EyeFrameDesigns.ColourID) On EyeFrameRims.Code=EyeFrameDesigns.RimID) On EyeFrameShapes.Code=EyeFrameDesigns.ShapeID) On EyeFrameMaterials.Code=EyeFrameDesigns.MaterialID

Union

Select '' As DesignDesc, 0 As DesignCode, 0 As MaterialCode, ''  As MaterialDesc, 0 As ShapeCode, '' As ShapeDesc, 0 As RimCode, '' As RimDesc, 0 As ColourCode, '' As ColourDesc  From Hosp_Info



go

