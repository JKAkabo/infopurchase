CREATE VIEW [dbo].[PatientQuestionnaireView]

AS


Select C.*, P.Score As PatScore, OPDNo, PatNo, PatAge, PatStatus, AttTime,
Remarks,ClinicCode,DoctorID,ConsultationID,RecordID,ServerTime,UserID,CAP_ID,PatAnswer  
From ClinicaQuestionnaireQuestionsView C, PatientClinicalQuestionnaires P where 
P.TypeID=C.TypeID And P.QuestionID=C.QuestionID  And P.AnswerID=C.AnswerID
go

