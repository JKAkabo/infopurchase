CREATE VIEW [dbo].[QBDispensedPrescriptionsLinesView]

AS

Select DispensedPrescriptions.RecordID As TransID, DispensedPrescriptions.UnitCost, DispensedPrescriptions.DispensedQty As MoveQty, Items.ItemID, DispensedPrescriptions.DispensedDate As TransDate, StoreID As IssuerID, OPDNo As ReceiverID,'Prescriptions' As MoveType,UPPER(Service_Places.Description) As ClientName, Items.Description As ServiceDescription, Items.ItemID As ServiceCode, Convert(Nvarchar(15),ItemClassCode) As ItemClassCode, CoPayFee 
, DispensedPrescriptions.UnitPrice, PresID, SponsorNo, PmtTypeCode, BillCategoryCode, CoPaySponsorNo, CoPayPmtTypeCode, CoPayBillCategoryCode From Service_Places Inner Join (Prescriptions Inner Join (Items Inner Join DispensedPrescriptions On Items.ItemID=DispensedPrescriptions.ItemID) On Prescriptions.RecordID=PresID) On Service_Places.Code=DispensedPrescriptions.StoreID Where Prescriptions.Archived='No' And DispensedPrescriptions.ItemID IN 
(Select Items.ItemID From Items Inner Join QBAcctsMappingView ON Convert(Nvarchar(15),ItemClassCode)=ServiceID)
go

