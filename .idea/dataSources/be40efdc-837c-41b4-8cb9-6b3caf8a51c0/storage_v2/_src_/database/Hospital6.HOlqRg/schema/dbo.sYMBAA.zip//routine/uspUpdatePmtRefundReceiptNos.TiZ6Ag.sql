CREATE PROCEDURE [dbo].[uspUpdatePmtRefundReceiptNos] 
	
AS

DECLARE @ReceiptNo nvarchar(15),@RefAmt numeric(18,6),@OPDNo nvarchar(15);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct  ReceiptNo, RefAmt,  OPDNo From BillsPaid Where RefAmt<>0 Order by ReceiptNo Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO @ReceiptNo, @RefAmt, @OPDNo;

  WHILE @@fetch_status = 0
    BEGIN
       
       update BillsPaid Set SpReceiptNo=@ReceiptNo, RefAmt=@RefAmt where OPDNo=@OPDNo And AmtPaid=@RefAmt       
       
       FETCH NEXT FROM C INTO @ReceiptNo, @RefAmt, @OPDNo;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

