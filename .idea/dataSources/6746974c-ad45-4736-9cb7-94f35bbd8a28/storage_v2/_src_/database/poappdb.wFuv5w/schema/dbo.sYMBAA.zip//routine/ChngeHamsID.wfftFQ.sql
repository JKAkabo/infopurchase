-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[ChngeHamsID] 
	-- Add the parameters for the stored procedure here

	@oldID nvarchar(100), @newHamsID nvarchar(100)
	
AS

DECLARE @Login NVARCHAR(15),@qry NVARCHAR(2000)

 set @Login='sa'

--'ALTER LOGIN ' + @Login + ' WITH PASSWORD = ''' + @Password + ''''
BEGIN

set @qry='sp_password ' + @oldID + ',' + @newHamsID + ',' + 'sa';


--set @qry='ALTER LOGIN ' + @Login + ' WITH PASSWORD = ''' + @newHamsID + ''' OLD_PASSWORD = ''' + @oldID + '''';
---EXEC	[dbo].[ChngeHamsID] @oldID = '745secret', @newHamsID = '745secret'


exec (@qry)
     
END
go

