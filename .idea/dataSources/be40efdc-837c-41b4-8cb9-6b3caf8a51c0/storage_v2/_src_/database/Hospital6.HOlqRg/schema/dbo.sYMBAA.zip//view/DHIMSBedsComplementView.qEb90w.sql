


CREATE VIEW [dbo].[DHIMSBedsComplementView]

AS

Select ISNULL(COUNT(Beds.BedNo),0) As BedCompliment, WardCode As Code, 6 As TransType From DHIMSMappedWardTypes Inner Join Beds On HamsWardCode=Beds.WardID Where BedType='REAL' and BedStatus='OPERATIONAL' Group By WardCode



go

