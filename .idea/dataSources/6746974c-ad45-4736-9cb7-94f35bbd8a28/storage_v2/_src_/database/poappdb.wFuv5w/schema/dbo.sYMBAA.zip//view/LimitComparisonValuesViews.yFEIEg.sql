CREATE VIEW [dbo].[LimitComparisonValuesViews]

AS

SELECT Description, Code FROM dbo.LimitComparisonValues

UNION

SELECT '' AS Description, 0 AS Code
go

