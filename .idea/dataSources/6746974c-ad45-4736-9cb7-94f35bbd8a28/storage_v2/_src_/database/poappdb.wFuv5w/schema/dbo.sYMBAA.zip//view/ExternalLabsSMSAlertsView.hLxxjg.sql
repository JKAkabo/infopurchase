CREATE VIEW [dbo].[ExternalLabsSMSAlertsView]

AS

SELECT Surname, LastName, LabTests.OPDNo, CellPhoneNo, ExpiryAlert, Title, LabTests.Pat_No, LabTests.RecordID, TestDate, TestTime, Verified, CatID as SerCatID, SubCatID as SerSubCatID, GrpCode, LabTests.SpecimenCode, TestCode, CollectID, LabTests.RequestID FROM SMSPatientInfoView INNER JOIN 
(LabSMSGroups Inner Join (AllSetUpServicesView Inner Join (PatientLabSpecimens Inner Join LabTests ON PatientLabSpecimens.SpecimenID=LabTests.SpecimenCode) On ItemID=TestCode) ON LabCatCode=CatID) ON SMSPatientInfoView.OPDNo = LabTests.OPDNo WHERE 
RequestID In (Select RecordID From Service_Points Inner Join ServiceRequestsView On SPCode=ClinicCode where ServiceTypeCode=11 and Type=2 and Status='Yes') And CellPhoneNo <>'' AND CellPhoneNo IS NOT NULL And LabTests.Archived='No' And LabSMSGroups.IsActive='Yes' And PatientLabSpecimens.Archived='No'
go

