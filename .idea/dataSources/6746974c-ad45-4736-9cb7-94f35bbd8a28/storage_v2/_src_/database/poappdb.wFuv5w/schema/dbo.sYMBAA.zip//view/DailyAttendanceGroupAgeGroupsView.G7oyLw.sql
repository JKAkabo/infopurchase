CREATE VIEW [dbo].[DailyAttendanceGroupAgeGroupsView]
AS

Select isnull(Count(Daily_Attendance.OPDNo),0) As PatTotal , Daily_Attendance.AgeClassCode, GenderCode, Daily_Attendance.PatCategoryCode From PatientsInfo Inner Join Daily_Attendance On PatientsInfo.OPDNo=Daily_Attendance.OPDNo Where Daily_Attendance.OPDNo<>'' Group By Daily_Attendance.AgeClassCode, GenderCode, Daily_Attendance.PatCategoryCode
go

