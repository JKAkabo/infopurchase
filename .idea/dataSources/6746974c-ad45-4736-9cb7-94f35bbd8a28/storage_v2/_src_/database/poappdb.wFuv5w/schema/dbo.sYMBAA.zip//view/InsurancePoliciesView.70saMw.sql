


CREATE VIEW [dbo].[InsurancePoliciesView]

AS

SELECT  Description, InsurancePolicies.RecordID, Code, IsActive,SponsorID,Priority,OPDCoPay,OPDDrgCoPay ,INPCoPay,INPDrgCoPay,PatientType,AttendTypeAuthorization FROM dbo.InsurancePolicies

Union

SELECT  '' As Description, 0 As RecordID, '' as Code, 'No' AS IsActive, '' As SponsorID, 0 As Priority ,0 AS OPDCoPay, 0 As OPDDrgCoPay ,0 As INPCoPay,0 As INPDrgCoPay,0 As PatientType,0 As AttendTypeAuthorization FROM dbo.Hosp_Info

go

