CREATE VIEW [dbo].[QBPurchaseOrderReceivedLinesView]

AS

Select ReceivedLineID As TransID, UnitCost, ReceivedQty As MoveQty, Items.ItemID, ReceivedOrders.ReceivedDate As TransDate, ReceivedOrders.SupplierID As IssuerID, ReceivedOrders.ReceivedStoreID As ReceiverID,'Orders' As MoveType,UPPER(ContactName) As ClientName, Items.Description As ServiceDescription, Items.ItemID As ServiceCode, Convert(Nvarchar(15),ItemClassCode) As ItemClassCode 
From Suppliers Inner Join (ReceivedOrders Inner Join (Items Inner Join OrderLinesReceived On Items.ItemID=OrderLinesReceived.ItemID) On ReceivedOrders.ReceivedID=OrderLinesReceived.ReceivedID) On Suppliers.SupplierID=ReceivedOrders.SupplierID Where OrderType=2 and ReceivedOrders.Archived='No' And OrderLinesReceived.Archived='No' And OrderLinesReceived.ItemID IN 
(Select Items.ItemID From Items Inner Join QBAcctsMappingView ON Convert(Nvarchar(15),ItemClassCode)=ServiceID) And ReceivedOrders.SupplierID IN (Select SupplierID From Suppliers Inner Join QBAcctsMappingView ON (SupplierID=ServiceID and AcctsTypeID=11))
go

