CREATE VIEW [dbo].[QBCreditItemsView]

AS

---ALL PRIVATE SPONSORED DRUGS

SELECT DISTINCT (RequiredQty *(UnitFee)) As PaidAmt ,ServiceCode ,Description As ServiceDescription,EndDate AS TransDate,RequestID As TransID,SponsorNo As ReceiverID,HWCode As IssuerID  
,'Item Credit Sale' As MoveType,UPPER(SponsorName ) as ClientName, SponsorTypeCode, Convert(Nvarchar(15),SubCatID) as ItemClassCode,'' As EpisodeSpecialityCode, 0 As DrugFee 
FROM Sponsors Inner Join(AllSetUpServicesView Inner Join PrivateClaimsServices ON ItemID =ServiceCode) ON Sponsors.SponsorNo =SponsorID WHERE PatCatCode NOT IN (0,1,4,11) 
And UnitFee>0 AND RequiredQty >0 And ServiceTypeCode=1 and Sponsors.SponsorTypeCode <>2

--(Non Copayed)	
--SELECT  ((Dispensedprescriptions.DispensedQty-Dispensedprescriptions.ReturnedQty) *Dispensedprescriptions.UnitPrice ) as PaidAmt,drugcode as ServiceCode 
--,items.Description as ServiceDescription,ReqDate as TransDate,Prescriptions.RecordID as TransID,Prescriptions.SponsorNo As ReceiverID ,ServicePlacesView.Code as IssuerID 
--,'Item Credit Sale' As MoveType,UPPER(SponsorName) as ClientName,3 As SponsorTypeCode,Convert(Nvarchar(15),ItemClassCode) as ItemClassCode,'' As EpisodeSpecialityCode, 0 As DrugFee
--FROM Sponsors Inner Join( Dispensedprescriptions Inner Join(ServicePlacesView Inner Join (Items Inner Join Prescriptions On Items.ItemID = Prescriptions.DrugCode) On ServicePlacesView.Code = Prescriptions.StoresID) on Prescriptions.RecordID=DispensedPrescriptions.PresID ) On Prescriptions.SponsorNo=Sponsors.SponsorNo
--WHERE
--  Prescriptions.PmtTypeCode NOT IN (0,1,4,11) and (DispensedPrescriptions.DispensedQty-DispensedPrescriptions.ReturnedQty)>0 And
--  UPPER(PresType)='INTERNAL' and
--  PaymentCode='P' and Archived ='No' 
--  And Sponsors.SponsorTypeCode <>2
--UNION ALL

----(Copayed)
--SELECT  ((Dispensedprescriptions.DispensedQty-Dispensedprescriptions.ReturnedQty) *Dispensedprescriptions.UnitPrice ) as PaidAmt,drugcode as ServiceCode 
--,items.Description as ServiceDescription,ReqDate as TransDate,Prescriptions.RecordID as TransID,Prescriptions.SponsorNo As ReceiverID ,ServicePlacesView.Code as IssuerID 
--,'Item Credit Sale' As MoveType,UPPER(SponsorName) as ClientName,3 As SponsorTypeCode,Convert(Nvarchar(15),ItemClassCode) as ItemClassCode,'' As EpisodeSpecialityCode, 0 As DrugFee
--FROM Sponsors Inner Join( Dispensedprescriptions Inner Join(ServicePlacesView Inner Join (Items Inner Join Prescriptions On Items.ItemID = Prescriptions.DrugCode) On ServicePlacesView.Code = Prescriptions.StoresID) on Prescriptions.RecordID=DispensedPrescriptions.PresID ) On Prescriptions.SponsorNo=Sponsors.SponsorNo
--WHERE 
--  Prescriptions.CoPayPmtTypeCode NOT IN (0,1,4,11) and (DispensedPrescriptions.DispensedQty-DispensedPrescriptions.ReturnedQty)>0 And
--  CoPaySponsorNo<>'' AND CoPayFee >0  And CoPayFee-Prescriptions.UnitPrice>0 And
--  UPPER(PresType)='INTERNAL' and
--  PaymentCode='P' and
--  Archived ='No' And  Sponsors.SponsorTypeCode <>2
go

