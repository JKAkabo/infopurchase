CREATE VIEW [dbo].[QBUnUsedDepositView]
AS
SELECT    
		   PmtRecordID As TransID
          ,BillsPaid.OPDNo As ServiceCode
          ,AmtPaid  AS PaidAmt
          ,PmtDate As TransDate
          ,'0104' as IssuerID
          ,BillsPaid.Pat_No As ReceiverID
          ,BillsPaid.Pat_No +' '+'Cash Deposit Payment' As ServiceDescription
          ,Surname+' '+LastName As ClientName 
          ,'Cash Deposit' As MoveType
FROM       
           PatientsInfo Inner Join( 
           dbo.BillsPaid Inner Join
           Deposits on BillsPaid.OPDNo 
           =Deposits.OPDNo And 
           BillsPaid.ReceiptNo =Deposits.ReceiptNo )
           On BillsPaid.OPDNo =PatientsInfo.OPDNo 
WHERE    
          (AmtPaid  > 0) AND (BillsPaid.Archived  = 'No')
go

