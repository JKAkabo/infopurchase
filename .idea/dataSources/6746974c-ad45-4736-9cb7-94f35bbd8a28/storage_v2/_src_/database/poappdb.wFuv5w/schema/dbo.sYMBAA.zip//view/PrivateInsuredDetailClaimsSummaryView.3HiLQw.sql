CREATE VIEW [dbo].[PrivateInsuredDetailClaimsSummaryView]

AS

SELECT D.ClaimEventID, D.BeginDate, D.EndDate, D.OPDNo, D.SponsorID,

ISNULL((Select SUM(C.RequiredQty * C.UnitFee) From PrivateClaimsServices C, AllSetUpServicesView A Where D.OPDNo=C.OPDNo And D.ClaimEventID=C.ClaimEventID And 
D.BeginDate=C.BeginDate And D.EndDate= C.EndDate And D.SponsorID=C.SponsorID And A.ItemID=C.ServiceCode And A.ServiceTypeCode NOT IN (1,11,12,13,14)),0) As ServicesToTal,

ISNULL((Select SUM(C.RequiredQty * C.UnitFee) From PrivateClaimsServices C, AllSetUpServicesView A Where D.OPDNo=C.OPDNo And D.ClaimEventID=C.ClaimEventID And 
D.BeginDate=C.BeginDate And D.EndDate= C.EndDate And D.SponsorID=C.SponsorID And A.ItemID=C.ServiceCode And A.ServiceTypeCode IN (1)),0) As DrugsToTal,

ISNULL((Select SUM(C.RequiredQty * C.UnitFee) From PrivateClaimsServices C, AllSetUpServicesView A Where D.OPDNo=C.OPDNo And D.ClaimEventID=C.ClaimEventID And 
D.BeginDate=C.BeginDate And D.EndDate= C.EndDate And D.SponsorID=C.SponsorID And A.ItemID=C.ServiceCode And A.ServiceTypeCode IN (11,12,13,14)),0) As DiagnosticsToTal

From PrivateClaimsDetail D
go

