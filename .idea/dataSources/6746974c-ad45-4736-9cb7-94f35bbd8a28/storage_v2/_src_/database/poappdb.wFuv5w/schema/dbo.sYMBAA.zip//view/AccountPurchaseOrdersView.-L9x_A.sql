CREATE VIEW [dbo].[AccountPurchaseOrdersView]

AS

--PURCHASE ORDERS
SELECT
	
S.ItemID As ServiceCode, S.ReceivedQty * S.UnitCost As TransAmt,S.ReceivedDate As TransDate,J.TransTypeID, J.AcctCode AS DebitAcctCode,UPPER(A.Description) as DebitAcctName,
UPPER(T.Description) as DebitPostType,ISNULL((Select TOP 1 UPPER(N.Description) From AccountCustomersVendors N Where P.SupplierID=N.MappedCode and N.TypeID=10),'') As Creditor,
O.OrderID As TransID,P.SupplierID As ClientID,

ISNULL((B.AcctCode),'') As CreditAcctCode, ISNULL(UPPER(G.Description),'') As CreditAcctName, ISNULL(UPPER(K.Description),'') As CreditPostType
	      	
FROM 
	
Suppliers P,Items R,AccountChartServicesMapping M, AccountChartSetup A,AccountPostingType T, AccountChartSetup G,AccountPostingType K,AccountsChartJournalMapping B,
OrderLinesReceived S, AccountsChartJournalMappingView J, ServicesConfigurationSetupView V, ReceivedOrders O, AccountChartServicesMapping X
	
WHERE 

R.ItemID=S.ItemID AND P.SupplierID =O.SupplierID AND J.TransTypeID=5 And A.Code=J.AcctCode And O.ReceivedID=S.ReceivedID And S.Archived='No' And O.Archived='No' And
T.Code=J.AcctPostType And J.TransTypeID=M.PostingType And J.AcctCode=M.AccountChartCode And A.Code=M.AccountChartCode And J.AcctPostType=1 
And ((V.AcctsDrugsMapID=4 and M.ServiceID = S.StoreID  AND M.ServiceTypeID=1) OR (V.AcctsDrugsMapID=3 and M.ServiceID = 1 AND M.ServiceTypeID=1) OR (V.AcctsDrugsMapID=6 and M.ServiceID = CONVERT(NVarchar(15),R.ItemTypeCode) AND M.ServiceTypeID=1) OR 
(V.AcctsDrugsMapID=2 and M.ServiceID = R.ItemID  AND M.ServiceTypeID=1) OR (V.AcctsDrugsMapID=5 and M.ServiceID = CONVERT(NVarchar(15),R.ItemClassCode) AND M.ServiceTypeID=1)) AND
B.TransTypeID=5 AND B.AcctTypeID=10 And G.Code=B.AcctCode And B.TransTypeID=J.TransTypeID AND B.AcctTypeIDJE=J.AcctTypeID And X.ServiceTypeID=3 AND 
B.AcctCodeJE=J.AcctCode And B.AcctCode=X.AccountChartCode And X.PostingType=5 AND X.ServiceID=P.SupplierID AND K.Code=B.AcctPostType And B.AcctPostType=2
	
UNION ALL

--PURCHASE ORDER RETURNS
SELECT
	
S.ItemID As ServiceCode, S.ReturnedQty * S.UnitCost,O.ReturnedDate As TransDate,J.TransTypeID, 

ISNULL((B.AcctCode),'') As DebitAcctCode, ISNULL(UPPER(G.Description),'') As DebitAcctName,'DEBIT' As DebitPostType,

ISNULL((Select TOP 1 UPPER(N.Description) From AccountCustomersVendors N Where P.SupplierID=N.MappedCode and N.TypeID=10),'') as Creditor,E.OrderID As PONo,P.SupplierID As ClientID,
J.AcctCode AS CreditAcctCode,UPPER(A.Description) as CreditAcctName,'CREDIT' as CreditPostType	
     	
FROM 
	
Suppliers P,Items R,AccountChartServicesMapping M, AccountChartSetup A,AccountPostingType T,ReceivedOrders E, AccountChartSetup G,AccountPostingType K,AccountsChartJournalMapping B,
ReturnedOrderLines S, AccountsChartJournalMappingView J, ServicesConfigurationSetupView V, ReturnedOrders O, AccountChartServicesMapping X
	
WHERE 

R.ItemID=S.ItemID AND P.SupplierID =O.SupplierID AND J.TransTypeID=5 And A.Code=J.AcctCode And O.ReturnedID=S.ReturnedNo And S.Archived='No' And O.Archived='No' And 
T.Code=J.AcctPostType And J.TransTypeID=M.PostingType And J.AcctCode=M.AccountChartCode And A.Code=M.AccountChartCode And J.AcctPostType=1 And E.ReceivedID=O.ReceivedID   
And ((V.AcctsDrugsMapID=4 and M.ServiceID = O.ReceivedStoreID AND M.ServiceTypeID=1) OR (V.AcctsDrugsMapID=3 and M.ServiceID = 1 AND M.ServiceTypeID=1)  OR (V.AcctsDrugsMapID=6 and M.ServiceID = CONVERT(NVarchar(15),R.ItemTypeCode) AND M.ServiceTypeID=1) OR 
(V.AcctsDrugsMapID=2 and M.ServiceID = R.ItemID  AND M.ServiceTypeID=1)  OR (V.AcctsDrugsMapID=5 and M.ServiceID = CONVERT(NVarchar(15),R.ItemClassCode) AND M.ServiceTypeID=1) ) AND
B.TransTypeID=5 AND B.AcctTypeID=10 And G.Code=B.AcctCode And B.TransTypeID=J.TransTypeID AND B.AcctTypeIDJE=J.AcctTypeID And X.ServiceTypeID=3 AND 
B.AcctCodeJE=J.AcctCode And B.AcctCode=X.AccountChartCode And X.PostingType=5 AND X.ServiceID=P.SupplierID AND K.Code=B.AcctPostType And B.AcctPostType=2
go

