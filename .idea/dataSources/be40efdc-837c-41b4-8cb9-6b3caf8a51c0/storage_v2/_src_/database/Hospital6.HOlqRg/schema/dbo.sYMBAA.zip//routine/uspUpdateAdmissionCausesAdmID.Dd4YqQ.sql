


CREATE PROCEDURE [dbo].[uspUpdateAdmissionCausesAdmID] 
	
AS

DECLARE @OPDNo nvarchar(15),@AdmTime datetime, @AdmID numeric(18,0);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;

  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct  RecordID , AdmTime, OPDNo From Admissions Order by RecordID Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO @AdmID, @AdmTime, @OPDNo;

  WHILE @@fetch_status = 0
    BEGIN       
       
       update AdmissionCauses Set AdmRecordID=@AdmID Where AdmTime=@AdmTime And OPDNo=@OPDNo

       FETCH NEXT FROM C INTO @AdmID, @AdmTime, @OPDNo;

	END

	CLOSE C;
	
    DEALLOCATE C;
    
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct Admissions.RecordID, Admissions.AdmTime,  Admissions.OPDNo from Admissions inner join AdmissionCauses on Admissions.OPDNo=AdmissionCauses.OPDNo and Admissions.AdmDate=AdmissionCauses.AdmDate where AdmRecordID=0 and Archived='No' 
    
  OPEN C
  
  FETCH NEXT FROM C INTO @AdmID, @AdmTime, @OPDNo;

  WHILE @@fetch_status = 0
    BEGIN       
       
       update AdmissionCauses Set AdmRecordID=@AdmID Where AdmTime=@AdmTime And OPDNo=@OPDNo and AdmRecordID=0

       FETCH NEXT FROM C INTO @AdmID, @AdmTime, @OPDNo;

	END

	CLOSE C;
	
 	DEALLOCATE C;
 	
 	
 	DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct Admissions.RecordID, Admissions.AdmTime,  Admissions.OPDNo from Admissions inner join AdmissionCauses on Admissions.OPDNo=AdmissionCauses.OPDNo and AdmissionCauses.AdmDate>=Admissions.AdmDate and AdmissionCauses.AdmDate<=Admissions.DisDate where AdmRecordID=0 and Archived='No' And Admissions.DisDate Is Not Null and AdmissionCauses.AdmDate>=Admissions.AdmDate and AdmissionCauses.AdmDate<=Admissions.DisDate
    
  OPEN C
  
  FETCH NEXT FROM C INTO @AdmID, @AdmTime, @OPDNo;

  WHILE @@fetch_status = 0
    BEGIN       
       
       update AdmissionCauses Set AdmRecordID=@AdmID Where AdmTime=@AdmTime And OPDNo=@OPDNo and AdmRecordID=0

       FETCH NEXT FROM C INTO @AdmID, @AdmTime, @OPDNo;

	END

	CLOSE C;
	
 	DEALLOCATE C;

END



go

