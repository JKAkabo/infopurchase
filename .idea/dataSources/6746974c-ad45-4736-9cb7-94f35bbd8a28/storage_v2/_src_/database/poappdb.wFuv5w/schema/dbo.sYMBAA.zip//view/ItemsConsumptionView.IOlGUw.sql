

CREATE VIEW [dbo].[ItemsConsumptionView]

AS

Select round(ConsumptionAmt/IsNull(FreqValue,1),0) As ConsumptionAmt,I.ItemID, StoreID,S.ServerDate, MoveCat, MoveType, ConverT(Date,StartDate) As StartDate, ConverT(Date,EndDate) As EndDate,
Isnull((Select sum(StockLevel) From StockedItemsView Where TypeCode=1 And ItemCode=I.ItemID
And (((IsDate(ExpiryDate)=1 And ItemExpirable ='Yes') And ((Year(ExpiryDate)> Year(Getdate())) OR 
(Year(ExpiryDate)= Year(Getdate()) And Month(ExpiryDate)>= Month(Getdate())))) Or 
(IsDate(ExpiryDate)=0 OR ItemExpirable ='No')) Group By ItemCode),0) As StockLevel, 
Isnull((Select sum(StockLevel) From StockedItemsView Where TypeCode=1 And ItemCode=I.ItemID And 
ServicePlaceCode=StoreID And (((IsDate(ExpiryDate)=1 And ItemExpirable ='Yes') And 
((Year(ExpiryDate)> Year(Getdate())) OR (Year(ExpiryDate)= Year(Getdate()) And 
Month(ExpiryDate)>= Month(Getdate())))) Or (IsDate(ExpiryDate)=0 OR ItemExpirable ='No')) Group By ServicePlaceCode),0) As StoreStockLevel
From Items I,ItemsStockmovementConsumptionView S, ItemsConsumptionParametersView P, ItemsConsumptionFreqValueView F 
Where I.Disabled='No' And I.ItemID=S.ItemID And  P.ItemsConsumpFreq=F.ItemsConsumpFreq 
and ((S.ServerDate>=Startdate And S.ServerDate<=EndDate) Or (S.ServerDate Is Null and MoveType Is Null))


go

