
CREATE VIEW [dbo].[UnitMeasuresView]
AS

SELECT Description,Code,IsActive,TypeCode FROM UnitMeasures

union

Select '' As Description, 0 as Code, 'Yes' As IsActive, 1 AS TypeCode from Hosp_Info



go

