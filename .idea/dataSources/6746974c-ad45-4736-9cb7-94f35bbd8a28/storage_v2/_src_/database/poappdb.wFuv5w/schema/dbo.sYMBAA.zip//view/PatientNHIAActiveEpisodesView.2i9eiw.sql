CREATE VIEW [dbo].[PatientNHIAActiveEpisodesView]

AS

SELECT Distinct Episode.OPDNo, Episode.Pat_No, Episode.EpisodeID, Died, Surname, LastName, MiddleName, PatientsInfo.GenderCode, PatientsInfo.StatusCode, TDOB, PatAge, Episode.StatusCode as EpisodeStatus, Episode.BillCtategoryCode, SponsorName, Episode.SponsorNo, MemberID, NHIASponsoredPatientsView.SerialNo As CardSerialNo, BeginEpisode, EndEpisode, EpisodeType, AttType, EpisodeDuration, EpisodeGDRGCode, EpisodePmtType, EpisodeFee, EpisodeSpecialityCode,ServiceType,EpisodeEnded,LastVisitDate, EpisodeDischargedStatus,EclaimProcessed,ClaimGDRGCode,ClaimServiceType,
EpisodeDoctor, ClaimDiaCode, '**' As Cap_ID, EpisodeBundled, SchemeCode, EpisodePrinted, NoOfVisit, AttDate, ClaimDataProcessed, ClaimDataProcessedBy, ClaimDataProcessedDate, ClaimPrintDate, ClaimPrintTime, ClaimPrintedBy, Clinic_Code, Service_Code, DirectID, DirectAttType, EpisodeBatchedBy, EpisodeBatchedTime, EpisodeBatchNo, MaxVisitsNo, DrugFee, ServiceFee, DiagnosticFee, PatAgeDescription FROM PatientsInfo Inner Join ( NHIASponsoredPatientsView Inner Join (Directorates Inner Join Episode On Directorates.ID=Episode.DirectID) 
On (NHIASponsoredPatientsView.OPDNo=Episode.OPDNo and NHIASponsoredPatientsView.SponsorNo=Episode.SponsorNo )) On PatientsInfo.OPDNo=Episode.OPDNo Where Episode.Archived='No' And NoOfVisit>0 and EndEpisode Is Not Null
go

