CREATE VIEW [dbo].[ItemsOrdersClassesView]

AS

SELECT Distinct  OrderLines.OrderLineID, OrderLines.OrderID  As OrderNo, ItemClassCode, Archived, OrderLineStatus, Items.ItemID, OrderLines.OrderQty, OrderLines.OrderQtyReceived,UnitCost FROM  dbo.Items Inner join OrderLines on Items.ItemID=OrderLines.ItemID where Archived='No'
go

