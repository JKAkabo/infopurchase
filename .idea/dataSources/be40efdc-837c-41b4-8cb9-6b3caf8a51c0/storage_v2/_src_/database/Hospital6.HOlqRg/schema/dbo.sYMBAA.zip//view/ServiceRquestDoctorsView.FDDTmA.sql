CREATE VIEW [dbo].[ServiceRquestDoctorsView]

AS

SELECT Distinct Consultations.AttServiceID, Consultations.OPDNo, Consultations.ClinicCode, 2 As PatStatus, Consultations.ReqDate, Consultations.ReqDate As DischargeDate, Doctor As DoctorID, RequestType, DoctorName FROM AllDoctorsView Inner Join (Consultations Inner Join Service_Requests On Service_Requests.RecordID=Consultations.AttServiceID) On AllDoctorsView.DoctorID=Doctor Where Consultations.Archived='No'

Union

Select Distinct Admissions.RecordID As AttServiceID, OPDNo, ClinicCode, 3 As PatStatus,  AdmDate As ReqDate, GETDATE() As DischargeDate, Admissions.DoctorID, 'INTERNAL' AS RequestType, DoctorName From AllDoctorsView Inner Join Admissions On AllDoctorsView.DoctorID=Admissions.DoctorID Where Admissions.Archived='No' And Discharged='No' And DisDate Is Null

Union

Select Distinct Admissions.RecordID As AttServiceID, OPDNo, ClinicCode, 2 As PatStatus,  AdmDate As ReqDate, DisDate As DischargeDate, DisAuthouriser As DoctorID, 'INTERNAL' AS RequestType, DoctorName From AllDoctorsView Inner Join Admissions On AllDoctorsView.DoctorID=DisAuthouriser Where Admissions.Archived='No' And Discharged='Yes' And DisDate Is Not Null
go

