





CREATE VIEW [dbo].[ClinicalHistoryQuestionsView]

AS

SELECT  OrderNo,SN, DSN, ClinicalHistoryQuestions.Description, ClinicalHistoryQuestions.ID, HistoryID, TypeID, ClinicalHistoryQuestions.IsActive, ClinicalHistoryQuestionTypes.Description As TypeDescription, ClinicalHistories.Description As HistoryDescription, AgeGroupCode, GenderCode FROM dbo.ClinicalHistoryQuestions, ClinicalHistories,ClinicalHistoryQuestionTypes where ClinicalHistories.ID=HistoryID and ClinicalHistoryQuestionTypes.Code=TypeID



go

