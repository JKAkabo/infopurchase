CREATE VIEW [dbo].[AccountItemsSalesView]

AS
  --------Cash Drugs Sales
  SELECT 
      s.RecordID As TransID
      ,DrugCode As ServiceCode
     ,S.Service_Fee *s.PaidQty As PaidAmt
     ,S.PmtDate As TransDate
     ,StoresID As IssuerID
     ,S.PmtTypeCode
     ,S.SponsorNo As ReceiverID
     ,i.Description as ServiceDescription
     ,UPPER(SP.Description) AS ClientName  
     ,'Cash' as SaleType 
     ,S.Pat_ID as OPDNo
     ,'Item Cash Sale' As MoveType
     ,Convert(nvarchar(15),i.ItemClassCode) As ItemClassCode   
  FROM 
       Service_Places SP Inner Join
       (Items i Inner Join(dbo.Prescriptions P Inner Join
       ServiceLinePayments S
       On P.RecordID =S.ServiceID 
       AND P.DrugCode =S.ServiceCode )
       ON i.ItemID =S.ServiceCode )
       ON SP.Code=P.StoresID 
  WHERE
      P.RecordID =S.ServiceID 
      And P.DrugCode =s.ServiceCode 
      And s.PmtTypeCode =1
      And  s.Archived='No' 
      And s.Refunded='No'
 
 UNION ALL
  
 ------Credit Drugs Sales
 ----NHIA----------------
 --SELECT Distinct 
 --  DispensedPrescriptions.RecordID,Items.ItemID, Left(ITEMS.Description,100)  As ServiceDescription
 -- ,Prescriptions.PmtTypeCode,  Prescriptions.UnitPrice AS UnitFee,Prescriptions.StoresID as IssuerID
 -- ,(DispensedPrescriptions.DispensedQty-DispensedPrescriptions.ReturnedQty)*Prescriptions.UnitPrice  As PaidAmt, ReqDate as TransDate
 -- ,Prescriptions.SponsorNo as ReceiverID,'Item Credit Sale' As MoveType,Prescriptions.OPDNo,UPPER(SponsorName )as ClientName,Convert(nvarchar(15),ITEMS.ItemClassCode) As ItemClassCode     
 --FROM 
	-- Sponsors Inner Join(NHIAPrescriptionLevels Inner Join
	-- (ITEMS inner Join (Prescriptions Inner Join DispensedPrescriptions On PresID=Prescriptions.RecordID) 
	-- On Items.ItemID=DrugCode) On NHIAPrescriptionLevels.ID = PresLevel ) 
	-- on Sponsors.SponsorNo =Prescriptions.SponsorNo 
 --WHERE
	--  ITEMS.ItemID<>'' and Archived='No'  and EpisodeID<>0 and QtyGiven>0 
	-- and Prescriptions.PmtTypeCode<>1 and Prescriptions.SponsorNo<>''
	-- and PresLevel<>0 and BillCategoryCode IN (4,11) 
	-- And ReqDate<=Prescriptions.ServerTime and Refunded ='No'
	 
 --  UNION ALL
 ----COPORATE------
Select  Prescriptions.RecordID As TransID
      ,Prescriptions.DrugCode as ServiceCode
      ,((Dispensedprescriptions.DispensedQty-Dispensedprescriptions.ReturnedQty) *Dispensedprescriptions.UnitPrice ) as PaidAmt
      , Prescriptions.ReqDate As TransDate 
      , StoresID As IssuerID
      ,Prescriptions.PmtTypeCode
      , Prescriptions.SponsorNo As ReceiverID 
      ,Items.Description As ServiceDescription
      ,UPPER(Sponsors.SponsorName) AS ClientName  
      ,'Credit' as SaleType 
      ,Prescriptions.OPDNo 
      ,'Item Credit Sale' As MoveType  
      ,Convert(nvarchar(15),Items.ItemClassCode) As ItemClassCode  
from 
 Sponsors Inner Join(Dispensedprescriptions Inner Join(ServicePlacesView Inner Join (Items Inner Join Prescriptions On Items.ItemID = Prescriptions.DrugCode) On ServicePlacesView.Code = Prescriptions.StoresID) on Prescriptions.RecordID=DispensedPrescriptions.PresID) On Prescriptions.SponsorNo=Sponsors.SponsorNo

Where
  Prescriptions.SponsorNo <>'' And 
  Prescriptions.PmtTypeCode NOT IN (0,1,4,11) And 
  PaymentCode='P' And 
  DispensedPrescriptions.DispensedQty-DispensedPrescriptions.ReturnedQty>0 And
  UPPER(PresType)='INTERNAL' And 
  Archived ='No' And
  Refunded ='No'
  
      
  
 UNION ALL
 SELECT  Prescriptions.RecordID As TransID
      , Prescriptions.DrugCode as ServiceCode
      ,((Dispensedprescriptions.DispensedQty-Dispensedprescriptions.ReturnedQty) *Dispensedprescriptions.UnitPrice)as PaidAmt
      , Prescriptions.ReqDate As TransDate 
      , StoresID As IssuerID
      ,Prescriptions.PmtTypeCode
      ,Prescriptions.SponsorNo As ReceiverID 
      ,Items.Description As ServiceDescription
      ,UPPER(Sponsors.SponsorName) AS ClientName  
      ,'Credit' as SaleType 
      ,Prescriptions.OPDNo 
      ,'Item Credit Sale' As MoveType  
      ,Convert(nvarchar(15),Items.ItemClassCode) As ItemClassCode  
FROM
 Sponsors Inner Join(Dispensedprescriptions Inner Join(ServicePlacesView Inner Join (Items Inner Join Prescriptions On Items.ItemID = Prescriptions.DrugCode) On ServicePlacesView.Code = Prescriptions.StoresID) on Prescriptions.RecordID=DispensedPrescriptions.PresID) On Prescriptions.SponsorNo=Sponsors.SponsorNo

WHERE
  Prescriptions.CoPaySponsorNo <>'' And Prescriptions.CoPayPmtTypeCode NOT IN (0,1,4,11) And 
  (CoPayFee-DispensedPrescriptions.UnitPrice)>0 and
   PaymentCode='P' And
   DispensedPrescriptions.DispensedQty-DispensedPrescriptions.ReturnedQty>0 And
   UPPER(PresType)='INTERNAL' And
   Archived ='No' and 
   Refunded ='No' 
  
  
--      --And SP.AcctsBlocked  ='No'
      
--      --Archived= 'No' And Refunded='No' 
--      --And
go

