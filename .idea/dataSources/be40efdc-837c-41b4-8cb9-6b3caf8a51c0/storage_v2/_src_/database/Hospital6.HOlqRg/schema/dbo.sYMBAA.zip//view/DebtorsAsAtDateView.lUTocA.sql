CREATE VIEW [dbo].[DebtorsAsAtDateView]

AS

SELECT Distinct PatOutTable.OPDNo As SponsorNo, PBOut As OutBal, Surname + ' ' + MiddleName + ' ' + LastName As DebtorName, EmailAddrs As EmailAdrs, CellPhoneNo AS ContactNo, Pat_No as DebtorCode,'PRIVATE CASH' AS DebtorType, '**' As Cap_ID, PatOutTable.ServerTime, PatOutTable.ServerDate, PatOutTable.OutAmt as DebtAmt
FROM PatientsInfo inner join PatientOutstandingBills As PatOutTable on PatientsInfo.OPDNo=PatOutTable.OPDNo Where PatOutTable.ServerTime IN (Select TOP 1 ServerTime From PatientOutstandingBills where PatientOutstandingBills.Pat_No = PatOutTable.Pat_No and OutAmt>0 order by PatientOutstandingBills.ServerTime Desc)

Union

Select Distinct Sponsors.SponsorNo, Sponsors.OutBal, SponsorName As DebtorName, EmailAddrs As EmailAdrs, TelNo AS ContactNo, Sponsors.SponsorNo as DebtorCode, UPPER(Description) As DebtorType, '**' As Cap_ID, SponsorOutTable.ServerTime, SponsorOutTable.TransDate As ServerDate, SponsorOutTable.SponBal as DebtAmt From 
SponsorTypes Inner Join (Sponsors Inner Join SponsorTransactions As SponsorOutTable On Sponsors.SponsorNo=SponsorOutTable.SponsorNo) On SponsorTypes.Code=SponsorTypeCode Where SponsorTypeCode<>2 and SponsorOutTable.RecordID IN (Select Top 1 RecordID From SponsorTransactions Where SponsorOutTable.SponsorNo=SponsorNo and SponBal>0  order By RecordID Desc )
go

