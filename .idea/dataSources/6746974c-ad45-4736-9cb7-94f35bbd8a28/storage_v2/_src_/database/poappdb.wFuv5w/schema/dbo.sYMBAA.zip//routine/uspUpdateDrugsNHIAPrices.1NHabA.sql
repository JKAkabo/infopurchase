CREATE PROCEDURE [dbo].[uspUpdateDrugsNHIAPrices] 
	
AS

DECLARE @itemID nvarchar(15),@ItemCost numeric(18,6);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct Items.ItemID, NHISPrice From items inner Join packs On Items.ItemID=packs.itemid where nhiscode<>'' and  nhiscode Is Not Null and Items.NHIS='Yes' And Disabled='No' Order by Items.ItemID Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO @itemID, @ItemCost;

  WHILE @@fetch_status = 0
    BEGIN

       --set @DisCategory=dbo.ItemDesc(@DisCategory);
              
       update Prescriptions Set UnitPrice=@ItemCost Where DrugCode=@itemID and ReqDate>='2016-02-14' and (BillCategoryCode=4 Or BillCategoryCode=11) and SponsorNo<>'' and EpisodeID<>0
       
       update DispensedPrescriptions Set UnitPrice=@ItemCost Where ItemID=@itemID and PresID IN (Select recordID From Prescriptions where DrugCode=@itemID and (BillCategoryCode=4 Or BillCategoryCode=11)  and SponsorNo<>'' And Archived='No' And PmtTypeCode IN (2,3)  and ReqDate>='2016-02-14')
        
       update ReturnedPrescriptions Set UnitPrice=@ItemCost Where ItemID=@itemID and PresID IN (Select recordID From Prescriptions where DrugCode=@itemID and (BillCategoryCode=4 Or BillCategoryCode=11)  and SponsorNo<>'' And Archived='No' And PmtTypeCode IN (2,3)  and ReqDate>='2016-02-14')
       
       update NHIAEpisodeServices Set ServiceFee=@ItemCost Where ServiceCode=@itemID  and ReqDate>='2016-02-14'
       
       FETCH NEXT FROM C INTO @itemID, @ItemCost;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

