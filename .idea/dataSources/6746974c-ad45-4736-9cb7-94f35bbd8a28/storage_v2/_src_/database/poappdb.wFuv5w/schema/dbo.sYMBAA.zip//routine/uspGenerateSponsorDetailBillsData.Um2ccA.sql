CREATE PROCEDURE [dbo].[uspGenerateSponsorDetailBillsData] 

	@fromDate datetime, @toDate datetime,@userID nvarchar(15),@SponsorID nvarchar(15)=''
	
AS

DECLARE @pmtDate datetime,@PmtTime datetime,@Pat_No nvarchar(15),@patName nvarchar(250),@TBill numeric(18,6),
        @AmtPaid numeric(18,6),@ReceiptNo nvarchar(15),@ReceivedBy nvarchar(15) ,@PType nvarchar(2);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  Delete from DetailBillsSummary Where UserID=@userID
  
  if @SponsorID<>''
	  DECLARE C CURSOR FAST_FORWARD FOR SELECT PmtDate,PmtTime,Pat_No,SponsorName As FullName,TAmtPaid,AmtPaid,ReceiptNo,BillsPaid.UserID,PayerType
	  from BillsPaid inner join Sponsors on BillsPaid.SponsorNo=Sponsors.SponsorNo Where PmtDate>= @FromDate And PmtDate<= @ToDate  And BillsPaid.Archived='No' 
	  And PayerType='S' And BillsPaid.SponsorNo=@SponsorID Order By PmtTime
  
  else
	  DECLARE C CURSOR FAST_FORWARD FOR SELECT PmtDate,PmtTime,Pat_No,SponsorName As FullName,TAmtPaid,AmtPaid,ReceiptNo,BillsPaid.UserID,PayerType
	  from BillsPaid inner join Sponsors on BillsPaid.SponsorNo=Sponsors.SponsorNo Where PmtDate>= @FromDate And PmtDate<= @ToDate  And BillsPaid.Archived='No' 
	  And PayerType='S' Order By PmtTime
    
  OPEN C
  
  FETCH NEXT FROM C INTO @pmtDate ,@PmtTime,@Pat_No,@patName,@TBill ,@AmtPaid,@ReceiptNo,@ReceivedBy ,@PType;
        
  WHILE @@fetch_status = 0
    BEGIN

       set @patName=dbo.ItemDesc(@patName);

       Insert into DetailBillsSummary ([PmtDate],[PmtTime],[Pat_No],[Name],[TBill],[AmtPaid],[ReceiptNo],[ReceivedBy],[PType],[FromDate],[ToDate],UserID)values 
                                      (@pmtDate ,@PmtTime,@Pat_No,@patName,@TBill ,@AmtPaid,@ReceiptNo,@ReceivedBy ,@PType,@fromDate, @toDate,@UserID)

       FETCH NEXT FROM C INTO @pmtDate ,@PmtTime,@Pat_No,@patName,@TBill ,@AmtPaid,@ReceiptNo,@ReceivedBy ,@PType;

	END

	CLOSE C;

	DEALLOCATE C;


END
go

