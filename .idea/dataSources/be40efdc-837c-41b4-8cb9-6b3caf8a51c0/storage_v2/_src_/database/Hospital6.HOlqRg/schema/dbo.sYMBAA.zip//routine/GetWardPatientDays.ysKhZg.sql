CREATE FUNCTION [dbo].[GetWardPatientDays]

(@DataElement AS NVARCHAR(20),@DateFrom as DateTime ,@DateTo as Datetime,@GenderCode as numeric) RETURNS numeric(18,0)

AS


BEGIN

Declare @AdmissionNo Numeric(18,0),@DischargedNo Numeric(18,0),@TransferInNo Numeric(18,0), @TransferOutNo as Numeric(18,0),@WardBedState Numeric(18,0)

SELECT @AdmissionNo=COUNT (DISTINCT AdmissionsWithoutWardTransfersView.RecordID ) FROM PatientsInfo Inner Join
( AdmissionsWithoutWardTransfersView Inner join Wards  on AdmissionsWithoutWardTransfersView .WardID =Wards.WardID ) 
On PatientsInfo.OPDNo=AdmissionsWithoutWardTransfersView.OPDNo WHERE Wards.WardType in (@DataElement) AND PatientsInfo.GenderCode=@GenderCode AND  AdmDate>= @DateFrom And AdmDate<= @DateTo

SELECT @DischargedNo=COUNT (DISTINCT AdmissionsWithoutWardTransfersView.RecordID ) 
FROM PatientsInfo Inner Join( AdmissionsWithoutWardTransfersView Inner join Wards  on AdmissionsWithoutWardTransfersView .WardID =Wards.WardID) On PatientsInfo.OPDNo=AdmissionsWithoutWardTransfersView.OPDNo 
WHERE Wards.WardType in (@DataElement) AND PatientsInfo.GenderCode=@GenderCode   AND  AdmDate>= @DateFrom And AdmDate<=@DateTo And AdmissionsWithoutWardTransfersView.DisDate is not null And AdmissionsWithoutWardTransfersView.DisTime is not null And AdmissionsWithoutWardTransfersView.Discharged='Yes'

SELECT  @TransferInNo=COUNT(RecordID) FROM PatientsInfo Inner Join (( dbo.Admissions Inner Join WardTransfers on RecordID=NewAdmRecordID) Inner Join Wards on Admissions.WardID =Wards.WardID) on 
PatientsInfo.OPDNo=Admissions.OPDNo  where  Admissions.Archived='No' AND PatientsInfo.GenderCode=@GenderCode and WardTransfers.Archived='No' and  Wards.WardType in (@DataElement) AND Admissions.AdmDate>= @DateFrom and Admissions.AdmDate<=  @DateTo

SELECT  @TransferOutNo=COUNT(RecordID) FROM PatientsInfo Inner Join (( dbo.Admissions Inner Join WardTransfers on RecordID=OldAdmRecordID) Inner Join Wards on Admissions.WardID =Wards.WardID) on 
PatientsInfo.OPDNo=Admissions.OPDNo  where  Admissions.Archived='No' AND PatientsInfo.GenderCode=@GenderCode and WardTransfers.Archived='No' and  Wards.WardType in (@DataElement) AND Admissions.AdmDate>= @DateFrom and Admissions.AdmDate<=  @DateTo

Set @WardBedState=(@AdmissionNo-@DischargedNo)+(@TransferInNo-@TransferOutNo)


RETURN @WardBedState;

END
go

