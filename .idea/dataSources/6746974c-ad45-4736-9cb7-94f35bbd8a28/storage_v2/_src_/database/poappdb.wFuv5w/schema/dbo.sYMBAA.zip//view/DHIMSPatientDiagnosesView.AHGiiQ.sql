
--, 'annMT9HKpPY' As DataSetID,Where RecType Not IN ('IN')
CREATE VIEW [dbo].[DHIMSPatientDiagnosesView]

AS

Select PatientsDiagnosesView.OPDNo , convert(NVARCHAR(5),  PatientsInfo.GenderCode) As GenderCode, AttDate, TDOB, ClinicCode, DiaType, ConOutCome, RecType, CaseType, AgeGroupCode, DataSetID, AgeRangeCode, ConType, ElementID, ICDCode From PatientsInfo Inner Join (DHIMSMappedDataElementsView Inner Join PatientsDiagnosesView On MappedCode=ICDCode) On PatientsInfo.OPDNo=PatientsDiagnosesView.OPDNo


go

