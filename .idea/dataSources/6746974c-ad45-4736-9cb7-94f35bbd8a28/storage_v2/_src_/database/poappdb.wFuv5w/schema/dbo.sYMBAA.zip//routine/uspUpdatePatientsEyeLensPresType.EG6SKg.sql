
CREATE PROCEDURE [dbo].[uspUpdatePatientsEyeLensPresType] 
	
AS

DECLARE @RecordID numeric(18,0);

BEGIN

Update PatientEyeExams set LensPresType=2

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct E.RecordID From dbo.PatientEyeExams E,PatientEyeExamRefraction R Where E.RecordID=R.ExamID and R.Archived='No'  and E.Archived='No' Order by E.RecordID Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO @RecordID

  WHILE @@fetch_status = 0
    BEGIN
					 
					 Update PatientEyeExams set LensPresType=1 Where RecordID=@RecordID

      FETCH NEXT FROM C INTO @RecordID

    	END

	CLOSE C;

	DEALLOCATE C;

END

go

