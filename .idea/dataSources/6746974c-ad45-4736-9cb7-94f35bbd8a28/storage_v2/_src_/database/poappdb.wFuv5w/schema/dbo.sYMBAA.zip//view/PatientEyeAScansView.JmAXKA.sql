CREATE VIEW [dbo].[PatientEyeAScansView]

AS

SELECT E.VScanID, E.ServerTime, E.UserID, M.UnitMeasure, M.ElementOrder, M.Description As ScanElement,C.Pat_No,C.OPDNo,
C.StatusCode,C.UserID As ScanUserID,E.RecordID,GenderCode,Surname,MiddleName,LastName,PatientAge,DOB,C.ScanTime,Gender,P.PatCategory,
C.PatAge, C.Remarks,E.LValue,E.RValue,C.ServerTime As ScanServerTime,C.SponsorNo,C.PatCategoryCode,Title,P.ClinicCode,
ServiceDescription, ReqRemarks,RequestID,RequesterID,P.ReqDate,P.PatStatus, U.UserID As UserName

FROM dbo.PatientEyeAScanLines E, dbo.PatientEyeAScans C, InvestigationRequestsView P, EyeExaminationElements M, UsersView U

Where C.RecordID=E.VScanID And C.OPDNo=P.OPDNo And C.Pat_No=P.Pat_No And C.RequestID=P.RecordID And C.Archived='No'
And E.Archived='No' And M.Code=E.ElementID And M.TypeID=3  and C.UserID=U.UserNo
go

