CREATE VIEW [dbo].[PatientMedicalHistoryView]

AS

SELECT Distinct HistoryID, C.Description As Question, Remarks, DoctorID, OPDNo, PatNo, PatAge, ClinicCode, PatStatus,ConsultationID,QuestionID, QueAnswer,HistoryDescription,SN, DSN,OrderNo, RecordID, 
AttDate, AttTime, P.ServerTime,P.UserID, CASE WHEN QueAnswer='' THEN 'No' Else QueAnswer END As QuetionAnswer FROM ClinicalHistoryQuestionsView C, PatientMedicalHistory P  Where ID= QuestionID  And HistoryType= HistoryID  And Archived='No'
go

