CREATE VIEW [dbo].[BillsPaidDepositsReceivedView]
AS
SELECT B.ReceiptNo, Sum(DepositAmount) As DeptAmt FROM dbo.BillsPaid B, Deposits D Where B.Archived='No' and B.ReceiptNo=D.BillReferenceNo 
and B.OPDNo=D.OPDNo Group By B.ReceiptNo

Union All

Select ReceiptNo, 0  From dbo.BillsPaid Where Archived='No' And ReceiptNo NOT IN (Select BillReferenceNo From dbo.Deposits Where Archived='No')
go

