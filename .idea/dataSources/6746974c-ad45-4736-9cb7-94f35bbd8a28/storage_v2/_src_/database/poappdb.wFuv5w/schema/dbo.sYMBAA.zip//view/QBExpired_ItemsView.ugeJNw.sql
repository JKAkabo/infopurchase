CREATE VIEW [dbo].[QBExpired_ItemsView]

AS

Select RecordID As TransID, UnitCost, Quantity As MoveQty, Expired_Items.ItemID, Convert(Date,Expired_Items.ServerDate) As TransDate, StoreID As IssuerID, Expired_Items.UserID As ReceiverID,'Expired Stocks' As MoveType,UPPER(Service_Places.Description) As ClientName, Items.Description As ServiceDescription, Items.ItemID As ServiceCode, Convert(Nvarchar(15),ItemClassCode) As ItemClassCode 
From Service_Places Inner Join (Items Inner Join Expired_Items On Items.ItemID=Expired_Items.ItemID) On Code=StoreID Where UPPER(Service_Places.Status)='YES' And Expired_Items.ItemID IN 
(Select Items.ItemID From Items Inner Join QBAcctsMappingView ON Convert(Nvarchar(15),ItemClassCode)=ServiceID)
go

