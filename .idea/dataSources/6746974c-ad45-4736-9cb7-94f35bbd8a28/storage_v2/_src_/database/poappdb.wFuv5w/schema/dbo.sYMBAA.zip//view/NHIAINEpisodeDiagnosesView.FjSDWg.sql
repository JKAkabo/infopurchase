CREATE VIEW [dbo].[NHIAINEpisodeDiagnosesView]

AS

SELECT Distinct Left(Diseases.DisDescription,100) As ServiceDescription, AdmissionCauses.DisCode As ServiceCode, 2 As PmtTypeCode, 'DIAGNOSIS(ES)' As ServicePlace, 
DiaFee as UnitFee, 1 As ServiceQty, Admissions.AdmDate As ReqDate, CASE WHEN Admissions.AdmAge>=12 THEN IsNull(Diseases.GDRGCodeA,'') ELSE IsNull(Diseases.GDRGCodeC,'') END AS GDRGCode, IsNull(Diseases.ICDCode,'') As ICDCOde, 
AdmissionCauses.EpisodeID, AdmissionCauses.OPDNo, 3 As PatStatus, Principal As IsPrincipal, Admissions.DisDate As ServiceDate, 1 As DirectID, '' As SponsorNo, 
IsNull(GDRGCodeA,'') As GDRGCodeA,IsNull(GDRGCodeC,'') As GDRGCodeC FROM Diseases Inner Join (Admissions Inner Join AdmissionCauses On 
Admissions.RecordID=AdmRecordID) On Diseases.DisCode=AdmissionCauses.DisCode Where Admissions.EpisodeID<>0  and Cancelled='No' and Admissions.DisDate Is Not Null And Admissions.Archived='No' And Admissions.Discharged='Yes'
go

