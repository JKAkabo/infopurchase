-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[CheckForUnMappedServices] 
(	
	-- Add the parameters for the function here
	@TransactionID as INT
)
RETURNS TABLE 
AS
RETURN 
(
	-- Add the SELECT statement with parameter references here
	       SELECT CONVERT(nvarchar(50),ItemID) as ItemID,(SELECT Description FROM AccountTypes WHERE ID=1)as AccountType from AllServicesView  WHERE ServiceTypeCode<>1 and (@TransactionID=13 or @TransactionID=14 or @TransactionID=16  ) 
	       except
	       SELECT serviceid,(SELECT Description FROM AccountTypes WHERE ID=1)as AccountType from AccountChartServicesMapping where AccountTypeID =1	and (@TransactionID=13 or @TransactionID=14 or @TransactionID=16  )     
           
            UNION ALL
           
           SELECT  Convert(nvarchar(10), code) as Code,(SELECT Description FROM AccountTypes WHERE ID=1)as AccountType  from ItemClasses WHERE  (@TransactionID=11 or @TransactionID=12 or @TransactionID=15  ) 
	       except
	       SELECT serviceid,(SELECT Description FROM AccountTypes WHERE ID=1)as AccountType from AccountChartServicesMapping where AccountTypeID =1	And  (@TransactionID=11 or @TransactionID=12 or @TransactionID=15  )       
           
            UNION ALL
	       
	       SELECT Convert(nvarchar(10), code) as Code,(SELECT Description FROM AccountTypes WHERE ID=6)as AccountType from ItemClasses WHERE @TransactionID in (1,2,3,4,5,6,7,8,9,10)
	        except
	       SELECT ServiceID,(SELECT Description FROM AccountTypes WHERE ID=6)as AccountType from AccountChartServicesMapping where AccountTypeID =6 And @TransactionID in (1,2,3,4,5,6,7,8,9,10)       
            
            UNION ALL
          
	       SELECT Convert(nvarchar(10), code) as Code,(SELECT Description FROM AccountTypes WHERE ID=2)as AccountType from ItemClasses WHERE @TransactionID in (4,5,8,9,10)
	        except
	       SELECT ServiceID,(SELECT Description FROM AccountTypes WHERE ID=2)as AccountType from AccountChartServicesMapping where AccountTypeID =2 And @TransactionID in (4,5,8,9,10)       
          
	       UNION ALL
	       
	       SELECT SponsorNo,(SELECT Description FROM AccountTypes WHERE ID=10)as AccountType  from Sponsors WHERE @TransactionID in (12,14) and AcctsBlocked='No' 
	        except
	       SELECT serviceID,(SELECT Description FROM AccountTypes WHERE ID=10)as AccountType from AccountChartServicesMapping where AccountTypeID =10 And @TransactionID in (12,14) 
	       
	       UNION ALL
	      
	       SELECT SupplierID,(SELECT Description FROM AccountTypes WHERE ID=11)as AccountType   from Suppliers   WHERE @TransactionID in (2,7) And Archived='No'
	        except
	       SELECT serviceID,(SELECT Description FROM AccountTypes WHERE ID=11)as AccountType from AccountChartServicesMapping where AccountTypeID =11 And @TransactionID in (2,7)
)
go

