CREATE VIEW [dbo].[ConsultationServiceRequestsView]

AS

--SELECT Distinct Service_Requests.*, Description as ServiceDescription, ServiceTypeCode, CatID, SubCatID,'**' As CAPID From AllSetUpServicesView Inner Join Service_Requests On ItemID=ServiceCode Where Archived='No'

SELECT S.*, A.Description as ServiceDescription, P.Description as ServicePlace,I.StatusCode As PatStatusCode,U.UserID As DoctorName ,Y.UserID As AssignedDoctor ,
ServiceTypeCode, A.CatID, A.SubCatID,'**' As CAPID, T.Description as PmtType, C.Description As Clinic,I.Weight,Nationality ,U.UserCategory,H.Description As PatCategory,
CASE WHEN U.UserCategory IN ('DOCTORS','DOCTOR','MEDICAL ASSISTANTS','PHYSICIAN ASSISTANTS','MEDICAL ASSISTANT','PHYSICIAN ASSISTANT','LOCUM DOCTORS','MIDWIVES','MIDWIVE') THEN RequesterID Else '' End As RequestedDoc,
V.Description As PatStatus,LastName,  MiddleName,  Surname, G.Description As Gender, Title, GenderCode, CONVERT(Date, TDOB) AS DOB, CONVERT(date,getdate()) as TodayDate,
CASE WHEN Year(CONVERT(Date, TDOB))=Year(getdate()) Then 0 WHEN Month(getdate())>Month(CONVERT(Date, TDOB)) Or (Month(getdate())=Month(CONVERT(Date, TDOB)) And day(getdate())>=day(CONVERT(Date, TDOB))) Then 
DateDiff(M,  CONVERT(Date, TDOB), getdate())/12 Else DateDiff(YYYY,  CONVERT(Date, TDOB), getdate()) - 1 END As PatientAge,C.QueueTimeBasedOn, W.Description As ConsultRoom
From AllSetUpServicesView A, Service_Requests S, ServicePlacesView P, PaymentTypessView T, PatientCategoryView H,
ClinicsView C, PatientsInfo I, GenderGroups G, PatientStatusView V, UsersView U, ConsultingRoomsView W, UsersView Y Where S.Archived='No' and H.Code=S.BillCategoryCode 
and ItemID=ServiceCode and P.Code=ServicePlaceCode and T.Code=S.PmtTypeCode and C.SPCode=ClinicCode and U.UserNo=RequesterID and W.Code=AssignedRoomID and Y.UserNo=AssignedUserID 
and G.Code=GenderCode and I.OPDNo=S.OPDNo and I.StatusCode=V.Code and ServiceTypeCode=5 and I.StatusCode=2
go

