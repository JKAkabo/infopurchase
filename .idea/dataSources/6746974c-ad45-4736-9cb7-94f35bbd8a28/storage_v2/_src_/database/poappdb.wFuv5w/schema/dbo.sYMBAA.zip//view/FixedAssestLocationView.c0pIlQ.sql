CREATE VIEW [dbo].[FixedAssestLocationView]

AS

SELECT LEFT(FixedAssetLocations.Description,100) As Location, Code FROM dbo.FixedAssetLocations
go

