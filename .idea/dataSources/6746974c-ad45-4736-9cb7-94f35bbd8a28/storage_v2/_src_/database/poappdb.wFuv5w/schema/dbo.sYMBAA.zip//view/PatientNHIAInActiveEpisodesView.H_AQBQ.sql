CREATE VIEW [dbo].[PatientNHIAInActiveEpisodesView]

AS

SELECT Distinct  Episode.OPDNo, Episode.Pat_No, Episode.EpisodeID, PatientNHIAActiveEpisodesView.EpisodeID As ActiveEpiID, Died, Surname, LastName, MiddleName, PatientNHIAActiveEpisodesView.GenderCode, Episode.StatusCode, TDOB, Episode.PatAge, Episode.StatusCode as EpisodeStatus, Episode.BillCtategoryCode, SponsorName, Episode.SponsorNo, Episode.BeginEpisode, Episode.EndEpisode, Episode.EpisodeType, Episode.AttType, Episode.EpisodeGDRGCode, Episode.EpisodePmtType, Episode.EpisodeFee, Episode.EpisodeSpecialityCode,
Episode.AttDate, Episode.ClaimDataProcessed, Episode.ClaimDataProcessedBy, Episode.ClaimDataProcessedDate, Episode.ClaimPrintDate, Episode.ClaimPrintTime, Episode.ClaimPrintedBy, Episode.Clinic_Code, Episode.Service_Code, Episode.DirectID, Directorates.DirectAttType, Episode.EpisodeBatchedBy, Episode.EpisodeBatchedTime, Episode.EpisodeBatchNo, Episode.MaxVisitsNo, Episode.DrugFee, Episode.ServiceFee FROM PatientNHIAActiveEpisodesView Inner Join 
(Directorates Inner Join Episode On Directorates.ID=Episode.DirectID) On (PatientNHIAActiveEpisodesView.OPDNo=Episode.OPDNo and PatientNHIAActiveEpisodesView.BeginEpisode=Episode.BeginEpisode and PatientNHIAActiveEpisodesView.EndEpisode=Episode.EndEpisode and PatientNHIAActiveEpisodesView.DirectAttType=Directorates.DirectAttType) Where Episode.Archived='No'  and Episode.NoOfVisit=0 and Episode.StatusCode=2
go

