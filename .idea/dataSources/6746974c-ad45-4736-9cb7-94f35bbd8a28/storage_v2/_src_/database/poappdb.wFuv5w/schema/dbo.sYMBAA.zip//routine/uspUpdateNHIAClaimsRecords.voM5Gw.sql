CREATE PROCEDURE [dbo].[uspUpdateNHIAClaimsRecords] 
	
AS

DECLARE @OPDNo nvarchar(15),@ClinicCode nvarchar(10),@EpisodeID numeric(18,0),
@RecordID numeric(18,0),@DisCode nvarchar(15),@DisDesc nvarchar(250),
@ClaimICDCode nvarchar(15), @AdmTime datetime,@StartDate datetime,@EndDate Datetime

BEGIN

SET @StartDate=''
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  --Consultations
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct E.OPDNo, E.EpisodeID, EndEpisode, BeginEpisode, Clinic_Code From Episode E Where E.Archived='No' And E.StatusCode=2 And E.Server_Time>=@StartDate Order by E.EpisodeID,E.OPDNo
            
  OPEN C
  
  FETCH NEXT FROM C INTO @OPDNo, @EpisodeID, @EndDate, @AdmTime, @ClinicCode      

  WHILE @@fetch_status = 0
    BEGIN
     
		 update Service_Requests Set EpisodeID=@EpisodeID Where ReqDate=@AdmTime and OPDNo=@OPDNo and ClinicCode=@ClinicCode
	   
		 update Consultations Set EpisodeID=@EpisodeID Where ReqDate=@AdmTime and OPDNo=@OPDNo and ClinicCode=@ClinicCode
		 
		 update Prescriptions Set EpisodeID=@EpisodeID Where ReqDate=@AdmTime and OPDNo=@OPDNo and ClinicCode=@ClinicCode
		 			
		 FETCH NEXT FROM C INTO @OPDNo, @EpisodeID, @EndDate, @AdmTime, @ClinicCode
	     
	 END
	     
	 CLOSE C;
     
     DEALLOCATE C;
         
  --Admissions
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct E.OPDNo, E.EpisodeID, EndEpisode, BeginEpisode, Clinic_Code From Episode E Where E.Archived='No' And E.StatusCode=3 And E.Server_Time>=@StartDate Order by E.EpisodeID,E.OPDNo
            
  OPEN C
  
  FETCH NEXT FROM C INTO @OPDNo, @EpisodeID, @EndDate, @AdmTime, @ClinicCode      

  WHILE @@fetch_status = 0
    BEGIN
     
	 update Admissions Set EpisodeID=@EpisodeID Where ((AdmDate>=@AdmTime and DisDate<=@EndDate And Discharged='Yes') Or (AdmDate>=@AdmTime and DisDate Is Null and @EndDate Is Null And Discharged='No')) And OPDNo=@OPDNo
   			 	 
	 update Prescriptions Set EpisodeID=@EpisodeID Where ((ReqDate>=@AdmTime and ReqDate<=@EndDate) Or (ReqDate>=@AdmTime and ReqDate<=GETDATE() and @EndDate Is Null)) and OPDNo=@OPDNo 
	 
	 update AdmissionCauses Set EpisodeID=@EpisodeID Where OPDNo=@OPDNo and AdmRecordID IN (Select RecordID From Admissions A Where ((A.AdmDate>=@AdmTime and A.DisDate<=@EndDate And A.Discharged='Yes') Or (A.AdmDate>=@AdmTime and A.DisDate Is Null and @EndDate Is Null And A.Discharged='No')) And A.OPDNo=@OPDNo)
	 
	 update InPatientConsultations Set EpisodeID=@EpisodeID Where OPDNo=@OPDNo and AdmID IN (Select RecordID From Admissions A Where ((A.AdmDate>=@AdmTime and A.DisDate<=@EndDate And A.Discharged='Yes') Or (A.AdmDate>=@AdmTime and A.DisDate Is Null and @EndDate Is Null And A.Discharged='No')) And A.OPDNo=@OPDNo)
	 
	 FETCH NEXT FROM C INTO @OPDNo, @EpisodeID, @EndDate, @AdmTime, @ClinicCode
	     
    END
	     
	CLOSE C;
     
    DEALLOCATE C;
     
END
go

