CREATE PROCEDURE [dbo].[uspUpdateDiseasesCategory] 
	
AS

DECLARE @DisCategory nvarchar(250),@DisCatCode smallint;

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT [Description],CatCode From MOHDiseaseCategories Order by CatCode Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO @DisCategory, @DisCatCode;

  WHILE @@fetch_status = 0
    BEGIN

       --set @DisCategory=dbo.ItemDesc(@DisCategory);
       
       update Diseases Set ClassCode=@DisCatCode,CategoryCode=@DisCatCode where upper(ltrim(rtrim(DisClass)))=rtrim(ltrim(@DisCategory))

       FETCH NEXT FROM C INTO @DisCategory, @DisCatCode;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

