CREATE PROCEDURE [dbo].[uspUpdateClaimsICD10Codes] 
	
AS

DECLARE @DisCode nvarchar(15), @ICDCode nvarchar(15);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;

  DECLARE C CURSOR FAST_FORWARD FOR SELECT DISTINCT DisCode, ICDCode from Episode Inner Join ( Diseases inner join NHIAEpisodeServices on DisCode=NHIAEpisodeServices.ServiceCode)  on Episode.EpisodeID=NHIAEpisodeServices.EpisodeID where ServiceTypeCode IN (2) and YEAR(Episode.EndEpisode)=2014 and month(Episode.EndEpisode)=1 and Archived='No' and ICD10Code<>ICDCode  AND ICDCode Is Not Null and ltrim(ICDCode) NOT IN ('','.',' ') order By DisCode
  
  OPEN C
  
  FETCH NEXT FROM C INTO @DisCode, @ICDCode;

  WHILE @@fetch_status = 0
    BEGIN

       --set @DisCategory=dbo.ItemDesc(@DisCategory);
       
       update NHIAEpisodeServices Set ICD10Code=@ICDCode Where ServiceCode=@DisCode And ServiceTypeCode=2

       FETCH NEXT FROM C INTO @DisCode, @ICDCode;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

