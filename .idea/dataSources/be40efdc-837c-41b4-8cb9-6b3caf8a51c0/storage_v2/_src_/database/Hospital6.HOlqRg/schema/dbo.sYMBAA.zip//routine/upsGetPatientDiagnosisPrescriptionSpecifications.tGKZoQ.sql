
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[upsGetPatientDiagnosisPrescriptionSpecifications] 
	-- Add the parameters for the stored procedure here

	@DisCode nvarchar(15),@ItemPresSpecType tinyint,@ItemPresSpecUnit tinyint,
    @PatientSpecValue numeric(18,2)
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    Select Distinct DiseaseDrugs.*, PrescriptionFrequencies.Description As Frequency, Diseases.PresUnitCode AS DiagPresUnit, ItemCode, Items.Description as ItemDesc, ItemTypeCode, IssueUnitQuantity,DefaultMethodCode, PresLevel 
    ,CoversionFactor, PresentationCode, ManufacturerCode, PresQuanityPerIssueUnit, PresUnitQuantity, Items.PresUnitCode, IssueUnitCode,AllowCoPay,Sharing,DeterminePresQty,MinPresQty,MaxPresQty From Diseases Inner Join (Items Inner Join ( PrescriptionFrequencies Inner Join DiseaseDrugs On 
    PrescriptionFrequencies.Code=DiseaseDrugs.FreqCode) On Items.ItemID=ItemCode) On Diseases.DisCode=DiseaseDrugs.DisCode Where Diseases.DisCode= @DisCode And 
    Diseases.PresUnitCode=@ItemPresSpecType And ValueUnit=@ItemPresSpecUnit And MinValue<=@PatientSpecValue
    And MaxValue>=@PatientSpecValue
     


END


go

