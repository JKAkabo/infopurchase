CREATE PROCEDURE [dbo].[uspGeneratePatientDetailPmtServices] 

	@fromDate Datetime,@toDate Datetime, @UserID nvarchar(15), @Pat_ID nvarchar(15)='', @cashier_ID nvarchar(15)=''
	
AS

DECLARE @serDesc nvarchar(250),@ItemID nvarchar(15),@PaidQty numeric(18,2),@UnitPrice numeric(18,6),@PmtTypeCode Tinyint,
        @SponsorNo nvarchar(15),@serPlace nvarchar(15),@reqDate datetime,@cashier nvarchar(15),@receiptNo nvarchar(15), @PmtDate DateTime;

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  Delete from PatientReceiptServices Where UserID=@UserID
  
  if @Pat_ID=''
	if @cashier_ID=''
	 DECLARE C CURSOR FAST_FORWARD FOR SELECT Items.Description,ItemID,PaidQty,UnitPrice,PmtTypeCode,SponsorNo,ReceiptNo,StoresID,PresDate,PmtUserID,PmtDate From Items Inner Join Prescriptions
	 On Items.ItemID =Prescriptions.DrugCode where PmtDate >= @fromDate and PmtDate <= @toDate and Prescriptions.Archived='No' Order by Items.Description Asc
    else
    
     DECLARE C CURSOR FAST_FORWARD FOR SELECT Items.Description,ItemID,PaidQty,UnitPrice,PmtTypeCode,SponsorNo,ReceiptNo,StoresID,PresDate,PmtUserID,PmtDate From Items Inner Join Prescriptions
	 On Items.ItemID =Prescriptions.DrugCode where PmtDate >= @fromDate and PmtDate <= @toDate and Prescriptions.Archived='No' and Prescriptions.PmtUserID=@cashier_ID Order by Items.Description Asc
 
  else
	 if @cashier_ID=''
		 DECLARE C CURSOR FAST_FORWARD FOR SELECT Items.Description,ItemID,PaidQty,UnitPrice,PmtTypeCode,SponsorNo,ReceiptNo,StoresID,PresDate,PmtUserID,PmtDate From Items Inner Join Prescriptions
		 On Items.ItemID =Prescriptions.DrugCode where PmtDate >= @fromDate and PmtDate <= @toDate and Prescriptions.Archived='No' And OPDNo=@Pat_ID Order by Items.Description Asc
     else
        DECLARE C CURSOR FAST_FORWARD FOR SELECT Items.Description,ItemID,PaidQty,UnitPrice,PmtTypeCode,SponsorNo,ReceiptNo,StoresID,PresDate,PmtUserID,PmtDate From Items Inner Join Prescriptions
		 On Items.ItemID =Prescriptions.DrugCode where PmtDate >= @fromDate and PmtDate <= @toDate and Prescriptions.Archived='No' And OPDNo=@Pat_ID and Prescriptions.PmtUserID=@cashier_ID Order by Items.Description Asc
  OPEN C
  
  FETCH NEXT FROM C INTO @serDesc, @ItemID, @PaidQty, @UnitPrice, @PmtTypeCode, @SponsorNo,@ReceiptNo,@serPlace ,@reqDate,@cashier,@PmtDate;
  WHILE @@fetch_status = 0
    BEGIN

       set @serDesc=dbo.ItemDesc(@serDesc);

       Insert into PatientReceiptServices (SerDesc, SerID, PaidQty, UnitFee, PmtTypeCode, SponsorNo,ReceiptNo,serPlace ,reqDate,cashier,pmtDate,UserID,FromDate,ToDate)values 
       (@serDesc, @ItemID, @PaidQty, @UnitPrice, @PmtTypeCode, @SponsorNo,@receiptNo,@serPlace ,@reqDate,@cashier,@PmtDate, @UserID,@fromDate,@toDate )

       FETCH NEXT FROM C INTO @serDesc, @ItemID, @PaidQty, @UnitPrice, @PmtTypeCode, @SponsorNo,@ReceiptNo,@serPlace ,@reqDate,@cashier,@PmtDate;

	END

	CLOSE C;

	DEALLOCATE C;

--co-pay prescriptions
 -- if @Pat_ID=''
	--  if @cashier_ID=''
	--	  DECLARE C CURSOR FAST_FORWARD FOR SELECT Items.Description,ItemID,CoPayServices.PaidQty,(CoPayFee-UnitPrice) As UnitPrice,CoPayServices.PmtTypeCode,CoPayServices.SponsorNo,CoPayServices.ReceiptNo,StoresID,PresDate,CoPayServices.PmtUserID,CoPayServices.PmtDate From Items Inner Join (CoPayServices Inner Join Prescriptions
	--	  On CoPayServices.ServiceID =Prescriptions.DrugCode and CoPayServices.RecordID =Prescriptions.RecordID) On Items.ItemID =Prescriptions.DrugCode where CoPayServices.PmtDate >= @fromDate and CoPayServices.PmtDate <= @toDate and Prescriptions.Archived='No' Order by Items.Description Asc
 --     else
 --         DECLARE C CURSOR FAST_FORWARD FOR SELECT Items.Description,ItemID,CoPayServices.PaidQty,(CoPayFee-UnitPrice) As UnitPrice,CoPayServices.PmtTypeCode,CoPayServices.SponsorNo,CoPayServices.ReceiptNo,StoresID,PresDate,CoPayServices.PmtUserID,CoPayServices.PmtDate From Items Inner Join (CoPayServices Inner Join Prescriptions
	--	  On CoPayServices.ServiceID =Prescriptions.DrugCode and CoPayServices.RecordID =Prescriptions.RecordID) On Items.ItemID =Prescriptions.DrugCode where CoPayServices.PmtDate >= @fromDate and CoPayServices.PmtDate <= @toDate and Prescriptions.Archived='No' and Prescriptions.PmtUserID=@cashier_ID Order by Items.Description Asc  
 -- else
	-- if @cashier_ID='' 
	--   DECLARE C CURSOR FAST_FORWARD FOR SELECT Items.Description,ItemID,CoPayServices.PaidQty,(CoPayFee-UnitPrice) As UnitPrice,CoPayServices.PmtTypeCode,CoPayServices.SponsorNo,CoPayServices.ReceiptNo,StoresID,PresDate,CoPayServices.PmtUserID,CoPayServices.PmtDate From Items Inner Join (CoPayServices Inner Join Prescriptions
	--   On CoPayServices.ServiceID =Prescriptions.DrugCode and CoPayServices.RecordID =Prescriptions.RecordID) On Items.ItemID =Prescriptions.DrugCode where CoPayServices.PmtDate >= @fromDate and CoPayServices.PmtDate <= @toDate and Prescriptions.Archived='No' And Prescriptions.OPDNo=@Pat_ID Order by Items.Description Asc
 --    else
 --      DECLARE C CURSOR FAST_FORWARD FOR SELECT Items.Description,ItemID,CoPayServices.PaidQty,(CoPayFee-UnitPrice) As UnitPrice,CoPayServices.PmtTypeCode,CoPayServices.SponsorNo,CoPayServices.ReceiptNo,StoresID,PresDate,CoPayServices.PmtUserID,CoPayServices.PmtDate From Items Inner Join (CoPayServices Inner Join Prescriptions
	--   On CoPayServices.ServiceID =Prescriptions.DrugCode and CoPayServices.RecordID =Prescriptions.RecordID) On Items.ItemID =Prescriptions.DrugCode where CoPayServices.PmtDate >= @fromDate and CoPayServices.PmtDate <= @toDate and Prescriptions.Archived='No' And Prescriptions.OPDNo=@Pat_ID and Prescriptions.PmtUserID=@cashier_ID Order by Items.Description Asc
  
 -- OPEN C
  
 -- FETCH NEXT FROM C INTO @serDesc, @ItemID, @PaidQty, @UnitPrice, @PmtTypeCode, @SponsorNo,@ReceiptNo,@serPlace ,@reqDate,@cashier,@PmtDate;
 -- WHILE @@fetch_status = 0
 --   BEGIN

 --      set @serDesc=dbo.ItemDesc(@serDesc);

 --      Insert into PatientReceiptServices (SerDesc, SerID, PaidQty, UnitFee, PmtTypeCode, SponsorNo,ReceiptNo,serPlace ,reqDate,cashier,pmtDate,UserID,FromDate,ToDate)values 
 --      (@serDesc, @ItemID, @PaidQty, @UnitPrice, @PmtTypeCode, @SponsorNo,@receiptNo,@serPlace ,@reqDate,@cashier,@PmtDate, @UserID,@fromDate,@toDate )

 --      FETCH NEXT FROM C INTO @serDesc, @ItemID, @PaidQty, @UnitPrice, @PmtTypeCode, @SponsorNo,@ReceiptNo,@serPlace ,@reqDate,@cashier,@PmtDate;

	--END

	--CLOSE C;

	--DEALLOCATE C;
	
  if @Pat_ID=''	
	 if @cashier_ID='' 
		  DECLARE C CURSOR FAST_FORWARD FOR SELECT ServiceType,Service_Requests.ServiceCode,PaidQty,Service_Fee,PmtTypeCode,SponsorNo,ReceiptNo,SerPlaceCode,ReqDate,PmtUserID,PmtDate From Service_Types Inner Join Service_Requests
		  On Service_Types.ServiceCode =Service_Requests.ServiceCode where  PmtDate >= @fromDate and PmtDate <= @toDate  and Service_Requests.Archived='No' 
		  Order by ServiceType Asc
     else
          DECLARE C CURSOR FAST_FORWARD FOR SELECT ServiceType,Service_Requests.ServiceCode,PaidQty,Service_Fee,PmtTypeCode,SponsorNo,ReceiptNo,SerPlaceCode,ReqDate,PmtUserID,PmtDate From Service_Types Inner Join Service_Requests
		  On Service_Types.ServiceCode =Service_Requests.ServiceCode where  PmtDate >= @fromDate and PmtDate <= @toDate  and Service_Requests.Archived='No' and Service_Requests.PmtUserID=@cashier_ID
		  Order by ServiceType Asc
  else
     if @cashier_ID='' 
		  DECLARE C CURSOR FAST_FORWARD FOR SELECT ServiceType,Service_Requests.ServiceCode,PaidQty,Service_Fee,PmtTypeCode,SponsorNo,ReceiptNo,SerPlaceCode,ReqDate,PmtUserID,PmtDate From Service_Types Inner Join Service_Requests
		  On Service_Types.ServiceCode =Service_Requests.ServiceCode where  PmtDate >= @fromDate and PmtDate <= @toDate  and Service_Requests.Archived='No' And OPDNo=@Pat_ID
		  Order by ServiceType Asc
	 else
	      DECLARE C CURSOR FAST_FORWARD FOR SELECT ServiceType,Service_Requests.ServiceCode,PaidQty,Service_Fee,PmtTypeCode,SponsorNo,ReceiptNo,SerPlaceCode,ReqDate,PmtUserID,PmtDate From Service_Types Inner Join Service_Requests
		  On Service_Types.ServiceCode =Service_Requests.ServiceCode where  PmtDate >= @fromDate and PmtDate <= @toDate  and Service_Requests.Archived='No' And OPDNo=@Pat_ID and Service_Requests.PmtUserID=@cashier_ID
		  Order by ServiceType Asc
  OPEN C
  
  FETCH NEXT FROM C INTO @serDesc, @ItemID, @PaidQty, @UnitPrice, @PmtTypeCode, @SponsorNo,@ReceiptNo,@serPlace ,@reqDate,@cashier,@PmtDate;
  WHILE @@fetch_status = 0
    BEGIN
       set @serDesc=dbo.ItemDesc(@serDesc);

       Insert into PatientReceiptServices (SerDesc, SerID, PaidQty, UnitFee, PmtTypeCode, SponsorNo,ReceiptNo,serPlace ,reqDate,cashier,pmtDate,UserID,FromDate,ToDate)values 
       (@serDesc, @ItemID, @PaidQty, @UnitPrice, @PmtTypeCode, @SponsorNo,@receiptNo,@serPlace ,@reqDate,@cashier,@PmtDate, @UserID,@fromDate,@toDate )

       FETCH NEXT FROM C INTO @serDesc, @ItemID, @PaidQty, @UnitPrice, @PmtTypeCode, @SponsorNo,@ReceiptNo,@serPlace ,@reqDate,@cashier,@PmtDate;

	END

	CLOSE C;

	DEALLOCATE C;
  
  if @Pat_ID=''
	    if @cashier_ID='' 
			  DECLARE C CURSOR FAST_FORWARD FOR SELECT FeeType,Service_Requests.ServiceCode,PaidQty,Service_Fee,PmtTypeCode,SponsorNo,ReceiptNo,SerPlaceCode,ReqDate,PmtUserID,PmtDate From WardFees Inner Join Service_Requests
			  On WardFees.FeeID =Service_Requests.ServiceCode where PmtDate >= @fromDate and PmtDate <= @toDate  and Service_Requests.Archived='No' 
			  Order by FeeType Asc
        else
              DECLARE C CURSOR FAST_FORWARD FOR SELECT FeeType,Service_Requests.ServiceCode,PaidQty,Service_Fee,PmtTypeCode,SponsorNo,ReceiptNo,SerPlaceCode,ReqDate,PmtUserID,PmtDate From WardFees Inner Join Service_Requests
			  On WardFees.FeeID =Service_Requests.ServiceCode where PmtDate >= @fromDate and PmtDate <= @toDate  and Service_Requests.Archived='No' and Service_Requests.PmtUserID=@cashier_ID
			  Order by FeeType Asc
  else
	   if @cashier_ID='' 
			  DECLARE C CURSOR FAST_FORWARD FOR SELECT FeeType,Service_Requests.ServiceCode,PaidQty,Service_Fee,PmtTypeCode,SponsorNo,ReceiptNo,SerPlaceCode,ReqDate,PmtUserID,PmtDate From WardFees Inner Join Service_Requests
			  On WardFees.FeeID =Service_Requests.ServiceCode where PmtDate >= @fromDate and PmtDate <= @toDate  and Service_Requests.Archived='No' And OPDNo=@Pat_ID 
			  Order by FeeType Asc
      else
              DECLARE C CURSOR FAST_FORWARD FOR SELECT FeeType,Service_Requests.ServiceCode,PaidQty,Service_Fee,PmtTypeCode,SponsorNo,ReceiptNo,SerPlaceCode,ReqDate,PmtUserID,PmtDate From WardFees Inner Join Service_Requests
			  On WardFees.FeeID =Service_Requests.ServiceCode where PmtDate >= @fromDate and PmtDate <= @toDate  and Service_Requests.Archived='No' And OPDNo=@Pat_ID and Service_Requests.Archived='No' and Service_Requests.PmtUserID=@cashier_ID 
			  Order by FeeType Asc
  OPEN C
  
  FETCH NEXT FROM C INTO @serDesc, @ItemID, @PaidQty, @UnitPrice, @PmtTypeCode, @SponsorNo,@ReceiptNo,@serPlace ,@reqDate,@cashier,@PmtDate;
  WHILE @@fetch_status = 0
    BEGIN
     
       set @serDesc=dbo.ItemDesc(@serDesc);

       Insert into PatientReceiptServices (SerDesc, SerID, PaidQty, UnitFee, PmtTypeCode, SponsorNo,ReceiptNo,serPlace ,reqDate,cashier,pmtDate,UserID,FromDate,ToDate)values 
       (@serDesc, @ItemID, @PaidQty, @UnitPrice, @PmtTypeCode, @SponsorNo,@receiptNo,@serPlace ,@reqDate,@cashier,@PmtDate, @UserID,@fromDate,@toDate )

       FETCH NEXT FROM C INTO @serDesc, @ItemID, @PaidQty, @UnitPrice, @PmtTypeCode, @SponsorNo,@ReceiptNo,@serPlace ,@reqDate,@cashier,@PmtDate;

	END

	CLOSE C;

	DEALLOCATE C;

  if @Pat_ID=''
	  if @cashier_ID='' 
		  DECLARE C CURSOR FAST_FORWARD FOR SELECT FeeType,Service_Requests.ServiceCode,PaidQty,Service_Fee,PmtTypeCode,SponsorNo,ReceiptNo,SerPlaceCode,ReqDate,PmtUserID,PmtDate From MortuaryFees Inner Join Service_Requests
		  On MortuaryFees.FeeID =Service_Requests.ServiceCode where PmtDate >= @fromDate and PmtDate <= @toDate and Service_Requests.Archived='No'
		  Order by FeeType Asc
	  else
		  DECLARE C CURSOR FAST_FORWARD FOR SELECT FeeType,Service_Requests.ServiceCode,PaidQty,Service_Fee,PmtTypeCode,SponsorNo,ReceiptNo,SerPlaceCode,ReqDate,PmtUserID,PmtDate From MortuaryFees Inner Join Service_Requests
		  On MortuaryFees.FeeID =Service_Requests.ServiceCode where PmtDate >= @fromDate and PmtDate <= @toDate and Service_Requests.Archived='No' and Service_Requests.PmtUserID=@cashier_ID 
		  Order by FeeType Asc 
  else
  	  if @cashier_ID='' 
  		  DECLARE C CURSOR FAST_FORWARD FOR SELECT FeeType,Service_Requests.ServiceCode,PaidQty,Service_Fee,PmtTypeCode,SponsorNo,ReceiptNo,SerPlaceCode,ReqDate,PmtUserID,PmtDate From MortuaryFees Inner Join Service_Requests
		  On MortuaryFees.FeeID =Service_Requests.ServiceCode where PmtDate >= @fromDate and PmtDate <= @toDate and Service_Requests.Archived='No' And OPDNo=@Pat_ID 
		  Order by FeeType Asc
      else
          DECLARE C CURSOR FAST_FORWARD FOR SELECT FeeType,Service_Requests.ServiceCode,PaidQty,Service_Fee,PmtTypeCode,SponsorNo,ReceiptNo,SerPlaceCode,ReqDate,PmtUserID,PmtDate From MortuaryFees Inner Join Service_Requests
		  On MortuaryFees.FeeID =Service_Requests.ServiceCode where PmtDate >= @fromDate and PmtDate <= @toDate and Service_Requests.Archived='No' And OPDNo=@Pat_ID and Service_Requests.PmtUserID=@cashier_ID 
		  Order by FeeType Asc
       
  OPEN C
  
  FETCH NEXT FROM C INTO @serDesc, @ItemID, @PaidQty, @UnitPrice, @PmtTypeCode, @SponsorNo,@ReceiptNo,@serPlace ,@reqDate,@cashier,@PmtDate;
  WHILE @@fetch_status = 0
    BEGIN
       
       set @serDesc=dbo.ItemDesc(@serDesc);

       Insert into PatientReceiptServices (SerDesc, SerID, PaidQty, UnitFee, PmtTypeCode, SponsorNo,ReceiptNo,serPlace ,reqDate,cashier,pmtDate,UserID,FromDate,ToDate)values 
       (@serDesc, @ItemID, @PaidQty, @UnitPrice, @PmtTypeCode, @SponsorNo,@receiptNo,@serPlace ,@reqDate,@cashier,@PmtDate, @UserID,@fromDate,@toDate )

       FETCH NEXT FROM C INTO @serDesc, @ItemID, @PaidQty, @UnitPrice, @PmtTypeCode, @SponsorNo,@ReceiptNo,@serPlace ,@reqDate,@cashier,@pmtDate;

	END

   CLOSE C;

   DEALLOCATE C;

END
go

