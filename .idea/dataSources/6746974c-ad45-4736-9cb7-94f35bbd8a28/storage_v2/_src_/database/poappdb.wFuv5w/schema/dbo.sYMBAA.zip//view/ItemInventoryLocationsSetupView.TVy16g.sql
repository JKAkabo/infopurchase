CREATE VIEW [dbo].[ItemInventoryLocationsSetupView]

AS

SELECT  Description, Code, StoreCode FROM ItemInventoryLocationsSetup

Union

SELECT  '' As Description, 0 As Code, '' As StoreCode FROM dbo.Hosp_Info
go

