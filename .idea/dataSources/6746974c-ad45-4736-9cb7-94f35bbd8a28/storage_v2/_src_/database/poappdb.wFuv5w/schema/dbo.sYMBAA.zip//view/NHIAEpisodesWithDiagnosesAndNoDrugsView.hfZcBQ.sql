CREATE VIEW [dbo].[NHIAEpisodesWithDiagnosesAndNoDrugsView]

AS

SELECT ActiveEpiID FROM NHIAEpisodesWithDiagnosesView Where ActiveEpiID NOT IN (Select ActiveEpiID From  NHIAEpisodesWithDrugsView)
go

