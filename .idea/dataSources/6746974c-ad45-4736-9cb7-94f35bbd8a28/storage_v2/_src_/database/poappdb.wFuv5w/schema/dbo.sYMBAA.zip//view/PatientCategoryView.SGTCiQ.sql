CREATE VIEW [dbo].[PatientCategoryView]

AS

SELECT Distinct upper(Description) As Description, Code,ActiveStatus, 
CASE WHEN Code IN (4,11) THEN 1  WHEN Code IN (2,3) THEN 2 WHEN Code IN (5,6) THEN 3 
WHEN Code IN (7,8) THEN 4 WHEN Code IN (9,10) THEN 5
WHEN Code IN (1) THEN 6 ELSE 7 END AS CatPriority
FROM dbo.PatientCategoryTypes

Union

SELECT  '' As Description, 0 As Code,'No',8 FROM dbo.Hosp_Info
go

