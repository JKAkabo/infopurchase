

CREATE VIEW [dbo].[ServiceLinesPaidView]

AS

SELECT Distinct ServiceLinePayments.PmtDate, ServiceLinePayments.PmtTime, ServiceLinePayments.RecordID, DrugCode As ServiceCode, 1 As ServiceTypeCode, ServiceLinePayments.PmtTypeCode, StoresID As SerPlaceCode , ServiceLinePayments.Service_Fee AS UnitFee, QtyPrescribed As ServiceQty, ReqDate, PresType As RequestType, BillsPaid.OPDNo, Prescriptions.StatusCode As PatStatus, ServiceLinePayments.PaidAmt, DirectID, ServiceLinePayments.PaidQty, '**' As CapID, Prescriptions.ServerTime, BillsPaid.Pat_No, ServiceLinePayments.ReceiptNo, Prescriptions.ClinicCode, ServiceLinePayments.PatAge, Prescriptions.BillCategoryCode As PatCategoryCode, ServiceLinePayments.UserID, 'DRUG' As RecType, ServiceLinePayments.BillCategoryCode,AmtPaid,BillOut,BillsPaid.RefAmtRequested FROM Prescriptions Inner Join (BillsPaid Inner Join ServiceLinePayments On BillsPaid.ReceiptNo =ServiceLinePayments.ReceiptNo) On (DrugCode=ServiceCode and Prescriptions.RecordID=ServiceID) Where ServiceLinePayments.Archived='No'

UNION ALL

SELECT Distinct ServiceLinePayments.PmtDate, ServiceLinePayments.PmtTime, ServiceLinePayments.RecordID, ServiceLinePayments.ServiceCode, ServiceTypeCode, ServiceLinePayments.PmtTypeCode, SerPlaceCode , ServiceLinePayments.Service_Fee AS UnitFee,  ServiceQty, ReqDate, RequestType, BillsPaid.OPDNo, Service_Requests.StatusCode As PatStatus, ServiceLinePayments.PaidAmt, DirectID, ServiceLinePayments.PaidQty, '**' As CapID, Service_Requests.ServerTime, BillsPaid.Pat_No, ServiceLinePayments.ReceiptNo, Service_Requests.ClinicCode, ServiceLinePayments.PatAge, Service_Requests.BillCategoryCode As PatCategoryCode,ServiceLinePayments.UserID, 'SERVICE' As RecType, ServiceLinePayments.BillCategoryCode,AmtPaid,BillOut,BillsPaid.RefAmtRequested FROM AllSetUpServicesView Inner Join (Service_Requests Inner Join (BillsPaid Inner Join ServiceLinePayments On BillsPaid.ReceiptNo =ServiceLinePayments.ReceiptNo) On (Service_Requests.ServiceCode=ServiceLinePayments.ServiceCode and Service_Requests.RecordID=ServiceID)) On ItemID=Service_Requests.ServiceCode Where ServiceLinePayments.Archived='No'


--SELECT SUM(ServiceLinePayments.PaidAmt) As PaidAmt, ServiceLinePayments.PmtDate, ServiceLinePayments.PmtTime, ServiceLinePayments.RecordID, DrugCode As ServiceCode, StoresID As SerPlaceCode , ReqDate, BillsPaid.OPDNo, DirectID, Prescriptions.ServerTime, BillsPaid.Pat_No, ServiceLinePayments.ReceiptNo, Prescriptions.ClinicCode, 'DRUG' As RecType, ServiceID FROM Prescriptions Inner Join (BillsPaid Inner Join ServiceLinePayments On BillsPaid.ReceiptNo =ServiceLinePayments.ReceiptNo) On (DrugCode=ServiceCode and Prescriptions.RecordID=ServiceID) Where ServiceLinePayments.Archived='No' and ServiceLinePayments.PmtTypeCode=1 and ServiceLinePayments.BillCategoryCode=1
--Group By ServiceLinePayments.ReceiptNo,ServiceLinePayments.PmtDate, ServiceLinePayments.PmtTime, ServiceLinePayments.RecordID, DrugCode,StoresID,BillsPaid.OPDNo, BillsPaid.Pat_No, ReqDate,DirectID, Prescriptions.ServerTime, Prescriptions.ClinicCode,ServiceID

--UNION ALL

--SELECT SUM(ServiceLinePayments.PaidAmt) As PaidAmt,  ServiceLinePayments.PmtDate, ServiceLinePayments.PmtTime, ServiceLinePayments.RecordID, ServiceLinePayments.ServiceCode, SerPlaceCode , ReqDate, BillsPaid.OPDNo, DirectID, Service_Requests.ServerTime, BillsPaid.Pat_No, ServiceLinePayments.ReceiptNo, Service_Requests.ClinicCode, 'SERVICE' As RecType, ServiceID FROM AllSetUpServicesView Inner Join (Service_Requests Inner Join (BillsPaid Inner Join ServiceLinePayments On BillsPaid.ReceiptNo =ServiceLinePayments.ReceiptNo) On (Service_Requests.ServiceCode=ServiceLinePayments.ServiceCode and Service_Requests.RecordID=ServiceID)) On ItemID=Service_Requests.ServiceCode Where ServiceLinePayments.Archived='No' and ServiceLinePayments.PmtTypeCode=1 and ServiceLinePayments.BillCategoryCode=1
--Group By ServiceLinePayments.ReceiptNo,ServiceLinePayments.PmtDate, ServiceLinePayments.PmtTime, ServiceLinePayments.RecordID, ServiceLinePayments.ServiceCode,SerPlaceCode,BillsPaid.OPDNo, BillsPaid.Pat_No, ReqDate,DirectID, Service_Requests.ServerTime, Service_Requests.ClinicCode,ServiceID


go

