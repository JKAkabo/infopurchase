CREATE VIEW [dbo].[QBPurchaseOrderReturnedLinesView]

AS

Select ReturnedLineID As TransID, UnitCost, ReturnedQty As MoveQty, ReturnedOrderLines.ItemID, ReturnedOrders.ReturnedDate As TransDate, ReturnedOrders.SupplierID As ReceiverID, ReturnedOrders.ReceivedStoreID As IssuerID,'Returns Outward' As MoveType, UPPER(ContactName) As ClientName, Items.Description As ServiceDescription, Items.ItemID As ServiceCode, Convert(Nvarchar(15),ItemClassCode) As ItemClassCode From 
Suppliers Inner Join (ReturnedOrders Inner Join (Items Inner Join ReturnedOrderLines On Items.ItemID=ReturnedOrderLines.ItemID) On ReturnedOrders.ReturnedID=ReturnedOrderLines.ReturnedNo) On Suppliers.SupplierID=ReturnedOrders.SupplierID Where OrderType=2 and ReturnedOrders.Archived='No' And ReturnedOrderLines.Archived='No' And 
ReturnedOrderLines.ItemID IN (Select Items.ItemID From Items Inner Join QBAcctsMappingView ON Convert(Nvarchar(15),ItemClassCode)=ServiceID) And ReturnedOrders.SupplierID IN (Select SupplierID From Suppliers Inner Join QBAcctsMappingView ON (SupplierID=ServiceID and AcctsTypeID=11))
go

