CREATE VIEW [dbo].[ServicesBillView]

AS

SELECT PatAge, OPDNo, Pat_No, RecordID, ServiceCode, Service_Cost, Service_Fee, Reqdate, ReqTime, PaidAmt, PaidQty, SerPlaceCode, PmtTypeCode, PmtModeCode, BillCategoryCode, PatCategoryCode, QtyGiven, ServiceQty, ClinicCode, DirectID, PaymentCode, Service_Requests.DeptID, EmpNo, SponsorNo, ServiceTypeCode, StatusCode, 'No' As CoPayed, Description FROM AllSetUpServicesView Inner Join Service_Requests On ItemID=ServiceCode Where Archived='No' And UPPER(RequestType)='INTERNAL'

UNION

SELECT PatAge, OPDNo, Pat_No, RecordID, ServiceCode, 0 As UnitCost, CoPayFee-Service_Fee As UnitPrice, Reqdate, ReqTime,  CoPayPaidAmt, CoPayPaidQty , SerPlaceCode, CoPayPmtTypeCode, CoPayPmtModeCode, CoPayBillCategoryCode, PatCategoryCode, QtyGiven, ServiceQty, ClinicCode, DirectID, PaymentCode, Service_Requests.DeptID, EmpNo, CoPaySponsorNo, ServiceTypeCode, StatusCode, 'Yes' As CoPayed, Description FROM AllSetUpServicesView Inner Join dbo.Service_Requests On ItemID=ServiceCode Where Archived='No' And CoPayFee-Service_Fee>0 And UPPER(RequestType)='INTERNAL'
go

