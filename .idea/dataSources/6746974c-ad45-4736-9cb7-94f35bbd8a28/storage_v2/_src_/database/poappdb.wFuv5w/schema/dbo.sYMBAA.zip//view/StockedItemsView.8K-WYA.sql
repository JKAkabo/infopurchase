CREATE VIEW [dbo].[StockedItemsView]

AS

SELECT IsNull(Sum(StockLevel),0) As StockLevel, ItemCode, TypeCode, Code As ServicePlaceCode, NoPerBaseUnit, UnitCode, UOM, BatchNo, ExpiryDate, ItemExpirable,ItemsUOMView.Description As ItemDescription, Service_Places.Description As ItemStore, ItemsUOMView.IssueUnitQuantity As UOMQty, Service_Places.OrderUnitID As OrderUnitType,Service_Places.IssueUnitID As IssueUnitType,  
BaseCost As UnitBaseCost, StockedItems.BaseItemID FROM Service_Places Inner Join (ItemsUOMView Inner Join StockedItems On ItemCode=ItemID) On Code=StoreID Where StockLevel>=0 And UPPER(Service_Places.Status)='YES' and ItemsUOMView.IssueUnitQuantity>0 and ItemsUOMView.IssueUnitQuantity Is Not Null 
Group By Code, Service_Places.Description, StockedItems.BaseItemID, ItemCode, ItemsUOMView.Description, BatchNo, ExpiryDate, TypeCode, UnitCode, UOM, NoPerBaseUnit, IssueUnitQuantity, IssueUnitID,OrderUnitID, ItemExpirable,BaseCost
go

