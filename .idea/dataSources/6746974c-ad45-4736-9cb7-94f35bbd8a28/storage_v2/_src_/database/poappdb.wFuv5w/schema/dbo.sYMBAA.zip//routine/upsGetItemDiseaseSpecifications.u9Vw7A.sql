-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[upsGetItemDiseaseSpecifications] 
	-- Add the parameters for the stored procedure here

	@ItemID nvarchar(15)
	
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    Select Distinct DiseaseSpecifications.*, DisDescription From Diseases Inner Join 
    DiseaseSpecifications On Diseases.DisCode=DiseaseSpecifications.DisCode Where ItemCode= @ItemID 

END
go

