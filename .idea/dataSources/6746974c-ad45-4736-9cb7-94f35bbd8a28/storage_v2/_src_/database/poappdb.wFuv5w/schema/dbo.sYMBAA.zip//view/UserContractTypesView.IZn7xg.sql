
CREATE VIEW [dbo].[UserContractTypesView]

AS

SELECT  Description, Code, IsActive FROM UserContractTypes

Union

SELECT  '' As Description, 0 As Code, 'No' As IsActive FROM dbo.Hosp_Info

go

