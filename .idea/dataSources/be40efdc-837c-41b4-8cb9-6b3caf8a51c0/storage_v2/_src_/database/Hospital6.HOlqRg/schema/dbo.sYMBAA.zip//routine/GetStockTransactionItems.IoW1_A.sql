-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetStockTransactionItems] 
	-- Add the parameters for the stored procedure here

	@transCriteria nvarchar(max),@TransType nvarchar(15),@ItemUnitType tinyint,
	@ConsumpType nvarchar(50)='',@transCriteria1 nvarchar(max)=''
	
AS

DECLARE @classStrg nvarchar(4000);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

set @classStrg=''


if @TransType='ISSUES'
   if @ConsumpType='DISPENSED DRUGS' or @ConsumpType=''
      set @classStrg='Select IsNull(Sum(abs(AdjustQty)),0) As MoveQty, STOCKMOVEMENT.ItemID,BaseQty From Items Inner Join STOCKMOVEMENT On Items.ItemID=STOCKMOVEMENT.ItemID ' + @transCriteria + ' and MoveType IN (''Requisitions'',''Prescriptions'',''Return Inwards'',''Return Outward'',''Internal Item Usage'',''Expired Stocks'') Group By STOCKMOVEMENT.ItemID,BaseQty Order By STOCKMOVEMENT.ItemID'
   
   else
      set @classStrg='Select IsNull(Sum(abs(AdjustQty)),0) As MoveQty, STOCKMOVEMENT.ItemID,BaseQty From Items Inner Join STOCKMOVEMENT On Items.ItemID=STOCKMOVEMENT.ItemID ' + @transCriteria + ' and MoveType IN (''Requisitions'',''Prescriptions'',''Return Inwards'',''Return Outward'',''Internal Item Usage'',''Expired Stocks'') Group By STOCKMOVEMENT.ItemID,BaseQty Order By STOCKMOVEMENT.ItemID'
   
if @TransType='RECEIPTS'
   set @classStrg='Select IsNull(Sum(AdjustQty),0) As MoveQty, STOCKMOVEMENT.ItemID,BaseQty From Items Inner Join STOCKMOVEMENT On Items.ItemID=STOCKMOVEMENT.ItemID ' + @transCriteria + ' and STOCKMOVEMENT.ServerDate <=@ToDate and MoveType IN (''Orders'',''Requisitions'',''Return Inwards'',''Prescription Returns'') Group By STOCKMOVEMENT.ItemUnit,BaseQty Order By STOCKMOVEMENT.ItemID'

if @TransType='ADJUSTMENTS'
   set @classStrg='Select IsNull(Sum(AdjustQty),0) As MoveQty, STOCKMOVEMENT.ItemID,BaseQty From Items Inner Join STOCKMOVEMENT On Items.ItemID=STOCKMOVEMENT.ItemID ' + @transCriteria + ' and MoveType IN (''Stock Adjustments'',''Initial Stocks'',''Obsolete Stocks'') Group By STOCKMOVEMENT.ItemID,BaseQty Order By STOCKMOVEMENT.ItemID'

execute(@classStrg)
	 
END
go

