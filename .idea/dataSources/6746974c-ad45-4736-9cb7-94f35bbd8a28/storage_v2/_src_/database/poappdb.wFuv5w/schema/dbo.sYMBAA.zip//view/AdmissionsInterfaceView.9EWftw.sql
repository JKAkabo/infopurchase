CREATE VIEW [dbo].[AdmissionsInterfaceView]
AS
SELECT     a.OPDNo, a.Pat_No, a.IPDNo, a.ReqDate, a.ReqTime, a.AdmAge, a.AdmDate, a.AdmTime, a.WardID, a.BedNo, a.BedType, a.DisDate, a.DisTime, a.DisAge, 
                      a.Discharged, a.Absconded, a.ReceiptNo, a.PmtDate, a.PmtTime, a.PaidQty, a.PmtUserID, a.PmtModeCode, a.PmtTypeCode, a.BillCycleDuration, a.BillMethodCode, 
                      a.BillCategoryCode, a.DeptID, S.IDNo AS EmpNo, a.Insured, a.Archived, a.ArchivedDate, a.ArchivedTime, a.ArchiverID, a.RecMode, a.ServerDate, a.ServerTime, a.RecID, 
                      a.Transfered, a.RecNo, a.PatCategoryCode, a.RecordID, a.DoctorID, a.DischargeStatus, a.EpisodeID, a.UserID, a.CAP_ID, a.ClinicCode, a.Sex, a.Status, 
                      a.DisAuthouriser, a.DischargeStatusCode, a.Refcliniccode, a.RefReason, a.AdmAgeClassCode, a.DisAgeClassCode, a.AttType, a.EpisodeType, a.Admitted, 
                      a.StatusCode, a.DisUserID, a.SurgicalInfec, a.NHIAMemberStatus, a.DirectID, a.ClaimPrinted, a.ClaimDataProcessed, a.ClaimPrintDate, a.ClaimPrintTime, 
                      a.ClaimPrintedBy, a.ClaimDataProcessedDate, a.ClaimDataProcessedBy, a.FirstAdmissionID, a.LastDischargeID, s.SponsorNo
FROM         dbo.Admissions AS a INNER JOIN
                      dbo.SponsoredPatients AS s ON a.OPDNo = s.OPDNo AND s.SponsorNo <> '000025' AND s.Archived = 'No'
go

