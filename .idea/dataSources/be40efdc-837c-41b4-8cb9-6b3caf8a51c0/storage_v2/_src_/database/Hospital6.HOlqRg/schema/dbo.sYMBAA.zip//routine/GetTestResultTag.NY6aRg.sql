


CREATE FUNCTION [dbo].[GetTestResultTag]

(@TestElementID AS Numeric(18,0),@GenderCode tinyint=1, @AgeGroup tinyint=3, @ValueType tinyint=0, @TestResult NVarchar(100)='') RETURNS NVARCHAR(100)

AS

BEGIN

if @TestElementID = 0 Or @ValueType=0 Or @TestResult='' RETURN ''

DECLARE @ResultTag NVARCHAR(100),@LValue NVARCHAR(100),@UValue NVARCHAR(100);

DECLARE @MaleFemaleGenderCode tinyint=1, @AdultChildCode tinyint=3

Set @ResultTag=''

if Isnumeric(@TestResult)<>1 and @ValueType=1 RETURN ''

--if @ValueType=1 
--   if Isnumeric(@TestResult)=1
--      Select TOP 1 @ResultTag=TestElementValuesView.TextTag From AgeGroupValuesView Inner Join TestElementValuesView On AgeGroupValuesView.RecordID=TestElementValuesView.AgeGroupID Where ElementID=@TestElementID AND convert(decimal(18,2),TestElementValuesView.LowerValue)  <=convert(decimal(18,2),@TestResult) and convert(decimal(18,2),TestElementValuesView.UpperValue)  >=convert(decimal(18,2),@TestResult) Order By LowerAgeUnit, UpperAgeUnit, AgeGroupValuesView.LowerValue, AgeGroupValuesView.UpperValue

--else
--   Select TOP 1 @ResultTag=TestElementValuesView.TextTag From AgeGroupValuesView Inner Join TestElementValuesView On AgeGroupValuesView.RecordID=TestElementValuesView.AgeGroupID Where ElementID=@TestElementID AND upper(rtrim(lTrim(TestElementValuesView.LowerValue))) = upper(@TestResult)  OR upper(rtrim(lTrim(TestElementValuesView.UpperValue))) =upper( @TestResult)

if @ValueType=2 
   BEGIN
      Select TOP 1 @ResultTag=TestElementValuesView.TextTag From AgeGroupValuesView Inner Join TestElementValuesView On AgeGroupValuesView.RecordID=TestElementValuesView.AgeGroupID Where ElementID=@TestElementID AND upper(rtrim(lTrim(TestElementValuesView.LowerValue))) = upper(@TestResult)  OR upper(rtrim(lTrim(TestElementValuesView.UpperValue))) =upper( @TestResult)

      RETURN @ResultTag

   END

DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct TestElementValuesView.LowerValue, TestElementValuesView.UpperValue, TextTag From AgeGroupValuesView Inner Join TestElementValuesView On AgeGroupValuesView.RecordID=TestElementValuesView.AgeGroupID Where ElementID=@TestElementID AND (GenderCode=@GenderCode Or GenderCode=@MaleFemaleGenderCode) And (TestElementValuesView.AgeGroupCode=@AgeGroup Or TestElementValuesView.AgeGroupCode=@AdultChildCode)

OPEN C

FETCH NEXT FROM C INTO @LValue, @UValue, @ResultTag;

WHILE @@fetch_status = 0

 BEGIN  
    if Isnumeric(@LValue)=1 And Isnumeric(@UValue)=1
       
       BEGIN
              
       if convert(numeric(18,4),@TestResult)>=convert(numeric(18,4),@LValue) and convert(numeric(18,4),@TestResult)<=convert(numeric(18,4),@UValue)
          
          Return @ResultTag
                 
       END
       
    else if Isnumeric(@LValue)=1 And Isnumeric(@UValue)=0
       
       BEGIN
       
       if convert(numeric(18,4),@TestResult)>convert(numeric(18,4),@LValue) 
          
          Return  @ResultTag
       
       END
       
    else if Isnumeric(@LValue)=0 And Isnumeric(@UValue)=1
       
       BEGIN
       
       if convert(numeric(18,4),@TestResult)<convert(numeric(18,4),@UValue) 
          
          Return @ResultTag
                 
       END
         
   FETCH NEXT FROM C INTO @LValue, @UValue, @ResultTag;
   
 END


CLOSE C;

DEALLOCATE C;

Return '-'
 
END



go

