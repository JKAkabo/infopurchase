
CREATE VIEW [dbo].[SingleDiagnosisPrescriptionsView]

AS

Select Distinct DrugCode, SingleDiagnosisConsulationView.AttServiceID From SingleDiagnosisConsulationView Inner Join Prescriptions On SingleDiagnosisConsulationView.AttServiceID=Prescriptions.AttServiceID WHERE Prescriptions.Archived='No' and Prescriptions.StatusCode=2

go

