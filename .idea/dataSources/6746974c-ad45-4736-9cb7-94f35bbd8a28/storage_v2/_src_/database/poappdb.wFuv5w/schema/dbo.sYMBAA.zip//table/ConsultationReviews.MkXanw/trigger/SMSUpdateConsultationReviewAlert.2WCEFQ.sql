/****** Object:  Trigger [dbo].[SMSUpdateConsultationReviewAlert]    Script Date: 06/02/2014 10:40:43 ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[SMSUpdateConsultationReviewAlert] 
   ON  [dbo].[ConsultationReviews] 
   AFTER UPDATE
   
AS 

--Make Sure DateTo Really Changed
IF  (NOT(UPDATE(ReviewDate)) And NOT(UPDATE(ReviewTime))) OR EXISTS (SELECT a.StatusCode FROM inserted a JOIN deleted b ON a.CONID=b.CONID WHERE a.ReviewDate=b.ReviewDate And a.ReviewTime=b.ReviewTime)
   RETURN	   

 --Checking if SMS is enabled in HAMS
if NOT EXISTS(SELECT ActivateSMS FROM Hosp_Info WHERE ActivateSMS='Yes' )
   RETURN
  
  
  DECLARE @msgContent nvarchar(200),@reviewDate datetime,@reviewDate1 datetime,@Consent nvarchar(3),@AgeGroup  tinyint,@GenderGroup tinyint;
  DECLARE @msgType nvarchar(100),@OnceFreq tinyint,@ExpiryAlert nvarchar(3),@OPDNo nvarchar(15),@patSurName nvarchar(250);
  DECLARE @DocNo nvarchar(5),@DocName nvarchar(50),@ClinicName nvarchar(30), @includePatName nvarchar(3),@MsgTypeID TINYINT;
  DECLARE @Day nvarchar(50), @DayTime nvarchar(50), @DayDate nvarchar(50), @DayDate1 nvarchar(50),@patCellNo nvarchar(50);
  
 SET @MsgTypeID=3;
 
--Checking if Con. Review SMS Alert is enabled in HAMS
 SELECT @msgType=h.Description, @msgContent=s.MsgContent,@Consent=s.EnforceConsent,@includePatName = s.includeRPT,@AgeGroup=AgeGroupCode,@GenderGroup=GenderCode FROM HamsMessageTypes h Inner Join HamsSMSSetup s On h.Code=s.TypeCode WHERE s.TypeCode=@msgTypeID And s.Active='Yes' And s.StartTime<=getdate()
 IF @@RowCount<=0 
    RETURN 

SELECT  @DayTime=RIGHT(CONVERT(VARCHAR, i.ReviewTime, 100),7), @DayDate=DATENAME(DD,i.ReviewTime) + '-' + left(DATENAME(MM,i.ReviewTime),3) + '-' + DATENAME(YYYY,i.ReviewTime), @Day= UPPER(DATENAME(dw,i.ReviewTime)),@patSurName=(Title + '.' + Surname),@ExpiryAlert=s.ExpiryAlert,@OPDNo=s.OPDNo,@reviewDate=s.reviewdate,@DocName=s.Doctor,@ClinicName=Clinic, @patCellNo=Rtrim(Ltrim(CellPhoneNo)) FROM SMSConsultationReviewAlertView s,inserted i WHERE s.ConID=i.ConID  And s.Received='No' And getdate()<s.reviewtime  And  Rtrim(Ltrim(CellPhoneNo))<>'' AND CellPhoneNo IS NOT NULL
IF @@RowCount<=0 OR @patCellNo=''
   RETURN 
    
BEGIN
         
set @OnceFreq=6;

set @Day=@Day + ',' + @DayDate + ' ' +  @DayTime
   
SELECT @DayDate1=DATENAME(DD,d.ReviewTime) + '-' + left(DATENAME(MM,d.ReviewTime),3) + '-' + DATENAME(YYYY,d.ReviewTime) FROM deleted d,inserted i WHERE i.ConID=d.ConID

set @msgContent ='Your Review On The ' + @DayDate1 + ' Has Been Rescheduled To ' + @Day + ' With Doctor ' + @DocName + ' At The ' + @ClinicName + ' Clinic. We Sincerely Apologize For Any Inconvenience. Thank You.'

insert into bulksms_db.dbo.sending_queue([from],[to],Message,queue_time,status) 
select 'System',@patCellNo,@msgContent,getdate(),'Sent'

END
go

