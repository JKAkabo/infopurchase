-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[uspGetPatientsInfo]
	-- Add the parameters for the stored procedure here
	@selectionCriteria nvarchar(2000)
AS

declare @selectionString nvarchar(4000)

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
    set @selectionString= 'Select PatientsInfo.*, PatNo from PatientsInfo Inner Join OPD_Nos On PatientsInfo.Opdno = OPD_Nos.Opdno ' + @selectionCriteria + ' Order By LastName,Surname'
   
    exec(@selectionString)


END
go

