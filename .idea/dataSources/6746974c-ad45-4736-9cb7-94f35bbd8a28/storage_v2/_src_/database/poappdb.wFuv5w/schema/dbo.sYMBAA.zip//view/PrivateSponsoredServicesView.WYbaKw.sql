CREATE VIEW [dbo].[PrivateSponsoredServicesView]

AS

---ALL PRIVATE SPONSORED SERVICES

SELECT DISTINCT (RequiredQty *(UnitFee)) As PaidAmt, RequiredQty, UnitFee ,ServiceCode,S.EndDate As PmtDate,RequestID,SponsorNo,HWCode As SerPlaceCode,S.PatCatCode As BillCategoryCode,S.ClinicCode,UPPER(SponsorName) As SponsorName,PatAge,AllSetUpServicesView.Description As ServiceDescription, 
IsNull((Select TOP 1 UPPER(Description) From ServiceTypes Where Code=AllSetUpServicesView.ServiceTypeCode),'') As ServiceTypeDesc,GDRGCode,ISNULL(ICD10Code,'') As ICD10Code,  
SponsorTypeCode,RequesterID,2 As PmtTypeCode,S.OPDNo, AllSetUpServicesView.ServiceTypeCode, ReqDate As ReqTime,S.UserID, CONVERT(Date,ReqDate) As ReqDate, Pat_No,S.ClaimEventID As ClaimID FROM Sponsors, AllSetUpServicesView, PrivateClaimsServices S,PrivateClaimsDetail
	WHERE S.PatCatCode NOT IN (0,1,4,11) And UnitFee>0 AND RequiredQty >0  And ItemID =ServiceCode And Sponsors.SponsorNo =S.SponsorID and S.ClaimEventID=PrivateClaimsDetail.ClaimEventID and S.OPDNo=PrivateClaimsDetail.OPDNo
go

