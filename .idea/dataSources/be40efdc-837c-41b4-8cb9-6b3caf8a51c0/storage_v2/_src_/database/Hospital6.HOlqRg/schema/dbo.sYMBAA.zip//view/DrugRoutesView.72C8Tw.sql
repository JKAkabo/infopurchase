

CREATE VIEW [dbo].[DrugRoutesView]

AS

SELECT  Description, Code FROM dbo.DrugRoutes

Union

SELECT  '' As Description, 0 As Code FROM dbo.Hosp_Info


go

