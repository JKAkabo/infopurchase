CREATE PROCEDURE [dbo].[uspGeneratePatientReceiptServices] 

	@receiptNo nvarchar(15)
	
AS

DECLARE @serDesc nvarchar(250),@ItemID nvarchar(15),@PaidQty numeric(18,2),@UnitPrice numeric(18,6),@PmtTypeCode Tinyint,@SponsorNo nvarchar(15);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
INSERT INTO PatientReceiptServices (SerDesc, SerID, PaidQty, UnitFee, PmtTypeCode, SponsorNo, ReceiptNo) SELECT AllSetUpServicesView.Description,ServiceLinePayments.ServiceCode,ServiceLinePayments.PaidQty,ServiceLinePayments.Service_Fee,ServiceLinePayments.PmtTypeCode,ServiceLinePayments.SponsorNo,ServiceLinePayments.ReceiptNo FROM AllSetUpServicesView Inner Join ServiceLinePayments
ON AllSetUpServicesView.ItemID =ServiceLinePayments.ServiceCode WHERE ServiceLinePayments.ReceiptNo = @receiptNo And ServiceLinePayments.Archived='No' AND ItemID NOT IN ('DEPTDRG','DEPTSER','UNDEPTDRG','UNDEPTSER','BILLAPPR','OUTBILLPMT','OUTBILLPMT1','SPSBILLPMT')
    
END
go

