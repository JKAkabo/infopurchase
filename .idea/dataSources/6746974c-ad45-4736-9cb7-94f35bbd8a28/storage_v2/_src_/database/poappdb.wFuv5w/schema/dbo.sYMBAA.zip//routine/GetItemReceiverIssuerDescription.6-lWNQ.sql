-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetItemReceiverIssuerDescription] 
	-- Add the parameters for the stored procedure here

	@issuerID nvarchar(15),@receiverID nvarchar(15),@TransType nvarchar(50),
    @issuerReceiver nvarchar(500) output 
    
	
AS

BEGIN
 Declare @issuerDesc nvarchar(150),@receiverDesc nvarchar(150)
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

if @TransType='Prescriptions'
    begin
		Select TOP 1 @receiverDesc=Lastname + ' ' + Surname + ' - ' + PatNo From PatientsInfo Inner Join OPD_Nos On PatientsInfo.OPDNo=OPD_Nos.OPDNo Where PatientsInfo.OPDNo=@receiverID
	    
		Select @issuerDesc=IsNull(Description,'') From Service_Places Where Code=@issuerID

        set @issuerReceiver=upper(@issuerDesc + ' / ' + @receiverDesc)

    end

if @TransType='Prescription Returns'
    begin
		Select TOP 1  @issuerDesc=Lastname + ' ' + Surname + ' - ' + PatNo From PatientsInfo Inner Join OPD_Nos On PatientsInfo.OPDNo=OPD_Nos.OPDNo Where PatientsInfo.OPDNo=@issuerID
	    
		Select @receiverDesc=IsNull(Description,'') From Service_Places Where Code=@receiverID

        set @issuerReceiver=upper(@issuerDesc + ' / ' + @receiverDesc)

    end

if @TransType='Requisitions' Or @TransType='Return Inwards'
    begin
		Select @receiverDesc=IsNull(Description,'') From Service_Places Where Code=@receiverID
	    
		Select @issuerDesc=IsNull(Description,'') From Service_Places Where Code=@issuerID

        Set @issuerReceiver=upper(@issuerDesc + ' / ' + @receiverDesc)

    end

if @TransType='Orders'
   if len(@receiverID)<>len(@issuerID)
		begin
			Select @receiverDesc=IsNull(Description,'') From Service_Places Where Code=@receiverID
		    
			Select @issuerDesc=ContactName From Suppliers Where SupplierID=@issuerID

			Set @issuerReceiver=upper(@issuerDesc + ' / ' + @receiverDesc)

		end

   else

		begin
			Select @receiverDesc=IsNull(Description,'') From Service_Places Where Code=@receiverID
		    
			Select @issuerDesc=IsNull(Description,'') From Service_Places Where Code=@issuerID

			Set @issuerReceiver=upper(@issuerDesc + ' / ' + @receiverDesc)

		end

if @TransType='Return Outward'
    begin
		Select @issuerDesc=IsNull(Description,'') From Service_Places Where Code=@issuerID
	    
		Select @receiverDesc=ContactName From Suppliers Where SupplierID=@receiverID

        Set @issuerReceiver=upper(@issuerDesc + ' / ' + @receiverDesc)

    end

if @TransType='Stock Adjustments' or @TransType='Initial Stocks' or @TransType='Obsolete Stocks'
    begin
		Select @receiverDesc=IsNull(Description,'') From Service_Places Where Code=@receiverID
	    
		Select @issuerDesc=IsNull(UserID,'') From Users Where UserNo=@issuerID

        Set @issuerReceiver=upper(@issuerDesc + ' / ' + @receiverDesc)

    end

if @TransType='Internal Item Usage'
    begin
		Select @receiverDesc=IsNull(Description,'') From Service_Places Where Code=@issuerID
	    
		Select @issuerDesc=IsNull(UserID,'') From Users Where UserNo=@receiverID

        Set @issuerReceiver=upper(@issuerDesc + ' / ' + @receiverDesc)

    end
	
	-- 
END
go

