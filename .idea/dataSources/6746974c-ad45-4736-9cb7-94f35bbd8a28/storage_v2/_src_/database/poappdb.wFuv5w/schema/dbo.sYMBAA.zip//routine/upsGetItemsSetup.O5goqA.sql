-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[upsGetItemsSetup] 
	-- Add the parameters for the stored procedure here

	@ItemDescription nvarchar(250),@ItemType tinyint =0,@AgeGroupCode tinyint=3,
	@GenderCode tinyint=1,@PatientType tinyint=1,@ItemStore nvarchar(15)='',@ItemClass tinyint =0
	,@StockTyype tinyint =0, @TransDate datetime ,@ItemFilterType nvarchar(15)=''
	
AS

declare @allAgeGroupCode tinyint,@InfantChildAgeGroupCode tinyint,@ChildAgeGroupCode tinyint,@InfantAgeGroupCode tinyint,@allGenderCode tinyint,@allPatientType tinyint;

BEGIN

set @allAgeGroupCode =3
set @allGenderCode =1
set @allPatientType =1
set @InfantChildAgeGroupCode =5
set @ChildAgeGroupCode =1
set @InfantAgeGroupCode =4

if @TransDate is null 
   BEGIN
     set @TransDate=GETDATE()
   
   END
   
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	--if @ItemType<>0
  Select Distinct Items.Description, StockType, ItemTypeCode, ManufacturerCode, PresentationCode,Expirable,Items.DefaultMethodCode,PresQuanityPerIssueUnit,PresSpecType, AllowCoPay,ItemManufacturers.Description as ItemManufacturer,ItemTypes.Description As ItemType,ItemPresentations.Description As ItemPresentation,DrugRoutesView.Description As DrugRoute,
  IssueUnitQuantity,PresUnitQuantity,PresUnitCode,AgeGroupCode,GenderCode, IssueUnitCode, UnitMeasures.Description As Unit_Name , Items.ItemID, PresLevel, StockType, CashPrice, CreditPrice, NHISPrice, NHIACoPayFee, NGPrice, FFee, AveUnitCost As UnitCost, MaxPresQty, MinPresQty , Sharing,DeterminePresQty,NHISCode,
  IsNull((Select TOP 1 Round(P.Price / P.UOMFactor,6) From NHIAMedicinesPriceList P Where P.MedicineCode=Items.NHISCode And ((convert(date,@TransDate)>=P.EffectiveDate)) And P.UOMFactor>0 And P.Price>0 Order By P.EffectiveDate Desc),0) As DrugNHIAPrice, 
  Isnull((Select sum(StockLevel) From StockedItemsView Where ItemCode=Items.ItemID And (((IsDate(ExpiryDate)=1 And Expirable ='Yes') And ((Year(ExpiryDate)> Year(Getdate())) OR (Year(ExpiryDate)= Year(Getdate()) And Month(ExpiryDate)>= Month(Getdate())))) Or (IsDate(ExpiryDate)=0 OR Expirable ='No')) and ((StockType=@StockTyype and @StockTyype<>0 And StockLevel>0) Or (@StockTyype=0)) Group By ItemCode),0) As StockLevel, 
  Isnull((Select sum(StockLevel) From StockedItemsView Where ItemCode=Items.ItemID And ServicePlaceCode=@ItemStore And (((IsDate(ExpiryDate)=1 And Expirable ='Yes') And ((Year(ExpiryDate)> Year(Getdate())) OR (Year(ExpiryDate)= Year(Getdate()) And Month(ExpiryDate)>= Month(Getdate())))) Or (IsDate(ExpiryDate)=0 OR Expirable ='No'))  and ((StockType=@StockTyype and @StockTyype<>0 And StockLevel>0) Or (@StockTyype=0)) Group By ServicePlaceCode),0) As StoreStockLevel, 
  Isnull((Select TOP 1 S.ReorderLevel From Stocks S Where S.ItemID=Items.ItemID  And StoreID=@ItemStore),0) As ReorderLevel,Isnull((Select TOP 1 S.MinLevel From Stocks S Where S.ItemID=Items.ItemID  And StoreID=@ItemStore),0) As MinLevel,Isnull((Select TOP 1 S.MaxLevel From Stocks S Where S.ItemID=Items.ItemID  And StoreID=@ItemStore),0) As MaxLevel
  From UnitMeasures, Items, Packs, ItemManufacturers, ItemTypes, ItemPresentations, DrugRoutesView Where ((ItemTypeCode=@ItemType and @ItemType<>0) OR (@ItemType=0 And ItemTypeCode IN (1,2))) and  UnitMeasures.Code = Items.IssueUnitCode and (((@ItemFilterType='' OR @ItemFilterType='START WITH') And Items.Description Like @ItemDescription + '%') OR (@ItemFilterType='END WITH' And Items.Description Like '%' + @ItemDescription ) OR (@ItemFilterType='CONTAIN' And Items.Description Like '%' + @ItemDescription + '%')) And 
  Items.ItemID=Packs.ItemID And Packs.Unit_Type ='Base' And Items.ItemID=Items.BaseItemID And ItemTypes.Code=ItemTypeCode And ItemPresentations.Code=PresentationCode  And ItemManufacturers.Code=ManufacturerCode  And
  (@AgeGroupCode=0 OR @AgeGroupCode=3 OR (AgeGroupCode =@AgeGroupCode Or AgeGroupCode =@allAgeGroupCode) OR (@AgeGroupCode =@ChildAgeGroupCode And (AgeGroupCode =@ChildAgeGroupCode Or AgeGroupCode =@InfantAgeGroupCode Or AgeGroupCode =@InfantChildAgeGroupCode))) And (Items.PatientType=@PatientType Or PatientType=@allPatientType) And (Items.GenderCode=@GenderCode Or GenderCode=@allGenderCode) 
  and Items.Disabled ='No' and DrugRoutesView.Code=items.DefaultMethodCode and ((ItemClassCode=@ItemClass and @ItemClass<>0 ) Or (@ItemClass=0)) and ((StockType=@StockTyype and @StockTyype<>0 ) Or (@StockTyype=0)) Order by Items.Description Asc
	  
END


  --Select Distinct Items.Description, StockType, ItemTypeCode, ManufacturerCode, PresentationCode,Expirable,Items.DefaultMethodCode,PresQuanityPerIssueUnit,PresSpecType, AllowCoPay,ItemManufacturers.Description as ItemManufacturer,ItemTypes.Description As ItemType,ItemPresentations.Description As ItemPresentation,DrugRoutesView.Description As DrugRoute,
  --IssueUnitQuantity,PresUnitQuantity,PresUnitCode,AgeGroupCode,GenderCode, IssueUnitCode, UnitMeasures.Description As Unit_Name , Items.ItemID, PresLevel, StockType, CashPrice, CreditPrice, NHISPrice, NHIACoPayFee, NGPrice, FFee, AveUnitCost As UnitCost, MaxPresQty, MinPresQty , Sharing,DeterminePresQty,NHISCode,
  --IsNull((Select TOP 1 Round(P.Price / P.UOMFactor,6) From NHIAMedicinesPriceList P Where P.MedicineCode=Items.NHISCode And ((convert(date,@TransDate)>=P.EffectiveDate)) And P.UOMFactor>0 And P.Price>0 Order By P.EffectiveDate Desc),0) As DrugNHIAPrice, 
  --Isnull((Select sum(StockLevel) From StockedItemsView Where TypeCode=1 And ItemCode=Items.ItemID And (((IsDate(ExpiryDate)=1 And Expirable ='Yes') And ((Year(ExpiryDate)> Year(Getdate())) OR (Year(ExpiryDate)= Year(Getdate()) And Month(ExpiryDate)>= Month(Getdate())))) Or (IsDate(ExpiryDate)=0 OR Expirable ='No')) and ((StockType=@StockTyype and @StockTyype<>0 And StockLevel>0) Or (@StockTyype=0)) Group By ItemCode),0) As StockLevel, 
  --Isnull((Select sum(StockLevel) From StockedItemsView Where TypeCode=1 And ItemCode=Items.ItemID And ServicePlaceCode=@ItemStore And (((IsDate(ExpiryDate)=1 And Expirable ='Yes') And ((Year(ExpiryDate)> Year(Getdate())) OR (Year(ExpiryDate)= Year(Getdate()) And Month(ExpiryDate)>= Month(Getdate())))) Or (IsDate(ExpiryDate)=0 OR Expirable ='No'))  and ((StockType=@StockTyype and @StockTyype<>0 And StockLevel>0) Or (@StockTyype=0)) Group By ServicePlaceCode),0) As StoreStockLevel, 
  --Isnull((Select TOP 1 S.ReorderLevel From Stocks S Where S.ItemID=Items.ItemID  And StoreID=@ItemStore),0) As ReorderLevel,Isnull((Select TOP 1 S.MinLevel From Stocks S Where S.ItemID=Items.ItemID  And StoreID=@ItemStore),0) As MinLevel,Isnull((Select TOP 1 S.MaxLevel From Stocks S Where S.ItemID=Items.ItemID  And StoreID=@ItemStore),0) As MaxLevel
  --From UnitMeasures, Items, Packs, ItemManufacturers, ItemTypes, ItemPresentations, DrugRoutesView Where ((ItemTypeCode=@ItemType and @ItemType<>0) OR (@ItemType=0 And ItemTypeCode IN (1,2))) and  UnitMeasures.Code = Items.IssueUnitCode and Items.Description Like @ItemDescription + '%' And Items.ItemID=Packs.ItemID and Packs.Unit_Type ='Base' And ItemTypes.Code=ItemTypeCode And ItemPresentations.Code=PresentationCode  And ItemManufacturers.Code=ManufacturerCode  And
  --(@AgeGroupCode=0  OR @AgeGroupCode=3 OR (AgeGroupCode =@AgeGroupCode Or AgeGroupCode =@allAgeGroupCode) OR (@AgeGroupCode =@ChildAgeGroupCode And (AgeGroupCode =@ChildAgeGroupCode Or AgeGroupCode =@InfantAgeGroupCode Or AgeGroupCode =@InfantChildAgeGroupCode))) And (Items.PatientType=@PatientType Or PatientType=@allPatientType) And (Items.GenderCode=@GenderCode Or GenderCode=@allGenderCode) 
  --and Items.Disabled ='No' and DrugRoutesView.Code=items.DefaultMethodCode and ((ItemClassCode=@ItemClass and @ItemClass<>0 ) Or (@ItemClass=0)) and ((StockType=@StockTyype and @StockTyype<>0 ) Or (@StockTyype=0)) Order by Items.Description Asc
go

