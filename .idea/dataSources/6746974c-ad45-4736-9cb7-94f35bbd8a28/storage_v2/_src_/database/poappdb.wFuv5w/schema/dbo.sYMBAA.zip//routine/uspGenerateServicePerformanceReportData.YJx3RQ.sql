create PROCEDURE [dbo].[uspGenerateServicePerformanceReportData] 

	@servicePlace nvarchar(15)='',@frmDate datetime,@toDate datetime,@user_ID nvarchar(10)
	
AS

DECLARE @serplace nvarchar(15),@serAmt numeric(18,6),@patCat tinyint,@maxDay int,@minDay int,@admDate datetime;

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
 
 Delete From PlaceOfServiceSummary Where UserID=@user_ID

 if @servicePlace='' 
	DECLARE SerPlaces CURSOR FAST_FORWARD FOR SELECT Code From Service_Places where [Status] = 'Yes' Order By Code

 else
	DECLARE SerPlaces CURSOR FAST_FORWARD FOR SELECT Code From Service_Places where [Status] = 'Yes' and Code=@servicePlace Order By Code

 OPEN SerPlaces

 FETCH NEXT FROM SerPlaces INTO @serplace;

	WHILE @@fetch_status = 0

	  BEGIN 
         DECLARE PatCats CURSOR FAST_FORWARD FOR SELECT Code From PatientCategoryTypes Order By Code

         OPEN PatCats
      
		 FETCH NEXT FROM PatCats INTO @patCat;
			WHILE @@fetch_status = 0
			  BEGIN 
		          
                  --Prescriptions
				  DECLARE C CURSOR FAST_FORWARD FOR SELECT isnull(sum(QtyPrescribed*UnitPrice),0) As SerAmt From Prescriptions where 
				  PresDate >= @frmDate  and PresDate <= @toDate and Archived='No' and Refunded='No' and BillCategoryCode=@patCat and StoresID=@serplace  and PaymentCode='P' 

				  OPEN C

				  if @@fetch_status <> 0
					BEGIN
                       set @serAmt=0;
					   Insert into PlaceOfServiceSummary (PlaceCode, CategoryCost, PatCategoryCode, FromDate, ToDate, UserID)values 
					   (@serplace, @serAmt, @patCat, @frmDate, @toDate, @user_ID)

					END
				  
                  FETCH NEXT FROM C INTO @serAmt;
				  WHILE @@fetch_status = 0
					BEGIN

					   Insert into PlaceOfServiceSummary (PlaceCode, CategoryCost, PatCategoryCode, FromDate, ToDate, UserID)values 
					   (@serplace, @serAmt, @patCat, @frmDate, @toDate, @user_ID)

					   FETCH NEXT FROM C INTO @serAmt;

					END

				  CLOSE C;

				  DEALLOCATE C;

     --             --Co-Pay Prescriptions
				 -- DECLARE C CURSOR FAST_FORWARD FOR SELECT isnull(sum(QtyPrescribed*(CoPayFee-UnitPrice)),0) As SerAmt From Prescriptions Inner Join CoPayServices On Prescriptions.DrugCode = CoPayServices.ServiceID and  
				 -- Prescriptions.RecordID = CoPayServices.RecordID where PresDate >= @frmDate  and PresDate <= @toDate and Archived='No' and CoPayServices.Refunded='No' and CoPayServices.BillCategoryCode=@patCat and StoresID=@serplace and PaymentCode='P' 

				 -- OPEN C
			  
     --             FETCH NEXT FROM C INTO @serAmt;
				 -- WHILE @@fetch_status = 0
					--BEGIN

					--   Insert into PlaceOfServiceSummary (PlaceCode, CategoryCost, PatCategoryCode, FromDate, ToDate, UserID)values 
					--   (@serplace, @serAmt, @patCat, @frmDate, @toDate, @user_ID)

					--   FETCH NEXT FROM C INTO @serAmt;

					--END

				 -- CLOSE C;

				 -- DEALLOCATE C;

                  --Other Services
				  DECLARE C CURSOR FAST_FORWARD FOR SELECT isnull(sum(ServiceQty*Service_Fee),0) As SerAmt From Service_Requests where 
				  ReqDate >= @frmDate  and ReqDate <= @toDate and Archived='No' and Refunded='No' and BillCategoryCode=@patCat and SerPlaceCode=@serplace and PaymentCode='P'

				  OPEN C
				  
                  FETCH NEXT FROM C INTO @serAmt;
				  WHILE @@fetch_status = 0
					BEGIN

					   Insert into PlaceOfServiceSummary (PlaceCode, CategoryCost, PatCategoryCode, FromDate, ToDate, UserID)values 
					   (@serplace, @serAmt, @patCat, @frmDate, @toDate, @user_ID)

					   FETCH NEXT FROM C INTO @serAmt;

					END
               
				  CLOSE C;

				  DEALLOCATE C;
               
                 --Patients in Mortuary
				  DECLARE C CURSOR FAST_FORWARD FOR SELECT MinDay,MaxDay,MortuaryAdmission.admDate,SerFee From MortuaryAdmission Inner Join MortuaryServices On MortuaryAdmission.OPDNo=MortuaryServices.OPDNo where Discharged='No' And 
				  MortuaryAdmission.admdate >= @frmDate  and MortuaryAdmission.admdate <= @toDate and MortuaryAdmission.MorID=@serplace

				  OPEN C
				  
                  FETCH NEXT FROM C INTO @minDay ,@maxDay,@admDate,@serAmt;
				  WHILE @@fetch_status = 0
					BEGIN
                       
					   If @maxDay <= datediff(d,@admDate,getdate())
						  set @serAmt = (@maxDay - @minDay + 1)* @serAmt

					   Else
						  set @serAmt = (datediff(d,@admDate,getdate()) - @minDay + 1)*@serAmt

					   Insert into PlaceOfServiceSummary (PlaceCode, CategoryCost, PatCategoryCode, FromDate, ToDate, UserID)values 
					   (@serplace, @serAmt, @patCat, @frmDate, @toDate, @user_ID)

					   FETCH NEXT FROM C INTO @minDay ,@maxDay,@admDate,@serAmt;

					END
               
				  CLOSE C;

				  DEALLOCATE C;   

                  FETCH NEXT FROM PatCats INTO @patCat

              END

			  CLOSE PatCats;

			  DEALLOCATE PatCats;
              
            FETCH NEXT FROM SerPlaces INTO @serplace

      END

	CLOSE SerPlaces;

	DEALLOCATE SerPlaces;

END
go

