CREATE VIEW [dbo].[QBPaidIOUView]
AS
SELECT    
           PmtRecordID As TransID
          ,BillsPaid.OPDNo  As ServiceCode
          ,IouAmtPaid  AS PaidAmt
          ,Convert(Date,BillsPaid.ServerTime)    As TransDate
          ,'0104' as ReceiverID
          ,Pat_No As IssuerID
          ,BillsPaid.Pat_No+' '+'Poor And Sick IOU' As ServiceDescription
          ,Surname+' '+LastName As ClientName 
          ,'Paid Cash IOU ' As MoveType
FROM        
           dbo.BillsPaid    Inner Join
           PatientsInfo 
           On BillsPaid.OPDNo =PatientsInfo.OPDNo 
WHERE    
          (IouAmtPaid   > 0)
go

