CREATE VIEW [dbo].[PregnancyUrineSetupView]

AS

SELECT  Description, Code FROM dbo.PregnancyUrineSetup

Union

SELECT  '', 0  FROM dbo.Hosp_Info
go

