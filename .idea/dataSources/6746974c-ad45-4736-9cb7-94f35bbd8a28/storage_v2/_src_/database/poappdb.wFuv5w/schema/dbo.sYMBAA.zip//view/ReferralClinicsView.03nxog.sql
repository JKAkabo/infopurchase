CREATE VIEW [dbo].[ReferralClinicsView]
AS

SELECT     HosID as Code, left(HosName,100) as Description

FROM         dbo.ReferralClinics

Union

SELECT    SPCode  as Code, left(Description,100)

FROM         dbo.Service_Points
go

