CREATE VIEW [dbo].[BillSponsorsView]
AS
SELECT     left(Sponsors.SponsorName, 100) As SponsorName, Sponsors.SponsorNo, Sponsors.SponsorTypeCode,Sponsors.SchemeCode
FROM       dbo.Sponsors

Union

Select LEFT (surname + ' ' + Lastname,100) As SponsorName, OPDNo as SponsorNo, 1 As SponsorTypeCode ,'' As SchemeCode from PatientsInfo
go

