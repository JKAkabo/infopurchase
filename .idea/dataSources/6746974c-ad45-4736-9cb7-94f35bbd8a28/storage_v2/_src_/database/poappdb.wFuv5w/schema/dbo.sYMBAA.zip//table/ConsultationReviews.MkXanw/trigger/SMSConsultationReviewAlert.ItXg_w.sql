-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[SMSConsultationReviewAlert] 
   ON  [dbo].[ConsultationReviews] 
   AFTER INSERT
AS 

  DECLARE @msgContent nvarchar(200),@reviewDate date,@Consent nvarchar(3),@AgeGroup  tinyint,@GenderGroup tinyint;
  DECLARE @msgType nvarchar(100),@OnceFreq tinyint,@ExpiryAlert nvarchar(3),@OPDNo nvarchar(15),@patSurName nvarchar(250);
  DECLARE @DocNo nvarchar(5),@DocName nvarchar(50),@ClinicName nvarchar(30), @includePatName nvarchar(3),@MsgTypeID TINYINT;
  DECLARE @Day nvarchar(50), @DayTime nvarchar(50), @DayDate nvarchar(50),@patCellNo nvarchar(50);
 
 SET @MsgTypeID=3;
 
 --Checking if SMS is enabled in HAMS
if NOT EXISTS(SELECT ActivateSMS FROM Hosp_Info WHERE ActivateSMS='Yes' )
   RETURN

--Checking if Con. Review SMS Alert is enabled in HAMS
 SELECT @msgType=h.Description, @msgContent=s.MsgContent,@Consent=s.EnforceConsent,@includePatName = s.includeRPT,@AgeGroup=AgeGroupCode,@GenderGroup=GenderCode FROM HamsMessageTypes h Inner Join HamsSMSSetup s On h.Code=s.TypeCode WHERE s.TypeCode=@msgTypeID And s.Active='Yes' And s.StartTime<=getdate()
 IF @@RowCount<=0 
    RETURN 

SELECT  @DayTime=RIGHT(CONVERT(VARCHAR, i.ReviewTime, 100),7), @DayDate=DATENAME(DD,i.ReviewTime) + '-' + left(DATENAME(MM,i.ReviewTime),3) + '-' + DATENAME(YYYY,i.ReviewTime), @Day= UPPER(DATENAME(dw,i.ReviewTime)),@patSurName=(Title + '.' + Surname),@ExpiryAlert=s.ExpiryAlert,@OPDNo=s.OPDNo,@reviewDate=s.reviewdate,@DocName=s.Doctor,@ClinicName=Clinic, @patCellNo=Rtrim(Ltrim(CellPhoneNo)) FROM SMSConsultationReviewAlertView s,inserted i WHERE s.ConID=i.ConID  And s.Received='No' And getdate()<s.reviewtime And Rtrim(Ltrim(CellPhoneNo))<>'' AND CellPhoneNo IS NOT NULL
IF @@RowCount<=0 OR @patCellNo=''
   RETURN 
   
--cast(@reviewDate as nvarchar(50))

BEGIN         
set @OnceFreq=6;

insert into bulksms_db.dbo.sending_queue([from],[to],Message,queue_time,status) 
select 'System',@patCellNo,'You Have A Scheduled Consultation Review On ' + UPPER(DATENAME(dw,i.ReviewTime)) + ',' + DATENAME(DD,i.ReviewTime) + '-' + left(DATENAME(MM,i.ReviewTime),3) + '-' + DATENAME(YYYY,i.ReviewTime) + ' ' +  RIGHT(CONVERT(VARCHAR, i.ReviewTime, 100),7) + ' With Doctor ' + s.Doctor + ' At The ' + s.Clinic + ' Clinic. Thank You.',getdate(),'Sent' FROM 
SMSConsultationReviewAlertView s Inner Join Inserted i On s.ConID=i.ConID WHERE ((@Consent='Yes' And @ExpiryAlert='Yes') or @Consent='No') And s.Received='No' And getdate()<s.reviewtime

END
go

