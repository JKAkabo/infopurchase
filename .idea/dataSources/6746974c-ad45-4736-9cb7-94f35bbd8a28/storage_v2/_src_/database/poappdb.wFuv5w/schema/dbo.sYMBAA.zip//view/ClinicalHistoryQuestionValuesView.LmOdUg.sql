

CREATE VIEW [dbo].[ClinicalHistoryQuestionValuesView]

AS

SELECT ValueOrderNo, ClinicalHistoryQuestionValues.Description, ClinicalHistoryQuestionValues.ID, QuestionID, ClinicalHistoryQuestionValues.IsActive, ClinicalHistoryQuestions.Description As Question, ClinicalHistories.Description As History, HistoryID FROM dbo.ClinicalHistoryQuestions, ClinicalHistoryQuestionValues, ClinicalHistories where ClinicalHistoryQuestions.ID=QuestionID And ClinicalHistories.ID=HistoryID


go

