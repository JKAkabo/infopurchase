

CREATE VIEW [dbo].[NHIAEpisodeDiagnosesView]

AS

SELECT Distinct Left(Diseases.DisDescription,100) As ServiceDescription, ConsultationDiagnoses.DisCode As ServiceCode, PmtTypeCode, 'DIAGNOSIS(ES)' As ServicePlace, DiaFee as UnitFee, 1 As ServiceQty, Consultations.ReqDate, ConsultationDiagnoses.GDRGCode As GDRDCode, IsNull(Diseases.ICDCode,'') As ICDCOde, Consultations.EpisodeID, Consultations.OPDNo,  2 As PatStatus, Principal As IsPrincipal, Consultations.ConDate As ServiceDate, Consultations.DirectID, Consultations.SponsorNo, Episode.EndEpisode As EpiEndDate FROM Diseases Inner Join (Episode Inner Join (Consultations Inner Join ConsultationDiagnoses On  Consultations.ConID=ConsultationDiagnoses.ConID) On (Episode.EpisodeID=Consultations.EpisodeID  and Episode.OPDNo=Consultations.OPDNo)) On Diseases.DisCode=ConsultationDiagnoses.DisCode Where Consultations.EpisodeID<>0 and Consultations.Archived='No' and Episode.Archived='No' and BillCategoryCode IN (4,11) and Consultations.StatusCode=2 and Episode.StatusCode=2 and PmtTypeCode NOT IN (0,1) and Cancelled='No'

Union

SELECT Distinct Left(Diseases.DisDescription,100) As ServiceDescription, AdmissionCauses.DisCode As ServiceCode, PmtTypeCode, 'DIAGNOSIS(ES)' As ServicePlace, DiaFee as UnitFee, 1 As ServiceQty, Episode.BeginEpisode As ReqDate, AdmissionCauses.GDRGCode As GDRDCode, IsNull(Diseases.ICDCode,'') As ICDCOde, Episode.EpisodeID, Episode.OPDNo, 3 As PatStatus, Principal As IsPrincipal, Episode.EndEpisode As ServiceDate, Episode.DirectID, Episode.SponsorNo, Episode.EndEpisode As EpiEndDate FROM Diseases Inner Join (Episode Inner Join (Admissions Inner Join AdmissionCauses On (Admissions.OPDNo=AdmissionCauses.OPDNo And Admissions.EpisodeID=AdmissionCauses.EpisodeID )) On (Episode.EpisodeID=Admissions.EpisodeID and Episode.OPDNo=Admissions.OPDNo)) On Diseases.DisCode=AdmissionCauses.DisCode Where Admissions.EpisodeID<>0 and Admissions.Archived='No' and Episode.Archived='No' and BillCategoryCode IN (4,11) and AdmissionCauses.EpisodeID<>0 and PmtTypeCode NOT IN (0,1,3) and Episode.EndEpisode Is Not Null And Admissions.DisDate Is Not Null and Cancelled='No'


go

