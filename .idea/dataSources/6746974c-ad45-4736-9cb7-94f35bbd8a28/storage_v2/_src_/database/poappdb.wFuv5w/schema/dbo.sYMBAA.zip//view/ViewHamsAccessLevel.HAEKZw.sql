CREATE VIEW [dbo].[ViewHamsAccessLevel]
AS
SELECT     left(Description,100) As Description,Code,RefCode,LevelType
FROM         dbo.HAMS_ACCESS_LEVELS Where LevelType=1
go

