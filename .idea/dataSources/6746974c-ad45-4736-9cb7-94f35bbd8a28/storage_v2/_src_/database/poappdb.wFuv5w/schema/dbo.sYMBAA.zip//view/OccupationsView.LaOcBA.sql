CREATE VIEW [dbo].[OccupationsView]

AS

SELECT Description, Code FROM dbo.Occupations

Union

Select 'NOT AVAILABLE' As Description, 0 as Code from Hosp_Info
go

