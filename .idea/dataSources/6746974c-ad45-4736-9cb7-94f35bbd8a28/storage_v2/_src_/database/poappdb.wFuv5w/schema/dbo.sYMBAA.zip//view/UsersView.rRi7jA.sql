CREATE VIEW [dbo].[UsersView]

AS

SELECT LEFT(U.UserID,100) As UserID, UserName, UserNo, EmailAddress, AlternateEmailAddress, U.CatID,User_Locked, U.Archived, UserGrade, ContractID, UserGender, UserTitle, 'INTERNAL' AS UserType, UPPER(C.Description) As UserCategory FROM dbo.Users U, UserCategories C Where U.CatID=C.CatID

Union

SELECT Distinct LEFT(DoctorName + '(' + HosName + ')',100) As UserID, DoctorName As UserName, ExternalDoctors.Code As UserNo, EmailAddress, AlternateEmailAddress, 0 As CatID, 'No' As User_Locked, ExternalDoctors.Archived, 0 As UserGrade, 0 As ContractID, 0 As UserGender, '' As UserTitle, 'EXTERNAL','EXTERNAL DOCTOR' FROM ReferralClinics Inner Join ExternalDoctors On HosID=ClinicCode

Union

SELECT '' As UserID, '' AS UserName, '' AS UserNo, '' AS EmailAddress, '' AS AlternateEmailAddress, 0 As CatID, '' As User_Locked, 'No' As Archived, 0 As UserGrade, 0 As ContractID , 0 As UserGender, '' As UserTitle, 'INTERNAL' AS UserType, '' FROM dbo.Hosp_Info
go

