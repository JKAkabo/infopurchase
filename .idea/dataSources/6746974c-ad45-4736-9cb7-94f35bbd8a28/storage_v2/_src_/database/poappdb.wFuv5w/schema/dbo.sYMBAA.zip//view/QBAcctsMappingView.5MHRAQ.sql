CREATE VIEW [dbo].[QBAcctsMappingView]

AS

SELECT PostType, ActivityID, PostMsg, ServiceID, Query, AcctsID, AcctsCode, AcctsName, AcctsTypeID, TypeID, PostCode, QBAcctPostingActivityDescription, CatID, SubCatID, FinanceActivityDescription FROM QBAcctPostingActivityTypesView Q Inner Join AccountChartServicesMapping A On AcctsID=AcctCode
go

