CREATE VIEW [dbo].[DrugOutputTypesView]

AS

SELECT  Description, Code FROM dbo.DrugOutputTypes 

Union

SELECT  '' As Description, 0 As Code FROM dbo.Hosp_Info
go

