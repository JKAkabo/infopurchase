CREATE VIEW [dbo].[OPDServicePlaceDailyAttendanceView]
AS

Select Distinct Daily_Attendance.EmpNo, Daily_Attendance.DeptID, PatientsInfo.GenderCode, DirectoratesView.Description As Directorate, 
Service_Points.Description As Clinic,  PatientCategoryTypes.Description As PatCategory, Service_Places.Description As ServicePlace, 
Daily_Attendance.Insured, Daily_Attendance.AttAge, Daily_Attendance.RegStatus, Daily_Attendance.RegType, Daily_Attendance.Pat_No, 
Daily_Attendance.SponsorNo, Daily_Attendance.DirectID, AttDate, AttTime,Daily_Attendance.RecordID, Daily_Attendance.OPDNo, 
Daily_Attendance.AgeClassCode, Daily_Attendance.PatCategoryCode, Daily_Attendance.ClinicCode, SerPlaceCode From 
DirectoratesView ,Service_Points, PatientCategoryTypes, Service_Places, PatientsInfo, Daily_Attendance, Service_Requests Where Daily_Attendance.OPDNo=Service_Requests.OPDNo And 
Daily_Attendance.AttDate=Service_Requests.ReqDate AND Daily_Attendance.ClinicCode=Service_Requests.ClinicCode AND PatientsInfo.OPDNo=Daily_Attendance.OPDNo AND Service_Places.Code=SerPlaceCode AND  
PatientCategoryTypes.Code=Daily_Attendance.PatCategoryCode AND SPCode=Service_Requests.ClinicCode AND DirectoratesView.ID=Service_Requests.DirectID  AND Service_Requests.Archived='No'
go

