

CREATE VIEW [dbo].[DepartmentsView]

AS

SELECT  Description, ID, Code, CompanyID, IsActive, DeptHead FROM dbo.Departments

Union

SELECT  '' As Description, 0 As ID, '' As Code,'' As CompanyID, 'No' As IsActive, '' As DeptHead FROM dbo.Hosp_Info


go

