CREATE VIEW [dbo].[SuppliersView]
AS
SELECT left(ContactName, 100) As Description,SupplierID,TIN,TelPhoneNo,FaxNo,OutAmt, EMail, AccountNo, CreditLimit, Disable, Archived, ItemsTypeSupplied, VatRate, PostalAddrs, AutoFillPO
FROM dbo.Suppliers
go

