-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetItemsForPrescriptions] 
	-- Add the parameters for the stored procedure here

	@ItemDescription nvarchar(250) ,@itemType nvarchar(50),@itemStore nvarchar(15)
	
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
 if @itemType<>''
	  Select Distinct Items.Description, Items.PrescriptionQty, Items.Manufacturer, Sum(StocksView.Quantity) as Qty, 
	  Items.ItemType, Items.Presentation ,No_Per_BaseUnit, Items.DefaultMethod, Items.ItemID, CashPrice, CreditPrice,
	  NHISPrice, isNull(NGPrice,0) as NGPrice, CtMarkup, ChMarkup, NGMarkup, MaxPresQty, MinPresQty , Sharing From Items Inner Join (StocksView Inner Join Packs On
	  StocksView.ItemID = Packs.ItemID) On Items.ItemID =StocksView.ItemID where Items.Description Like @ItemDescription + '%' and 
	  Unit_Type ='Base' and Items.Disabled ='No' And Items.ItemType =@itemType and StocksView.StoreID= @itemStore And Items.ItemID=Items.BaseItemID
	  and Quantity >=0 Group By Items.ItemID,Items.Description,Items.Presentation,Items.DefaultMethod,Items.Manufacturer,No_Per_BaseUnit,
	  CashPrice,CreditPrice,NHISPrice,NGPrice,Items.ItemType, CtMarkup, ChMarkup, NGMarkup, Items.PrescriptionQty, MaxPresQty, MinPresQty , Sharing Order by Items.Description Asc

else
	  Select Distinct Items.Description, Items.PrescriptionQty, Items.Manufacturer, Sum(StocksView.Quantity) as Qty, 
	  Items.ItemType, Items.Presentation ,No_Per_BaseUnit, Items.DefaultMethod, Items.ItemID, CashPrice, CreditPrice,
	  NHISPrice, isNull(NGPrice,0) as NGPrice, CtMarkup, ChMarkup, NGMarkup, MaxPresQty, MinPresQty, Sharing From Items Inner Join (StocksView Inner Join Packs On
	  StocksView.ItemID = Packs.ItemID) On Items.ItemID =StocksView.ItemID where Items.Description Like @ItemDescription + '%' and 
	  Unit_Type ='Base' and Items.Disabled ='No' And StocksView.StoreID= @itemStore And Items.ItemID=Items.BaseItemID 
	  and Quantity >=0 Group By Items.ItemID,Items.Description,Items.Presentation,Items.DefaultMethod,Items.Manufacturer,No_Per_BaseUnit,
	  CashPrice,CreditPrice,NHISPrice,NGPrice,Items.ItemType, CtMarkup, ChMarkup, NGMarkup, Items.PrescriptionQty, MaxPresQty, MinPresQty , Sharing Order by Items.Description Asc


END
go

