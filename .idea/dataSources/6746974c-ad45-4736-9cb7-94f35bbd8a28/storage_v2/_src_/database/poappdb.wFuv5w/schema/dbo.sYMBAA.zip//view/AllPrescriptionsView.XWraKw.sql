

CREATE VIEW [dbo].[AllPrescriptionsView]

AS

SELECT Distinct Prescriptions.UserID, Archived, Refunded, StoresID, PresDate, PresTime, DrugCode, '' As DespenserID, EpisodeType, AttType, EpisodeID, ServerTime, PreReason, DirectID, PresStatus, AttServiceID, PatCategoryCode, PatAge, PresType As DeliveryType, PresDate As AttDate, PresTime As AttTime, Prescriber,Items.Description, StartDate, FinishDate, PrescribeUnit, Dosage As Freq, Units As Dosage, PresDays As Duration, QtyPrescribed As Quantity, ServicePlacesView.Description As ServicePlace, ClinicCode, StatusCode, OPDNo, Pat_No, UnitPrice, BillCategoryCode, PmtTypeCode, PmtModeCode, BillCycleDuration, PaymentCode, PaidQty, PaidAmt, SponsorNo From ServicePlacesView Inner Join ( Items Inner Join  Prescriptions On ItemID=DrugCode) On Code =StoresID Where Archived='No' And QtyGiven=0 and ReturnedQty=0

Union ALL

SELECT Distinct Prescriptions.UserID, Archived, Refunded, StoreID, PresDate, PresTime, DrugCode, DespenserID, EpisodeType,  AttType, EpisodeID, DispensedPrescriptions.ServerTime, PreReason, DirectID, PresStatus, AttServiceID, PatCategoryCode, DispensedPrescriptions.PatAge, PresType As DeliveryType, PresDate As AttDate, PresTime As AttTime, Prescriber,Items.Description, StartDate, FinishDate, PrescribeUnit, Frequency As Freq,DispensedPrescriptions.Dosage, Duration, (DispensedPrescriptions.DispensedQty -DispensedPrescriptions.ReturnedQty) As Quantity, ServicePlacesView.Description As ServicePlace, ClinicCode, DispensedPrescriptions.StatusCode, OPDNo, Pat_No, Prescriptions.UnitPrice, BillCategoryCode, PmtTypeCode, PmtModeCode, BillCycleDuration, PaymentCode, PaidQty, PaidAmt, SponsorNo From ServicePlacesView Inner Join ( Items Inner Join (Prescriptions Inner Join DispensedPrescriptions On Prescriptions.RecordID=PresID)  On Items.ItemID=DrugCode) On Code =StoreID Where Archived='No' And (DispensedPrescriptions.DispensedQty-DispensedPrescriptions.ReturnedQty)>0

Union ALL

SELECT Distinct Prescriptions.UserID, Archived, Refunded, StoresID, PresDate, PresTime, DrugCode, '' As DespenserID,EpisodeType, AttType, EpisodeID, ServerTime, PreReason, DirectID, PresStatus, AttServiceID, PatCategoryCode, PatAge, PresType As DeliveryType, PresDate As AttDate, PresTime As AttTime, Prescriber,Items.Description, StartDate, FinishDate, PrescribeUnit, Dosage As Freq, Units As Dosage, PresDays As Duration, QtyPrescribed As Quantity, ServicePlacesView.Description As ServicePlace, ClinicCode, StatusCode, OPDNo, Pat_No, CoPayFee-UnitPrice As UnitPrice, CoPayBillCategoryCode, CoPayPmtTypeCode, CoPayPmtModeCode, CoPayBillCycleDuration, PaymentCode, CoPayPaidQty, CoPayPaidAmt, CoPaySponsorNo From ServicePlacesView Inner Join ( Items Inner Join  Prescriptions On ItemID=DrugCode) On Code =StoresID Where Archived='No' And QtyGiven=0 and ReturnedQty=0 And CoPayFee-UnitPrice>0

Union ALL

SELECT Distinct Prescriptions.UserID, Archived, Refunded, StoreID, PresDate, PresTime, DrugCode, DespenserID, EpisodeType, AttType, EpisodeID, DispensedPrescriptions.ServerTime, PreReason, DirectID, PresStatus, AttServiceID, PatCategoryCode, DispensedPrescriptions.PatAge, PresType As DeliveryType, PresDate As AttDate, PresTime As AttTime, Prescriber,Items.Description, StartDate, FinishDate, PrescribeUnit, Frequency As Freq,DispensedPrescriptions.Dosage, Duration, (DispensedPrescriptions.DispensedQty -DispensedPrescriptions.ReturnedQty) As Quantity, ServicePlacesView.Description As ServicePlace, ClinicCode, DispensedPrescriptions.StatusCode, OPDNo, Pat_No, CoPayFee - Prescriptions.UnitPrice, CoPayBillCategoryCode, CoPayPmtTypeCode, CoPayPmtModeCode, CoPayBillCycleDuration, PaymentCode, CoPayPaidQty, CoPayPaidAmt, CoPaySponsorNo From ServicePlacesView Inner Join ( Items Inner Join (Prescriptions Inner Join DispensedPrescriptions On Prescriptions.RecordID=PresID)  On Items.ItemID=DrugCode) On Code =StoreID Where Archived='No' And (DispensedPrescriptions.DispensedQty-DispensedPrescriptions.ReturnedQty)>0  And CoPayFee- Prescriptions.UnitPrice>0


go

