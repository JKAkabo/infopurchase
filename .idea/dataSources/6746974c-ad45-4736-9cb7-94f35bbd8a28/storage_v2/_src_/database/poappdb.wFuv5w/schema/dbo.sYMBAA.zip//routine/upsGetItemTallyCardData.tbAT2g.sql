-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[upsGetItemTallyCardData] 
	-- Add the parameters for the stored procedure here

@itemStore nvarchar(15),@itemID nvarchar(15) ,@FromDate datetime, @ToDate datetime,@ItemUnitType tinyint=1,
@ItemBaseQty int=1,@ItemUnitID int=0
    
	
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
if @ItemUnitType=0 
   Set @ItemUnitType=1 
	
if @ItemBaseQty=0 
   Set @ItemBaseQty=1 
	
SET NOCOUNT ON;

if @ItemUnitType=1
   Select TransUnitType, UnitCost, MoveType, AdjustQty As MoveQty, MoveDate, MoveTime, MoveNo, MoveOrder, IssuerID, ReceiverID, IssuerStock, ReceiverStock, ItemID, ServerTime, IssuerUOMID, ReceiverUOMID, BaseQty From STOCKMOVEMENT Where (IssuerID =@itemStore Or ReceiverID= @itemStore) and itemID=@itemID and (ServerDate >=@FromDate and ServerDate <=@ToDate) Order By ServerTime,MoveOrder 

else
   if @ItemUnitID=0 
      Select TransUnitType, UnitCost*BaseQty As UnitCost, MoveType, convert(Numeric(18,6),AdjustQty/BaseQty) As MoveQty, MoveDate, MoveTime, MoveNo, MoveOrder, IssuerID, ReceiverID, convert(Numeric(18,6),IssuerStock/BaseQty) As IssuerStock, convert(Numeric(18,6),ReceiverStock/BaseQty) As ReceiverStock, ItemID, ServerTime, IssuerUOMID, ReceiverUOMID, BaseQty From STOCKMOVEMENT Where (IssuerID =@itemStore Or ReceiverID= @itemStore) And (TransUnitType=1 OR (BaseQty=@ItemBaseQty And TransUnitType=@ItemUnitType)) and itemID=@itemID and (ServerDate >=@FromDate and ServerDate <=@ToDate) Order By ServerTime,MoveOrder 
   else
      Select TransUnitType, UnitCost*BaseQty As UnitCost, MoveType, convert(Numeric(18,6),AdjustQty/BaseQty) As MoveQty, MoveDate, MoveTime, MoveNo, MoveOrder, IssuerID, ReceiverID, convert(Numeric(18,6),IssuerStock/BaseQty) As IssuerStock, convert(Numeric(18,6),ReceiverStock/BaseQty) As ReceiverStock, ItemID, ServerTime, IssuerUOMID, ReceiverUOMID, BaseQty From STOCKMOVEMENT Where (IssuerID =@itemStore Or ReceiverID= @itemStore) And (TransUnitType=1 OR ((IssuerUOMID =@ItemUnitID Or ReceiverUOMID= @ItemUnitID) And BaseQty=@ItemBaseQty And TransUnitType=@ItemUnitType)) and itemID=@itemID and (ServerDate >=@FromDate and ServerDate <=@ToDate) Order By ServerTime,MoveOrder 
    
END
go

