CREATE VIEW [dbo].[RequisitionsIssuedSummaryView]

AS

SELECT  SUM((L.IssuedQty - L.TotalReturnedQty) * L.UnitCost) As IssuedTotal,COUNT(L.ItemID) As ItemsNo, I.IssuedID FROM  
IssuedOrders I, IssuedOrderLines L Where I.IssuedID = L.IssuedID And I.Archived='No' And L.Archived='No' Group By I.IssuedID
Having SUM((L.IssuedQty - L.TotalReturnedQty) * L.UnitCost)>0 and COUNT(L.ItemID)>0
go

