CREATE VIEW [dbo].[AllPaidServicesView]

AS

SELECT Distinct ServiceLinePayments.PmtDate, ServiceLinePayments.PmtTime, ServiceLinePayments.RecordID, DrugCode As ServiceCode, 1 As ServiceTypeCode, ServiceLinePayments.PmtTypeCode, StoresID As SerPlaceCode , ServiceLinePayments.Service_Fee AS UnitFee, QtyPrescribed As ServiceQty, PresType As RequestType, BillsPaid.OPDNo, Prescriptions.StatusCode As PatStatus, ServiceLinePayments.PaidAmt, DirectID, ServiceLinePayments.PaidQty, '**' As CapID, Prescriptions.ServerTime, BillsPaid.Pat_No, ServiceLinePayments.ReceiptNo, Prescriptions.ClinicCode, ServiceLinePayments.PatAge, Prescriptions.BillCategoryCode As PatCategoryCode, BillsPaid.UserID, 'DRUG' As RecType,Prescriber As RequesterID, Prescriptions.PresDate As ReqDate, Prescriptions.PresTime As Reqtime,CoPayed, ServiceLinePayments.SponsorNo,BillsPaid.PmtModeCode FROM Prescriptions Inner Join (BillsPaid Inner Join ServiceLinePayments On BillsPaid.ReceiptNo =ServiceLinePayments.ReceiptNo) On (DrugCode=ServiceCode and Prescriptions.RecordID=ServiceID) Where ServiceLinePayments.Archived='No'

UNION ALL

SELECT Distinct ServiceLinePayments.PmtDate, ServiceLinePayments.PmtTime, ServiceLinePayments.RecordID, ServiceLinePayments.ServiceCode, ServiceTypeCode, ServiceLinePayments.PmtTypeCode, SerPlaceCode , ServiceLinePayments.Service_Fee AS UnitFee,  ServiceQty, RequestType, BillsPaid.OPDNo, Service_Requests.StatusCode As PatStatus, ServiceLinePayments.PaidAmt, DirectID, ServiceLinePayments.PaidQty, '**' As CapID, Service_Requests.ServerTime, BillsPaid.Pat_No, ServiceLinePayments.ReceiptNo, Service_Requests.ClinicCode, ServiceLinePayments.PatAge, Service_Requests.BillCategoryCode As PatCategoryCode,BillsPaid.UserID, 'SERVICE' As RecType,RequesterID, ReqDate, Reqtime,CoPayed, ServiceLinePayments.SponsorNo,BillsPaid.PmtModeCode FROM AllSetUpServicesView Inner Join (Service_Requests Inner Join (BillsPaid Inner Join ServiceLinePayments On BillsPaid.ReceiptNo =ServiceLinePayments.ReceiptNo) On (Service_Requests.ServiceCode=ServiceLinePayments.ServiceCode and Service_Requests.RecordID=ServiceID)) On ItemID=Service_Requests.ServiceCode Where ServiceLinePayments.Archived='No'

UNION ALL

SELECT Distinct Deposits.DepositDate As PmtDate, Deposits.DepositTime  As Pmtime, 0 As RecordID, 'DEPTDRG' As ServiceCode, 1 AS ServiceTypeCode, 1 As PmtTypeCode, 'DEPTDRG' AS SerPlaceCode , DepositAmount AS UnitFee,  1 AS ServiceQty,  'INTERNAL' AS RequestType, OPDNo, Deposits.StatusCode As PatStatus, Deposits.DepositAmount AS PaidAmt,0 AS DirectID, 1 AS PaidQty, '**' As CapID, Deposits.DepServerTime  As PmtTime, Pat_No, Deposits.ReceiptNo, 'DEPTDRG' AS ClinicCode, Deposits.PatAge, 1 As PatCategoryCode, Deposits.UserID, 'DRUG DEPOSIT' As RecType, Deposits.UserID, Deposits.DepositDate AS ReqDate, Deposits.DepositTime AS ReqTime,'No' As CoPayed,Deposits.SponsorNo,Deposits.PmtModeCode FROM Deposits Where Archived='No' and Deposits.DepReason='DRUGS'

UNION ALL

SELECT Distinct Deposits.DepositDate As PmtDate, Deposits.DepositTime  As Pmtime, 0 As RecordID, 'DEPTSER' As ServiceCode, 10 AS ServiceTypeCode, 1 As PmtTypeCode, 'DEPTSER' AS SerPlaceCode , DepositAmount AS UnitFee,  1 AS ServiceQty,  'INTERNAL' AS RequestType, OPDNo, Deposits.StatusCode As PatStatus, Deposits.DepositAmount AS PaidAmt,0 AS DirectID, 1 AS PaidQty, '**' As CapID, Deposits.DepServerTime  As PmtTime, Pat_No, Deposits.ReceiptNo, 'DEPTSER' AS ClinicCode, Deposits.PatAge, 1 As PatCategoryCode, Deposits.UserID, 'DRUG DEPOSIT' As RecType, Deposits.UserID, Deposits.DepositDate AS ReqDate, Deposits.DepositTime AS ReqTime,'No',Deposits.SponsorNo,Deposits.PmtModeCode FROM Deposits Where Archived='No' and Deposits.DepReason<>'DRUGS'

UNION ALL

SELECT Distinct BillsPaid.PmtDate, BillsPaid.PmtTime, 0 As RecordID, 'OUTBILLPMT' As ServiceCode, 10 AS ServiceTypeCode, 1 As PmtTypeCode, 'OUTBILLPMT' AS SerPlaceCode , AmtPaid AS UnitFee,  1 AS ServiceQty, 'INTERNAL' AS RequestType, OPDNo, BillsPaid.StatusCode As PatStatus, BillsPaid.AmtPaid AS PaidAmt,0 AS DirectID, 1 AS PaidQty, '**' As CapID, BillsPaid.PmtTime, Pat_No, BillsPaid.ReceiptNo, 'OUTBILLPMT' AS ClinicCode, BillsPaid.PatAge, 1 As BillCategoryCode,BillsPaid.UserID, 'OUT' As RecType,BillsPaid.UserID, BillsPaid.PmtDate AS ReqDate, BillsPaid.PmtTime AS ReqTim, 'No', BillsPaid.SponsorNo,BillsPaid.PmtModeCode FROM BillsPaid Where Archived='No' And BillsPaid.AmtPaid>0 AND BillsPaid.RefAmtRequested=0 And ReceiptNo Not IN (Select ReceiptNo FROM Deposits) And ReceiptNo Not IN (Select ReceiptNo FROM ServiceLinePayments)
go

