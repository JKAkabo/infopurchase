CREATE PROCEDURE [dbo].[uspUpdateKinsInfo] 
	
AS

DECLARE @OPDNo nvarchar(15),@patno nvarchar(10),@ContactName nvarchar(50),@Relation nvarchar(50),@KHomeAddrs nvarchar(500),
        @KWorkAddrs nvarchar(500),@KHomeTelNo nvarchar(25),@KWorkTelNo nvarchar(25),@KEmailAddrs nvarchar(50)

BEGIN

Delete From Kins

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  

DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct OPDNo,Pat_No,ContactName,Relation,KHomeAddrs,KWorkAddrs,KHomeTelNo,KWorkTelNo,KEmailAddrs From Kins1 Order by OPDNo
           
  OPEN C
  
  FETCH NEXT FROM C INTO @OPDNo,@PatNo,@ContactName,@Relation,@KHomeAddrs,@KWorkAddrs,@KHomeTelNo,@KWorkTelNo,@KEmailAddrs          

  WHILE @@fetch_status = 0
    BEGIN

       insert into Kins (OPDNo,ContactName,Relation,HomeAddrs,WorkAddrs,HomeTelNo,WorkTelNo,EmailAddrs,CellPhoneNo,HomeStreet,WorkStreet) Values 
                        (@OPDNo,@ContactName,@Relation,@KHomeAddrs,@KWorkAddrs,@KHomeTelNo,@KWorkTelNo,@KEmailAddrs,@KHomeTelNo,@KHomeAddrs,@KWorkAddrs)

  FETCH NEXT FROM C INTO @OPDNo,@PatNo,@ContactName,@Relation,@KHomeAddrs,@KWorkAddrs,@KHomeTelNo,@KWorkTelNo,@KEmailAddrs       

	END

	CLOSE C;

	DEALLOCATE C;

END
go

