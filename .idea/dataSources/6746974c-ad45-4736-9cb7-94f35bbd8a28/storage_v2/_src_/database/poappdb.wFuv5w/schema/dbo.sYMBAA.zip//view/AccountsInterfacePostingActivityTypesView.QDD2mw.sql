CREATE VIEW [dbo].[AccountsInterfacePostingActivityTypesView]

AS

SELECT C.PostMsg, C.Code As ActivityID, AcctTypeID, C.Description, C.DebitAcctQuery, C.CreditAcctQuery,AcctQuery,
A.Description As AcctTypeDescription, C.AutoGenerateRefNo , P.Description As PostType, P.Code As PostTypeID
FROM AccountsJournalTransactionsCombined C, AccountTypes A, AccountPostingType P 
Where C.IsActive='Yes' And A.ID=C.AcctTypeID and P.Code=C.PostType
go

