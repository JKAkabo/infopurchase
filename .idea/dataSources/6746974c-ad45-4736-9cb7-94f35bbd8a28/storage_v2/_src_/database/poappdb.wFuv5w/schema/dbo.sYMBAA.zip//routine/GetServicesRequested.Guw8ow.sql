CREATE FUNCTION [dbo].[GetServicesRequested]

(@OPDNo AS NVARCHAR(15),@DateFrom DateTime,@DateTo DateTime,@ServiceType TinyInt) RETURNS NVARCHAR(MAX)

AS

BEGIN

Declare @ServicesRequested NVARCHAR(MAX),@ServiceDescription nvarchar(250),@UnitFee Numeric(18,6)

Set @ServicesRequested=''

if @ServiceType<>1 
   DECLARE C CURSOR FAST_FORWARD FOR SELECT DISTINCT ServiceType, Service_Fee From Service_Types Inner Join Service_Requests On Service_Types.ServiceCode = Service_Requests.ServiceCode Where OPDNo=@OPDNo And ServiceTypeCode=@ServiceType And ReqDate>=@DateFrom And ReqDate<=@DateTo And Archived='No' And Refunded='No' Order By Service_Fee Desc, ServiceType

else
   DECLARE C CURSOR FAST_FORWARD FOR SELECT  DISTINCT  AllSetUpServicesView.Description, UnitPrice From AllSetUpServicesView Inner Join Prescriptions On ItemID = Prescriptions.DrugCode Where OPDNo=@OPDNo And PresDate>=@DateFrom And PresDate<=@DateTo And Archived='No' And Refunded='No' ORDER BY Description

OPEN C

FETCH NEXT FROM C INTO @ServiceDescription, @UnitFee;

WHILE @@fetch_status = 0

	BEGIN
                IF LTRIM(RTRIM(@ServicesRequested))<>''
				   Set @ServicesRequested=@ServicesRequested + ',' + @ServiceDescription 
				   
				ELSE
				   Set @ServicesRequested= @ServiceDescription 
								
	  FETCH NEXT FROM C INTO @ServiceDescription, @UnitFee;
	       
	END    
                      
    CLOSE C;

	DEALLOCATE C;		  


RETURN UPPER(@ServicesRequested)

END
go

