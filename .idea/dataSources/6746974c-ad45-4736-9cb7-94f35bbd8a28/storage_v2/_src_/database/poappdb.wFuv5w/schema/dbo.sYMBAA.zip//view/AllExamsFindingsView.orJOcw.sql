CREATE VIEW [dbo].[AllExamsFindingsView]

AS

--SELECT Distinct [System], ExamFind, Doctor As UserID, OPDNo, Pat_No, ClinicCode, 2 As PatStatus, ConDate As AttDate, ConTime As AttTime, ConID As RecordID FROM ExamFindings  Where Cancelled='No'

--Union ALL

--SELECT Distinct [System], ExamFind, DoctorID As UserID, OPDNo, Pat_No, ClinicCode, 3 As PatStatus, AdmDate As AttDate, AdmTime As AttTime, AdmID As RecordID FROM InPatientExamFindings  Where Cancelled='No'

SELECT Distinct SystemID, ClinicSystemsView.Description As [System], ExamFind, Doctor As UserID, OPDNo, Pat_No, ClinicCode, 2 As PatStatus, ConDate As AttDate, ConTime As AttTime, ConID, RecordID FROM ClinicSystemsView, ExamFindings  Where ID= SystemID  And Cancelled='No'

Union ALL

SELECT Distinct SystemID, ClinicSystemsView.Description As [System], ExamFind, DoctorID As UserID, OPDNo, Pat_No, ClinicCode, 3 As PatStatus, AdmDate As AttDate, AdmTime As AttTime, AdmID, RecordID FROM ClinicSystemsView, InPatientExamFindings  Where  ID= SystemID  And Cancelled='No'
go

