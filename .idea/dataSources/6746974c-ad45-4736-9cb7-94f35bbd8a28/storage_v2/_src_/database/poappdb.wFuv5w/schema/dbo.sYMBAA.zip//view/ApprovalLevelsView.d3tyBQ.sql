CREATE VIEW [dbo].[ApprovalLevelsView]

AS

SELECT  Description, Code FROM dbo.ApprovalLevels

Union

SELECT  '' As Description, 0 As Code FROM dbo.Hosp_Info
go

