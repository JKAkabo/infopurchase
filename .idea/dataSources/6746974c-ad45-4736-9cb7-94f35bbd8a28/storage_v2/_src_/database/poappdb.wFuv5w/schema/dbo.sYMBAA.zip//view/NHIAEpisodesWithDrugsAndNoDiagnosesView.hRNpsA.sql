CREATE VIEW [dbo].[NHIAEpisodesWithDrugsAndNoDiagnosesView]

AS

SELECT ActiveEpiID FROM NHIAEpisodesWithDrugsView  Where ActiveEpiID NOT IN (Select ActiveEpiID From NHIAEpisodesWithDiagnosesView )
go

