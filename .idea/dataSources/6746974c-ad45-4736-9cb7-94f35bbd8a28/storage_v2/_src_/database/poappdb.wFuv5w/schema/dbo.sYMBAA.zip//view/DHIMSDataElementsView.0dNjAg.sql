CREATE VIEW [dbo].[DHIMSDataElementsView]

AS

SELECT  HamsCode, ElementID, DataSetID, Description, PatientType, GenderCode, AgeGroupCode, ElementOrder AS OrderNo, CategoryCode, AgeRangeCode, ServiceTypeID,IsDummy, CatOptionQuery, DataElementSource FROM DHIMSDataElements Where IsActive='Yes'
go

