CREATE VIEW [dbo].[ItemsStockLevelView]

AS

SELECT IsNull(Sum(StockLevel),0) As StockLevel, ItemID, BaseItemID FROM Service_Places Inner Join StockedItems ON  Code=StoreID Where StockLevel>=0 And UPPER(Service_Places.Status)='YES' Group By ItemID, BaseItemID
go

