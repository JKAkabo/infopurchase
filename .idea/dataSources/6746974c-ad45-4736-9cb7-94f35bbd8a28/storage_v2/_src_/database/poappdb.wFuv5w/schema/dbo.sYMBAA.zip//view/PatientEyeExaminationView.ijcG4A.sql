CREATE VIEW [dbo].[PatientEyeExaminationView]

AS

SELECT E.ExamID, E.DoctorID, E.ServerTime, E.UserID, M.UnitMeasure, M.ElementOrder, M.Description As VaElement,C.Pat_No,C.OPDNo,E.PatStatus,C.EyeExamsPlans,C.ClinicCode,E.RecordID, 
CASE WHEN M.ResultValueType=1 Then ISNULL((Select TOP 1 X.Description From EyeElementTextValues X Where X.Code=E.VRID And M.ResultValueType=1 And X.TypeCode=M.Code),'') 
ELSE E.VR END AS VR,CASE WHEN M.ResultValueType=1 Then ISNULL((Select TOP 1 X.Description From EyeElementTextValues X Where X.Code=E.VLID And M.ResultValueType=1 And X.TypeCode=M.Code),'') 
ELSE E.VL END AS VL, Surname,MiddleName,LastName,PatientAge,DOB, C.Doctor, C.ConTime, C.DoctorRemarks, Gender, PatientCategory, C.TreatmentPlan,C.ReqDate,C.ConOutCome, C.VFResults,E.VR As RightVA
,E.VL As LeftVA

FROM dbo.PatientEyeExamVA E, Consultations C, PatientInfoView P, EyeExaminationElements M 
Where C.ConID=E.ExamID And C.OPDNo=P.PatientID And C.Pat_No=P.OPDNo And C.Archived='No'
And E.Archived='No' And M.Code=E.VaID And M.TypeID=1
go

