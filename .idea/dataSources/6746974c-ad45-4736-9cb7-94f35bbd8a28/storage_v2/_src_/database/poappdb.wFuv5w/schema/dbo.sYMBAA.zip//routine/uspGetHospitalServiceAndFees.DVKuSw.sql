CREATE PROCEDURE [dbo].[uspGetHospitalServiceAndFees] 

@UserID nvarchar(15)='',@ServicePlace nvarchar(15)='',@ServiceType Tinyint=0
	
AS

DECLARE @serDesc nvarchar(250),@CreditFee numeric(18,4),@CashPrice numeric(18,4),@SexCode Tinyint,@TypeCode Tinyint,@AgeCode Tinyint,@SerAgeCode Tinyint,
        @ClinicCode nvarchar(5),@NHIAFee numeric(18,4),@NGFee numeric(18,4),@SerPlace nvarchar(15),@IsWard nvarchar(3)='No',@IsMorgue nvarchar(5)='No',@SerSexCode Tinyint;

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;

Delete From ServiceFeesReportData Where UserID=@UserID

if @ServicePlace=''
   if @ServiceType=0 
      DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct Service_Places.Code,IsWard, IsMorgue, GenderCode, AgeGroupCode From Service_Places Inner Join ServicePlaceServiceTypes On Service_Places.Code = ServicePlaceServiceTypes.ServicePlaceCode Where [Status]='Yes'

   else
      DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct Service_Places.Code,IsWard, IsMorgue, GenderCode, AgeGroupCode From Service_Places Inner Join ServicePlaceServiceTypes On Service_Places.Code = ServicePlaceServiceTypes.ServicePlaceCode Where SerType=@ServiceType And [Status]='Yes'
   
else
   if @ServiceType=0 
      DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct Service_Places.Code,IsWard, IsMorgue, GenderCode, AgeGroupCode From Service_Places Inner Join ServicePlaceServiceTypes On Service_Places.Code = ServicePlaceServiceTypes.ServicePlaceCode Where Code=@ServicePlace And [Status]='Yes'

   else
      DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct Service_Places.Code,IsWard, IsMorgue, GenderCode, AgeGroupCode From Service_Places Inner Join ServicePlaceServiceTypes On Service_Places.Code = ServicePlaceServiceTypes.ServicePlaceCode Where Code=@ServicePlace And SerType=@ServiceType And [Status]='Yes'
   
--DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct Service_Places.Code,IsWard, IsMorgue, ClinicCode From Service_Places Inner Join (ClinicServicePlaces Inner Join Service_Types On ClinicServicePlaces.ServicePlaceCode = Service_Types.ServicePlaceCode) On Service_Places.Code = ClinicServicePlaces.ServicePlaceCode 
--set @selectionCriteria='DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct Service_Places.Code,IsWard, IsMorgue, ClinicCode From Service_Places Inner Join (ClinicServicePlaces Inner Join Service_Types On ClinicServicePlaces.ServicePlaceCode = Service_Types.ServicePlaceCode) On Service_Places.Code = ClinicServicePlaces.ServicePlaceCode ' + @selectionCriteria + ' Order by Service_Places.Code Asc ' 
--exec (@selectionCriteria) 
OPEN C
FETCH NEXT FROM C INTO @SerPlace, @IsWard, @IsMorgue, @SexCode, @AgeCode;

WHILE @@fetch_status = 0
	BEGIN
	  if @ServiceType=0 
	     DECLARE D CURSOR FAST_FORWARD FOR SELECT Distinct UPPER(ServiceType) As ServiceType, NHISPrice, CreditPrice, CashPrice, NGFee, GenderCode, AgeGroupCode, ServiceTypeCode From Service_Types Where ServicePlaceCode=@SerPlace And Disabled='No' Order by ServiceType Asc 
	  
	  else
	     DECLARE D CURSOR FAST_FORWARD FOR SELECT Distinct UPPER(ServiceType) As ServiceType, NHISPrice, CreditPrice, CashPrice, NGFee, GenderCode, AgeGroupCode, ServiceTypeCode From Service_Types Where ServicePlaceCode=@SerPlace And Disabled='No' And ServiceTypeCode=@ServiceType Order by ServiceType Asc 
	  
	  OPEN D
	  FETCH NEXT FROM D INTO @serDesc, @NHIAFee, @CreditFee, @CashPrice, @NGFee, @SerSexCode, @SerAgeCode,@TypeCode;
	  WHILE @@fetch_status = 0
			BEGIN
			   set @serDesc=dbo.ItemDesc(@serDesc);

			   Insert into ServiceFeesReportData (Description, NHIAFee, CreditFee, CashFee, NGFee, GenderCode,AgeGroupCode,SerPlaceCode,[Type],UserID)values 
			   (@serDesc, @NHIAFee, @CreditFee, @CashPrice, @NGFee, @SexCode,@AgeCode,@serPlace ,@TypeCode, @UserID)

	           FETCH NEXT FROM D INTO @serDesc, @NHIAFee, @CreditFee, @CashPrice, @NGFee, @SexCode, @AgeCode,@TypeCode;

			END

			CLOSE D;

			DEALLOCATE D;
			
			if @IsWard='Yes' And (@ServiceType=0 Or @ServiceType=5 Or @ServiceType=6 Or @ServiceType=7)
			   BEGIN
				  DECLARE D CURSOR FAST_FORWARD FOR SELECT Distinct  UPPER(FeeType) As FeeType, NHISFee, CreditFee, CashFee, NGFee, ServiceTypeCode From WardFees Where WardID=@SerPlace And Disabled='No' Order by FeeType Asc 
				  OPEN D
				  FETCH NEXT FROM D INTO @serDesc, @NHIAFee, @CreditFee, @CashPrice, @NGFee,@TypeCode;
				  WHILE @@fetch_status = 0
						BEGIN
						   set @serDesc=dbo.ItemDesc(@serDesc);

						   Insert into ServiceFeesReportData (Description, NHIAFee, CreditFee, CashFee, NGFee, GenderCode,AgeGroupCode,SerPlaceCode,[Type],UserID)values 
						   (@serDesc, @NHIAFee, @CreditFee, @CashPrice, @NGFee, @SexCode,@AgeCode,@serPlace ,@TypeCode, @UserID)

						   FETCH NEXT FROM D INTO @serDesc, @NHIAFee, @CreditFee, @CashPrice, @NGFee, @TypeCode;

						END

						CLOSE D;

						DEALLOCATE D;
							   
			   END
			
			if @IsMorgue='Yes'  And (@ServiceType=0 Or @ServiceType=5 Or @ServiceType=6 Or @ServiceType=7)
			   BEGIN
				  DECLARE D CURSOR FAST_FORWARD FOR SELECT Distinct UPPER(FeeType) As FeeType, NHISFee, CreditFee, CashFee, NGFee From MortuaryFees Where MorID=@SerPlace And Disabled='No' Order by FeeType Asc 
				  OPEN D
				  FETCH NEXT FROM D INTO @serDesc, @NHIAFee, @CreditFee, @CashPrice, @NGFee;
				  WHILE @@fetch_status = 0
						BEGIN
						   set @serDesc=dbo.ItemDesc(@serDesc);
						   
                           set @TypeCode=10
                           
						   Insert into ServiceFeesReportData (Description, NHIAFee, CreditFee, CashFee, NGFee, GenderCode,AgeGroupCode,SerPlaceCode,[Type],UserID)values 
						   (@serDesc, @NHIAFee, @CreditFee, @CashPrice, @NGFee, @SexCode,@AgeCode,@serPlace ,@TypeCode, @UserID)

						   FETCH NEXT FROM D INTO @serDesc, @NHIAFee, @CreditFee, @CashPrice, @NGFee;

						END

						CLOSE D;

						DEALLOCATE D;
							   
			   END
								
	  FETCH NEXT FROM C INTO @SerPlace, @IsWard, @IsMorgue, @SerSexCode, @SerAgeCode;
	       
	END    
                      
    CLOSE C;

	DEALLOCATE C;		  

END
go

