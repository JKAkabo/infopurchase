
CREATE VIEW [dbo].[ItemsView]

AS

SELECT  I.Description, ItemID, IssueUnitCode, I.IssueUnitQuantity, U.UOM, ItemClassCode,ItemTypeCode,PresentationCode, ManufacturerCode,OrderID,
GenderCode,AgeGroupCode,I.PatientType,I.DefaultMethodCode,I.AllowCoPay,I.MaxPresQty,MinPresQty,I.NHIS,NHISCode,I.PresUnitQuantity,I.DeterminePresQty,
I.PrescriptionQty,I.PresLevel,I.PresUnitCode,I.Sharing,I.StockType,I.ItemNo,I.PresQuanityPerIssueUnit,I.ExDescription,U.Disabled, Expirable,AveUnitCost,
T.Description As ItemTyppe,C.Description As ItemClass, M.Description As ItemManufacturer, P.Description As ItemPresentation, R.Description As DrugRoute,
G.Description As Gender, V.Description As PatientStatus, A.Description As AgeGroup, S.Description As StockTypeDescription,W.Description As OrderStore
FROM Items I, ItemsUOMView U, ItemPresentations P, ItemTypes T, ItemClasses C, ItemManufacturers M, DrugRoutes R,GenderGroupsView G,ServicePlacesView W, 
PatientStatusView V, AgeGroups A, ItemStockType S, NHIAPrescriptionLevels N, PrescriptionSpecificationTypes F Where W.Code=OrderID And
U.UnitCode=IssueUnitCode and U.IsActive='Yes' And  U.TypeCode=1 and ItemTypeCode=T.Code And ItemClassCode=C.Code And ManufacturerCode=M.Code and
R.Code=DefaultMethodCode and S.Code=StockType and V.Code=PatientType and G.Code=GenderCode and A.Code=AgeGroupCode and N.ID=PresLevel and F.Code=I.PresSpecType
and P.Code=I.PresentationCode


go

