CREATE PROCEDURE [dbo].[uspUpdateEpisodeDiagnosesServicePlaces] 
	
AS

DECLARE @OPDNo nvarchar(15),@SerPlace nvarchar(15),@EpisodeID numeric(18,0),@DisCode nvarchar(15)

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  

  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct A.OPDNo, E.EpisodeID, WardID, DisCode From Admissions A, AdmissionCauses C, Episode E 
  Where A.OPDNo=C.OPDNo And A.RecordID=C.AdmRecordID And A.Archived='No' And C.Cancelled='No' And A.DisDate Is Not Null And A.DisDate<>'' And 
  A.OPDNo=E.OPDNo And A.EpisodeID=E.EpisodeID And E.ServiceType=2 And E.StatusCode=3 And E.Service_Code=C.DisCode And E.EndEpisode Is Not Null Order by E.EpisodeID
            
  OPEN C
  
  FETCH NEXT FROM C INTO @OPDNo, @EpisodeID, @SerPlace, @DisCode       

  WHILE @@fetch_status = 0
    BEGIN
   
   update NHIAEpisodeServices Set ServicePlaceID=@SerPlace Where EpisodeID=@EpisodeID and OPDNo=@OPDNo And ServiceCode=@DisCode
   
  FETCH NEXT FROM C INTO @OPDNo, @EpisodeID,  @SerPlace, @DisCode         

	END

	CLOSE C;

	DEALLOCATE C;
	
END
go

