CREATE PROCEDURE [dbo].[uspUpdateServiceRequestsFacAttType] 
	
AS

DECLARE @RegStatus tinyint, @OPDNo nvarchar(15), @ReqDate datetime,@attID numeric(18,0);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;

  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct AttRecordID, P.OPDNo, ReqDate, CASE WHEN RegStatus='NEW' THEN 1 ELSE 2 END AS RegStatus From PatientsInfo P, Service_Requests S where P.OPDNo=S.OPDNo And RegDate=ReqDate And archived='No' and FacAttType=0  Order By ReqDate Desc

  
  OPEN C
  
  FETCH NEXT FROM C INTO @attID, @OPDNo, @ReqDate, @RegStatus;

  WHILE @@fetch_status = 0
    BEGIN
           
     Update Service_Requests Set FacAttType=@RegStatus Where OPDNo=@OPDNo and ReqDate=@ReqDate 
     
     Update Prescriptions Set FacAttType=@RegStatus Where OPDNo=@OPDNo and ReqDate=@ReqDate
     
     Update PatientDailyAttendance Set FacAttType=@RegStatus Where OPDNo=@OPDNo and CONVERT(date,servertime)=@ReqDate or AttRecordID=@attID
     
          
     FETCH NEXT FROM C INTO @attID, @OPDNo, @ReqDate, @RegStatus;

	END

	CLOSE C;

	DEALLOCATE C;


  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct AttRecordID, P.OPDNo, ReqDate, CASE WHEN RegStatus='NEW' THEN 1 ELSE 2 END AS RegStatus From PatientsInfo P, Service_Requests S where P.OPDNo=S.OPDNo And RegDate<ReqDate And archived='No' and FacAttType=0 and 
  IsNull((Select Count(OPDNo) From Service_Requests Where archived='No' and S.ReqDate>RegDate and S.OPDNo=OPDNo),0)<=0  Order By ReqDate Desc

  
  OPEN C
  
  FETCH NEXT FROM C INTO @attID, @OPDNo, @ReqDate, @RegStatus;

  WHILE @@fetch_status = 0
    BEGIN
           
     Update Service_Requests Set FacAttType=@RegStatus Where OPDNo=@OPDNo and ReqDate=@ReqDate 
     
     Update Prescriptions Set FacAttType=@RegStatus Where OPDNo=@OPDNo and ReqDate=@ReqDate
     
     Update PatientDailyAttendance Set FacAttType=@RegStatus Where OPDNo=@OPDNo and CONVERT(date,servertime)=@ReqDate or AttRecordID=@attID
          
     FETCH NEXT FROM C INTO @attID, @OPDNo, @ReqDate, @RegStatus;

	END

	CLOSE C;

	DEALLOCATE C;

 Update Service_Requests Set FacAttType=2 Where FacAttType=0 
 
 Update Prescriptions Set FacAttType=2 Where FacAttType=0 

 Update PatientDailyAttendance Set FacAttType=2 Where FacAttType=0 
	
END
go

