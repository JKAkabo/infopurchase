CREATE VIEW [dbo].[RequisitionLinesApprovedPendingIssueView]

AS

Select R.OrderType, D.*, 0 As CashPrice, 0 As CreditPrice, 0 As NGPrice, 0 As NHISPrice, I.Description, ItemTypeCode, Expirable,P.ApprovedQty,R.OrderStoreID,R.SupplierID,R.OrderDate,R.ProformaNo,R.InvoiceNo, 
I.AveUnitCost From Items I, RequisitionApprovals A, OrderLines D, RequisitionApprovalLines P, Orders R  Where ((IssuedOrderQty<OrderQty)) and ((IssuedOrderQty<P.ApprovedQty)) 
and I.ItemID = D.ItemID and A.ApproveID =P.ApproveID And D.OrderLineID = P.OrderLineID and R.OrderNo=D.OrderID and R.ApprovalStatus=R.ApprovalLevel and R.OrderNo=A.RequestID And OrderLineStatus IN (1,2,13)
and A.ApprovalNo=R.ApprovalLevel and R.Archived='No' and A.Archived='No' and D.Archived='No' and P.Archived='No' and R.Archived='No' and R.OrderType=1
go

