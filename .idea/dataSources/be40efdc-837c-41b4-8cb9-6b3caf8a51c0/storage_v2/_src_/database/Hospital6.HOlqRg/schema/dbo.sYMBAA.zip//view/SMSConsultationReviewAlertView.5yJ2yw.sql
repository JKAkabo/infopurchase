CREATE VIEW [dbo].[SMSConsultationReviewAlertView]

AS

SELECT ReviewDate, Surname, LastName, Consultations.OPDNo, CellPhoneNo, ExpiryAlert, ReviewTime, ConsultationReviews.Received, Service_Points.Description AS Clinic, 
Users.UserID AS Doctor, Consultations.ConID, Title FROM Service_Points INNER JOIN (SMSPatientInfoView INNER JOIN (Users INNER JOIN (Consultations INNER JOIN ConsultationReviews ON Consultations.ConID = ConsultationReviews.ConID) ON Users.UserNo =Consultations.Doctor )
ON SMSPatientInfoView.OPDNo = Consultations.OPDNo) ON Service_Points.SPCode =ClinicCode WHERE CellPhoneNo <>'' AND CellPhoneNo IS NOT NULL And Consultations.Archived='No'
go

