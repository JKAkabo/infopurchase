CREATE VIEW [dbo].[PrivateInsuredOutPatientsAttendanceView]

AS

SELECT Distinct A.ClaimPrinted,3 AS StatusCode, AdmRecID As RecordID,A.ClaimDataProcessed, Convert(DateTime,A.ClaimPrintTime) As ClaimPrintDate, A.ClaimPrintedBy, S.DirectID, S.BillCategoryCode, S.SponsorNo, A.OPDNo, S.ClinicCode, AdmDate, DisDate, A.AdmAge As AttAge,A.Pat_No,S.PmtTypeCode, AttDate, S.episodeID From AdmissionDischrgesView A Inner Join ServicesRevenueView S On (A.OPDNo=S.OPDNo And AttDate>=AdmDate And AttDate<=DisDate) Where S.BillCategoryCode NOT IN (1,0) and S.SponsorNo<>'' And S.PmtTypeCode IN (2,3)

Union All

SELECT Distinct Daily_Attendance.ClaimPrinted,2 As StatusCode,Daily_Attendance.RecordID,Daily_Attendance.ClaimDataProcessed,Daily_Attendance.ClaimPrintDate, Daily_Attendance.ClaimPrintedBy, ServicesRevenueView.DirectID, ServicesRevenueView.BillCategoryCode,ServicesRevenueView.SponsorNo,ServicesRevenueView.OPDNo,ServicesRevenueView.ClinicCode, ReqDate,ReqDate, Daily_Attendance.AttAge,ServicesRevenueView.Pat_No,PmtTypeCode,ReqDate, ServicesRevenueView.episodeID FROM Daily_Attendance inner join ServicesRevenueView On 
(Daily_Attendance.OPDNo=ServicesRevenueView.OPDNo and Daily_Attendance.AttDate=ServicesRevenueView.AttDate) Where Daily_Attendance.StatusCode=2 and ServicesRevenueView.StatusCode=2 and BillCategoryCode NOT IN (1,0) And ServicesRevenueView.SponsorNo<>'' And PmtTypeCode IN (2,3) And ((ServiceTypeCode=5 and attType<>2) OR (AttServiceID<>0 and attType<>2) OR (ServiceTypeCode IN (11,12,13,14) And attType=2)) and Daily_Attendance.RecordID NOT IN (Select D.RecordID FROM 
Daily_Attendance D, AdmissionDischrgesView A, ServicesRevenueView S Where D.OPDNo= A.OPDNo And D.OPDNo= S.OPDNo And S.AttDate>=AdmDate And S.AttDate<=DisDate And D.AttDate=S.AttDate)
go

