CREATE VIEW [dbo].[DiscountTypesView]

AS

SELECT  Description, Code FROM dbo.DiscountTypes

Union

SELECT  'N/A' As Description, 0 As Code FROM dbo.Hosp_Info
go

