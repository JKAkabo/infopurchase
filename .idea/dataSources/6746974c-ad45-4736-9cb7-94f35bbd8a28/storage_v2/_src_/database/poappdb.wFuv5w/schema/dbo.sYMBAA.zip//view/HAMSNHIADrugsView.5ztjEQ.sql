CREATE VIEW [dbo].[HAMSNHIADrugsView]

AS

Select Upper(I.Description) as Description, Upper(U.Description) AS UOM,ItemID, 
IsNull((Select TOP 1 N.NHISCode From NHIADrugsSetup N Where I.NHISCode=N.NHISCODE),'') As NHISCode, 
IsNull((Select TOP 1 Upper(N.Description) From NHIADrugsSetup N Where I.NHISCode=N.NHISCODE),'') As NHIADescription 
From UnitMeasuresView U, Items I Where U.Code=I.IssueUnitCode and I.Disabled='No' and U.IsActive='Yes' and ItemTypeCode=1  And I.NHIS='Yes'
go

