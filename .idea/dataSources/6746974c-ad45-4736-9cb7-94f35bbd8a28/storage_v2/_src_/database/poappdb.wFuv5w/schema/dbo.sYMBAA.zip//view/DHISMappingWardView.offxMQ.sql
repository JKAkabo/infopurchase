

CREATE VIEW [dbo].[DHISMappingWardView]

AS

SELECT  Description, RecordID As ID , DHISMappingWard.WardMappingCode AS Code, GenderCode,AgeGroupCode, Disabled FROM dbo.DHISMappingWard Where Disabled='No'

Union

SELECT  '' As Description, 0 As ID, '' As Code,1 As GenderCode, 1 as AgeGroupCode, 'No' As  Disabled FROM dbo.Hosp_Info


go

