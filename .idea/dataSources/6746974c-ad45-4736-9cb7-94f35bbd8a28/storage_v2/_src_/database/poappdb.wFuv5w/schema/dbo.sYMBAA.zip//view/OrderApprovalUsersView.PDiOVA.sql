create VIEW [dbo].[OrderApprovalUsersView]

AS

SELECT LEFT(Users.UserID,100) As UserID, UserNo, UserTitle, UserSign, ApproveID, OrderType, OrderNo, ApprovedDate, ApprovalLevel FROM dbo.Users Inner Join OrderApprovalSignatures On UserNo=UserCode
go

