CREATE VIEW [dbo].[NHIATransactionsView]

AS

--Diagnoses and Investigative Services
SELECT
 
S.ServiceCode, S.ServiceFee * S.RequiredQty As TransAmt, E.EndEpisode As TransDate,
P.SponsorTypeCode,S.ServicePlaceID,P.SponsorName,S.ServiceTypeCode,N.Description As Specialty,
IsmainMDC,N.Code As SpecialtyCode, E.* 

FROM 

Sponsors P, Episode E, NHIAEpisodeServices S, NHIAMDCS N

WHERE 

S.ServiceTypeCode IN (2,11,12,13,14) And E.EpisodeID=S.EpisodeID And P.SponsorNo =E.SponsorNo And P.SponsorTypeCode=2 And
E.EpisodeID=S.EpisodeID And E.OPDNo=S.OPDNo And P.SponsorNo=E.SponsorNo And E.Archived='No' and NoOfVisit>0 And S.ServiceFee>0  
and  UPPER(S.RequestType)='INTERNAL' And E.IsDuplicate='No' And E.ClaimDataProcessed='Yes' And E.EpisodeSpecialityCode<>'' 
And ((E.EpisodePrinted='Yes' OR (E.EclaimProcessed='Yes' And E.EpisodeAllBatchNo<>'')) And (E.EpisodeBatchNo<>'' And E.EpisodeBatchNo<>'None')) 
And ((AttType<>2 And E.ClaimGDRGCode<>'' And E.ServiceType IN (2) And E.Service_Code=S.ServiceCode) OR ((AttType=2 OR E.EpisodePmtType=3) And DiagnosticFee>0 And S.ServiceTypeCode IN (11,12,13,14))) 
And N.Code=E.EpisodeSpecialityCode

UNION ALL

--Consultation, Surgery, Detention and Referral Services
SELECT
 
E.Service_Code As ServiceCode, E.ServiceFee As TransAmt, E.EndEpisode As TransDate,
P.SponsorTypeCode,R.ServicePlaceCode,P.SponsorName,R.ServiceTypeCode,N.Description As Specialty,
IsmainMDC,N.Code As SpecialtyCode,E.*

FROM 

Sponsors P, Episode E, Service_Types R, NHIAMDCS N

WHERE 

E.Service_Code=R.ServiceCode And P.SponsorNo=E.SponsorNo And E.Archived='No' and NoOfVisit>0 And E.ServiceFee>0 And E.ServiceType IN (3,5,16,17)
and E.IsDuplicate='No' And E.ClaimDataProcessed='Yes' And E.EpisodeSpecialityCode<>''  And N.Code=E.EpisodeSpecialityCode
And ((E.EpisodePrinted='Yes' OR (E.EclaimProcessed='Yes' And E.EpisodeAllBatchNo<>'')) And (E.EpisodeBatchNo<>'' And E.EpisodeBatchNo<>'None')) 
And AttType<>2 And E.ClaimGDRGCode<>'' And E.ServiceType IN (3,5,16,17) And E.Service_Code=R.ServiceCode And P.SponsorNo =E.SponsorNo And P.SponsorTypeCode=2

UNION ALL

--Drugs
SELECT
 
S.ServiceCode As ServiceCode, S.ServiceFee * S.RequiredQty As TransAmt, E.EndEpisode As TransDate,
P.SponsorTypeCode,S.ServicePlaceID,P.SponsorName,S.ServiceTypeCode,N.Description As Specialty,
IsmainMDC,N.Code As SpecialtyCode,E.* 

FROM 

Sponsors P, Episode E, NHIAEpisodeServices S,Items R,NHIAMDCS N

WHERE 

R.ItemID=S.ServiceCode And E.EpisodeID=S.EpisodeID And P.SponsorNo=E.SponsorNo And E.Archived='No' and NoOfVisit>0  
and  UPPER(S.RequestType)='INTERNAL' And E.IsDuplicate='No' And E.ClaimDataProcessed='Yes' And E.EpisodeSpecialityCode<>'' 
And ((E.EpisodePrinted='Yes' OR (E.EclaimProcessed='Yes' And E.EpisodeAllBatchNo<>'')) And (E.EpisodeBatchNo<>'' And 
E.EpisodeBatchNo<>'None')) and E.EpisodeSpecialityCode IN (Select Code From NHIAMDCS) And AttType<>2 And E.ClaimGDRGCode<>''
And N.Code=E.EpisodeSpecialityCode And R.ItemID=S.ServiceCode and S.ServiceTypeCode=1 And E.EpisodeID=S.EpisodeID And P.SponsorNo =E.SponsorNo
And P.SponsorTypeCode=2 And S.ServiceFee>0
go

