CREATE VIEW [dbo].[SponsoredPatientsView]
AS
SELECT SponsoredPatients.SponsorNo,SponsoredPatients.UnNo As SerialNo,SponsoredPatients.IDNo As MemberID,SponsoredPatients.EmpNo,SponsoredPatients.DeptID,
SponsoredPatients.PatCategoryCode  As PatCat, Archived, OPDNo, SponsorTypeCode  FROM dbo.SponsoredPatients, Sponsors Where Sponsors.SponsorNo=SponsoredPatients.SponsorNo  And Archived='No'

Union

Select '' As SponsorNo, '' as SerialNo, '' As MemberID ,'' As EmpNo, '' as DeptID, 1 as PatCat, 'No' As Archived, OPDNo, 1 As SponsorTypeCode from PatientsInfo Where OPDNo NOT IN (
 Select OPDNo from SponsoredPatients where Archived='No')
go

