CREATE VIEW [dbo].[SMSDailyAttendanceAlertView]
AS
SELECT DISTINCT 
                      Daily_Attendance.AttDate, Daily_Attendance.OPDNo, SMSPatientInfoView.Surname, SMSPatientInfoView.LastName, SMSPatientInfoView.GenderCode, 
                      Daily_Attendance.AttAge, SMSPatientInfoView.CellPhoneNo, SMSPatientInfoView.ExpiryAlert, 
                      SMSPatientInfoView.Title FROM Daily_Attendance INNER JOIN SMSPatientInfoView ON Daily_Attendance.OPDNo = SMSPatientInfoView.OPDNo
WHERE SMSPatientInfoView.CellPhoneNo IS NOT NULL AND Rtrim(Ltrim(SMSPatientInfoView.CellPhoneNo)) <> ''
go

