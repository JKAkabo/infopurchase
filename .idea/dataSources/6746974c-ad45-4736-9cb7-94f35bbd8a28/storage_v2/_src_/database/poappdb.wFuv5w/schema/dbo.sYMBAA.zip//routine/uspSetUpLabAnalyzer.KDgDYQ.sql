
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[uspSetUpLabAnalyzer]
	-- Add the parameters for the stored procedure here
	@Desc nvarchar(250), @TypeID tinyint,@ManfCode tinyint, @ConnectID tinyint
	
	
AS

if LTRIM(RTRIM(@Desc))='' or @TypeID=0
   return
   
Select Code From LabAnalyzers where Description=LTRIM(RTRIM(@Desc))

if @@ROWCOUNT>0     
   return
   
BEGIN

Declare @AnalyID numeric(18,0), @elementID numeric(18,0),@ParamID numeric(18,0),@ParamValue NVarchar(250)
	
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


Insert Into LabAnalyzers(Description,Model,TypeCode,UserID,ServerDate,ManufacCode,ConnectCode,Code,IsActive,EnforceElementsOrder)
   values( @Desc,'',@TypeID,'00001',GetDate(),@ManfCode,@ConnectID,'','Yes','No')
   

   if @@ROWCOUNT>0
     Select @AnalyID=@@Identity From LabAnalyzers
   
   else
      return
      
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct ElementID From TestElementsView Where IsActive='Yes' And CatID=@TypeID Order By ElementID
  
  OPEN C
  
  FETCH NEXT FROM C INTO @elementID;

  WHILE @@fetch_status = 0
  
    BEGIN
       
      Insert Into LabAnalyzerElements (AnalyzerID, CalculatedFormula, IsActive, UserID, ServerTime, Code,MappedElement,OrderNo)       
      
      values(@AnalyID,'','Yes','00001',GETDATE(),'',@elementID,0)
      
       FETCH NEXT FROM C INTO @elementID;

	    END

	CLOSE C;

	DEALLOCATE C;
	
	if @ConnectID=0 
	   return
	   
	 DECLARE C CURSOR FAST_FORWARD FOR Select Distinct DefaultValue, Code From LabAnalyzerConnectivityParametersSetup Where IsActive='Yes' and IsOptional='No' And TypeID=@ConnectID  and DefaultValue<>'' Order By Code
  
  OPEN C
  
  FETCH NEXT FROM C INTO @ParamValue,@ParamID;

  WHILE @@fetch_status = 0
  
    BEGIN
       
      Insert Into LabAnalyzerConnectorConfigSettings (AnalyzerCode, ConnectorCode, ParamCode, ConfigValue)       
      
      values(@AnalyID,@ConnectID,@ParamID,@ParamValue)
      
       FETCH NEXT FROM C INTO @ParamValue,@ParamID;

	    END

	CLOSE C;

	DEALLOCATE C;
          
END

go

