-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[upsGetItemStockLevel] 
	-- Add the parameters for the stored procedure here

	@ItemID nvarchar(15) ,@itemStore nvarchar(15)='',@itemBatchNo nvarchar(25) ='',@ServerDate datetime='',
	@expiryDateMonth int =0,@expiryDateYear int =0, @UnitType int=0,@UnitCode int=0, @PackQty int=0,@Expirable nvarchar(3) ='No'
	
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
 
 Declare @SelectionStrg Nvarchar(4000),@serverTime nvarchar(50)
 
 --Select @serverTime=convert(Date,GetDate())
  
 Set @SelectionStrg='Select IsNull(Sum(StockLevel),0) As StockLevel From Items Inner Join StockedItems On Items.ItemID=StockedItems.ItemID Where StockedItems.ItemID =''' + @ItemID + ''' And (((IsDate(ExpiryDate)=1 And Items.Expirable <>''' + @Expirable + ''') And ((Year(ExpiryDate)> Year(''' + GetDate() + ''')) OR (Year(ExpiryDate)= Year(''' + GetDate() + ''') And Month(ExpiryDate)>= Month(''' + GetDate() + ''')))) Or (IsDate(ExpiryDate)=0 OR Items.Expirable =''' + @Expirable + '''))'

 if @itemStore<>''
    Set @SelectionStrg= @SelectionStrg  + ' And StockedItems.StoreID=''' + @itemStore + ''''
  
 if @itemBatchNo<>''
    Set @SelectionStrg= @SelectionStrg  + ' And StockedItems.BatchNo=''' + @itemBatchNo + ''''
    
 if @expiryDateMonth<>0 and @expiryDateYear<>0
    Set @SelectionStrg= @SelectionStrg  + ' And Year(ExpiryDate)=' + str(@expiryDateYear) + ' and Month(ExpiryDate)=' + str(@expiryDateMonth)
 
 if @UnitType<>0
    Set @SelectionStrg= @SelectionStrg  + ' And StockedTypeID=' + str(@UnitType)
 
 if @UnitCode<>0
    Set @SelectionStrg= @SelectionStrg  + ' And StockedUnitID=' + str(@UnitCode)

 if @PackQty<>0
    Set @SelectionStrg= @SelectionStrg  + ' And StockedItems.NoPerBaseUnit=' + str(@PackQty)

 --Set @SelectionStrg='Select IsNull(Sum(StockLevel),0) As StockLevel From StockedItems Where StockedUnitID=' + str(@UnitCode) + ' And  Year(ExpiryDate)=' + str(@expiryDateYear) + ' and Month(ExpiryDate)=' + str(@expiryDateMonth) + ' And StoreID=''' + @itemStore + ''' And ItemID =''' + @ItemID + ''' And ((IsDate(ExpiryDate)=1 And ((Year(ExpiryDate)> Year(''' + @serverTime + ''')) OR (Year(ExpiryDate)= Year(''' + @serverTime + ''') And Month(ExpiryDate)>= Month(''' + @serverTime + ''')))) Or IsDate(ExpiryDate)=0)'
 
 Set @SelectionStrg= @SelectionStrg
 
 Exec (@SelectionStrg)
 
-- if @itemStore=''
--    if @itemBatchNo=''
--       Select IsNull(Sum(StockLevel),0) As StockLevel From StockedItems Where ItemID =@ItemID  And (( (not(ExpiryDate Is Null or ExpiryDate='') And ((Year(ExpiryDate)>Year(@ServerDate)) OR (Year(ExpiryDate)=Year(@ServerDate) And Month(ExpiryDate)>=Month(@ServerDate))))) Or (ExpiryDate Is Null or ExpiryDate=''))
    
--    else
--       if @expiryDateMonth=0 or @expiryDateYear=0
--          Select IsNull(Sum(StockLevel),0) As StockLevel From StockedItems Where ItemID =@ItemID And BatchNo =@itemBatchNo And (( (not(ExpiryDate Is Null or ExpiryDate='') And ((Year(ExpiryDate)>Year(@ServerDate)) OR (Year(ExpiryDate)=Year(@ServerDate) And Month(ExpiryDate)>=Month(@ServerDate))))) Or (ExpiryDate Is Null or ExpiryDate=''))
       
--       else
--          Select IsNull(Sum(StockLevel),0) As StockLevel From StockedItems Where ItemID =@ItemID And BatchNo =@itemBatchNo And Year(ExpiryDate)=@expiryDateYear and Month(ExpiryDate)=@expiryDateMonth And (( (not(ExpiryDate Is Null or ExpiryDate='') And ((Year(ExpiryDate)>Year(@ServerDate)) OR (Year(ExpiryDate)=Year(@ServerDate) And Month(ExpiryDate)>=Month(@ServerDate))))) Or (ExpiryDate Is Null or ExpiryDate=''))
       
--else
--    if @itemBatchNo=''
--       Select IsNull(Sum(StockLevel),0) As StockLevel From StockedItems Where ItemID =@ItemID And StoreID =@itemStore And (( (not(ExpiryDate Is Null or ExpiryDate='') And ((Year(ExpiryDate)>Year(@ServerDate)) OR (Year(ExpiryDate)=Year(@ServerDate) And Month(ExpiryDate)>=Month(@ServerDate))))) Or (ExpiryDate Is Null or ExpiryDate=''))
    
--    else
--       if @expiryDateMonth<>0 or @expiryDateYear<>0
--          Select IsNull(Sum(StockLevel),0) As StockLevel From StockedItems Where StoreID =@itemStore And ItemID =@ItemID And BatchNo =@itemBatchNo And Year(ExpiryDate)=@expiryDateYear and Month(ExpiryDate)=@expiryDateMonth And (( (not(ExpiryDate Is Null or ExpiryDate='') And ((Year(ExpiryDate)>Year(@ServerDate)) OR (Year(ExpiryDate)=Year(@ServerDate) And Month(ExpiryDate)>=Month(@ServerDate))))) Or (ExpiryDate Is Null or ExpiryDate=''))
       
--       else 
--          Select IsNull(Sum(StockLevel),0) As StockLevel From StockedItems Where ItemID =@ItemID And StoreID =@itemStore And BatchNo =@itemBatchNo And (( (not(ExpiryDate Is Null or ExpiryDate='') And ((Year(ExpiryDate)>Year(@ServerDate)) OR (Year(ExpiryDate)=Year(@ServerDate) And Month(ExpiryDate)>=Month(@ServerDate))))) Or (ExpiryDate Is Null or ExpiryDate=''))

END
go

