
CREATE VIEW [dbo].[ItemsConsumptionParametersView]

AS

Select TOP 1 ItemsConsumpFreq, ItemsConsumpFreqValue, ItemsConsumpPeriod, ItemsConsumpPeriodValue,
(Select TOP 1 VbConvertionFactor From BillingFrequencies Where Code=ItemsConsumpFreq) As FreqType,
(Select TOP 1 VbConvertionFactor From BillingFrequencies Where Code=ItemsConsumpPeriod) As PeriodType,   
DrugConsumption,convert(date,GETDATE()) as EndDate, case when ItemsConsumpPeriod=1 then convert(date,dateadd(D,-ItemsConsumpPeriodValue,getdate())) 
when ItemsConsumpPeriod=2 then convert(date,dateadd(WW,-ItemsConsumpPeriodValue,getdate()))
when ItemsConsumpPeriod=3 then convert(date,dateadd(M,-ItemsConsumpPeriodValue,getdate()))
when ItemsConsumpPeriod=4 then convert(date,dateadd(Q,-ItemsConsumpPeriodValue,getdate()))
when ItemsConsumpPeriod=5 then convert(date,dateadd(YYYY,-ItemsConsumpPeriodValue,getdate())) end as StartDate
From OrdersConfigurationSetup


go

