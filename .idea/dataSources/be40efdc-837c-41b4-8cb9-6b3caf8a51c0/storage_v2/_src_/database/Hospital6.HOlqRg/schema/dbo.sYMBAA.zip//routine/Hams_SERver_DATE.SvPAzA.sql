CREATE PROCEDURE [dbo].[Hams_SERver_DATE] AS

select left(convert(varchar, sysdatetime())+ltrim(cap_id),19) from hosp_Info
go

