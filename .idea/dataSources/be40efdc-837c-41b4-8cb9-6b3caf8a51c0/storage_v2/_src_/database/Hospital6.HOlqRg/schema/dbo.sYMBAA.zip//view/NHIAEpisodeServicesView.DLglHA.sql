
CREATE VIEW [dbo].[NHIAEpisodeServicesView]

AS

SELECT Distinct Prescriptions.RecordID, Left(Description,100) As ServiceDescription,Dosage As Frequency,Prescriptions.PresDays As Duration, Prescriptions.Units As Dosage, ITEMS.ItemID As ServiceCode, 1 As ServiceTypeCode, PmtTypeCode, 'MEDICINES' As ServicePlace , Prescriptions.UnitPrice AS UnitFee, QtyPrescribed AS ServiceQty, PresDate As ReqDate, Items.NHISCode As GDRDCode, '' As ICDCOde, EpisodeID, PresType As RequestType, OPDNo, 'No' As ServiceIssued, StatusCode As PatStatus, ActiveEpiID, '' As IsPrincipal, 'No' As IsRefill, ReqDate As ServiceDate, 1 As DrugServiceType, 0 As DiagServiceType FROM ITEMS inner Join (NHIAEpisodesView Inner Join Prescriptions On EpiID=EpisodeID And PatID=Prescriptions.OPDNo) on Items.ItemID=DrugCode Where ITEMS.ItemID<>'' and Archived='No' and Refunded='No' and EpisodeID<>0 and QtyGiven=0 and ReturnedQty=0 and PmtTypeCode<>1 and SponsorNo<>''

UNION

SELECT Distinct DispensedPrescriptions.RecordID, Left(Description,100)  As ServiceDescription,Frequency, DispensedPrescriptions.Duration, Prescriptions.Units As Dosage, ITEMS.ItemID As ServiceCode, 1 As ServiceTypeCode, PmtTypeCode, 'MEDICINES' As ServicePlace , Prescriptions.UnitPrice AS UnitFee, DispensedPrescriptions.DispensedQty-DispensedPrescriptions.ReturnedQty As ServiceQty, PresDate As ReqDate, Items.NHISCode As GDRDCode, '' As ICDCOde, EpisodeID, PresType As RequestType, OPDNo, 'Yes' As ServiceIssued, Prescriptions.StatusCode As PatStatus, ActiveEpiID, '' As IsPrincipal, IsRefill, DispensedPrescriptions.DispensedDate As ServiceDate, 1 As DrugServiceType, 0 As DiagServiceType  FROM ITEMS inner Join (NHIAEpisodesView Inner Join (Prescriptions Inner Join DispensedPrescriptions on PresID=Prescriptions.RecordID) On (EpiID=EpisodeID And PatID=Prescriptions.OPDNo)) on Items.ItemID=DrugCode Where ITEMS.ItemID<>'' and Archived='No' and Refunded='No' and EpisodeID<>0 and QtyGiven>0 and PmtTypeCode<>1 and SponsorNo<>''

Union

SELECT Distinct Service_Requests.RecordID, Left(SERVICETYPE,100) As ServiceDescription, '' As Frequency, 0 As Duration, 0 As Dosage, Service_Requests.ServiceCode, ServiceTypeCode, PmtTypeCode, 'PROCEDURE(S)' As ServicePlace, Service_Fee as UnitFee, ServiceQty, ReqDate, GDRG_Code As GDRDCode, '' As ICDCOde, EpisodeID, RequestType, OPDNo, Issued As ServiceIssued, Service_Requests.StatusCode As PatStatus, ActiveEpiID, '' As IsPrincipal, 'No' As IsRefill, ServiceDate, -1 As DrugServiceType, -1 As DiagServiceType   FROM Service_Types Inner Join (NHIAEpisodesView Inner Join Service_Requests On (EpiID=EpisodeID And PatID=OPDNo)) On Service_Types.ServiceCode=Service_Requests.ServiceCode Where EpisodeID<>0 and ServiceTypeCode=3 and Archived='No' and Refunded='No' and PmtTypeCode<>1 and SponsorNo<>''

union

SELECT Distinct Service_Requests.RecordID, Left(SERVICETYPE,100) As ServiceDescription, '' As Frequency, 0 As Duration, 0 As Dosage, Service_Requests.ServiceCode, ServiceTypeCode, PmtTypeCode, 'INVESTIGATIONS' As ServicePlace, Service_Fee as UnitFee, ServiceQty, ReqDate, GDRG_Code As GDRDCode, '' As ICDCOde, EpisodeID, RequestType, OPDNo, Issued As ServiceIssued, Service_Requests.StatusCode As PatStatus, ActiveEpiID, '' As IsPrincipal, 'No' As IsRefill, ServiceDate, -1 As DrugServiceType, -1 As DiagServiceType   FROM Service_Types Inner Join (NHIAEpisodesView Inner Join Service_Requests On (EpiID=EpisodeID And PatID=OPDNo)) On Service_Types.ServiceCode=Service_Requests.ServiceCode Where EpisodeID<>0 and ServiceTypeCode In (11,12,13,14) and Archived='No' and Refunded='No' and PmtTypeCode<>1 and SponsorNo<>''

Union

SELECT Distinct ConsultationDiagnoses.ConID, Left(Diseases.DisDescription,100) As ServiceDescription, '' As Frequency, 0 As Duration, 0 As Dosage, ConsultationDiagnoses.DisCode As ServiceCode, 2 As ServiceTypeCode, PmtTypeCode, 'DIAGNOSIS(ES)' As ServicePlace, DiaFee as UnitFee, 1 As ServiceQty, Consultations.ReqDate, ConsultationDiagnoses.GDRGCode As GDRDCode, Diseases.ICDCode As ICDCOde, EpisodeID, 'INTERNAL' As RequestType, Consultations.OPDNo, 'Yes' As ServiceIssued, 2 As PatStatus, ActiveEpiID, Principal As IsPrincipal, 'No' As IsRefill, Consultations.ConDate As ServiceDate, 0 As DrugServiceType, 1 As DiagServiceType   FROM Diseases Inner Join (NHIAEpisodesView Inner Join (Consultations Inner Join ConsultationDiagnoses On  Consultations.ConID=ConsultationDiagnoses.ConID) On (EpiID=EpisodeID And PatID=Consultations.OPDNo)) On Diseases.DisCode=ConsultationDiagnoses.DisCode Where EpisodeID<>0 and Archived='No' and Consultations.StatusCode=2 and Cancelled='No'

Union

SELECT Distinct AdmissionCauses.RecordID, Left(Diseases.DisDescription,100) As ServiceDescription, '' As Frequency, 0 As Duration, 0 As Dosage, AdmissionCauses.DisCode As ServiceCode, 2 As ServiceTypeCode, PmtTypeCode, 'DIAGNOSIS(ES)' As ServicePlace, DiaFee as UnitFee, 1 As ServiceQty, Admissions.ReqDate, AdmissionCauses.GDRGCode As GDRDCode, Diseases.ICDCode As ICDCOde, Admissions.EpisodeID, 'INTERNAL' As RequestType, Admissions.OPDNo, 'Yes' As ServiceIssued, 3 As PatStatus, ActiveEpiID, Principal As IsPrincipal, 'No' As IsRefill, DisDate As ServiceDate, 0 As DrugServiceType, 1 As DiagServiceType   FROM Diseases Inner Join (NHIAEpisodesView Inner Join (Admissions Inner Join AdmissionCauses On  (Admissions.OPDNo=AdmissionCauses.OPDNo and Admissions.AdmTime=AdmissionCauses.AdmTime)) On (EpiID=Admissions.EpisodeID And PatID=Admissions.OPDNo)) On Diseases.DisCode=AdmissionCauses.DisCode Where Admissions.EpisodeID<>0 and Archived='No' and AdmissionCauses.EpisodeID<>0 and Cancelled='No'

union

SELECT Distinct Service_Requests.RecordID, Left(SERVICETYPE,100) As ServiceDescription, '' As Frequency, 0 As Duration, 0 As Dosage, Service_Requests.ServiceCode, ServiceTypeCode, PmtTypeCode, 'CONSULTATIONS' As ServicePlace, Service_Fee as UnitFee, ServiceQty, ReqDate, GDRG_Code As GDRDCode, '' As ICDCOde, EpisodeID, RequestType, OPDNo, Issued As ServiceIssued, Service_Requests.StatusCode As PatStatus, ActiveEpiID, '' As IsPrincipal, 'No' As IsRefill, ServiceDate, -1 As DrugServiceType, -1 As DiagServiceType   FROM Service_Types Inner Join (NHIAEpisodesView Inner Join Service_Requests On (ActiveEpiID=EpisodeID And EpiID=EpisodeID And Clinic_Code= ClinicCode And PatID=OPDNo)) On Service_Types.ServiceCode=Service_Requests.ServiceCode Where EpisodeID<>0 and ServiceTypeCode=5 and Archived='No' and Refunded='No' and PmtTypeCode<>1 and SponsorNo<>''

Union

SELECT Distinct Service_Requests.RecordID, Left(SERVICETYPE,100) As ServiceDescription, '' As Frequency, 0 As Duration, 0 As Dosage, Service_Requests.ServiceCode, ServiceTypeCode, PmtTypeCode, 'CONSULTATIONS' As ServicePlace, Service_Fee as UnitFee, ServiceQty, ReqDate, GDRG_Code As GDRDCode, '' As ICDCOde, EpisodeID, RequestType, OPDNo, Issued As ServiceIssued, Service_Requests.StatusCode As PatStatus, ActiveEpiID, '' As IsPrincipal, 'No' As IsRefill, ServiceDate, -1 As DrugServiceType, -1 As DiagServiceType   FROM Service_Types Inner Join (NHIAEpisodesView Inner Join Service_Requests On (ActiveEpiID=EpisodeID And EpiID=EpisodeID And Clinic_Code= ClinicCode And PatID=OPDNo)) On Service_Types.ServiceCode=Service_Requests.ServiceCode Where EpisodeID<>0 and ServiceTypeCode In (16, 17) and Archived='No' and Refunded='No' and PmtTypeCode<>1 and SponsorNo<>'' and Service_Requests.StatusCode=3

go

