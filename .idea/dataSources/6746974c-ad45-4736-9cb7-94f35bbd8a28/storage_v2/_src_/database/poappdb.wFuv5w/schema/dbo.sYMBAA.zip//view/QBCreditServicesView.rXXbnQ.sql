CREATE VIEW [dbo].[QBCreditServicesView]

AS

---ALL PRIVATE SPONSORED SERVICES

SELECT DISTINCT (RequiredQty *(UnitFee)) As PaidAmt ,ServiceCode ,Description As ServiceDescription,EndDate AS TransDate,RequestID As TransID,SponsorNo As ReceiverID,HWCode As IssuerID  
,'Service Credit Sale' As MoveType,UPPER(SponsorName ) as ClientName, SponsorTypeCode, '' As EpisodeSpecialityCode FROM Sponsors Inner Join(AllSetUpServicesView Inner Join PrivateClaimsServices ON ItemID =ServiceCode)
	ON Sponsors.SponsorNo =SponsorID 
	WHERE ServiceTypeCode<>1 And PatCatCode NOT IN (0,1,4,11) And UnitFee>0 AND RequiredQty >0  and Sponsors.SponsorTypeCode <>2

----(Non Copayed)	
--SELECT DISTINCT ServiceQty * Service_Fee As PaidAmt ,ServiceCode ,Description As ServiceDescription,ReqDate AS TransDate,RecordID As TransID,Service_Requests.SponsorNo As ReceiverID,SerPlaceCode As IssuerID  
--,'Service Credit Sale' As MoveType,UPPER(SponsorName ) as ClientName, SponsorTypeCode, '' As EpisodeSpecialityCode FROM Sponsors Inner Join(AllSetUpServicesView Inner Join Service_Requests ON ItemID =Service_Requests.ServiceCode)
--	ON Sponsors.SponsorNo  =Service_Requests.SponsorNo WHERE Service_Requests.PmtTypeCode NOT IN (0,1) AND BillCategoryCode NOT IN (1,4,11) 
--	AND ServiceQty >0 And Service_Requests.SponsorNo<>'' And UPPER(RequestType)='INTERNAL'  and Service_Fee>0 
--	and Sponsors.SponsorTypeCode <>2
		
--UNION ALL

----(Copayed)	
--SELECT DISTINCT (ServiceQty *(CoPayFee-Service_Fee)) As PaidAmt ,ServiceCode ,Description As ServiceDescription,ReqDate AS PmtDate,RecordID,Service_Requests.CoPaySponsorNo As ReceiverID,SerPlaceCode As IssuerID  
--,'Service Credit Sale' As MoveType,UPPER(SponsorName ) as ClientName, SponsorTypeCode, '' As EpisodeSpecialityCode FROM Sponsors Inner Join(AllSetUpServicesView Inner Join Service_Requests ON ItemID =Service_Requests.ServiceCode)
--	ON Sponsors.SponsorNo  =Service_Requests.CoPaySponsorNo WHERE CoPayPmtTypeCode NOT IN (0,1) AND CoPayBillCategoryCode NOT IN (1,4,11)  And CoPaySponsorNo<>''
--	AND CoPayFee >0 And UPPER(RequestType)='INTERNAL' And CoPayFee-Service_Fee>0 AND ServiceQty >0 
--	and Sponsors.SponsorTypeCode <>2
go

