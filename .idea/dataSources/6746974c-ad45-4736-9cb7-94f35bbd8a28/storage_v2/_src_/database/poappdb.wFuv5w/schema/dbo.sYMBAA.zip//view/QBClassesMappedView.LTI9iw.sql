CREATE VIEW [dbo].[QBClassesMappedView]

AS

SELECT OverSeer As AcctsClass, ServicePlaceCode, Service_Places.Description As ClientName FROM Service_Places Inner Join (AccountClassView Inner Join AccountsSubClassServicePlaceMapping  On AccountClassView.RecordID=SubClassID) On Service_Places.Code=ServicePlaceCode
go

