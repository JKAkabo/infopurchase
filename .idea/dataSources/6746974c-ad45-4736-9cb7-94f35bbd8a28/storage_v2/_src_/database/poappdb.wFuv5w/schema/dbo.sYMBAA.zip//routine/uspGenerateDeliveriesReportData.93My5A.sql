create PROCEDURE [dbo].[uspGenerateDeliveriesReportData] 

	@frmDate datetime, @toDate datetime, @user_ID nvarchar(10), @ReportDate datetime
	
AS

DECLARE @Specialty nvarchar(15),@RecordID numeric(18,0),@OPDNo nvarchar(15),@PatGender nvarchar(15),@PatInsured nvarchar(3),@TreatmentCost numeric(18,4),@PatAge int,@admDate datetime,@DisDate datetime,@PatWardID nvarchar(250);

DECLARE @DurationOfPreg nvarchar(max),@DeliveryType nvarchar(max),@Parity numeric(18,2),@PatOccupation nvarchar(100),@PatName nvarchar(250),@PatEducation nvarchar(100),@DischargedOutcome nvarchar(250);

DECLARE @BillCategoryCode tinyint,@EpisodeID numeric(18,0),@Pat_No nvarchar(15),@SurName nvarchar(100),@MiddleName nvarchar(100),@FirstName nvarchar(100),@TDOB nvarchar(100), @PatAddress nvarchar(max);

DECLARE @DeliveryComplications nvarchar(Max),@DeliveryOutcome nvarchar(100),@StillBirths tinyint,@LiveBirths tinyint

--@DurationOfPreg,@Parity,@DeliveryType
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
 
 --Delete From GHSInPatientMortalityMorbidityData Where FromDate>=@frmDate And FromDate<=@toDate

	DECLARE DischargedRecords CURSOR FAST_FORWARD FOR SELECT BillCategoryCode, OPDNo, PatAge, AdmDate, DisDate, RecordID, EpisodeID, Pat_No, SurName, LastName, MiddleName, TDOB, EducDesc, Insured, ConsultationOutComesSetup.Description As DischargedOutcome, OccupDesc, DurationOfPreg, Parity, DeliveryType From ConsultationOutComesSetup Inner Join BirthRegistryView On Code = DischargeStatusCode Where RegDate >= @frmDate And RegDate <= @toDate 


 OPEN DischargedRecords

 FETCH NEXT FROM DischargedRecords INTO @BillCategoryCode,@OPDNo,@PatAge,@admDate,@DisDate,@RecordID,@EpisodeID,@Pat_No, @SurName, @FirstName, @MiddleName, @TDOB, @PatEducation, @PatInsured, @DischargedOutcome,@PatOccupation,@DurationOfPreg,@Parity,@DeliveryType;

	WHILE @@fetch_status = 0

	  BEGIN 
	  
	       set @StillBirths=0
	       
	       set @LiveBirths=0
	  
	       set @DeliveryComplications=dbo.GetPatientBirthComplications(@RecordID)
	       	       
	       set @DeliveryType=dbo.GetPatientDeliveryMethod(@RecordID)
	       	       	       	       
	       set @TreatmentCost=dbo.GetPatientBill(@OPDNo,@admDate,@DisDate,@BillCategoryCode,3,@EpisodeID)
	       
	       set @DeliveryOutcome=dbo.GetPatientDeliveryOutCome(@RecordID)
	       
	       set @StillBirths=dbo.GetPatientDeliveryCount(@RecordID,2)
	       
	       set @LiveBirths=dbo.GetPatientDeliveryCount(@RecordID,1)
	       
	       set @LiveBirths= @LiveBirths + dbo.GetPatientDeliveryCount(@RecordID,3)
	       
	       if LEFT(ltrim(@DurationOfPreg),1)=1 
	          set @DurationOfPreg='13'
	          
	       else if LEFT(ltrim(@DurationOfPreg),1) =2 
	          set @DurationOfPreg='27'
	          
	       else
	       	 set @DurationOfPreg='40'      
	       	 
	       --set @DurationOfPreg=''
	       
	       --set @DeliveryType=''
	       
	       --set @TreatmentCost=0
	       
	       set @PatAddress=dbo.GetPatientAddress(@OPDNo)
	       
	       if @MiddleName<>'' 
	          set @PatName=@FirstName + ' ' + @MiddleName + ' ' + @SurName
	          
	       else
	          set @PatName=@FirstName + ' ' + @SurName
	          
        select RecordID From GHSDeliveriesData Where RecordID=@RecordID 
        
        If @@ROWCOUNT<=0
											Insert into GHSDeliveriesData(RecordID,PregnancyDuration,Parity,DeliveryComplications,DeliveryOutcome,TreatmentCost,FromDate,ToDate,UserID,ReportDate,PatAddress,AdmDate,DisDate,PatAge,OPDNo,PatName,PatOccupation,PatEducation,PatInsured,DischargedOutcome,DeliveryType,LiveBirths,StillBirths)values 
											(@RecordID, @DurationOfPreg,@Parity,@DeliveryComplications, @DeliveryOutcome, @TreatmentCost, @frmDate, @toDate, @user_ID,@ReportDate,@PatAddress,@AdmDate,@DisDate,@PatAge,@Pat_No,@PatName,@PatOccupation,@PatEducation,@PatInsured,@DischargedOutcome,@DeliveryType,@LiveBirths,@StillBirths)
        
        else
											Update GHSDeliveriesData Set PregnancyDuration=@DurationOfPreg,Parity=@Parity,DeliveryComplications=@DeliveryComplications,DeliveryOutcome=@DeliveryOutcome, TreatmentCost=@TreatmentCost,FromDate=@frmDate,ToDate=@toDate,UserID=@user_ID, 
											 ReportDate=@ReportDate,PatAddress=@PatAddress,AdmDate=@AdmDate,DisDate=@DisDate,PatAge=@PatAge,OPDNo=@Pat_No,PatName=@PatName,PatOccupation=@PatOccupation,PatEducation=@PatEducation,PatInsured=@PatInsured,DischargedOutcome=@DischargedOutcome,
											 DeliveryType=@DeliveryType,LiveBirths=@LiveBirths,StillBirths=@StillBirths Where RecordID=@RecordID 
         
        FETCH NEXT FROM DischargedRecords INTO @BillCategoryCode,@OPDNo,@PatAge,@admDate,@DisDate,@RecordID,@EpisodeID,@Pat_No, @SurName, @FirstName, @MiddleName, @TDOB, @PatEducation, @PatInsured, @DischargedOutcome,@PatOccupation,@DurationOfPreg,@Parity,@DeliveryType;

   END

	CLOSE DischargedRecords;

	DEALLOCATE DischargedRecords;

END
go

