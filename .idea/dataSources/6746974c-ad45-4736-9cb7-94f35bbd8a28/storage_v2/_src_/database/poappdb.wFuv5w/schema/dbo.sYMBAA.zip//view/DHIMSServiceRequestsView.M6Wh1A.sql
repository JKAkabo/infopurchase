CREATE VIEW [dbo].[DHIMSServiceRequestsView]

AS

Select Service_Requests.OPDNo , Convert(NVARCHAR(5),  PatientsInfo.GenderCode) As GenderCode, Service_Requests.Issued, Service_Requests.Insured, ReqDate As AttDate, TDOB, ClinicCode, Code, ServiceDate, DirectID, ServiceTypeCode From PatientsInfo Inner Join (DHIMSHAMSServicesView Inner Join Service_Requests On DHIMSHAMSServicesView.ServiceCode=Service_Requests.ServiceCode) On PatientsInfo.OPDNo=Service_Requests.OPDNo Where Service_Requests.Archived='No'
go

