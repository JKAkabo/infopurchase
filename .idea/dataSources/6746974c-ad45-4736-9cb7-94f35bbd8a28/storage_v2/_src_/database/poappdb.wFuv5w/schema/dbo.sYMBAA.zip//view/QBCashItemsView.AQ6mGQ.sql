CREATE VIEW [dbo].[QBCashItemsView]

AS

SELECT s.RecordID As TransID,DrugCode As ServiceCode,S.Service_Fee *s.PaidQty As PaidAmt,S.PmtDate As TransDate,StoresID As IssuerID
,S.PmtTypeCode,S.SponsorNo As ReceiverID,i.Description as ServiceDescription,UPPER(SP.Description) AS ClientName,S.Pat_ID as OPDNo
 ,'Item Cash Sale' As MoveType,Convert(nvarchar(15),i.ItemClassCode) As ItemClassCode FROM Service_Places SP Inner Join
 (Items i Inner Join(dbo.Prescriptions P Inner Join ServiceLinePayments S On P.RecordID =S.ServiceID AND P.DrugCode =S.ServiceCode )
ON i.ItemID =S.ServiceCode )ON SP.Code=P.StoresID WHERE P.RecordID =S.ServiceID And P.DrugCode =s.ServiceCode And s.PmtTypeCode =1
go

