CREATE VIEW [dbo].[PatientEyeRefractionView]

AS

SELECT E.ExamID As RefractionID, C.DoctorID, E.ServerTime, E.UserID, M.UnitMeasure, M.ElementOrder, M.Description As RefractionElement,C.Pat_No,C.OPDNo,C.StatusCode,C.UserID As RefractUserID,C.ClinicCode,E.RecordID,C.OucomeID, 
CASE WHEN M.ResultValueType=1 Then ISNULL((Select TOP 1 X.Description From EyeElementTextValues X Where X.Code=E.RID And M.ResultValueType=1 And X.TypeCode=M.Code),'') 
ELSE E.RR END AS RightValue,CASE WHEN M.ResultValueType=1 Then ISNULL((Select TOP 1 X.Description From EyeElementTextValues X Where X.Code=E.LID And M.ResultValueType=1 And X.TypeCode=M.Code),'') 
ELSE E.RL END AS LeftValue, Surname,MiddleName,LastName,PatientAge,DOB, C.ExamTime, C.FrameOrderType, C.LensIndex, Gender, PatientCategory, C.ReviewTime,C.ReqDate,C.PatAge, C.VFResults,RR,RL,
F.MaterialDesc,L.Description As EyeLensType,V.Description As PrescriptionType, C.ServerTime As RefractServerTime,E.RefractionType As RefractionTypeID,E.Remarks, N.Description As RefractionType, S.Description As RefractionOutcome

FROM dbo.PatientEyeExamRefraction E, PatientEyeExams C, PatientInfoView P, EyeExaminationElements M,EyeRefractionOutcomes S,
EyeFrameMaterialsView F, EyeLensTypesView L, EyePrescriptionTypesView V,EyeRefractionTypes N
Where C.RecordID=E.ExamID And C.OPDNo=P.PatientID And C.Pat_No=P.OPDNo And C.Archived='No'And F.MaterialCode=C.LensMaterial And S.Code=C.OucomeID
And E.Archived='No' And M.Code=E.RefractID And M.TypeID=2 And L.Code=C.LensType And V.Code=C.LensPresType And N.Code=E.RefractionType
go

