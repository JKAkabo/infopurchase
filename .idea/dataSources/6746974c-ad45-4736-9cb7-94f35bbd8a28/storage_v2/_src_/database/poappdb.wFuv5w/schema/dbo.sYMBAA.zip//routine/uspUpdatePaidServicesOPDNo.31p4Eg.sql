CREATE PROCEDURE [dbo].[uspUpdatePaidServicesOPDNo] 
	
AS

DECLARE @OPDNo nvarchar(15),@ReceiptNo nvarchar(15)

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct OPDNo, ReceiptNo From BillsPaid Order by OPDNo
            
  OPEN C
  
  FETCH NEXT FROM C INTO @OPDNo, @ReceiptNo        

  WHILE @@fetch_status = 0
   BEGIN

   update ServiceLinePayments set Pat_ID=@OPDNo Where ReceiptNo=@ReceiptNo
   
  FETCH NEXT FROM C INTO @OPDNo, @ReceiptNo        

	END

	CLOSE C;

	DEALLOCATE C;

END
go

