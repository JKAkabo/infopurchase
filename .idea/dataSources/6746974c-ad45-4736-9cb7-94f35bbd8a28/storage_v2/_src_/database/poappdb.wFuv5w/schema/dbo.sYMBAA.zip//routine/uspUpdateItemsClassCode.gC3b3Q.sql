CREATE PROCEDURE [dbo].[uspUpdateItemsClassCode] 
	
AS

DECLARE @DisCategory nvarchar(250),@DisCatCode int;

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT [Description],code From ItemClasses Order by Code Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO @DisCategory, @DisCatCode;

  WHILE @@fetch_status = 0
    BEGIN

       --set @DisCategory=dbo.ItemDesc(@DisCategory);
       
       update Items Set ItemClassCode=@DisCatCode where upper(ltrim(rtrim(ItemClass)))=upper(rtrim(ltrim(@DisCategory)))

       FETCH NEXT FROM C INTO @DisCategory, @DisCatCode;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

