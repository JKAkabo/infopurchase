CREATE VIEW [dbo].[DailyWardAdmissionsCountView]
AS

SELECT  Isnull(Count(OPDNo),0) As AdmCount, AdmDate, WardID From AllAdmissionsView 
 where RecordSerialNo=1 Group By WardID, AdmDate
go

