

CREATE PROCEDURE [dbo].[uspGetDailyWardsStateSummaryData] 

@WardID nvarchar(15)='',@StateDate datetime=''
	
AS

DECLARE @StateWardID nvarchar(15),@RemainedPrevDayAdms numeric(18,0),@RemainedCurrentDayNight numeric(18,0),@RemainedPrevNight numeric(18,0),@EmptyBeds numeric(18,0)

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;

Delete From DailyWardStateSummary

if @WardID=''
   DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct AllAdmissionsView.WardID From Wards Inner Join AllAdmissionsView On Wards.WardID = AllAdmissionsView.WardID 
   
else
   DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct AllAdmissionsView.WardID From Wards Inner Join AllAdmissionsView On Wards.WardID = AllAdmissionsView.WardID Where AllAdmissionsView.WardID=@WardID

OPEN C

FETCH NEXT FROM C INTO @StateWardID;

WHILE @@fetch_status = 0
	BEGIN
	
       Set @RemainedPrevDayAdms=dbo.GetWardRemainedPrevDayTotalAdmsCount(@statewardid,@StateDate)
       
       Set @RemainedPrevNight=dbo.GetWardRemainedPrevNightCount(@statewardid,@StateDate)
       
       set  @RemainedCurrentDayNight=dbo.GetWardRemainedCurrentDayCount(@statewardid,@StateDate)
       
       Set @EmptyBeds=dbo.GetWardRealBedsNo(@StateWardID) - @RemainedCurrentDayNight
       
       if @RemainedPrevDayAdms is Null 
          Set @RemainedPrevDayAdms=0
          
       if @EmptyBeds is Null 
          Set @EmptyBeds=0
          
       if @RemainedCurrentDayNight is Null 
          Set @RemainedCurrentDayNight=0
          
	   if @RemainedPrevNight is Null 
		  Set @RemainedPrevNight=0       
	   
	   Insert into DailyWardStateSummary (WardID, EmptyBedsNo, RemainedPrevDayAdms, RemainedPrevNight, RemainedCurrentNight)Values 
	   (@StateWardID, @EmptyBeds, @RemainedPrevDayAdms, @RemainedPrevNight, @RemainedCurrentDayNight)
								
	  FETCH NEXT FROM C INTO @StateWardID;
	       
	END    
                      
    CLOSE C;

	DEALLOCATE C;		  

END


go

