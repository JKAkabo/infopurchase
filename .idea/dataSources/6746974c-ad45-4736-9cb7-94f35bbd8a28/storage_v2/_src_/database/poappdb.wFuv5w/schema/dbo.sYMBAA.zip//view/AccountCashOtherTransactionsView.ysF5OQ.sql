CREATE VIEW [dbo].[AccountCashOtherTransactionsView]

AS

--BILLS APPROXIMATIONS
SELECT
	
'' As ServiceCode,R.BillApprox As TransAmt ,R.PmtDate As TransDate,12 AS TransTypeID,
ISNULL((Select TOP 1 J.AcctCodeJE From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=12 AND J.AcctTypeIDJE=12 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As CreditAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=12 AND J.AcctTypeIDJE=12 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As CreditAcctName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=12 AND J.AcctTypeIDJE=12 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As CreditPostType,

--M.ServiceTypeID, '' As TransID,A.TypeDescription,A.AcctTypeID,
'' as ClientName,10 As ServiceTypeID, '' As TransID,'' As TypeDescription,12 As AcctTypeID,'' As ClientID,

ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitPostType

FROM 

BillsPaid R WHERE R.BillApprox >0 And R.Archived ='No' 

UNION ALL

--DEPOSIT PAYMENTS
SELECT
	
'', R.AmtPaid PaidAmt,R.PmtDate,3 AS TransTypeID,
ISNULL((Select TOP 1 J.AcctCodeJE From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctsName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As PostType,

'',6, '' As TransID,'',8,'',

ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitPostType

FROM 

BillsPaid R WHERE R.Archived ='No' AND R.AmtPaid>0  and R.ReceiptNo IN (SELECT D.ReceiptNo FROM Deposits D WHERE Archived='No')
			
UNION ALL

--IOUS PAYMENTS
SELECT
	
'', R.IouAmtPaid as PaidAmt,R.PmtDate,4 AS TransTypeID,
ISNULL((Select TOP 1 J.AcctCodeJE From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=4 AND J.AcctTypeIDJE=5 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=4 AND J.AcctTypeIDJE=5 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctsName, 

'CREDIT' As PostType,

'',7, '' As TransID,'',5,'',

ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitPostType

FROM 

BillsPaid R WHERE R.Archived ='No' AND R.IouAmtPaid>0
			
UNION ALL

--IOUS
SELECT
	
'', R.IOUAmt as PaidAmt,R.PmtDate,8 AS TransTypeID,
ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctsName, 

'CREDIT' As PostType,

'',7, '' As TransID,'',5,'',

ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=8 AND J.AcctTypeID=5 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=8 AND J.AcctTypeID=5 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=8 AND J.AcctTypeID=5 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitPostType

FROM 

BillsPaid R WHERE R.Archived ='No' AND R.IOUAmt>0
			
UNION ALL
-- DISCOUNTS
SELECT
	
'', R.DisAmt as PaidAmt,R.PmtDate,9 AS TransTypeID,

ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctsName, 

'CREDIT' As PostType,'',9, '' As TransID,'',9,'',

ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=9 AND J.AcctTypeID=2 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=9 AND J.AcctTypeID=2 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=9 AND J.AcctTypeID=2 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitPostType

FROM 
BillsPaid R WHERE R.DisAmt >0 And R.Archived ='No'
	
UNION ALL

--REFUND PAYMENTS 1 - EXCESS DEPOSITS  PAYMENT
SELECT
	
'', R.AmtPaid-L.RefundAmt as PaidAmt,R.PmtDate,7 AS TransTypeID,

ISNULL((Select TOP 1 J.AcctCodeJE From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=7 AND J.AcctTypeIDJE=11 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=7 AND J.AcctTypeIDJE=11 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctsName, 

'CREDIT' As PostType,'',8, '' As TransID,'',11,'',

ISNULL((Select TOP 1 J.AcctCodeJE From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctsName, 

'DEBIT' As PostType

FROM 

BillsRefunds R, ReceiptNoRefundServiceLinesView L WHERE  R.AmtPaid-L.RefundAmt >0 And R.Archived ='No'  and R.ReceiptNo=L.RefundReceiptNo
			
UNION ALL

--REFUND PAYMENTS 2 - EXCESS DEPOSITS  PAYMENT
SELECT
	
'', R.AmtPaid as PaidAmt,R.PmtDate,7 AS TransTypeID,
ISNULL((Select TOP 1 J.AcctCodeJE From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=7 AND J.AcctTypeIDJE=11 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=7 AND J.AcctTypeIDJE=11 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctsName, 

'CREDIT' As PostType,'',8, '' As TransID,'',11,'',

ISNULL((Select TOP 1 J.AcctCodeJE From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As DebitAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As DebitAcctsName, 

'DEBIT' As DebitPostType

FROM 

BillsRefunds R WHERE R.Archived ='No' AND R.AmtPaid>0 and R.ReceiptNo NOT IN (Select F.RefundReceiptNo From RefundServiceLines F)

UNION ALL
			
--DEPOSITS USED 
SELECT 

'', R.DepAmtUsed As PaidAmt,R.PmtDate,3 AS TransTypeID,
ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctsName, 

'CREDIT' As PostType,'',6, '' As TransID,'',8,'',

ISNULL((Select TOP 1 J.AcctCodeJE From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As DebitAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As DebitAcctsName, 

'DEBIT' As DebitPostType

FROM 

BillsPaid R WHERE R.Archived ='No' AND R.DepAmtUsed>0
go

