CREATE VIEW [dbo].[ServiceCategoriesView]

AS

SELECT Description, Code FROM dbo.ServiceCategories

Union

Select '' As Description, 0 as Code from Hosp_Info
go

