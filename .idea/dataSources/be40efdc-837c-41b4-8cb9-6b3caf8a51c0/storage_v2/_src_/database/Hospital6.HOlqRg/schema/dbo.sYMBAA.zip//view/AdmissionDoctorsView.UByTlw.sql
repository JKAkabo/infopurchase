





CREATE VIEW [dbo].[AdmissionDoctorsView]

AS

Select Distinct DoctorID as Doctor, Users.UserID, AdmDate, DisDate, OPDNo, User_Locked, Users.CatID, UserCategories.Description From UserCategories Inner Join ( Users Inner Join Admissions On UserNo=DoctorID) On UserCategories.CatID=Users.CatID where Admissions.Archived='No' and (DoctorID=DisAuthouriser or DisAuthouriser is Null)

Union

Select Distinct DisAuthouriser as Doctor, Users.UserID, AdmDate, DisDate, OPDNo, User_Locked, Users.CatID,UserCategories.Description From UserCategories Inner Join ( Users Inner Join Admissions On UserNo=DoctorID) On UserCategories.CatID=Users.CatID where Admissions.Archived='No' and DisDate Is Not Null And Discharged='Yes' and DoctorID<>DisAuthouriser And DisAuthouriser is Not Null and DisAuthouriser<>''



go

