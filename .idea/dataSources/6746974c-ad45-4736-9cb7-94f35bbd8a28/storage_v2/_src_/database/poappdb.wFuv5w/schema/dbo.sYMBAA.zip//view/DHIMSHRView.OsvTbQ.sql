CREATE VIEW [dbo].[DHIMSHRView]

AS

Select UsersView.UserNo , Convert(Nvarchar(5), UserGender ) As GenderCode, ContractID As TransType, '' As Insured, DataSetID, ElementID From UsersView Inner Join (UserGrades Inner Join DHIMSMappedDataElementsView On Convert(Nvarchar(6), UserGrades.Code)=MappedCode) On UsersView.UserGrade=UserGrades.Code Where Archived='No' and DataSetID='szF7by0DJnr' and UserGender<>0 and ContractID<>0
go

