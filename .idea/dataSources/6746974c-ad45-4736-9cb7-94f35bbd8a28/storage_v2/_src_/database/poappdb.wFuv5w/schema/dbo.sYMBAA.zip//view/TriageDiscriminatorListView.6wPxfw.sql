CREATE VIEW [dbo].[TriageDiscriminatorListView]

AS

SELECT  Description, Code FROM TriagePresentationsSetup

Union

SELECT  '' As Description, 0 As Code FROM dbo.Hosp_Info
go

