CREATE VIEW [dbo].[SponsorsView]
AS
SELECT     left(Sponsors.SponsorName, 100) As SponsorName,Sponsors.SponsorNo,Sponsors.SponsorTypeCode,Sponsors.SchemeCode,Fax,TelNo, BillCatType,
CASE WHEN SponsorTypeCode=2 THEN 1  WHEN SponsorTypeCode=3 THEN 2 WHEN SponsorTypeCode=6 THEN 3 WHEN SponsorTypeCode=4 THEN 4 WHEN SponsorTypeCode=5 THEN 5
WHEN SponsorTypeCode=1 THEN 6 END AS AttPriority, UPPER(SponsorTypes.Description) As SponsorType,AcctsBlocked  FROM  dbo.Sponsors, SponsorTypes where Sponsors.SponsorTypeCode=SponsorTypes.Code

union

Select 'PATIENT' As SponsorName, '' as SponsorNo, 1 As SponsorTypeCode ,'' As SchemeCode,'' As Fax,'' As TelNo, 'DIRECT' As BillCatType,6, '','Yes' from Hosp_Info
go

