CREATE VIEW [dbo].[InvestigationRequestsView]

AS

SELECT S.*, A.ServiceType as ServiceDescription, P.Description as ServicePlace,I.StatusCode As PatStatusCode,U.UserID As DoctorName ,Y.UserID As AssignedDoctor ,C.Type As ClinicTypeID,
ServiceTypeCode, A.CatID, A.SubCatID,'**' As CAPID, T.Description as PmtType, C.Description As Clinic,I.Weight,Nationality ,U.UserCategory,H.Description As PatCategory,
CASE WHEN U.UserCategory IN ('DOCTORS','DOCTOR','MEDICAL ASSISTANTS','PHYSICIAN ASSISTANTS','MEDICAL ASSISTANT','PHYSICIAN ASSISTANT','LOCUM DOCTORS','MIDWIVES','MIDWIVE') THEN RequesterID Else '' End As RequestedDoc,
V.Description As PatStatus,LastName,  MiddleName,  Surname, G.Description As Gender, Title, I.GenderCode, CONVERT(Date, TDOB) AS DOB, CONVERT(date,getdate()) as TodayDate,
CASE WHEN Year(CONVERT(Date, TDOB))=Year(getdate()) Then 0 WHEN Month(getdate())>Month(CONVERT(Date, TDOB)) Or (Month(getdate())=Month(CONVERT(Date, TDOB)) And day(getdate())>=day(CONVERT(Date, TDOB))) Then 
DateDiff(M,  CONVERT(Date, TDOB), getdate())/12 Else DateDiff(YYYY,  CONVERT(Date, TDOB), getdate()) - 1 END As PatientAge,C.QueueTimeBasedOn, W.Description As ConsultRoom,
ISNULL((Select TOP 1 H.TransSatatus From HamsTransactionsQueue H, HamsTransactions D Where D.ID=H.TransTypeID And S.RecordID=H.TransID and S.ReqDate=H.TransDate And D.CatCode IN ('04') Order By H.TransID Desc),0) As TransStatus,
ISNULL((Select TOP 1 H.TransOutCome From HamsTransactionsQueue H, HamsTransactions D Where D.ID=H.TransTypeID And S.RecordID=H.TransID and S.ReqDate=H.TransDate And D.CatCode IN ('04') Order By H.TransID Desc),0) As TransOutCome,
ISNULL((Select TOP 1 H.TransUserID From HamsTransactionsQueue H, HamsTransactions D Where D.ID=H.TransTypeID And S.RecordID=H.TransID and S.ReqDate=H.TransDate And D.CatCode IN ('04') Order By H.TransID Desc),'') As TransUserID

From Service_Types A, Service_Requests S, ServicePlacesView P, PaymentTypessView T, PatientCategoryView H,
ClinicsView C, PatientsInfo I, GenderGroups G, PatientStatusView V, UsersView U, ConsultingRoomsView W, UsersView Y Where S.Archived='No' and H.Code=S.BillCategoryCode 
and A.ServiceCode=S.ServiceCode and P.Code=ServicePlaceCode and T.Code=S.PmtTypeCode and C.SPCode=ClinicCode and U.UserNo=RequesterID and W.Code=AssignedRoomID and Y.UserNo=AssignedUserID 
and G.Code=I.GenderCode and I.OPDNo=S.OPDNo and I.StatusCode=V.Code and ServiceTypeCode IN (11,12,13,14)
go

