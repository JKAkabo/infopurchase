-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[LabAnalyzerResultsCaptureAlert] 

   ON  [dbo].[Interface] 
   
   AFTER INSERT
   
AS 

DECLARE @DayTime nvarchar(50), @DayDate nvarchar(50), @testID numeric(18,0),@UserID nvarchar(15),@testResult nvarchar(100),@testRange nvarchar(100);
DECLARE @Day nvarchar(50),  @ReqID numeric(18,0),@SerCode nvarchar(15),@SpecimenCode nvarchar(50), @ElementID numeric(18,0),@ResultUnit nvarchar(100),@ResultID tinyint;
DECLARE @PatGender tinyint,@PatAge tinyint,@PatAgeGroup tinyint, @SpecimenCode1 Nvarchar(100),@AgeClassCode tinyint, @ElementID1 numeric(18,0), 
@testTime Datetime, @recID numeric(18,0), @AnalyzerID smallint,@ResultsTag nvarchar(100)='',@ValueType tinyint; 

SET @UserID='00001'
 
SELECT @AnalyzerID=AnalyzerCode, @SpecimenCode=IsNull(SpecimenID,''),@testResult=IsNull(Result,''), @ResultUnit=IsNull(Unit,''),@testRange=IsNull(Range,''),@ElementID=Inserted.ElementID ,@testTime=Inserted.ServerTime ,@recID=Inserted.ID,@ValueType=TestElements.ResultValueType From TestElements Inner Join Inserted On TestElements.Code=Inserted.ElementID;

IF @SpecimenCode='' or @ElementID=0
   RETURN

if @ValueType=2 
   SET @testRange=''
   
Set @DayDate=DATENAME(DD,@testTime) + '-' + left(DATENAME(MM,@testTime),3) + '-' + DATENAME(YYYY,@testTime)
Set @DayTime=@testTime

DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct PatientLabSpecimens.SpecimenID , PatientLabSpecimens.SerCode, LabSpecimenCollection.PatAge, GenderCode, AgeClassCode, PatientLabSpecimens.ReqID From PatientsInfo Inner Join  (LabSpecimenCollection Inner Join (PatientLabSpecimens Inner Join LabTestElements On SerCode=TestID) On LabSpecimenCollection.RecordID=CollectID) On PatientsInfo.OPDNo=LabSpecimenCollection.OPDNo Where LabSpecimenCollection.SpecimenCode=@SpecimenCode and LabTestElements.Code=@ElementID and PatientLabSpecimens.Archived='No' and LabSpecimenCollection.Archived='No' Order by PatientLabSpecimens.SpecimenID Asc

OPEN C

FETCH NEXT FROM C INTO @SpecimenCode1, @SerCode, @PatAge, @PatGender, @AgeClassCode, @ReqID;

WHILE @@fetch_status = 0

 BEGIN  
   
   SET @ResultsTag=''
   
   Set @PatAgeGroup=dbo.GetAgeGroupCode(@PatAge)
        
	if Rtrim(ltrim(@testRange))='' OR Rtrim(ltrim(@testRange))='-' OR  isnumeric(left(Rtrim(ltrim(@testRange)),1))=0
	
	    BEGIN
				
	      if @ValueType=1   
		     Set @testRange=dbo.GetTestElementNormalRange(@ElementID,@PatGender,@PatAgeGroup)
 
		END
		
		SET @ResultsTag=dbo.GetTestResultTag(@ElementID,@PatGender,@PatAgeGroup,@ValueType,left(@testResult,100))

			   
			BEGIN TRANSACTION
			 
				--Check if Results is already captured in HAMS
			SELECT @testID=RecordID,@DayDate=testdate,@DayTime=testtime FROM labtests WHERE specimencode=@SpecimenCode1 and TestCode=@SerCode and Requestid=@ReqID
			IF @@RowCount<=0   
						BEGIN
			   				   
							Insert into LabTests(Pat_No,OPDNo,TestDate,TestTime,UserID,Insured,AgeClassCode,PatAge,PatCategory,LabTechID, ServerTime, SpecimenID, SpecimenCode, RequestID,TestCode,DeptID,EmpNo,Comments,RequestedBy, StatusCode, MainSponsorNo,Analyzer_ID) 
							SELECT Distinct TOP 1 Service_Requests.Pat_No, OPDNo,@DayDate, @testTime, @UserID,Insured,@AgeClassCode,PatAge,BillCategoryCode,@UserID,@testTime, SpecimenCode, SpecimenID, ReqID, ServiceCode,DeptID, EmpNo,'', RequesterID,Service_Requests.StatusCode,
							Service_Requests.SponsorNo,@AnalyzerID From Service_Requests Inner Join PatientLabSpecimens On Service_Requests.RecordID=ReqID Where Service_Requests.Archived='No' and specimenid=@SpecimenCode1
				      
							SELECT @testID=RecordID FROM labtests WHERE specimencode=@SpecimenCode1 and Requestid=@ReqID
			       
			       			       
						END

			SELECT @ElementID1=LabTestResults.RecordID FROM labtests Inner Join LabTestResults on labtests.RecordID=TestID WHERE specimencode=@SpecimenCode1 and ElementID=@ElementID and labtests.RecordID=@testID

			IF @@RowCount<=0   
			    
				BEGIN
				  			      
						SET @ResultID=dbo.GetTestElementRating (@ElementID,@testResult,@testRange)
			      			      			      
						Insert into LabTestResults(ElementID,Results,TestID,TestRange,Comments,RatingID,UserID,ServerTime,NormalRangeID,ResultID,ResultsTag,SerID,InterfaceID) Select 
						Inserted.ElementID, @testResult,@testID,@testRange,Inserted.Comments,0,@UserID,@testTime,0,@ResultID, @ResultsTag, @SerCode, @recID From Inserted
			      			      
				END
			    
			ELSE
				  BEGIN
						  Update LabTestResults Set Results=@testResult, TestRange=@testRange, ResultsTag=@ResultsTag,SERVERTIME=@testTime,InterfaceID=@recID Where RecordID=@ElementID1
			    
				  END
			 
			IF @@RowCount>0 

						BEGIN
			    
						  Update Service_Requests Set ServiceDate=@DayDate,ServiceTime=@testTime,Issued='Yes',ServicerID =@UserID,QtyGiven=1 Where RecordID=@ReqID
			 
						END
			 
			COMMIT

			FETCH NEXT FROM C INTO @SpecimenCode1, @SerCode, @PatAge, @PatGender, @AgeClassCode, @ReqID;

END

CLOSE C;

DEALLOCATE C;
go

