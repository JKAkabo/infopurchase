CREATE VIEW [dbo].[InPatientFluidOutputsView]

AS

Select InPatientFluidOutputs.Remarks, InPatientFluidOutputs.RecordID, OutputTime, 
LastName,Surname,MiddleName,TDOB,GenderGroups.Description As Gender,InPatRecordID,
Pat_No,PatAge,PatientsInfo.OPDNo,PatientsInfo.StatusCode,Users.UserID As Nurse, 
InPatientFluidOutputs.CAP_ID,InPatientFluidOutputs.ServerTime, InPatientFluidOutputs.PatCategoryCode 
From InPatientFluidOutputs,Users, PatientsInfo, GenderGroups Where Users.UserNo=InPatientFluidOutputs.UserID And 
InPatientFluidOutputs.Archived ='No' and GenderGroups.Code=GenderCode and
PatientsInfo.OPDNo=InPatientFluidOutputs.OPDNo
go

