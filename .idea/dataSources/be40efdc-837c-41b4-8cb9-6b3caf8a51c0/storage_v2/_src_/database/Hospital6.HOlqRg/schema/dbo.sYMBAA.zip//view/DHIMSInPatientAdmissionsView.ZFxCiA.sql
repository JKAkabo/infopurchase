

CREATE VIEW [dbo].[DHIMSInPatientAdmissionsView]

AS

Select AllAdmissionsView.OPDNo , AllAdmissionsView.Insured, convert(NVARCHAR(5),  PatientsInfo.GenderCode) As GenderCode, AdmDate, TDOB, WardID, 'JHP0HrrFcPn' As DataSetID, RecordSerialNo, convert(NVARCHAR(5),  RecordSerialNo) As TransType From PatientsInfo Inner Join AllAdmissionsView On PatientsInfo.OPDNo = AllAdmissionsView.OPDNo where RecordSerialNo In (1,5)



go

