

CREATE VIEW [dbo].[AccountsSubClassServicePlaceMappingView]

AS

SELECT SubClassID, ClassID,RecordID,ServicePlaceCode FROM AccountsSubClassServicePlaceMapping Where Archived='No'

UNION

SELECT 0 As SubClassID, 0 As ClassID,0 As RecordID,Code As ServicePlaceCode FROM  ServicePlacesView where Code NOT IN (Select ServicePlaceCode FROM AccountsSubClassServicePlaceMapping Where Archived='No')


go

