CREATE VIEW [dbo].[QBAcctPostingActivityTypesView]

AS

SELECT (Select Description From AccountPostingType Where Code=1) As PostType, PostMsg, Q.Query, A.ID As AcctsID, A.Code As AcctsCode, A.Description As AcctsName, A.TypeID As AcctsTypeID, Q.RecordID As ActivityID, Q.TypeID, 1 As PostCode, Q.Description As QBAcctPostingActivityDescription, DebitAcctCatID As CatID, DebitAcctSubCatID As SubCatID,H.Description As FinanceActivityDescription, DebitAccoutNo As PostAcctID, DebitAcctQuery As PostDataQuery FROM HamsFinancialActivityTypes H Inner Join (AccountQBPostingActivity Q Inner Join AccountChatsView A On (DebitAcctCatID=CategoryID And DebitAcctSubCatID=SubCategoryID)) On H.Code=Q.TypeID Where Q.IsActive='Yes' And H.IsActive='Yes' And A.Archived='No'

Union All

SELECT (Select Description From AccountPostingType Where Code=2) As PostType,PostMsg, Q.Query, A.ID As AcctsID, A.Code As AcctsCode, A.Description As AcctsName, A.TypeID As AcctsTypeID, Q.RecordID As ActivityID, Q.TypeID, 2 As PostCode, Q.Description As QBAcctPostingActivityDescription, CreditAcctCatID As CatID, CreditAcctSubCatID As SubCatID,H.Description As FinanceActivityDescription, CreditAccoutNo As PostAcctID, CreditAcctQuery As PostDataQuery FROM HamsFinancialActivityTypes H Inner Join (AccountQBPostingActivity Q Inner Join AccountChatsView A On (CreditAcctCatID=CategoryID And CreditAcctSubCatID=SubCategoryID)) On H.Code=Q.TypeID Where Q.IsActive='Yes' And H.IsActive='Yes' And A.Archived='No'
go

