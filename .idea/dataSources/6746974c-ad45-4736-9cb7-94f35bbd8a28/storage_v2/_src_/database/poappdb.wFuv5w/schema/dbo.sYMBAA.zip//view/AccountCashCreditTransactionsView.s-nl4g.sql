CREATE VIEW [dbo].[AccountCashCreditTransactionsView]

AS

--SERVICES CASH SALE
SELECT
	
S.ServiceCode,S.Service_Fee *S.PaidQty as TransAmt,S.PmtDate As TransDate,J.TransTypeID, J.AcctCodeJE As CreditAcctCode,UPPER(A.Description) as CreditAcctName,
UPPER(T.Description) as CreditPostType,UPPER(P.Description) as ClientName, M.ServiceTypeID, '' As TransID,A.TypeDescription,A.AcctTypeID,P.Code As ClientID,

ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitPostType
      	
FROM 
	
ServicePlacesView P,Service_Types R,AccountChartServicesMapping M, AccountChatsView A,AccountPostingType T,
ServiceLinePayments S, AccountsChartJournalMapping J, ServicesConfigurationSetupView V
	
WHERE 

M.ServiceTypeID=2 And S.Service_Fee>0 And S.PmtTypeCode =1 And S.Archived ='No' AND R.ServiceCode=S.ServiceCode AND P.Code =R.ServicePlaceCode AND J.TransTypeID=1 And A.Code=J.AcctCodeJE And 
T.Code=J.AcctJEPostType And J.TransTypeID=M.PostingType And J.AcctCodeJE=M.AccountChartCode  AND S.PmtTypeCode=1 and S.SponsorNo='' AND M.ServiceTypeID=2
And A.Code=M.AccountChartCode And J.AcctJEPostType=2  And ((V.AcctsServicesMapID=4 and M.ServiceID = R.ServicePlaceCode And M.ServiceTypeID=2) OR
(V.AcctsServicesMapID=3 and M.ServiceID = R.ServiceTypeCode And M.ServiceTypeID=2) OR (V.AcctsServicesMapID=2 and M.ServiceID = R.ServiceCode And M.ServiceTypeID=2))
			
UNION ALL

--DRUGS CASH SALE
SELECT
	
S.ServiceCode,S.Service_Fee *S.PaidQty as PaidAmt,S.PmtDate,J.TransTypeID, J.AcctCodeJE AS AcctsCode,UPPER(A.Description) as AcctsName,
UPPER(T.Description) as PostType,UPPER(P.Description) as ClientName, M.ServiceTypeID, '' As TransID,A.TypeDescription,A.AcctTypeID,P.Code As ClientID,

ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitPostType
      		      	
FROM 
	
ServicePlacesView P,Prescriptions R,AccountChartServicesMapping M, AccountChatsView A,AccountPostingType T,
ServiceLinePayments S, AccountsChartJournalMapping J, ServicesConfigurationSetupView V, Items I
	
WHERE 

M.ServiceTypeID=1 And S.Service_Fee>0 And I.ItemID=R.DrugCode And S.PmtTypeCode =1 And S.Archived ='No' AND R.DrugCode=S.ServiceCode And R.RecordID=S.ServiceID AND P.Code =R.StoresID AND J.TransTypeID=1  and S.BillCategoryCode=1
And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.TransTypeID=M.PostingType AND S.PmtTypeCode=1 and S.SponsorNo=''  And J.AcctJEPostType=2 AND V.AcctsDrugsMapID<>0
And A.Code=M.AccountChartCode And J.AcctCodeJE=M.AccountChartCode  AND M.ServiceTypeID=1 And ((V.AcctsDrugsMapID=4 and M.ServiceID = R.StoresID And M.ServiceTypeID=1) OR
(V.AcctsDrugsMapID=3 and M.ServiceID = 1 And M.ServiceTypeID=1) OR (V.AcctsDrugsMapID=2 and M.ServiceID = R.DrugCode And M.ServiceTypeID=1)  OR (V.AcctsDrugsMapID=5 and M.ServiceID = CONVERT(NVarchar(15),I.ItemClassCode) AND M.ServiceTypeID=1) 
 OR (V.AcctsDrugsMapID=6 and M.ServiceID = CONVERT(NVarchar(15),I.ItemTypeCode) AND M.ServiceTypeID=1))
			
UNION ALL

--BILLS APPROXIMATIONS
SELECT
	
'',R.BillApprox As PaidAmt,R.PmtDate,12 AS TransTypeID,
ISNULL((Select TOP 1 J.AcctCodeJE From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=12 AND J.AcctTypeIDJE=12 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=12 AND J.AcctTypeIDJE=12 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctsName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=12 AND J.AcctTypeIDJE=12 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As PostType,

--M.ServiceTypeID, '' As TransID,A.TypeDescription,A.AcctTypeID,
'',10, '' As TransID,'',12,'',

ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitPostType

FROM 

BillsPaid R WHERE R.BillApprox >0 And R.Archived ='No' 

UNION ALL

--DEPOSIT PAYMENTS
SELECT
	
'', R.AmtPaid PaidAmt,R.PmtDate,3 AS TransTypeID,
ISNULL((Select TOP 1 J.AcctCodeJE From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctsName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As PostType,

'',6, '' As TransID,'',8,'',

ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitPostType

FROM 

BillsPaid R WHERE R.Archived ='No' AND R.AmtPaid>0  and R.ReceiptNo IN (SELECT D.ReceiptNo FROM Deposits D WHERE Archived='No')
			
UNION ALL

--IOUS PAYMENTS
SELECT
	
'', R.IouAmtPaid as PaidAmt,R.PmtDate,4 AS TransTypeID,
ISNULL((Select TOP 1 J.AcctCodeJE From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=4 AND J.AcctTypeIDJE=5 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=4 AND J.AcctTypeIDJE=5 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctsName, 

'CREDIT' As PostType,

'',7, '' As TransID,'',5,'',

ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitPostType

FROM 

BillsPaid R WHERE R.Archived ='No' AND R.IouAmtPaid>0
			
UNION ALL

--IOUS
SELECT
	
'', R.IOUAmt as PaidAmt,R.PmtDate,8 AS TransTypeID,
ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctsName, 

'CREDIT' As PostType,

'',7, '' As TransID,'',5,'',

ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=8 AND J.AcctTypeID=5 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=8 AND J.AcctTypeID=5 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=8 AND J.AcctTypeID=5 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitPostType

FROM 

BillsPaid R WHERE R.Archived ='No' AND R.IOUAmt>0
			
UNION ALL
-- DISCOUNTS
SELECT
	
'', R.DisAmt as PaidAmt,R.PmtDate,9 AS TransTypeID,

ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctsName, 

'CREDIT' As PostType,'',9, '' As TransID,'',9,'',

ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=9 AND J.AcctTypeID=2 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=9 AND J.AcctTypeID=2 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitAcctName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=9 AND J.AcctTypeID=2 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As DebitPostType

FROM 
BillsPaid R WHERE R.DisAmt >0 And R.Archived ='No'


UNION All

--SERICES REFUND
SELECT
	
S.ServiceCode, S.Service_Fee *S.RefundQty as PaidAmt,S.RefundDate,J.TransTypeID, 

ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctsName, 

'CREDIT' As PostType,UPPER(P.Description),2, '' As TransID,'',11,P.Code As ClientID,

J.AcctCodeJE AS AcctsCode,UPPER(A.Description) as AcctsName,
'DEBIT' as PostType
	      	
FROM 
	
ServicePlacesView P,Service_Types R,AccountChartServicesMapping M, AccountChartSetup A,
RefundServiceLines S, AccountsChartJournalMapping J, ServicesConfigurationSetupView V
	
WHERE 

M.ServiceTypeID=2 And S.Service_Fee>0 And S.PmtTypeCode =1 AND R.ServiceCode=S.ServiceCode AND P.Code =R.ServicePlaceCode AND J.TransTypeID=1 
And A.Code=J.AcctCodeJE  And J.TransTypeID=M.PostingType AND S.PmtTypeCode=1 And J.AcctJEPostType=2
And A.Code=M.AccountChartCode And J.AcctCodeJE=M.AccountChartCode And M.ServiceTypeID=2
And A.Code=M.AccountChartCode And J.AcctJEPostType=2  And ((V.AcctsServicesMapID=4 and M.ServiceID = R.ServicePlaceCode And M.ServiceTypeID=2) OR
(V.AcctsServicesMapID=3 and M.ServiceID = R.ServiceTypeCode And M.ServiceTypeID=2) OR (V.AcctsServicesMapID=2 and M.ServiceID = R.ServiceCode And M.ServiceTypeID=2))
			

UNION ALL

--DRUGS REFUND
SELECT
	
S.ServiceCode, S.Service_Fee *S.RefundQty as PaidAmt,S.RefundDate,J.TransTypeID, 

ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctsName, 

'CREDIT' As PostType,UPPER(P.Description),1, '' As TransID,'',11,P.Code As ClientID,

J.AcctCodeJE AS AcctsCode,UPPER(A.Description) as AcctsName,'DEBIT' as PostType
	      	
FROM 
	
ServicePlacesView P,Prescriptions R,AccountChartServicesMapping M, AccountChartSetup A,
RefundServiceLines S, AccountsChartJournalMapping J, ServicesConfigurationSetupView V, Items I
	
WHERE 

M.ServiceTypeID=1 And S.Service_Fee>0 And I.ItemID=R.DrugCode And S.PmtTypeCode =1 AND R.DrugCode=S.ServiceCode And R.RecordID=S.ServiceID AND P.Code =R.StoresID AND J.TransTypeID=1 
And A.Code=J.AcctCodeJE  And J.TransTypeID=M.PostingType AND S.PmtTypeCode=1 And J.AcctJEPostType=2
And A.Code=M.AccountChartCode And J.AcctCodeJE=M.AccountChartCode AND V.AcctsDrugsMapID<>0  And M.ServiceTypeID=1
And A.Code=M.AccountChartCode And J.AcctCodeJE=M.AccountChartCode  AND M.ServiceTypeID=1 And ((V.AcctsDrugsMapID=4 and M.ServiceID = R.StoresID) OR
(V.AcctsDrugsMapID=3 and M.ServiceID = 1 And M.ServiceTypeID=1) OR (V.AcctsDrugsMapID=2 and M.ServiceID = R.DrugCode And M.ServiceTypeID=1)  OR (V.AcctsDrugsMapID=5 and M.ServiceID = CONVERT(NVarchar(15),I.ItemClassCode) AND M.ServiceTypeID=1)
 OR (V.AcctsDrugsMapID=6 and M.ServiceID = CONVERT(NVarchar(15),I.ItemTypeCode) AND M.ServiceTypeID=1))
			
UNION ALL

--REFUND PAYMENTS 1 - EXCESS DEPOSITS  PAYMENT
SELECT
	
'', R.AmtPaid-L.RefundAmt as PaidAmt,R.PmtDate,7 AS TransTypeID,

ISNULL((Select TOP 1 J.AcctCodeJE From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=7 AND J.AcctTypeIDJE=11 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=7 AND J.AcctTypeIDJE=11 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctsName, 

'CREDIT' As PostType,'',8, '' As TransID,'',11,'',

ISNULL((Select TOP 1 J.AcctCodeJE From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctsName, 

'DEBIT' As PostType

FROM 

BillsRefunds R, ReceiptNoRefundServiceLinesView L WHERE  R.AmtPaid-L.RefundAmt >0 And R.Archived ='No'  and R.ReceiptNo=L.RefundReceiptNo
			
UNION ALL

--REFUND PAYMENTS 2 - EXCESS DEPOSITS  PAYMENT
SELECT
	
'', R.AmtPaid as PaidAmt,R.PmtDate,7 AS TransTypeID,
ISNULL((Select TOP 1 J.AcctCodeJE From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=7 AND J.AcctTypeIDJE=11 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=7 AND J.AcctTypeIDJE=11 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctsName, 

'CREDIT' As PostType,'',8, '' As TransID,'',11,'',

ISNULL((Select TOP 1 J.AcctCodeJE From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As DebitAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As DebitAcctsName, 

'DEBIT' As DebitPostType

FROM 

BillsRefunds R WHERE R.Archived ='No' AND R.AmtPaid>0 and R.ReceiptNo NOT IN (Select F.RefundReceiptNo From RefundServiceLines F)

UNION ALL
			
--DEPOSITS USED 
SELECT 

'', R.DepAmtUsed As PaidAmt,R.PmtDate,3 AS TransTypeID,
ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctsName, 

'CREDIT' As PostType,'',6, '' As TransID,'',8,'',

ISNULL((Select TOP 1 J.AcctCodeJE From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As DebitAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As DebitAcctsName, 

'DEBIT' As DebitPostType

FROM 

BillsPaid R WHERE R.Archived ='No' AND R.DepAmtUsed>0
go

