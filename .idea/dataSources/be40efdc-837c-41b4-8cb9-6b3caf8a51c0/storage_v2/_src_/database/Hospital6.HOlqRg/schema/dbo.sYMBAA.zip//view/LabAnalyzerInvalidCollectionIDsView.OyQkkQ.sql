CREATE VIEW [dbo].[LabAnalyzerInvalidCollectionIDsView]

AS

Select I.AnalyzerCode, I.ElementID, Range, I.Result, I.SpecimenID, TestDate, I.ServerTime, I.Unit, I.TestUserName,CONVERT(Datetime, CONVERT(varchar, I.ServerTime,100)) As TestTime,
I.TestUserID, T.Description, T.TestDescription, TestID, CatID, L.Description As Analyzer, UnitMeasure, ElementOrder, ResultValueType, ValueOptional, ElementIsActive, T.IsActive,I.ID 
From Interface I, TestElementsView T,LabAnalyzersView L, LabAnalyzerElements E Where SpecimenID NOT IN (Select SpecimenCode From LabSpecimenCollection) And I.ElementID=T.ElementID 
and L.RecordID=AnalyzerCode and I.AnalyzerCode<>0 and E.MappedElement=I.ElementID And L.RecordID=E.AnalyzerID And AnalyzerCode=E.AnalyzerID
go

