CREATE VIEW [dbo].[AccountTypesView]

AS

SELECT  Description, Code, ID FROM dbo.AccountTypes

Union

SELECT  '' As Description, '' As Code,0 As ID FROM dbo.Hosp_Info
go

