
CREATE FUNCTION [dbo].[GetPatientAddress]

(@OPDNo AS NVARCHAR(15)) RETURNS NVARCHAR(max)

AS

BEGIN

Declare @PatientAddress NVARCHAR(max)='',@District NVARCHAR(max)='',@Region NVARCHAR(max)='',@Town NVARCHAR(max)='',@Street NVARCHAR(max)=''

Select Top 1 @Region=ViewRegions.Description,@District=ViewDistricts.Description,@Town=TwnName,@Street=IsNull(HomeStreet,'') From ViewRegions Inner Join (ViewDistricts Inner Join (ViewTowns Inner Join PatientsInfo On TwnID=HomeTownID) On ViewDistricts.ID=HomeDistrictID) On ViewRegions.ID=HomeRegionID Where PatientsInfo.OPDNo=@OPDNo 

set @PatientAddress=@Street

if @Town<>''
   set @PatientAddress=@PatientAddress + ',' + @Town
   
if @District<>''
   set @PatientAddress=@PatientAddress + ',' + @District
   
if @Region<>''
   set @PatientAddress=@PatientAddress + ',' + @Region  + ' REGION'
   

RETURN UPPER(@PatientAddress)

END


go

