CREATE VIEW [dbo].[NHIASetupInfoView]

AS

select TOP 1 * From NHIASetupInfo
go

