
CREATE FUNCTION [dbo].[GetPatientActualAdmissionDate]

(@OPDNo AS NVARCHAR(15),@RecordID Numeric(18,0)) RETURNS Date

AS

BEGIN

Declare @AdmissionDate Date='',@OldAdmRecordID Numeric(18,0),@NewAdmRecordID Numeric(18,0)

Select Top 1 @AdmissionDate=AdmDate, @OldAdmRecordID=OldAdmRecordID, @NewAdmRecordID=NewAdmRecordID From Admissions Inner Join WardTransfers On Admissions.RecordID=OldAdmRecordID Where Admissions.OPDNo=@OPDNo And Admissions.Archived='No' And (NewAdmRecordID=@RecordID Or OldAdmRecordID=@RecordID) Order By OldAdmRecordID, NewAdmRecordID, AdmDate
If @@rowcount<=0
   Select Top 1 @AdmissionDate=AdmDate From Admissions Where Admissions.OPDNo=@OPDNo And Admissions.Archived='No' And RecordID=@RecordID 

RETURN @AdmissionDate

END


go

