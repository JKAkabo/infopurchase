CREATE FUNCTION [dbo].[GetWardRemainedPrevNightCount]

(@WardID AS NVARCHAR(15),@CurrentDate DateTime) RETURNS numeric(18,0)

AS

BEGIN

Declare @RemainedPrevNightCount Numeric(18,0),@RemainedPrevNightCount1 Numeric(18,0),@WardState Numeric(18,0),
@PrevDate DateTime,@StateDate DateTime

set @WardState=0

set @RemainedPrevNightCount=0

set @RemainedPrevNightCount1=0

Set @PrevDate=dateadd(d,-1,@CurrentDate)

select @StateDate=SetupDate, @WardState=InitialBedState From Wards where WardID=@WardID

if @StateDate Is NOT Null

   if @StateDate=@CurrentDate   
   
      RETURN @WardState
   
   Else if @StateDate>@CurrentDate
      RETURN 0
      
   else
     BEGIN
								select @RemainedPrevNightCount=IsNull(SUM(AdmCount),0) from DailyWardAdmissionsCountView where AdmDate>=@StateDate and AdmDate<=@PrevDate and WardID=@WardID

								select @RemainedPrevNightCount1=IsNull(SUM(DisCount),0) from DailyWardDischargesCountView where AdmDate>=@StateDate and AdmDate<=@PrevDate and WardID=@WardID
     END
     
else 
BEGIN  
			select @RemainedPrevNightCount=IsNull(SUM(AdmCount),0) from DailyWardAdmissionsCountView where AdmDate<=@PrevDate and WardID=@WardID

			select @RemainedPrevNightCount1=IsNull(SUM(DisCount),0) from DailyWardDischargesCountView where AdmDate<=@PrevDate and WardID=@WardID
END

RETURN @RemainedPrevNightCount+@WardState-@RemainedPrevNightCount1;

END
go

