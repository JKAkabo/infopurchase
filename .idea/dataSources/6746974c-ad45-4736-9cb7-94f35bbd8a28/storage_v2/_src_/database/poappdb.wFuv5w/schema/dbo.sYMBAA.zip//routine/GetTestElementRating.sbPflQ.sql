CREATE FUNCTION [dbo].[GetTestElementRating]

(@TestElementID AS numeric(18,0),@TestResult AS NVARCHAR(100),@NormalRange AS NVARCHAR(200)) RETURNS tinyint

AS

BEGIN

DECLARE @strg NVARCHAR(4000),@y int,@x int,@w int,@z tinyint,@strg1 NVARCHAR(4000),@strg2 NVARCHAR(4000);

set @strg = rtrim(lTrim(@NormalRange));

set @TestResult= rtrim(lTrim(@TestResult));

If @strg = '' 

   if @TestElementID = 0 RETURN 0
   
	  BEGIN
	   --(((rtrim(lTrim(LowerValue)) = @TestResult OR rtrim(lTrim(UpperValue)) = @TestResult) And ResultValueType= 2) Or (convert(numeric(18,2),LowerValue)  <=convert(numeric(18,2),@TestResult) and convert(numeric(18,2),UpperValue)  >=convert(numeric(18,2),@TestResult))
	    
	    Select @y=ResultValueType From TestElements Where Code=@TestElementID
	    
	    if @y=1 
	       Select TOP 1 @strg1=TestElementNormalValuesView.LowerValue, @strg2=TestElementNormalValuesView.UpperValue From AgeGroupValuesView Inner Join TestElementNormalValuesView On AgeGroupValuesView.RecordID=TestElementNormalValuesView.AgeGroupID Where ElementID=@TestElementID AND (((rtrim(lTrim(TestElementNormalValuesView.LowerValue)) = @TestResult OR rtrim(lTrim(TestElementNormalValuesView.UpperValue)) = @TestResult) And ResultValueType= 2) Or (convert(numeric(18,2),TestElementNormalValuesView.LowerValue)  <=convert(numeric(18,2),@TestResult) and convert(numeric(18,2),TestElementNormalValuesView.UpperValue)  >=convert(numeric(18,2),@TestResult))) Order By LowerAgeUnit, UpperAgeUnit, AgeGroupValuesView.LowerValue, AgeGroupValuesView.UpperValue
	    
	    else
	       Select TOP 1 @strg1=TestElementNormalValuesView.LowerValue, @strg2=TestElementNormalValuesView.UpperValue From AgeGroupValuesView Inner Join TestElementNormalValuesView On AgeGroupValuesView.RecordID=TestElementNormalValuesView.AgeGroupID Where ElementID=@TestElementID AND upper(rtrim(lTrim(TestElementNormalValuesView.LowerValue))) = upper(@TestResult)  OR upper(rtrim(lTrim(TestElementNormalValuesView.UpperValue))) =upper( @TestResult)
	    
	    if @@RowCount<>0 
		   Set @z= 1
				
	    else
		   Set @z= 2
	   
	   
	    RETURN @z
	   
	  END
   
If charindex('-', @strg, 1) = 0 

   Begin
   
	 If @strg = @TestResult
	      
		Set @z= 1
	   
	 Else
	    Set @z= 2
   
   
   RETURN @z
   
   End
   
Set @y = Len(@strg)

Set @x = 0

Set @z = 0

While @x < @y

  Begin
  
   If charindex('-', @strg, @x)<>0
	  Begin
	    Set @w = @x
	    Set @strg2 = Right(@strg, Len(@strg) - @w)
	    Set @strg1 = left(@strg,  @w-1)
	   
	    if convert(numeric(18,2),@strg1)  <=convert(numeric(18,2),@TestResult) and convert(numeric(18,2),@strg2)  >=convert(numeric(18,2),@TestResult)
	      
		   Set @z= 1
	   
	    else
		   Set @z= 2
	   		  
	  End

	  Set @x = @x+1
	  
  End
  
  RETURN @z

END
go

