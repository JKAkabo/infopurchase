CREATE VIEW [dbo].[QBStockAdjustmentDownWardLinesView]

AS

Select RecordID As TransID, UnitCost, OldQty-ApprovedQty As MoveQty,  StockAdjustmentApprovalLines.ItemID, ApproveDate As TransDate, StockAdjustmentApprovals.StoreID As IssuerID, StockAdjustmentApprovals.UserID As ReceiverID,'Stock Adjustments' As MoveType,UPPER(Service_Places.Description) As ClientName, Items.Description As ServiceDescription, Items.ItemID As ServiceCode, Convert(Nvarchar(15),ItemClassCode) As ItemClassCode 
From Service_Places Inner Join (StockAdjustmentApprovals Inner Join (Items Inner Join  StockAdjustmentApprovalLines On Items.ItemID= StockAdjustmentApprovalLines.ItemID) ON StockAdjustmentApprovals.ApproveID= StockAdjustmentApprovalLines.ApprID) On Code=StockAdjustmentApprovals.StoreID Where OldQty-ApprovedQty>0 And ReasonCode<>9 And  StockAdjustmentApprovalLines.Archived='No' And StockAdjustmentApprovals.Archived='No' And  StockAdjustmentApprovalLines.ItemID IN 
(Select Items.ItemID From Items Inner Join QBAcctsMappingView ON Convert(Nvarchar(15),ItemClassCode)=ServiceID)

--UPPER(Service_Places.Status)='YES' And
go

