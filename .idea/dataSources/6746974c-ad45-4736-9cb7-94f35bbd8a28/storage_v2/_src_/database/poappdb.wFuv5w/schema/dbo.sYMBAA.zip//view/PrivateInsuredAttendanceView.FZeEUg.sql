
CREATE VIEW [dbo].[PrivateInsuredAttendanceView]

AS
--Select Distinct IsNull(HFAC,'') As HFAC, DirectID, ClinicCode, Pat_No, ClaimPrinted, ClaimDataProcessed,ClaimPrintDate, ClaimPrintedBy, D.RecordID, 2 As StatusCode, D.OPDNo, AttDate As admDate, AttDate As DisDate, AttAge From TempMedicalClaims, D Where TempMedicalClaims.StatusCode=2 And TempMedicalClaims.StatusCode = D.StatusCode And TempMedicalClaims.BeginDate = D.AttDate And TempMedicalClaims.OPDNo = D.OPDNo

SELECT Distinct 3 AS StatusCode, AdmRecID As RecordID, S.SponsorNo, A.OPDNo, AdmDate, DisDate, AttDate, A.AdmAge As AttAge From AdmissionDischrgesView A, ServicesRevenueView S Where (A.OPDNo=S.OPDNo And AttDate>=AdmDate And AttDate<=DisDate) And S.BillCategoryCode NOT IN (1,0,4,11) and S.SponsorNo<>'' And S.PmtTypeCode IN (2)

Union All

SELECT Distinct 2 As StatusCode,D.RecordID,S.SponsorNo,S.OPDNo, ReqDate,ReqDate, D.AttAge,ReqDate FROM Daily_Attendance D, ServicesRevenueView S 
Where (D.OPDNo=S.OPDNo and D.AttDate=S.AttDate) And D.StatusCode=2 and S.StatusCode=2 and BillCategoryCode NOT IN (1,0,4,11) And S.SponsorNo<>'' And PmtTypeCode IN (2,3) And ((ServiceTypeCode=5 and attType<>2) OR (AttServiceID<>0 and attType<>2) OR (ServiceTypeCode IN (11,12,13,14) And attType=2)) and D.RecordID NOT IN (Select D.RecordID FROM 
Daily_Attendance D, AdmissionDischrgesView A, ServicesRevenueView S Where D.OPDNo= A.OPDNo And D.OPDNo= S.OPDNo And S.AttDate>=AdmDate And S.AttDate<=DisDate And D.AttDate=S.AttDate)
go

