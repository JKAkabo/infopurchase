CREATE VIEW [dbo].[PrescriptionsView]

AS

SELECT Distinct DirectID, Pat_No, P.OPDNo, Left(I.Description,100) As Description, P.PaymentCode, P.BillCycleDuration, P.PmtTypeCode, P.BillMethodCode, P.PmtModeCode, StoresID, 
SponsorNo, PresTime, PresDate, clinicCode, DrugCode, ExRate, P.BillCategoryCode ,UnitPrice,UnitCost,QtyGiven As IssuedQty, P.ReqDate, ReturnedQty,Method,PrescribeUnit,
QtyPrescribed,AttServiceID,PresType,CoPayBillCategoryCode,CoPayFee,CoPayPaidQty,CoPaySponsorNo,CoPayPmtTypeCode,P.StatusCode, PatAge,EpisodeID, AttType, EpisodeType,
P.PatCategoryCode, PaidQty,  PaidAmt, PmtDate, PmtTime, S.Description As Pharmacy, convert(numeric(18,2), Units) As Dosage, convert(NVARCHAR(100), Dosage) As Frequency, 
IsNull((Select TOP 1 Description From PatientCategoryView Where PatientCategoryView.Code=P.BillCategoryCode Order By CatPriority),'') As BillCategory,
IsNull((Select TOP 1 Description From PatientCategoryView Where PatientCategoryView.Code=P.CoPayBillCategoryCode and CoPayFee>UnitPrice Order By CatPriority),'') As COPayBillCategory,
IsNull((Select TOP 1 Description From ServicePlacesView Where Code=StoresID),'') As ServicePlace,P.ReceiptNo As AuthorizationCode,
IsNull((Select TOP 1 Description From PaymentTypessView Where Code=p.PmtTypeCode),'') As PaymentType,Issued,PatientAge,Gender,DOB,CellPhoneNo,IDNo,MemberID,LastName,SurName,MiddleName,Title,Nationality,StaffID ,
IsNull((Select TOP 1 Description From PaymentTypessView Where Code=CoPayPmtTypeCode),'') As COPayPaymentType,IsNull((Select TOP 1 UserID From UsersView Where UserNo=P.UserID),'') As PrescriptionEnteredBy,
IsNull((Select TOP 1 SponsorName From SponsorsView Where SponsorsView.SponsorNo=P.SponsorNo Order By AttPriority),'') As Sponsor,
IsNull((Select TOP 1 Description From ClinicsView Where SPCode=ClinicCode),'') As Clinic,IsNull((Select TOP 1 UserID From UsersView Where UserNo=P.Prescriber),'') As PrescribedBy,
IsNull((Select TOP 1 UsersView.UserID From UsersView, DispensedPrescriptions D Where PresID=P.RecordID and D.UserID=UserNo ),'') As DispensedBy ,
(Select TOP 1 DispensedTime From DispensedPrescriptions D Where PresID=P.RecordID) As DispensedTime,IsNull((Select TOP 1 DispensedQty From DispensedPrescriptions D Where PresID=P.RecordID),0) As DispensedQty,
IsNull((Select TOP 1 DispenserID From DispensedPrescriptions D Where PresID=P.RecordID),'') As DispenserID,IsNull((Select TOP 1 D.RecordID From DispensedPrescriptions D Where PresID=P.RecordID),0) As DispensedID,
IsNull((Select TOP 1 Description From ServicePlacesView, DispensedPrescriptions D Where PresID=P.RecordID and D.StoreID=Code ),'') As DispensedPharmacy,
IsNull((Select TOP 1 Description From PatientStatusView Where Code=P.StatusCode),'') As PatStatus,
IsNull((Select TOP 1 SponsorName From SponsorsView Where SponsorsView.SponsorNo=P.CoPaySponsorNo and CoPayFee>UnitPrice Order By AttPriority),'') As COPaySponsor,
convert(int, PresDays) As Duration, Prescriber, RecordID, P.UserID,P.ServerTime,PatName,ReceiptNo From ServicePlacesView S, Items I, Prescriptions P, PatientInfoView
Where Archived='No' and I.ItemID=DrugCode and S.Code = StoresID and PatientInfoView.PatientID=P.OPDNo and PatientInfoView.OPDNo=Pat_No
go

