
CREATE VIEW [dbo].[MentalStateElementsView]

AS

SELECT E.OrderNo As ElementOrderNo, M.OrderNo As TypeOrderNo, E.Description As ElementType,M.Description As StateType, E.Code  As ElementCode, 
M.Code As TypeCode, E.ID As ElementID, M.ID As TypeID, E.GenderCode,  M.GenderCode As TypeGenderCode, E.IsActive, G.Description As Gender, E.ValuesTypeID FROM
dbo.MentalStateGroupElements E, GenderGroups G, MentalStateGroups M where G.Code=E.GenderCode and E.GroupID=M.ID and M.IsActive='Yes'


go

