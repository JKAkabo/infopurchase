


CREATE VIEW [dbo].[StoreItemsStockLevelAtDateView]

AS

SELECT IsNull(Sum(StockLevel),0) As StockLevel, ItemID, StoreID FROM Service_Places Inner Join ItemsStockLevels ON  Code=StoreID Where StockLevel>=0 And UPPER(Service_Places.Status)='YES' Group By StoreID, ItemID



go

