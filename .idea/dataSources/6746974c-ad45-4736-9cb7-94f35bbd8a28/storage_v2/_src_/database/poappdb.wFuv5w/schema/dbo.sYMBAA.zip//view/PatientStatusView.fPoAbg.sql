CREATE VIEW [dbo].[PatientStatusView]

AS

SELECT Distinct upper(Description) As Description, Code FROM dbo.PatientStatus

Union

SELECT  '' As Description, 0 As Code FROM dbo.Hosp_Info
go

