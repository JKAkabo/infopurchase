

CREATE VIEW [dbo].[OrderSuppliersView]

AS

SELECT  Description, Code FROM dbo.Service_Places

Union

SELECT  ContactName, SupplierID FROM dbo.Suppliers

Union

SELECT  '' As Description, '' As Code FROM dbo.Hosp_Info


go

