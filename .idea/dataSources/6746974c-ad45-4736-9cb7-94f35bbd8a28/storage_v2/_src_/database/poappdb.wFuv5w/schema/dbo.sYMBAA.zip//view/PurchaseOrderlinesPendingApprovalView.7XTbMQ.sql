CREATE VIEW [dbo].[PurchaseOrderlinesPendingApprovalView]

AS

Select L.*, Packs.CashPrice, Packs.CreditPrice, Packs.NGPrice, Packs.NHISPrice, Items.Description, ItemTypeCode, Expirable, ItemClassCode,
ISNULL((Select TOP 1 ApprovedQty from PurchaseOrderLines P Where P.OrderLineID=L.OrderLineID and P.Archived='No' Order By P.RecordID Desc) ,0) As ApprovedQty
From Items, Packs, OrderLines L, Orders Where Orders.OrderNo=L.OrderID And Packs.ItemID = L.ItemID And Items.ItemID = L.ItemID
and OrderLineStatus IN (1) and OrderType=1 and Orders.Archived='No' and L.Archived='No' and OrderStatus IN (1,2,13,14) 
 And L.OrderLineID NOT IN (Select P.OrderLineID From PurchaseOrderApprovals A, PurchaseOrderLines P Where A.ApproveID =P.ApproveID And P.Archived='No' And A.Archived='No' And A.OrderNo=L.OrderID And L.OrderLineID=P.OrderLineID)
go

