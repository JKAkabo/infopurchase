CREATE VIEW [dbo].[QBExcessDepositRefundView]
AS
SELECT    
           RefRecordID As TransID
          ,BillsRefunds.OPDNo As ServiceCode
          ,ExcessRefund   AS PaidAmt
          ,PmtDate   As TransDate
          ,'0104' as IssuerID
          ,BillsRefunds.Pat_No As ReceiverID
          ,BillsRefunds.Pat_No+' '+'EXCESS DEPOSIT REFUND'  As ServiceDescription
          ,Surname+' '+LastName As ClientName 
          ,'Excess Deposit Refund' As MoveType
FROM        
           dbo.BillsRefunds   Inner Join
           PatientsInfo 
           On BillsRefunds .OPDNo =PatientsInfo.OPDNo 
WHERE    
          (ExcessRefund>0)
go

