CREATE VIEW [dbo].[DrugsRefundInterfaceView]
AS
SELECT     dbo.DrugsRefund.OPDNo, dbo.DrugsRefund.Pat_No, dbo.DrugsRefund.Status, dbo.DrugsRefund.PmtDate, dbo.DrugsRefund.PmtTime, 
                      dbo.DrugsRefund.ReceiptNo, dbo.DrugsRefund.AmtPaid, dbo.DrugsRefund.DollarTBill, dbo.DrugsRefund.UserID, dbo.DrugsRefund.CAP_ID, 
                      dbo.DrugsRefund.Archived, dbo.DrugsRefund.ArchivedDate, dbo.DrugsRefund.ArchivedTime, dbo.DrugsRefund.ArchiverID, dbo.DrugsRefund.DeptID, 
                      SponsoredPatients.IDNo as EmpNo , dbo.DrugsRefund.ExRate, dbo.DrugsRefund.Drug_Type, dbo.DrugsRefund.SerQty, dbo.DrugsRefund.Comments, 
                      dbo.DrugsRefund.RecMode, dbo.DrugsRefund.OldAmt, dbo.DrugsRefund.ServerDate, dbo.DrugsRefund.ServerTime, dbo.DrugsRefund.RecID, 
                      dbo.DrugsRefund.Transfered, dbo.DrugsRefund.RecNo, dbo.DrugsRefund.PatCategory, dbo.SponsoredPatients.SponsorNo
FROM         dbo.DrugsRefund INNER JOIN
                      dbo.SponsoredPatients ON dbo.DrugsRefund.OPDNo = dbo.SponsoredPatients.OPDNo
WHERE     (dbo.SponsoredPatients.Archived = N'No') AND (dbo.SponsoredPatients.SponsorNo = N'000001')  and DrugsRefund.Archived='No' And DrugsRefund.ArchivedDate Is Null

UNION ALL

SELECT     dbo.DrugsRefund.OPDNo, dbo.DrugsRefund.Pat_No, dbo.DrugsRefund.Status, DrugsRefund.ArchivedDate As PmtDate, DrugsRefund.ArchivedTime As PmtTime, 
                      dbo.DrugsRefund.ReceiptNo, -(dbo.DrugsRefund.AmtPaid) As AmtPaid, -dbo.DrugsRefund.DollarTBill, dbo.DrugsRefund.UserID, dbo.DrugsRefund.CAP_ID, 
                      dbo.DrugsRefund.Archived, dbo.DrugsRefund.ArchivedDate, dbo.DrugsRefund.ArchivedTime, dbo.DrugsRefund.ArchiverID, dbo.DrugsRefund.DeptID, 
                      SponsoredPatients.IDNo as EmpNo , dbo.DrugsRefund.ExRate, dbo.DrugsRefund.Drug_Type, dbo.DrugsRefund.SerQty, dbo.DrugsRefund.Comments, 
                      dbo.DrugsRefund.RecMode, dbo.DrugsRefund.OldAmt, dbo.DrugsRefund.ServerDate, dbo.DrugsRefund.ServerTime, dbo.DrugsRefund.RecID, 
                      dbo.DrugsRefund.Transfered, dbo.DrugsRefund.RecNo, dbo.DrugsRefund.PatCategory, dbo.SponsoredPatients.SponsorNo
FROM         dbo.DrugsRefund INNER JOIN
                      dbo.SponsoredPatients ON dbo.DrugsRefund.OPDNo = dbo.SponsoredPatients.OPDNo
WHERE     (dbo.SponsoredPatients.Archived = N'No') AND (dbo.SponsoredPatients.SponsorNo = N'000001') and DrugsRefund.Archived='Yes' And DrugsRefund.ArchivedDate Is Not Null
go

