




CREATE VIEW [dbo].[NutritionConsultationDoctorsView]

AS

SELECT Distinct NutritionUnit.AttID, NutritionUnit.OPDNo, NutritionUnit.ClinicCode, 2 As PatStatus, NutritionUnit.NutDate, DoctorID As NutritionistID, UserCategories.Description as CategoryName, users.UserID as Nutritionist  FROM UserCategories Inner Join (Users Inner Join (UserClinics Inner Join NutritionUnit On UserClinics.UserCode=NutritionUnit.DoctorID) On UserNo=UserCode) On UserCategories.CatID=Users.CatID Where NutritionUnit.Archived='No'



go

