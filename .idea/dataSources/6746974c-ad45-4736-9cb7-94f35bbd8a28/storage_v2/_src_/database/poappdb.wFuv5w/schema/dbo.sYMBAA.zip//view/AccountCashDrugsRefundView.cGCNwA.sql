CREATE VIEW [dbo].[AccountCashDrugsRefundView]

AS

SELECT
	
S.ServiceCode, S.Service_Fee *S.RefundQty as TransAmt,S.RefundDate As TransDate,J.TransTypeID, 

ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As CreditAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As CreditAcctName, 

'CREDIT' As CreditPostType,UPPER(P.Description) As ClientName,1 As ServiceTypeID, '' As TransID,'' As TypeDescription,11 As AcctTypeID,P.Code As ClientID,

J.AcctCodeJE AS DebitAcctCode,UPPER(A.Description) as DebitAcctName,'DEBIT' as DebitPostType
	      	
FROM 
	
ServicePlacesView P,Prescriptions R,AccountChartServicesMapping M, AccountChartSetup A,
RefundServiceLines S, AccountsChartJournalMapping J, ServicesConfigurationSetupView V, Items I
	
WHERE 

M.ServiceTypeID=1 And S.Service_Fee>0 And I.ItemID=R.DrugCode And S.PmtTypeCode =1 AND R.DrugCode=S.ServiceCode And R.RecordID=S.ServiceID AND P.Code =R.StoresID AND J.TransTypeID=1 
And A.Code=J.AcctCodeJE  And J.TransTypeID=M.PostingType AND S.PmtTypeCode=1 And J.AcctJEPostType=2
And A.Code=M.AccountChartCode And J.AcctCodeJE=M.AccountChartCode AND V.AcctsDrugsMapID<>0  And M.ServiceTypeID=1
And A.Code=M.AccountChartCode And J.AcctCodeJE=M.AccountChartCode  AND M.ServiceTypeID=1 And ((V.AcctsDrugsMapID=4 and M.ServiceID = R.StoresID) OR
(V.AcctsDrugsMapID=3 and M.ServiceID = 1 And M.ServiceTypeID=1) OR (V.AcctsDrugsMapID=2 and M.ServiceID = R.DrugCode And M.ServiceTypeID=1)  OR (V.AcctsDrugsMapID=5 and M.ServiceID = CONVERT(NVarchar(15),I.ItemClassCode) AND M.ServiceTypeID=1)
 OR (V.AcctsDrugsMapID=6 and M.ServiceID = CONVERT(NVarchar(15),I.ItemTypeCode) AND M.ServiceTypeID=1))
go

