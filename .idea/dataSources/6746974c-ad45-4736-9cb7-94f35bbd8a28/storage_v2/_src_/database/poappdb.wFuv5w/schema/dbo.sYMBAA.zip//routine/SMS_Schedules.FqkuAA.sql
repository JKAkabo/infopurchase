-- =============================================
-- Author:		<Author,,Faisal>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SMS_Schedules] 
	-- Add the parameters for the stored procedure here
	
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	SET NOCOUNT ON;

	IF NOT EXISTS(SELECT ActivateSMS FROM Hosp_Info WHERE ActivateSMS='Yes')
	   RETURN

	DECLARE @MsgTypeID tinyint;
	DECLARE @AgeGroup tinyint;
	DECLARE @GenderGroup tinyint;
	DECLARE @OnceFreq tinyint;
	DECLARE @msgContent nvarchar(max);
	DECLARE @Consent nvarchar(3);
	DECLARE @msgType nvarchar(100);
	DECLARE @allAgeGroup tinyint;
	DECLARE @allGenderGroup tinyint;
	DECLARE @childAgeLimit tinyint;
	DECLARE @adultAgeLimit tinyint;
	DECLARE @allAgeLimit tinyint;
	DECLARE @includePatName nvarchar(3);

	set @OnceFreq=6; 
	set @allAgeGroup=3; 
	set @allGenderGroup=1;
	set @childAgeLimit=11
	set @adultAgeLimit=12;
	set @allAgeLimit=150;

	SELECT @MsgTypeID=h.TypeCode,@msgContent=h.MsgContent,@Consent=h.EnforceConsent,@AgeGroup=h.AgeGroupCode,
	@GenderGroup=h.GenderCode,@includePatName=h.includeRPT
	FROM  HamsSMSSetup h,HamsMessageTypes m ,Hosp_Info i
	WHERE h.TypeCode=m.Code and i.ActivateSMS='Yes' and h.Active='Yes' and  h.TypeCode IN (6, 7,16)
	

	If @@RowCount<=0 
	   RETURN
	   
	BEGIN  	
	  --CHRISTMAS AND NEW YEAR=7,16 
		if @MsgTypeID=7 or @MsgTypeID=16				
					insert into bulksms_db.dbo.sending_queue([From],[To],message)
					select 'System',CellPhoneNo,@msgContent FROM SMSPatientInfoView WHERE ((@GenderGroup=@allGenderGroup) OR (GenderCode=@GenderGroup)) And 
					Rtrim(Ltrim(CellPhoneNo))<>'' And CellPhoneNo Is Not Null  And ((@Consent='Yes' And ExpiryAlert='Yes') or @Consent='No')	
					And ((datediff(year,DOB,GETDATE())<=@childAgeLimit and @AgeGroup=1) OR (datediff(year,DOB,GETDATE())>=@adultAgeLimit and @AgeGroup=2) OR @AgeGroup=3)
		
		--BIRTH DAY WISHES=6			 			
		if @MsgTypeID=6 			
					insert into bulksms_db.dbo.sending_queue([From],[To],message)
					select 'System',CellPhoneNo,@msgContent FROM SMSPatientInfoView WHERE ((@GenderGroup=@allGenderGroup) OR (GenderCode=@GenderGroup)) And 
					Rtrim(Ltrim(CellPhoneNo))<>'' And CellPhoneNo Is Not Null  And ((@Consent='Yes' And ExpiryAlert='Yes') or @Consent='No')	And MONTH(DOB)=MONTH(GETDATE()) And DAY(DOB)=DAY(GETDATE())
					And ((datediff(year,DOB,GETDATE())<=@childAgeLimit and @AgeGroup=1) OR (datediff(year,DOB,GETDATE())>=@adultAgeLimit and @AgeGroup=2) OR @AgeGroup=3)
	END
	
END
go

