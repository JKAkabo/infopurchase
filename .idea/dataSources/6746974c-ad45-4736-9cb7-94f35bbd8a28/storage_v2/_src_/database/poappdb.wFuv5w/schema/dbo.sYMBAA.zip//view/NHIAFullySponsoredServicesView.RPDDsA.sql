CREATE VIEW [dbo].[NHIAFullySponsoredServicesView]

AS

Select A.* From Sponsors S, AllServicesRevenueView A Where A.BillCategoryCode IN (4,11) And A.SponsorNo<>'' And A.SponsorNo=S.SponsorNo And CoPayed='No' And A.PmtTypeCode IN (2,3) And SponsorTypeCode=2
go

