CREATE VIEW [dbo].[ServiceRequestedUsersView]

AS

SELECT Distinct Users.UserID, Users.UserNo, UserCategories.Description, UserClinics.ClinicCode From UserCategories Inner Join (Users Inner Join UserClinics On UserCode=UserNo) On UserCategories.CatID=Users.CatID Where Users.Archived='No' And User_Locked='No'

Union

SELECT Distinct Users.UserID, Users.UserNo, UserCategories.Description, '' As ClinicCode  From UserCategories Inner Join Users On UserCategories.CatID=Users.CatID Where Users.Archived='No' And User_Locked='No' And UserNo Not In (Select Distinct UserCode From UserClinics)
go

