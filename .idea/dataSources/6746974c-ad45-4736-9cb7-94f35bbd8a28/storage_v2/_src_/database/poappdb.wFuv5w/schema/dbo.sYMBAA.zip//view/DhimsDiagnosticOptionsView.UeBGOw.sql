
CREATE VIEW [dbo].[DhimsDiagnosticOptionsView]

AS

SELECT  Description, ID, IsActive FROM dbo.DHIMSDiagnosticOptions

Union

SELECT TOP 1 '' As Description, 0 As ID, 'No' As IsActive FROM dbo.Hosp_Info



go

