

CREATE VIEW [dbo].[NHIARefillEpisodesView]

AS

SELECT Distinct Episode.*, ServiceDate From Episode Inner Join NHIAEpisodePrescriptionsView On Episode.EpisodeID=NHIAEpisodePrescriptionsView.EpisodeID where Archived='No' and NoOfVisit>0  and EndEpisode Is Not Null and IsRefill='Yes'



go

