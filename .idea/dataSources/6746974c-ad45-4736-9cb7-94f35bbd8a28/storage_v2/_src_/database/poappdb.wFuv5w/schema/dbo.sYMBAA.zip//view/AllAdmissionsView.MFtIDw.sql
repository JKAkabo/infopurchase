CREATE VIEW [dbo].[AllAdmissionsView]

AS

SELECT  RecordID, 'ADMISSIONS' AS AdmRecordType, 1 As RecordSerialNo, OPDNo, Pat_No, AdmDate, AdmTime, DisDate, DisTime, AdmAge,DisAge, PatCategoryCode,Insured, DoctorID,DisAuthouriser, Admissions.WardID, BedNo, BedType, Transfered, ClinicCode,Admissions.DischargeStatusCode,Admissions.EpisodeID,BillCategoryCode, SponsorNo
FROM    dbo.Admissions where Archived='No' And DischargeStatusCode<>2 and RecordID Not IN (Select Distinct NewAdmRecordID from WardTransfers Where Archived='No')

UNION

SELECT  RecordID, 'TRANSFERS IN' AS AdmRecordType, 2 As RecordSerialNo, Admissions.OPDNo, Pat_No, AdmDate, AdmTime, DisDate, DisTime,AdmAge,DisAge, PatCategoryCode,Insured, DoctorID,DisAuthouriser, Admissions.WardID, BedNo, BedType, Transfered,ClinicCode,Admissions.DischargeStatusCode,Admissions.EpisodeID,BillCategoryCode, SponsorNo
FROM         dbo.Admissions Inner Join WardTransfers on RecordID=NewAdmRecordID where Admissions.Archived='No' and WardTransfers.Archived='No' And DischargeStatusCode<>2  

UNION

SELECT  RecordID, 'TRANSFERS OUT' AS AdmRecordType, 4 As RecordSerialNo, Admissions.OPDNo, Pat_No,AdmDate, AdmTime, DisDate, DisTime,AdmAge,DisAge, PatCategoryCode,Insured, DoctorID,DisAuthouriser, Admissions.WardID, BedNo, BedType, Transfered,ClinicCode,Admissions.DischargeStatusCode,Admissions.EpisodeID,BillCategoryCode, SponsorNo
FROM         ( dbo.Admissions Inner Join WardTransfers on RecordID=OldAdmRecordID) where Admissions.Archived='No' and WardTransfers.Archived='No' And DischargeStatusCode<>2  

UNION

SELECT  RecordID, 'DISCAHRGES' AS AdmRecordType, 3 As RecordSerialNo, OPDNo, Pat_No, AdmDate, AdmTime,DisDate, DisTime, AdmAge, DisAge, PatCategoryCode,Insured, DoctorID,DisAuthouriser, Admissions.WardID, BedNo, BedType, Transfered, ClinicCode,Admissions.DischargeStatusCode,Admissions.EpisodeID,BillCategoryCode, SponsorNo
FROM         dbo.Admissions where Archived='No' and Discharged='Yes' and Transfered='No' and DisDate Is Not Null  And DischargeStatusCode<>2  and RecordID Not IN (Select Distinct OldAdmRecordID from WardTransfers Where Archived='No')

UNION

SELECT  RecordID, 'DEATHS' AS AdmRecordType, 5 As RecordSerialNo, Admissions.OPDNo, Admissions.Pat_No, AdmDate, AdmTime, DisDate, DisTime, AdmAge, DisAge, admissions.PatCategoryCode, admissions.Insured, Admissions.DoctorID,DisAuthouriser, Admissions.WardID, BedNo, BedType, Transfered,Admissions.ClinicCode,Admissions.DischargeStatusCode,Admissions.EpisodeID,BillCategoryCode, SponsorNo
FROM   dbo.Admissions where Admissions.Archived='No' And DischargeStatusCode=2  and Discharged='Yes' and Transfered='No' and DisDate Is Not Null  And RecordID Not IN (Select Distinct NewAdmRecordID from WardTransfers Where Archived='No')
go

