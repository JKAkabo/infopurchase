

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetNonStockItemsForPrescriptions] 
	-- Add the parameters for the stored procedure here

	@ItemDescription nvarchar(250),@itemType tinyint =0,@AgeGroupCode tinyint=3,@GenderCode tinyint=1,@PatientType tinyint=1
	
AS

declare @allAgeGroupCode tinyint,@allGenderCode tinyint,@allPatientType tinyint;

BEGIN

set @allAgeGroupCode =3
set @allGenderCode =1
set @allPatientType =1

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	if @itemType<>0
	  Select Distinct Items.Description, StockType, ItemTypeCode, ManufacturerCode, PresentationCode,Expirable,Items.DefaultMethodCode,PresQuanityPerIssueUnit,PresSpecType, AllowCoPay,
	  IssueUnitQuantity,PresUnitQuantity,PresUnitCode,AgeGroupCode,GenderCode, IssueUnitCode, UnitMeasures.Description As Unit_Name , Items.ItemID, PresLevel, MinPresQty, MaxPresQty  From UnitMeasures 
	  Inner Join  Items  On UnitMeasures.Code = Items.IssueUnitCode  Where Items.Description Like @ItemDescription + '%' And  StockType=2 And ItemTypeCode =@itemType  And 
	  (AgeGroupCode =@AgeGroupCode Or AgeGroupCode =@allAgeGroupCode) And (PatientType=@PatientType Or PatientType=@allPatientType) And (GenderCode=@GenderCode Or GenderCode=@allGenderCode) and Items.Disabled ='No' Order by Items.Description Asc
	
	else
	 Select Distinct Items.Description,StockType, ItemTypeCode, ManufacturerCode, PresentationCode,Expirable,Items.DefaultMethodCode,PresQuanityPerIssueUnit,PresSpecType, AllowCoPay,
	  IssueUnitQuantity,PresUnitQuantity,PresUnitCode,AgeGroupCode,GenderCode, IssueUnitCode, UnitMeasures.Description As Unit_Name , Items.ItemID, PresLevel, MinPresQty, MaxPresQty  From UnitMeasures 
	  Inner Join  Items  On UnitMeasures.Code = Items.IssueUnitCode  Where Items.Description Like @ItemDescription + '%' And  StockType=2 And 
	  (AgeGroupCode =@AgeGroupCode Or AgeGroupCode =@allAgeGroupCode) And (PatientType=@PatientType Or PatientType=@allPatientType) And (GenderCode=@GenderCode Or GenderCode=@allGenderCode) and Items.Disabled ='No' Order by Items.Description Asc
	  
END


go

