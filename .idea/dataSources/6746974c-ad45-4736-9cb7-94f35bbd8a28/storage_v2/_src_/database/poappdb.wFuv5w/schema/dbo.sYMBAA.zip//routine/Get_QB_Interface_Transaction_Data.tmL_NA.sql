-- =============================================
	-- Author:		<Author,,Name>
	-- Create date: <Create Date,,>
	-- Description:	<Description,,>
	-- =============================================
	CREATE FUNCTION [dbo].[Get_QB_Interface_Transaction_Data] 
	(	
		-- Add the parameters for the function here
		@ServicePlace nvarchar(max), @fromDate nvarchar(20),@toDate nvarchar(20),@TransactionID int
	)
	RETURNS TABLE 
	AS
   
	RETURN 
	(
	
		-- Add the SELECT statement with parameter references here
	   
	---STOCK OPENING BALANCE
	select u.Code as AccountCode,u.Description As AccountName,Round(Sum(isnull(Amount,0)),2) as Amount ,tbl.Overseer,tbl.MoveOrder,u.ID as AccountID,'Debit' As EntryType,'OTHER CURRENT ASSET' as AccountType,'AUTOMATIC OPENING BALANCE POSTING' AS Memo,@TransactionID as ActivityTypeID,tbl.MoveDate ,''ClientName from AccountChartSetup U cross apply 
	(select (s.UnitCost *s.AdjustQty )Amount,C.Overseer as Overseer,s.MoveOrder,s.MoveDate from STOCKMOVEMENT s,Items i,AccountChartServicesMapping m,AccountsSubClassServicePlaceMapping O,AccountClassView C
	Where s.ItemID =i.ItemID and m.ServiceID =i.ItemClassCode and m.AcctCode =U.ID and s.ReceiverID =O.ServicePlaceCode and O.SubClassID =C.RecordID AND S.MoveDate>=@fromDate and S.MoveDate< =@toDate and s.ReceiverID in (@ServicePlace)and MoveType ='Initial Stocks' and m.AccountTypeID =6 AND u.categoryID=4 )tbl
	WHERE  @TransactionID=1
	GRoup by code,Description ,Overseer ,MoveOrder,ID,MoveDate

	union all

	select (select Code FROM AccountChartsetup WHERE ID=185) as AccountCode,(select Description FROM AccountChartsetup WHERE ID=185) as AccountName,Round(Sum(isnull(s.UnitCost *s.AdjustQty,0)),2) As Amount,C.Overseer as Overseer,s.MoveOrder,'185' as AccountID,'Credit'EntryType,'Equity' as AccountType,'AUTOMATIC OPENING BALANCE POSTING' as Memo,@TransactionID as ActivityTypeID,s.MoveDate,''ClientName  from STOCKMOVEMENT s,Items i,AccountChartServicesMapping m,AccountsSubClassServicePlaceMapping O,AccountClassView C,AccountChartSetup u
	Where s.ItemID =i.ItemID and m.ServiceID =i.ItemClassCode and m.AcctCode =U.ID and s.ReceiverID =O.ServicePlaceCode and O.SubClassID =C.RecordID AND S.MoveDate>=@fromDate and S.MoveDate< =@toDate and s.ReceiverID in (@ServicePlace)and MoveType ='Initial Stocks' and m.AccountTypeID =6 and u.CategoryID=4  and @TransactionID=1
	Group by Overseer,MoveOrder,ID,MoveDate

	union all
	---PURCHASES RECEIPTS
	select u.Code As AccountCode,u.Description As AccountName,Round(Sum(isnull(tbl.Amount,0)),2) as Amount ,tbl.Overseer,tbl.MoveOrder,u.ID as AccountID,'Debit' As EntryType,'EXPENSE' as AccountType,'AUTOMATIC PURCHASE RECEIPT POSTING' AS Memo,@TransactionID as ActivityTypeID,tbl.MoveDate,(SELECT ContactName From Suppliers WHERE SupplierID=tbl.IssuerID) as ClientName  from AccountChartSetup U cross apply 
	(select (s.UnitCost *s.AdjustQty )Amount,Overseer,m.AccountTypeID,s.MoveOrder,s.MoveDate,s.IssuerID from STOCKMOVEMENT s,Items i,AccountChartServicesMapping m,AccountsSubClassServicePlaceMapping O,AccountClassView C
	Where    s.ItemID =i.ItemID and m.ServiceID =i.ItemClassCode and m.AcctCode =U.ID and s.ReceiverID =O.ServicePlaceCode and O.SubClassID =c.RecordID AND S.MoveDate>=@fromDate and S.MoveDate <=@toDate and s.ReceiverID in (@ServicePlace)and MoveType ='orders' And m.AccountTypeID =2  AND u.categoryID=3 )tbl
	WHERE  @TransactionID=2
	GRoup by Code,Description ,OverSeer,MoveOrder ,ID,MoveDate,tbl.IssuerID

	UNION ALL

	select u.Code As AccountCode,u.Description As AccountName,Round(Sum(isnull(tbl.Amount,0)),2) as Amount ,tbl.Overseer,tbl.MoveOrder,U.ID as AccountID,'Credit' As EntryType,'ACCOUNT PAYABLES' as AccountType,'AUTOMATIC PURCHASE RECEIPT POSTING' AS Memo,@TransactionID as ActivityTypeID,tbl.MoveDate,(SELECT ContactName From Suppliers WHERE SupplierID=tbl.IssuerID) as ClientName  from AccountChartSetup U cross apply 
	(select (s.UnitCost *s.AdjustQty )Amount, Overseer,m.AccountTypeID,s.MoveOrder,s.MoveDate,S.IssuerID  from STOCKMOVEMENT s,AccountChartServicesMapping m,AccountsSubClassServicePlaceMapping O,AccountClassView C
	Where   s.IssuerID   =m.ServiceID    and m.AcctCode =U.ID     and s.ReceiverID =O.ServicePlaceCode and O.SubClassID =C.RecordID AND S.MoveDate>=@fromDate and S.MoveDate <=@toDate and s.ReceiverID in (@ServicePlace)and MoveType ='orders'And m.AccountTypeID =11   AND u.categoryID=7 )tbl
	where @TransactionID=2 GRoup by Code,Description ,OverSeer,MoveOrder,ID ,MoveDate,IssuerID
    
    UNION ALL
    
    ---INTERNAL ISSUES
    
    select u.Code As AccountCode,u.Description As AccountName,Round(Sum(isnull(tbl.Amount,0)),2) as Amount ,tbl.Overseer,tbl.MoveOrder,u.ID as AccountID,'Debit' As EntryType,'OTHER CURRENT ASSET' as AccountType,'AUTOMATIC INTERNAL ISSUES POSTING' AS Memo,@TransactionID as ActivityTypeID,tbl.MoveDate,(select Description  from Service_Places where Code=tbl.ReceiverID   )As ClientName   from AccountChartSetup U cross apply 
	(select (s.UnitCost *s.AdjustQty )Amount,Overseer,m.AccountTypeID,s.MoveOrder,s.MoveDate,s.ReceiverID  from STOCKMOVEMENT s,Items i,AccountChartServicesMapping m,AccountsSubClassServicePlaceMapping O,AccountClassView C
	Where   s.ItemID =i.ItemID and m.ServiceID =i.ItemClassCode and m.AcctCode =U.ID and s.ReceiverID =O.ServicePlaceCode and O.SubClassID =c.RecordID AND S.MoveDate>=@fromDate and S.MoveDate <=@toDate and  s.IssuerID in (@ServicePlace) and MoveType ='Requisitions' And m.AccountTypeID =6   AND u.categoryID=4 )tbl
	WHERE  @TransactionID=3
	GRoup by Code,Description ,OverSeer,MoveOrder ,ID,MoveDate,tbl.ReceiverID 
    
    
    UNION ALL

	
	select u.Code As AccountCode,u.Description As AccountName,Round(Sum(isnull(tbl.Amount,0)),2) as Amount ,tbl.Overseer,tbl.MoveOrder,u.ID as AccountID,'Credit' As EntryType,'OTHER CURRENT ASSET' as AccountType,'AUTOMATIC INTERNAL ISSUES POSTING' AS Memo,@TransactionID as ActivityTypeID,tbl.MoveDate,(select Description  from Service_Places where Code=tbl.ReceiverID   )As ClientName  from AccountChartSetup U cross apply 
	(select (s.UnitCost *s.AdjustQty )Amount,Overseer,m.AccountTypeID,s.MoveOrder,s.MoveDate,s.ReceiverID   from STOCKMOVEMENT s,Items i,AccountChartServicesMapping m,AccountsSubClassServicePlaceMapping O,AccountClassView C
	Where   s.ItemID =i.ItemID and m.ServiceID =i.ItemClassCode and m.AcctCode =U.ID and s.IssuerID =O.ServicePlaceCode and O.SubClassID =c.RecordID AND S.MoveDate>=@fromDate and S.MoveDate <=@toDate and  s.IssuerID in (@ServicePlace)and MoveType ='Requisitions' And m.AccountTypeID =6   AND u.categoryID=4 )tbl
	WHERE  @TransactionID=3
	GRoup by Code,Description ,OverSeer,MoveOrder ,ID,MoveDate,tbl.ReceiverID  
	
    
	)
go

