
CREATE VIEW [dbo].[ItemsUOMView]

AS

SELECT  Items.Description, ItemCode, UnitCode, ItemUOMS.IssueUnitQuantity, 2 As TypeCode, UnitMeasures.Description As UOM, ItemUOMS.IsActive, ItemUOMS.RecordID, AveUnitCost*ItemUOMS.IssueUnitQuantity As ItemCost, Disabled, Expirable As ItemExpirable,AveUnitCost As BaseCost FROM UnitMeasures Inner Join (Items Inner Join dbo.ItemUOMS On ItemID=ItemCode) On UnitMeasures.Code=UnitCode Where UnitMeasures.IsActive='Yes' And  ItemUOMS.IsActive='Yes' And Disabled='No' and UnitMeasures.TypeCode=2 and ItemUOMS.IssueUnitQuantity<>0

Union

SELECT  Items.Description, ItemID, IssueUnitCode, IssueUnitQuantity, UnitMeasures.TypeCode, UnitMeasures.Description As UOM, UnitMeasures.IsActive, 1 As RecordID, Items.AveUnitCost as ItemCost, Disabled, Expirable As ItemExpirable,AveUnitCost As BaseCost FROM UnitMeasures Inner Join Items On UnitMeasures.Code=IssueUnitCode Where UnitMeasures.IsActive='Yes' And Disabled='No' And ItemID + convert(Nvarchar(15),UnitMeasures.Code) NOT IN (Select ItemCode + convert(Nvarchar(15),UnitCode) From ItemUOMS Where ItemUOMS.IsActive='Yes')

go

