CREATE PROCEDURE [dbo].[uspUpdatePatientOldConsultationRecords] 
	
AS

DECLARE @DisCode nvarchar(500), @GDRGCode numeric(18,0);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  --EXAMS FINDINGS
  DECLARE C CURSOR FAST_FORWARD FOR SELECT DISTINCT E.System, C.ID From ExamFindings E, ClinicalSystems C Where E.SystemID=0 AND Cancelled='No' and RTRIM(LTRIM(ExamFind))<>'' AND (('%' + RTRIM(LTRIM(E.System)) + '%') LIKE ('%' + C.DESCRIPTION + '%') OR RTRIM(LTRIM(E.System))= C.DESCRIPTION OR '%' + RTRIM(LTRIM(E.System)) + '%' LIKE C.DESCRIPTION OR RTRIM(LTRIM(E.System)) LIKE '%' + C.DESCRIPTION + '%') order By C.ID
  
  OPEN C
  
  FETCH NEXT FROM C INTO @DisCode, @GDRGCode;

  WHILE @@fetch_status = 0
    BEGIN

       update ExamFindings Set SystemID=@GDRGCode Where System=@DisCode
              
       FETCH NEXT FROM C INTO @DisCode, @GDRGCode;

	END
    
	CLOSE C;

	DEALLOCATE C;
	
	
	update ExamFindings Set SystemID=1 Where System='GENERAL'  and RTRIM(LTRIM(ExamFind))<>'' and Cancelled='No'


  DECLARE C CURSOR FAST_FORWARD FOR SELECT DISTINCT E.System, C.ID From InPatientExamFindings E, ClinicalSystems C Where E.SystemID=0 AND Cancelled='No' and RTRIM(LTRIM(ExamFind))<>'' AND (('%' + RTRIM(LTRIM(E.System)) + '%') LIKE ('%' + C.DESCRIPTION + '%') OR RTRIM(LTRIM(E.System))= C.DESCRIPTION OR '%' + RTRIM(LTRIM(E.System)) + '%' LIKE C.DESCRIPTION OR RTRIM(LTRIM(E.System)) LIKE '%' + C.DESCRIPTION + '%') order By C.ID
  
  OPEN C
  
  FETCH NEXT FROM C INTO @DisCode, @GDRGCode;

  WHILE @@fetch_status = 0
    BEGIN

       update InPatientExamFindings Set SystemID=@GDRGCode Where System=@DisCode
              
       FETCH NEXT FROM C INTO @DisCode, @GDRGCode;

	END
    
	CLOSE C;

	DEALLOCATE C;
	
	
	update InPatientExamFindings Set SystemID=1 Where (System='GENERAL' Or SystemID=0)  and RTRIM(LTRIM(ExamFind))<>'' and Cancelled='No'


  --complaints SETUP
  DECLARE C CURSOR FAST_FORWARD FOR SELECT DISTINCT E.Category, C.ID From Complaints E, ClinicalSystems C Where E.SysID=0 and RTRIM(LTRIM(E.Description))<>'' AND (('%' + RTRIM(LTRIM(E.Category)) + '%') LIKE ('%' + C.DESCRIPTION + '%') OR RTRIM(LTRIM(E.Category))= C.DESCRIPTION OR '%' + RTRIM(LTRIM(E.Category)) + '%' LIKE C.DESCRIPTION OR RTRIM(LTRIM(E.Category)) LIKE '%' + C.DESCRIPTION + '%') order By C.ID
  
  OPEN C
  
  FETCH NEXT FROM C INTO @DisCode, @GDRGCode;

  WHILE @@fetch_status = 0
    BEGIN

       update Complaints Set SysID=@GDRGCode Where Category=@DisCode
              
       FETCH NEXT FROM C INTO @DisCode, @GDRGCode;

	END
    
	CLOSE C;

	DEALLOCATE C;
	
	update Complaints Set SysID=1 Where Category='GENERAL' or SysID=0
	
	
	  --system reviews/complaints
  DECLARE C CURSOR FAST_FORWARD FOR SELECT DISTINCT C.Complaint, E.CompID From Complaints E, ConComplaints C Where ComplaintID=0 and RTRIM(LTRIM(E.Description))<>'' AND (('%' + UPPER(RTRIM(LTRIM(E.Description))) + '%') LIKE ('%' + UPPER(RTRIM(LTRIM(C.Complaint))) + '%') OR UPPER(RTRIM(LTRIM(E.Description)))= UPPER(RTRIM(LTRIM(C.Complaint))) OR '%' + UPPER(RTRIM(LTRIM(E.Description))) + '%' LIKE UPPER(RTRIM(LTRIM(C.Complaint))) OR UPPER(RTRIM(LTRIM(E.Description))) LIKE '%' + UPPER(RTRIM(LTRIM(C.Complaint))) + '%') order By E.CompID
  
  OPEN C
  
  FETCH NEXT FROM C INTO @DisCode, @GDRGCode;

  WHILE @@fetch_status = 0
    BEGIN

       update ConComplaints Set ComplaintID=@GDRGCode Where Complaint=@DisCode
              
       FETCH NEXT FROM C INTO @DisCode, @GDRGCode;

	END
    
	CLOSE C;

	DEALLOCATE C;
	
  DECLARE C CURSOR FAST_FORWARD FOR SELECT DISTINCT C.Complaint, E.CompID From Complaints E, InPatientComplaints C Where ComplaintID=0 and RTRIM(LTRIM(E.Description))<>'' AND (('%' + UPPER(RTRIM(LTRIM(E.Description))) + '%') LIKE ('%' + UPPER(RTRIM(LTRIM(C.Complaint))) + '%') OR UPPER(RTRIM(LTRIM(E.Description)))= UPPER(RTRIM(LTRIM(C.Complaint))) OR '%' + UPPER(RTRIM(LTRIM(E.Description))) + '%' LIKE UPPER(RTRIM(LTRIM(C.Complaint))) OR UPPER(RTRIM(LTRIM(E.Description))) LIKE '%' + UPPER(RTRIM(LTRIM(C.Complaint))) + '%') order By E.CompID
  
  OPEN C
  
  FETCH NEXT FROM C INTO @DisCode, @GDRGCode;

  WHILE @@fetch_status = 0
    BEGIN

       update InPatientComplaints Set ComplaintID=@GDRGCode Where Complaint=@DisCode
              
       FETCH NEXT FROM C INTO @DisCode, @GDRGCode;

	END
    
	CLOSE C;

	DEALLOCATE C;	
	DECLARE C CURSOR FAST_FORWARD FOR SELECT TOP 1 CompID From Complaints  Where Description IN ('Other(s)............(Specify)','Other(s)','Other')
	 
	OPEN C

	FETCH NEXT FROM C INTO @GDRGCode;

	WHILE @@fetch_status = 0
	BEGIN

	   update ConComplaints Set ComplaintID=@GDRGCode Where Complaint NOT IN (SELECT Description From Complaints)
	   
	   update InPatientComplaints Set ComplaintID=@GDRGCode Where Complaint NOT IN (SELECT Description From Complaints)
	          
	   FETCH NEXT FROM C INTO @GDRGCode;

	END
    
	CLOSE C;

	DEALLOCATE C;	 
	
	DECLARE @Complaints nvarchar(max),@SysEnquiry nvarchar(max),@MedHistory nvarchar(max),@PatStatus Tinyint,@PatComplaint nvarchar(max)
	
	DECLARE C CURSOR FAST_FORWARD FOR SELECT EnqID, Complaints, SysEnquiry, MedHistory, PatStatus From AllSystemicEnquiriesView  Where Complaints<>'' Or MedHistory<>'' Or SysEnquiry<>''
	 
	OPEN C

	FETCH NEXT FROM C INTO @GDRGCode,@Complaints,@SysEnquiry,@MedHistory,@PatStatus;

	WHILE @@fetch_status = 0
	BEGIN
       SET @PatComplaint=''
       
       IF @Complaints<>''
          SET @PatComplaint=@Complaints

       IF @MedHistory<>''
          IF @PatComplaint<>''
             SET @PatComplaint= @PatComplaint + ', ' + @MedHistory
       
          ELSE
             SET @PatComplaint=@MedHistory
       
       IF @SysEnquiry<>''
          IF @PatComplaint<>''
             SET @PatComplaint= @PatComplaint + ', ' + @SysEnquiry
       
          ELSE
             SET @PatComplaint=@SysEnquiry
       
       IF @PatStatus=2      
	      update ConsultationEnquiriesComplaints Set Complaints=@PatComplaint Where RecordID=@GDRGCode
	   
	   ELSE
	      update InPatientEnquiriesComplaints Set Complaints=@PatComplaint Where RecordID=@GDRGCode
	          
	   FETCH NEXT FROM C INTO @GDRGCode,@Complaints,@SysEnquiry,@MedHistory,@PatStatus;

	END
    
	CLOSE C;

	DEALLOCATE C;	
	
	
Insert into PatientSystemsReview(ConsultationID,AttDate,AttTime,OPDNo,PatNo,PatStatus,SystemID,SymptomID,QueAnswer,Remarks,ClinicCode,DoctorID,PatAge,UserID) Select 
M.ConID,M.ConDate,M.ConTime,M.OPDNo,C.Pat_No,2,SysID,ComplaintID,0,'',ClinicCode,M.Doctor,ConAge,M.UserID From ConComplaints M, Consultations C, Complaints L where Cancelled='No'
and C.ConID=M.ConID and L.CompID=ComplaintID and M.OPDNo + '2' NOT IN (Select OPDNo + '2' From PatientSystemsReview Where PatStatus=2)
	
Insert into PatientSystemsReview(ConsultationID,AttDate,AttTime,OPDNo,PatNo,PatStatus,SystemID,SymptomID,QueAnswer,Remarks,ClinicCode,DoctorID,PatAge,UserID) Select Distinct 
M.RecordID,M.AdmDate,M.AdmTime,M.OPDNo,C.Pat_No,3,SysID,ComplaintID,0,'',IsNull((Select TOP 1 Admissions.ClinicCode From Admissions Where RecordID=C.AdmID And Archived='No'),''),M.DoctorID,M.PatAge,M.UserID From InPatientComplaints M, InPatientConsultations C, Complaints L where Cancelled='No'
and C.AdmID=M.AdmID and L.CompID=ComplaintID and M.OPDNo + '3' NOT IN (Select OPDNo + '3' From PatientSystemsReview Where PatStatus=3)
	   	
Insert into PatientPresentingComplaints(PatConID,ServerTime,PatID,PatStatus,Complaints,DoctorID,UserID) Select Distinct 
RecordID,AttTime,OPDNo,PatStatus,LTRIM(LTRIM(Complaints)),Doctor,UserID From AllSystemicEnquiriesView where LTRIM(LTRIM(Complaints))<>'' 
and OPDNo NOT IN (Select OPDNo From PatientPresentingComplaints) Order By AttTime, PatStatus
   		 	
Insert into PatientComplaintsHistory(PatConID,ServerTime,PatID,PatStatus,Complaints,DoctorID,UserID) Select Distinct 
RecordID,AttTime,OPDNo,PatStatus,LTRIM(LTRIM(MedHistory)),Doctor,UserID From AllSystemicEnquiriesView where LTRIM(LTRIM(MedHistory))<>'' 
and OPDNo NOT IN (Select OPDNo From PatientComplaintsHistory) Order By AttTime, PatStatus

Insert into PatientClinicalNotes(PatConID,ServerTime,PatID,PatStatus,Notes,DoctorID,UserID) Select Distinct 
RecordID,AttTime,OPDNo,PatStatus,LTRIM(LTRIM(Complaints)),Doctor,UserID From AllSystemicEnquiriesView where LTRIM(LTRIM(Complaints))<>'' 
and OPDNo NOT IN (Select OPDNo From PatientClinicalNotes) Order By AttTime, PatStatus

   		 			
END

go

