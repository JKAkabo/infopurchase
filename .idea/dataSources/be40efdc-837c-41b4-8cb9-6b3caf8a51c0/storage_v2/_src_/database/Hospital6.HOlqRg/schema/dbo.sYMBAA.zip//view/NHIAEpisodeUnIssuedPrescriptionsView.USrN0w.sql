
CREATE VIEW [dbo].[NHIAEpisodeUnIssuedPrescriptionsView]

AS

SELECT Distinct Left(ITEMS.Description,100) As ServiceDescription,Dosage As Frequency,presTable.PresDays As Duration, presTable.Units As Dosage, ITEMS.ItemID As ServiceCode, 1 As ServiceTypeCode, PmtTypeCode, 'MEDICINES' As ServicePlace , presTable.UnitPrice AS UnitFee, QtyPrescribed AS ServiceQty, ReqDate, Items.NHISCode As GDRDCode, EpisodeID, PresType As RequestType, OPDNo, 'No' As ServiceIssued, StatusCode As PatStatus, 'No' As IsRefill, ReqDate As ServiceDate, PresDate, DirectID, LevelOrder, '**' As CapID, ServerTime, SponsorNo , StoresID As SerPlaceID, presTable.OPDNo As PatID FROM NHIAPrescriptionLevels Inner Join (ITEMS inner Join Prescriptions as presTable On Items.ItemID=DrugCode) On NHIAPrescriptionLevels.ID = Items.PresLevel Where ITEMS.ItemID<>'' and Archived='No' and Refunded='No' and EpisodeID<>0 and QtyGiven=0 and ReturnedQty=0 and PmtTypeCode<>1 and SponsorNo<>'' and PresLevel<>0 and BillCategoryCode IN (4,11) And ReqDate<=servertime

go

