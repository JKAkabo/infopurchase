CREATE VIEW [dbo].[PatientInvoiceView]

AS

Select '' As ServicePoint, '' As Directorate, '' As ServiceType, '' As PaymentType, BillsPaid.Pat_No As PatientID, BillsPaid.PmtTime As InvoiceTime, BillsPaid.PmtDate As InvoiceDate, BillsPaid.ReceiptNo As InvoiceNo,BillsPaid.TAmtPaid As InvoiceAmt,
PayeeName As PatName ,GenderGroups.Description As Gender, CONVERT(nvarchar(10),BillsPaid.PatAge) As PatAge, PBOut As OutstandingBill, IOUAmt, PatientStatus.Description As PatientStatus, BillsPaid.Status As BillStatus From GenderGroups, PatientsInfo, BillsPaid, PatientStatus 
 Where BillsPaid.Archived='No' and PatientsInfo.OPDNo=BillsPaid.OPDNo and GenderGroups.Code=PatientsInfo.GenderCode and PatientStatus.Code=BillsPaid.StatusCode
go

