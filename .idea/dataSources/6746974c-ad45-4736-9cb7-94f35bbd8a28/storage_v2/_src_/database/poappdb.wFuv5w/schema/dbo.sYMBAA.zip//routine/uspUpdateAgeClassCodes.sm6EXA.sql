CREATE PROCEDURE [dbo].[uspUpdateAgeClassCodes] 
	
AS

DECLARE @MinPatAge int,@MaxPatAge int, @AgeClassCode tinyint;

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;

  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct  AgeClassCode , MinAge, MaxAge From ReportsAgeClassification Order by AgeClassCode Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO @AgeClassCode, @MinPatAge, @MaxPatAge;

  WHILE @@fetch_status = 0
    BEGIN
       
       update Consultations Set AgeClassCode=@AgeClassCode where PatAge>=@MinPatAge And PatAge<=@MaxPatAge
       
       update Admissions Set AdmAgeClassCode=@AgeClassCode where AdmAge>=@MinPatAge And AdmAge<=@MaxPatAge

       update Admissions Set DisAgeClassCode=@AgeClassCode where DisAge>=@MinPatAge And DisAge<=@MaxPatAge
       
       update AdmissionCauses Set AgeClassCode=@AgeClassCode where AdmAge>=@MinPatAge And AdmAge<=@MaxPatAge
       
       update Daily_Attendance Set AgeClassCode=@AgeClassCode where AttAge>=@MinPatAge And AttAge<=@MaxPatAge

       update Deaths Set AgeClassCode=@AgeClassCode where DeathAge>=@MinPatAge And DeathAge<=@MaxPatAge
       
       update DeathCauses Set AgeClassCode=@AgeClassCode where DisAge>=@MinPatAge And DisAge<=@MaxPatAge

       FETCH NEXT FROM C INTO @AgeClassCode, @MinPatAge, @MaxPatAge;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

