CREATE VIEW [dbo].[PatientMentalStateAnswersView]

AS

SELECT P.RecordID,OPDNo,AttDate,AttTime,Remarks,DoctorID,AttRecordID,ConsultationID,QueAnswer,P.ServerTime,P.UserID,PatStatus, V.* 
FROM dbo.PatientMentalState P, MentalStateElementAnswersView V where 
V.ElementID=P.QuestionID and V.TypeID=P.TypeID and V.AnswerID=P.QueAnswer and V.AnswerIsActive='Yes'
go

