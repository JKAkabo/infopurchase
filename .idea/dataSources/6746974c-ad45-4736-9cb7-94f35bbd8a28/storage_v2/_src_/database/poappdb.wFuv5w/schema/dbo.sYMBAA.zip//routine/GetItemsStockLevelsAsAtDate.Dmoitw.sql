-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetItemsStockLevelsAsAtDate] 
	-- Add the parameters for the stored procedure here

	@itemStore nvarchar(50),@itemID nvarchar(15) ,@asAtDate datetime, @stockState nvarchar(3)='',@ItemUnitType tinyint=1
    
	
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

if @ItemUnitType=0 
   Set @ItemUnitType=1 
   
--Select TOP 1 MoveOrder, ServerTime, MoveType, ReceiverID, IssuerID, ReceiverStock, IssuerStock, AdjustQty From STOCKMOVEMENT Where (ReceiverID= @itemStore Or IssuerID =@itemStore) and itemID=@itemID and ServerDate <=@asAtDate Order By MoveOrder Desc, ServerTime Desc
if UPPER(@stockState) <>'OUT'
			if @ItemUnitType=1 
					Select TOP 1 TransUnitType, MoveOrder, ServerTime, MoveType, ReceiverID, IssuerID, ReceiverStock, IssuerStock, AdjustQty,UnitCost,IssuerUOMID, ReceiverUOMID, BaseQty From STOCKMOVEMENT Where (ReceiverID= @itemStore Or IssuerID =@itemStore) and itemID=@itemID and ServerDate <=@asAtDate Order By  ServerTime Desc,MoveOrder Desc

			else
					Select TOP 1 TransUnitType, MoveOrder, ServerTime, MoveType, ReceiverID, IssuerID, convert(Numeric(18,6),ReceiverStock/BaseQty) As ReceiverStock, convert(Numeric(18,6),IssuerStock/BaseQty) As IssuerStock, convert(Numeric(18,6),AdjustQty/BaseQty) As AdjustQty, BaseQty*UnitCost As UnitCost,IssuerUOMID,ReceiverUOMID,BaseQty  From STOCKMOVEMENT Where (ReceiverID= @itemStore Or IssuerID =@itemStore) and itemID=@itemID and ServerDate <=@asAtDate Order By  ServerTime Desc,MoveOrder Desc

else
			if @ItemUnitType=1 
					Select TOP 1 TransUnitType, MoveOrder, ServerTime, MoveType, ReceiverID, IssuerID, ReceiverStock, IssuerStock, AdjustQty,UnitCost,IssuerUOMID, ReceiverUOMID, BaseQty From STOCKMOVEMENT Where (ReceiverID= @itemStore And ReceiverStock=0) Or (IssuerID =@itemStore  And IssuerStock=0) and itemID=@itemID and ServerDate <=@asAtDate Order By  ServerTime Desc,MoveOrder Desc

			else
					Select TOP 1 TransUnitType, MoveOrder, ServerTime, MoveType, ReceiverID, IssuerID, convert(Numeric(18,6),ReceiverStock/BaseQty) As ReceiverStock, convert(Numeric(18,6),IssuerStock/BaseQty) As IssuerStock, convert(Numeric(18,6),AdjustQty/BaseQty) As AdjustQty, BaseQty*UnitCost As UnitCost,IssuerUOMID,ReceiverUOMID,BaseQty  From STOCKMOVEMENT Where (ReceiverID= @itemStore And ReceiverStock=0) Or (IssuerID =@itemStore  And IssuerStock=0) and itemID=@itemID and ServerDate <=@asAtDate Order By  ServerTime Desc,MoveOrder Desc
	 
END
go

