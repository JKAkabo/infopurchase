CREATE PROCEDURE [dbo].[uspUpdateDrugNHIAFees] 
	
AS

DECLARE @itemID nvarchar(15),@ItemCost numeric(18,6),@UnitCost numeric(18,6);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct  ItemID, NHISPrice, UnitCost From Packs Where ItemID='D000081' Order by ItemID Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO @itemID, @ItemCost, @UnitCost;

  WHILE @@fetch_status = 0
    BEGIN
       
       update DispensedPrescriptions Set UnitPrice=@ItemCost, UnitCost=@UnitCost,ItemID='D000080' Where ItemID=@itemID and PresID IN (Select recordID From Prescriptions where DrugCode=@itemID and (BillCategoryCode=4 Or BillCategoryCode=11)  and SponsorNo<>'' And Archived='No' And PmtTypeCode IN (2,3))
        
       update ReturnedPrescriptions Set UnitPrice=@ItemCost, UnitCost=@UnitCost,ItemID='D000080' Where ItemID=@itemID and PresID IN (Select recordID From Prescriptions where DrugCode=@itemID and (BillCategoryCode=4 Or BillCategoryCode=11)  and SponsorNo<>'' And Archived='No' And PmtTypeCode IN (2,3))
       
       update Prescriptions Set UnitPrice=@ItemCost, UnitCost=@UnitCost,DrugCode='D000080' Where DrugCode=@itemID and (BillCategoryCode=4 Or BillCategoryCode=11)  and SponsorNo<>'' And Archived='No' And PmtTypeCode IN (2,3)
                     
       update STOCKMOVEMENT Set  UnitCost=@UnitCost,ItemID='D000080' Where ItemID=@itemID
            
       update NHIAEpisodeServices Set ServiceFee=@ItemCost, ServiceCode='D000080' Where ServiceCode=@itemID
       
       FETCH NEXT FROM C INTO @itemID, @ItemCost, @UnitCost;

	END

	CLOSE C;

	DEALLOCATE C;
	
    update Episode Set  DrugChanged='Yes' where DrugFee>0 And Archived='No'

END
go

