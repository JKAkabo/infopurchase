

CREATE VIEW [dbo].[FacilitiesView]

AS

SELECT * FROM dbo.Hosp_Info


go

