


CREATE VIEW [dbo].[DHIMSDataElementQueriesView]

AS

SELECT  ElementID, DataSetID, AgeRangeCode, AgeGroupCode, ElementQuery, TypeTag, TypeID FROM DHIMSDataElements Inner Join  DHIMS_ELEMENTS_QUERIES On ElementID=ElementCode Where IsActive='Yes'


go

