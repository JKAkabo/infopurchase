CREATE VIEW [dbo].[DispensedPrescriptionsView]

AS

SELECT Distinct Pat_No, P.OPDNo, I.Description, D.DispensedDate,D.DispensedTime, PaymentCode, P.BillCycleDuration, P.PmtTypeCode,QtyPrescribed,BeginDate,EndDate,
BillMethodCode, P.PmtModeCode, StoreID, SponsorNo, PresTime, PresDate, clinicCode,DrugCode, ExRate, P.BillCategoryCode ,D.UnitPrice,D.UnitCost,Method, 
D.DispensedQty - D.ReturnedQty As IssuedQty, P.ReqDate,D.DispensedQty,D.StatusCode, StockLevel, PresID, D.DispenserID, PresType, EpisodeID,AttServiceID,D.UserID,
AttType, EpisodeType, PatCategoryCode,PaidQty,  PaidAmt, PmtDate, PmtTime, S.Description As Pharmacy, D.Dosage, Frequency, Duration,Prescriber,PrescribeUnit,
PatientAge,Gender,DOB,CellPhoneNo,IDNo,MemberID,LastName,SurName,MiddleName,Title,Nationality,StaffID,IsNull((Select TOP 1 Description From PatientStatusView Where Code=P.StatusCode),'') As PatStatus,
IsNull((Select TOP 1 Description From PatientCategoryView Where PatientCategoryView.Code=P.BillCategoryCode Order By CatPriority),'') As BillCategory,
IsNull((Select TOP 1 Description From PatientCategoryView Where PatientCategoryView.Code=P.CoPayBillCategoryCode and CoPayFee>P.UnitPrice Order By CatPriority),'') As COPayBillCategory,
IsNull((Select TOP 1 Description From PaymentTypessView Where Code=P.PmtTypeCode),'') As PaymentType,P.ReceiptNo As AuthorizationCode,AdmissionWard,
IsNull((Select TOP 1 Description From PaymentTypessView Where Code=CoPayPmtTypeCode),'') As COPayPaymentType,IsNull((Select TOP 1 UserID From UsersView Where UserNo=P.UserID),'') As PrescriptionEnteredBy,
IsNull((Select TOP 1 SponsorName From SponsorsView Where SponsorsView.SponsorNo=P.SponsorNo Order By AttPriority),'') As Sponsor,
IsNull((Select TOP 1 Description From ClinicsView Where SPCode=ClinicCode),'') As Clinic,IsNull((Select TOP 1 UserID From UsersView Where UserNo=P.Prescriber),'') As PrescribedBy,
IsNull((Select TOP 1 UsersView.UserID From UsersView Where P.RecordID= D.PresID And D.UserID=UserNo ),'') As DispensedBy 
From Service_Places S, Items I, Prescriptions P, DispensedPrescriptions D, PatientInfoView Where Archived='No' And 
P.RecordID = D.PresID And I.ItemID=DrugCode And S.Code = D.StoreID and PatientInfoView.PatientID=P.OPDNo
go

