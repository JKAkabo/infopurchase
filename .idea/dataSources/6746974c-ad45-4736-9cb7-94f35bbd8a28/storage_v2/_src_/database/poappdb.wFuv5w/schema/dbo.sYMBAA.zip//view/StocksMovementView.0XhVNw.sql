CREATE VIEW [dbo].[StocksMovementView]

AS
--'Stock Adjustments','Initial Stocks','Obsolete Stocks'
--'Requisitions', 'Prescriptions','Return Inwards','Return Outward','Internal Item Usage','Expired Stocks'

SELECT MoveOrder,ItemID,UnitCost,ItemUnit,MoveQty,IssuerID,ReceiverID,MoveDate,MoveTime,MoveType, ReceiverStock,IssuerStock,AdjustQty,MoveNo,UserID,ServerDate,BaseQty,ServerTime,ReceiverUOMID,IssuerUOMID,TransUnitType,ExpiredStock, 

CASE WHEN MoveType IN ('Prescriptions','Return Inwards','Return Outward','Internal Item Usage','Expired Stocks') and rtrim(ltrim(IssuerID))<>'' and IssuerID is not Null THEN IssuerStock + ABS(AdjustQty) 

WHEN MoveType IN ('Orders','Return Inwards','Stock Adjustments','Initial Stocks','Obsolete Stocks','Prescription Returns','UnitCost Adjustment') and rtrim(ltrim(ReceiverID))<>'' and ReceiverID is not Null THEN ReceiverStock - AdjustQty END AS StockLevel,

CASE WHEN MoveType IN ('Prescriptions','Return Inwards','Return Outward','Internal Item Usage','Expired Stocks') and rtrim(ltrim(IssuerID))<>'' and IssuerID is not Null THEN IssuerStock 

WHEN MoveType IN ('Orders','Return Inwards','Stock Adjustments','Initial Stocks','Obsolete Stocks','Prescription Returns','UnitCost Adjustment') and rtrim(ltrim(ReceiverID))<>'' and ReceiverID is not Null THEN ReceiverStock END AS ActualStockLevel,

CASE WHEN MoveType IN ('Prescriptions','Return Inwards','Return Outward','Internal Item Usage','Expired Stocks') and rtrim(ltrim(IssuerID))<>'' and IssuerID is not Null THEN IssuerID 

WHEN MoveType IN ('Orders','Return Inwards','Stock Adjustments','Initial Stocks','Obsolete Stocks','Prescription Returns','UnitCost Adjustment') and rtrim(ltrim(ReceiverID))<>'' and ReceiverID is not Null THEN ReceiverID END AS StoreCode,

CASE WHEN MoveType IN ('Prescriptions','Return Inwards','Return Outward','Internal Item Usage','Expired Stocks') and rtrim(ltrim(IssuerID))<>'' and IssuerID is not Null THEN IsNUll((Select TOP 1 left(UPPER(Description),100) From ServicePlacesView Where Code= IssuerID),'') 

WHEN MoveType IN ('Orders') THEN IsNUll((Select TOP 1 left(UPPER(Description),100) From SuppliersView Where SupplierID= IssuerID),'') WHEN MoveType IN ('Stock Adjustments','Initial Stocks','Obsolete Stocks','UnitCost Adjustment') THEN IsNUll((Select TOP 1 left(UPPER(UsersView.UserID),100) From UsersView Where UserNo=rtrim(ltrim(STOCKMOVEMENT.UserID))),'') WHEN MoveType IN ('Prescription Returns') THEN IsNUll((Select TOP 1 left(UPPER(LastName + ' ' + MiddleName + ' ' + Surname)  + ' - ' + OPDNo,100) From PatientInfoView Where PatientID= IssuerID),'') END AS IssuedBy,

CASE WHEN MoveType IN ('Orders','Return Inwards','Stock Adjustments','Initial Stocks','Obsolete Stocks','Prescription Returns','UnitCost Adjustment') AND rtrim(ltrim(ReceiverID))<>'' and ReceiverID is not Null THEN IsNUll((Select TOP 1 UPPER(Description) From ServicePlacesView Where Code= ReceiverID),'')  WHEN MoveType IN ('Prescriptions') THEN IsNUll((Select TOP 1 left(UPPER(LastName + ' ' + MiddleName + ' ' + Surname)  + ' - ' + OPDNo,100) From PatientInfoView Where PatientID= ReceiverID),'')

WHEN MoveType IN ('Return Outward') THEN IsNUll((Select TOP 1 left(UPPER(Description),100) From SuppliersView Where SupplierID= ReceiverID),'') WHEN MoveType IN ('Internal Item Usage','Expired Stocks') THEN IsNUll((Select TOP 1 left(UPPER(UsersView.UserID),100) From UsersView Where UsersView.UserNo= rtrim(ltrim(STOCKMOVEMENT.UserID))),'') END AS ReceivedBy,

CASE WHEN MoveType IN ('Prescriptions','Return Inwards','Return Outward','Internal Item Usage') and rtrim(ltrim(IssuerID))<>'' and IssuerID is not Null THEN 'ISSUE' 

WHEN MoveType IN ('Orders','Return Inwards','Initial Stocks','Prescription Returns') and rtrim(ltrim(ReceiverID))<>'' and ReceiverID is not Null THEN 'RECEIPT' WHEN MoveType IN ('Stock Adjustments','Obsolete Stocks','Expired Stocks','UnitCost Adjustment') THEN 'ADJUSTMENT' END AS TransType

FROM dbo.STOCKMOVEMENT where MoveType NOT IN ('Requisitions')

UNION ALL

SELECT MoveOrder,ItemID,UnitCost,ItemUnit,MoveQty,IssuerID,ReceiverID,MoveDate,MoveTime,MoveType, ReceiverStock,IssuerStock,abs(AdjustQty),MoveNo,UserID,ServerDate,BaseQty,ServerTime,ReceiverUOMID,IssuerUOMID,TransUnitType,ExpiredStock, 

ReceiverStock - AdjustQty, ReceiverStock, ReceiverID , CASE WHEN rtrim(ltrim(IssuerID))<>'' and IssuerID is not Null THEN IsNUll((Select TOP 1 UPPER(Description) From ServicePlacesView Where Code= IssuerID),'') 

ELSE IsNUll((Select TOP 1 left(UPPER(Description),100) From ServicePlacesView, Orders Where Code= SupplierID AND OrderID=MoveNo and OrderType=1),'') END AS IssuedBy,IsNUll((Select TOP 1 left(UPPER(Description),100) From ServicePlacesView Where Code= ReceiverID),''),'RECEIPT'

FROM dbo.STOCKMOVEMENT where MoveType IN ('Requisitions') and rtrim(ltrim(ReceiverID))<>'' and ReceiverID is not Null  and IssuerStock=0

UNION ALL

SELECT MoveOrder,ItemID,UnitCost,ItemUnit,MoveQty,IssuerID,ReceiverID,MoveDate,MoveTime,MoveType, ReceiverStock,IssuerStock,-abs(AdjustQty),MoveNo,UserID,ServerDate,BaseQty,ServerTime,ReceiverUOMID,IssuerUOMID,TransUnitType,ExpiredStock, 

IssuerStock + ABS(AdjustQty), IssuerStock, IssuerID ,IsNUll((Select TOP 1 left(UPPER(Description),100) From ServicePlacesView Where Code= IssuerID),''), CASE WHEN rtrim(ltrim(ReceiverID))<>'' and ReceiverID is not Null THEN IsNUll((Select TOP 1 left(UPPER(Description),100) From ServicePlacesView Where Code= ReceiverID),'') 

ELSE IsNUll((Select TOP 1 UPPER(Description) From ServicePlacesView, Orders Where Code= OrderStoreID AND OrderID=MoveNo and OrderType=1),'') END AS ReceivedBy,'ISSUE'

FROM dbo.STOCKMOVEMENT where MoveType IN ('Requisitions') and rtrim(ltrim(IssuerID))<>'' and IssuerID is not Null  and ReceiverStock=0
go

