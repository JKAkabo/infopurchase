CREATE VIEW [dbo].[AccountClaassesMappedView]

AS

SELECT Distinct AcctsClassesMapID As MapTypeID, CASE WHEN AcctsClassesMapID=4 THEN Code END As ServiceMapID,I.Description 
FROM ServicesConfigurationSetupView S, ServicePlacesView I Where Code<>'' And UPPER(Status)='YES' And S.CAPID='**' and AcctsClassesMapID IN (4)

Union

SELECT Distinct AcctsClassesMapID, CASE WHEN AcctsClassesMapID=3 THEN Convert(nvarchar(15),Code) END As ServiceMapID,I.Description 
FROM ServicesConfigurationSetupView S, ServiceTypes I Where  S.CAPID='**' and AcctsClassesMapID IN (3)

Union

SELECT Distinct AcctsClassesMapID, CASE WHEN AcctsClassesMapID=8 THEN ClinicCode END As ServiceMapID, V.Description FROM ClinicServicePlaces C,ClinicsView V, 
ServicesConfigurationSetupView S Where AcctsClassesMapID=8 And S.CAPID='**' And ClinicCode=SPCode 

Union

SELECT Distinct AcctsDignosisMapID, CASE WHEN AcctsDignosisMapID=9 THEN Convert(nvarchar(15),DirectID) END As ServiceMapID, D.Description FROM ClinicServicePlaces C, ClinicsView V,DirectoratesView D,
ServicesConfigurationSetupView S Where AcctsDignosisMapID=9 And S.CAPID='**' And SPCode<>'' and  V.SPCode=ClinicCode And D.ID=DirectID
go

