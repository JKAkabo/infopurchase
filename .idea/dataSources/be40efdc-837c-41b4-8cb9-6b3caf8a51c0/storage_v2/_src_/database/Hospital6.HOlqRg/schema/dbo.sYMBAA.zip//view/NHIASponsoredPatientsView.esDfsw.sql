CREATE VIEW [dbo].[NHIASponsoredPatientsView]
AS
SELECT left(Sponsors.SponsorName, 100) As SponsorName,SponsoredPatients.SponsorNo,ISNULL(UnNo,'') As SerialNo,ISNULL(IDNo,'') As MemberID,
SponsoredPatients.PatCategoryCode  As PatCat, OPDNo, Archived, ISNULL(SchemeCode,'') As SchemeCode  FROM Sponsors Inner Join dbo.SponsoredPatients on Sponsors.SponsorNo=SponsoredPatients.SponsorNo Where Archived='No' and SponsorTypeCode=2 and IDNo<>''

Union

SELECT left(Sponsors.SponsorName, 100) As SponsorName,SP.SponsorNo,ISNULL(SP.UnNo,'')  As SerialNo,ISNULL(SP.IDNo,'') As MemberID,
SP.PatCategoryCode  As PatCat, OPDNo, Archived, ISNULL(SchemeCode,'') As SchemeCode  FROM Sponsors Inner Join dbo.SponsoredPatients As SP on Sponsors.SponsorNo=SP.SponsorNo Where Archived='Yes' and SponsorTypeCode=2 and IDNo<>'' and opdno not in
 ( Select Distinct OPDNo FROM Sponsors Inner Join dbo.SponsoredPatients on Sponsors.SponsorNo=SponsoredPatients.SponsorNo Where Archived='No' and SponsorTypeCode=2 and IDNo<>'' and SP.OPDNo=SponsoredPatients.OPDNo)
go

