CREATE VIEW [dbo].[ClinicsClinicTypesView]

AS

SELECT  Service_Points.Description, SPCode,Code AS ClinicTypeCode,ClinicTypes.Description As ClinicTypeDescription FROM dbo.Service_Points Inner Join ClinicTypes On Service_Points.Type=ClinicTypes.Code  

Union

SELECT  '' As Description, '' As Code,0 AS ClinicTypeCode,'' As ClinicTypeDescription FROM dbo.Hosp_Info
go

