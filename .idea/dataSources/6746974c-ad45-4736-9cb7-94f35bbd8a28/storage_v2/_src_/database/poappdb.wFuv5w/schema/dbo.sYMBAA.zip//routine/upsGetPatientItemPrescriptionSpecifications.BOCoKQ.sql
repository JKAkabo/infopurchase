-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[upsGetPatientItemPrescriptionSpecifications] 
	-- Add the parameters for the stored procedure here

	@ItemID nvarchar(15),@ItemPresSpecType tinyint,@ItemPresSpecUnit tinyint,
    @PatientSpecValue numeric(18,2)
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    Select Distinct PrescriptionSpecifications.*, PrescriptionFrequencies.Description As Frequency 
    ,CoversionFactor From PrescriptionFrequencies Inner Join PrescriptionSpecifications On 
    PrescriptionFrequencies.Code=PrescriptionSpecifications.FreqCode Where ItemCode= @ItemID And 
    TypeCode=@ItemPresSpecType And ValueUnit=@ItemPresSpecUnit And MinValue<=@PatientSpecValue
    And MaxValue>=@PatientSpecValue
     


END
go

