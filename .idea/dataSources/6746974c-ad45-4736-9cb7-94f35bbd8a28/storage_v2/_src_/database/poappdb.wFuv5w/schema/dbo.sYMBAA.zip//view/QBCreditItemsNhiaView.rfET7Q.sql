CREATE VIEW [dbo].[QBCreditItemsNhiaView]

AS

--

--NHIA Drugs
Select NHIAEpisodeServices.ServiceFee*RequiredQty As PaidAmt, ServiceCode, Description As ServiceDescription, endepisode As TransDate, RecordID As TransID, Episode.SponsorNo As ReceiverID, ServicePlaceID As IssuerID,
'Item Credit Sale-Nhia' As MoveType, UPPER(SponsorName) As ClientName, 2 As SponsorTypeCode, Convert(Nvarchar(15),ItemClassCode) As ItemClassCode, EpisodeSpecialityCode, DrugFee From Sponsors Inner Join 
(Episode Inner Join (Items Inner Join NHIAEpisodeServices On ItemID=ServiceCode) On Episode.EpisodeID=NHIAEpisodeServices.EpisodeID) On Sponsors.SponsorNo=Episode.SponsorNo Where AttType<>2  And Archived='No' and NoOfVisit>0 and NHIAEpisodeServices.ServiceTypeCode IN (1) 
 And UPPER(RequestType)='INTERNAL' And Episode.IsDuplicate='No' And Episode.ClaimDataProcessed='Yes' And Episode.ClaimGDRGCode<>'' And Episode.EpisodeSpecialityCode<>'' And (Episode.EpisodePrinted='Yes' Or (Episode.EpisodeBatchNo<>'' And EpisodeAllBatchNo<>'' And Episode.EpisodeBatchNo<>'None'))  and EpisodeSpecialityCode IN (Select Code From NHIAMDCS)
go

