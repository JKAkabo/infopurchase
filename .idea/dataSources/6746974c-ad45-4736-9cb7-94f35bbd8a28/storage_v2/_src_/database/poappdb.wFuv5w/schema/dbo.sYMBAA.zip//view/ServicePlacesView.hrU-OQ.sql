CREATE VIEW [dbo].[ServicePlacesView]

AS

SELECT  Description, Code, StoreFunction, Service_Places.Status FROM dbo.Service_Places

Union

SELECT  '' As Description, '' As Code, 0 as StoreFunction, 'Yes' As Status FROM dbo.Hosp_Info

Union

SELECT  'DRUGS DEPOSIT' As Description, 'DEPTDRG' As Code, 0 as StoreFunction, 'No' As Status FROM dbo.Hosp_Info
Union

SELECT  'SERVICES DEPOSIT' As Description, 'DEPTSER' As Code, 0 as StoreFunction, 'No' As Status FROM dbo.Hosp_Info

Union

SELECT  'OTHER DEPOSIT' As Description, 'DEPTOTH' As Code, 0 as StoreFunction, 'No' As Status FROM dbo.Hosp_Info

Union

SELECT  'UNUSED DRUGS DEPOSIT' As Description, 'UNDEPTDRG' As Code, 0 as StoreFunction, 'No' As Status FROM dbo.Hosp_Info
Union

SELECT  'UNUSED SERVICES DEPOSIT' As Description, 'UNDEPTSER' As Code, 0 as StoreFunction, 'No' As Status FROM dbo.Hosp_Info

Union

SELECT  'BILLS APPROMIXATION' As Description, 'BILLAPPR' As Code, 0 as StoreFunction, 'No' As Status FROM dbo.Hosp_Info

Union

SELECT  'OUTSTANDING BILLS PAYMENT' As Description, 'OUTBILLPMT' As Code, 0 as StoreFunction, 'No' As Status FROM dbo.Hosp_Info

Union

SELECT  'SPONSORS BILLS PAYMENT' As Description, 'SPSBILLPMT' As Code, 0 as StoreFunction, 'No' As Status FROM dbo.Hosp_Info
go

