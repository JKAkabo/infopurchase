CREATE VIEW [dbo].[NHIAClaimServicesView]

AS

SELECT ServiceCode, Description, EpisodeID, OPDNo, N.ServiceTypeCode, ReqDate, ServiceFee, RequiredQty, GDRGCode, RequestType, Issued, ICD10Code, ServicePmtType, Duration, Dosage, Freq,  IsNull((Select TOP 1 CASE WHEN Dosage - Convert(int,Dosage)<>0 And Dosage>1 THEN Convert(Nvarchar(15),Dosage) + ' ' + UPPER(LEFT(UnitMeasures.Description,1)) + LOWER(RIGHT(UnitMeasures.Description,LEN(UnitMeasures.Description)-1)) + 's' 
WHEN Dosage - Convert(int,Dosage)<>0 And Dosage<=1 THEN Convert(Nvarchar(15),Dosage) + ' ' + UPPER(LEFT(UnitMeasures.Description,1)) + LOWER(RIGHT(UnitMeasures.Description,LEN(UnitMeasures.Description)-1)) WHEN Dosage>1 THEN Convert(Nvarchar(15),Convert(int,Dosage)) + ' ' + UPPER(LEFT(UnitMeasures.Description,1)) + LOWER(RIGHT(UnitMeasures.Description,LEN(UnitMeasures.Description)-1)) + 's' ELSE 
Convert(Nvarchar(15),Convert(int,Dosage)) + ' ' + UPPER(LEFT(UnitMeasures.Description,1)) + LOWER(RIGHT(UnitMeasures.Description,LEN(UnitMeasures.Description)-1)) END AS Dosage From Items,UnitMeasures Where PresUnitCode=Code And A.ItemID=Items.ItemID),'') AS ClaimDosage, IsNull(AdultCode,'') AS AdultCode, IsNull(ChildCode,'') AS ChildCode,
IsNull((Select TOP 1 CASE WHEN Code>=1 And Code<=5 THEN Convert(Nvarchar(15),Code) + ' DAILY' WHEN Code>=13 And Code<=19 THEN Convert(Nvarchar(15),Code-12) + ' HOURLY' WHEN (Code>=6 And Code<=8) OR Code=26 THEN '1 DAILY' ELSE '' END AS Freq From PrescriptionFrequencies Where Description=N.Freq),'') AS ClaimFreq,IsNull((Select TOP 1 UPPER(Description) From ServiceTypes Where Code=A.ServiceTypeCode),'') As ServiceTypeDesc FROM 
NHIAEpisodeServices N, AllSetUpServicesView A Where RequestType='INTERNAL' And ServiceCode=ItemID And ((N.ServiceTypeCode IN (2,3)) OR (N.ServiceTypeCode=1 And RequiredQty>0) Or (N.ServiceTypeCode>=11 And N.ServiceTypeCode<=14)) And N.ServiceTypeCode<>0
go

