
CREATE VIEW [dbo].[ReturnedPrescriptionsView]

AS

SELECT Distinct ReturnedPrescriptions.RecordID, Pat_No, OPDNo, Items.Description, ReturnedPrescriptions.ReturnedDate,ReturnedPrescriptions.ReturnedTime, PaymentCode, Prescriptions.BillCycleDuration, Prescriptions.PmtTypeCode, Prescriptions.BillMethodCode, Prescriptions.PmtModeCode, StoreID, Prescriptions.SponsorNo, PresTime, PresDate, clinicCode, DrugCode, ExRate, BillCategoryCode ,Prescriptions.UnitPrice,Prescriptions.UnitCost,ReturnedPrescriptions.ReturnedQty, Prescriptions.ReqDate,ReturnedPrescriptions.DispensedQty, ReturnedPrescriptions.ReturnReason,DispensedID,

ItemClassCode, PresID, ReturnedPrescriptions.ReturnerID, PresType, EpisodeID, AttType, EpisodeType, PatCategoryCode, PaidQty,  PaidAmt, PmtDate, PmtTime, Service_Places.Description As Pharmacy, ReturnedPrescriptions.Dosage, Frequency, Duration, '**' As CAP_ID From Service_Places Inner Join (Items Inner Join(Sponsors Inner Join ( Prescriptions Inner Join ReturnedPrescriptions On Prescriptions.RecordID = ReturnedPrescriptions.PresID) On Sponsors.SponsorNo=Prescriptions.SponsorNo) On items.ItemID=DrugCode) On Service_Places.Code = ReturnedPrescriptions.StoreID Where Archived='No' And LTRIM(rtrim(Prescriptions.SponsorNo))<>'' and SponsorTypeCode<>2

Union

SELECT Distinct ReturnedPrescriptions.RecordID,Pat_No, OPDNo, Items.Description, ReturnedPrescriptions.ReturnedDate,ReturnedPrescriptions.ReturnedTime, PaymentCode, Prescriptions.BillCycleDuration, Prescriptions.PmtTypeCode, Prescriptions.BillMethodCode, Prescriptions.PmtModeCode, StoreID, '0001NHIA' As SponsorNo, PresTime, PresDate, clinicCode, DrugCode, ExRate, BillCategoryCode ,Prescriptions.UnitPrice,Prescriptions.UnitCost,ReturnedPrescriptions.ReturnedQty, Prescriptions.ReqDate,ReturnedPrescriptions.DispensedQty, ReturnedPrescriptions.ReturnReason,DispensedID,

ItemClassCode, PresID, ReturnedPrescriptions.ReturnerID, PresType, EpisodeID, AttType, EpisodeType, PatCategoryCode, PaidQty,  PaidAmt, PmtDate, PmtTime, Service_Places.Description As Pharmacy, ReturnedPrescriptions.Dosage, Frequency, Duration, '**' As CAP_ID From Service_Places Inner Join (Items Inner Join(Sponsors Inner Join ( Prescriptions Inner Join ReturnedPrescriptions On Prescriptions.RecordID = ReturnedPrescriptions.PresID) On Sponsors.SponsorNo=Prescriptions.SponsorNo) On items.ItemID=DrugCode) On Service_Places.Code = ReturnedPrescriptions.StoreID Where Archived='No' And LTRIM(rtrim(Prescriptions.SponsorNo))<>'' and SponsorTypeCode=2

Union

SELECT Distinct ReturnedPrescriptions.RecordID,Pat_No, OPDNo, Items.Description, ReturnedPrescriptions.ReturnedDate,ReturnedPrescriptions.ReturnedTime, PaymentCode, BillCycleDuration, PmtTypeCode, BillMethodCode, PmtModeCode, StoreID, OPDNo As SponsorNo, PresTime, PresDate, clinicCode, DrugCode, ExRate, BillCategoryCode ,Prescriptions.UnitPrice,Prescriptions.UnitCost,ReturnedPrescriptions.ReturnedQty, Prescriptions.ReqDate,ReturnedPrescriptions.DispensedQty, ReturnedPrescriptions.ReturnReason,DispensedID,

ItemClassCode, PresID, ReturnedPrescriptions.ReturnerID, PresType, EpisodeID, AttType, EpisodeType, PatCategoryCode, PaidQty,  PaidAmt, PmtDate, PmtTime, Service_Places.Description As Pharmacy, ReturnedPrescriptions.Dosage, Frequency, Duration, '**' As CAP_ID From Service_Places Inner Join (Items Inner Join( Prescriptions Inner Join ReturnedPrescriptions On Prescriptions.RecordID = ReturnedPrescriptions.PresID) On items.ItemID=DrugCode) On Service_Places.Code = ReturnedPrescriptions.StoreID Where Archived='No' And LTRIM(rtrim(Prescriptions.SponsorNo))=''

go

