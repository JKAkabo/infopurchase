CREATE PROCEDURE [dbo].[uspUpdateSponsorsInfo] 
	
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
 
       
update sponsors1 Set SponsorTypeCode=2 where SponsorType='Gov. Insurance(N.H.I.S)'

update sponsors1 Set SponsorTypeCode=3 where SponsorType='Insurance Company'

update sponsors1 Set SponsorTypeCode=5 where SponsorType='Private'
 
update sponsors1 Set SponsorTypeCode=4 where SponsorType='Company'


END
go

