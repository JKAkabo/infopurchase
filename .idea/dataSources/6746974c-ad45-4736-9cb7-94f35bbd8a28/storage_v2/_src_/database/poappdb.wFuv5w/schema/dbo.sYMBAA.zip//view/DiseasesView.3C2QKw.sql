CREATE VIEW [dbo].[DiseasesView]

AS

SELECT     left(DisDescription,100) Description, DisCode, ClassCode, PmtType, IsNull(ICDCode,'') As ICDCode, MainDiseaseCode, IsNull(ICDCode,'') As Code,Disabled FROM dbo.Diseases

Union

SELECT  TOP 1 '' As Description, '' As DisCode, 0 As ClassCode, 2 As PmtType, '' As ICDCode, '' As MainDiseaseCode, '' As Code, 'No' As Disabled FROM dbo.Diseases where DisCode<>''
go

