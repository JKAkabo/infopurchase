CREATE VIEW [dbo].[AllServicesRevenueView]

AS

SELECT AttServiceID,BillCycleDuration,billMethodCode,PmtModeCode,episodeID,attType,episodeType,ItemCode As GDRG_Code,Issued,Description, DrugCode As ServiceCode, 
1 As ServiceTypeCode, PmtTypeCode, StoresID As SerPlaceCode ,UnitPrice AS UnitFee, QtyPrescribed As RequestedQty, CASE WHEN QtyGiven<>0 and QtyGiven>QtyPrescribed THEN QtyPrescribed WHEN QtyGiven<>0 and QtyGiven<=QtyPrescribed THEN QtyGiven
WHEN (ReturnedQty=0 and QtyGiven=0) THEN QtyPrescribed WHEN (ReturnedQty<>0 and QtyGiven=0) THEN 0  END As ServiceQty, Prescriptions.PresDate As ReqDate, 
Prescriptions.PresTime As Reqtime, PresType As RequestType, OPDNo, StatusCode, DirectID, '**' As CapID, ServerTime, Pat_No, ClinicCode, PatAge, BillCategoryCode, 
UserID, SponsorNo, 'No' As CoPayed, ReqDate As AttDate, RecordID,PaidQty,Prescriber As RequesterID, PaymentCode,exrate,Dosage As Frequency, PresDays As Duration, 
Units As Dosage, AllSetUpServicesView.PmtType, ReceiptNo, PresAmt As ServiceAmt,PresDate As ServiceDate, Prescriptions.PresTime As ServiceTime,ReturnedQty,QtyGiven FROM 
AllSetUpServicesView Inner Join Prescriptions On ItemID=DrugCode Where Archived='No' and PresType='INTERNAL'  

UNION ALL

SELECT AttServiceID,BillCycleDuration,billMethodCode,PmtModeCode,episodeID,attType,episodeType,GDRG_Code,Issued,Description, ServiceCode, ServiceTypeCode, PmtTypeCode, SerPlaceCode , Service_Fee,  ServiceQty, ServiceQty, ReqDate, ReqTime, RequestType,
OPDNo, StatusCode, DirectID, '**' As CapID, ServerTime, Pat_No, ClinicCode, PatAge, BillCategoryCode,Service_Requests.UserID, SponsorNo, 'No' As CoPayed, ReqDate As AttDate, RecordID,PaidQty,RequesterID,PaymentCode,exrate,'' As Frequency, 1 As Duration, 
0 As Dosage, AllSetUpServicesView.PmtType, ReceiptNo, ServiceAmt, ReqDate, ReqTime,0,QtyGiven FROM AllSetUpServicesView Inner Join Service_Requests On ItemID=Service_Requests.ServiceCode Where Archived='No' And RequestType='INTERNAL' 

UNION ALL

SELECT AttServiceID,CoPayBillCycleDuration,CoPayBillMethodCode,CoPayPmtModeCode,episodeID,attType,episodeType,GDRG_Code,Issued,Description, DrugCode As ServiceCode, 
1 As ServiceTypeCode, CoPayPmtTypeCode, StoresID As SerPlaceCode , (CoPayFee - UnitPrice) AS UnitFee, QtyPrescribed As ServiceQty, CASE WHEN QtyGiven<>0 THEN QtyGiven 
WHEN (ReturnedQty=0 and QtyGiven=0) THEN QtyPrescribed WHEN (ReturnedQty<>0 and QtyGiven=0) THEN 0  END As ServiceQty, Prescriptions.PresDate As ReqDate, 
Prescriptions.PresTime As Reqtime, PresType As RequestType, OPDNo, StatusCode, DirectID, '**' As CapID, ServerTime, Pat_No, ClinicCode, PatAge, CoPayBillCategoryCode, 
UserID, CoPaySponsorNo, 'Yes' As CoPayed, ReqDate As AttDate, RecordID,PaidQty,Prescriber As RequesterID,PaymentCode,exrate,Dosage As Frequency, PresDays As Duration, 
Units As Dosage, AllSetUpServicesView.PmtType, ReceiptNo,(CoPayAmt - PresAmt),PresDate,PresTime,ReturnedQty,QtyGiven FROM 
AllSetUpServicesView Inner Join Prescriptions On ItemID=DrugCode Where Archived='No' and CoPayBillCategoryCode<>0 and CoPayPmtTypeCode<>0  and CoPayFee>UnitPrice and PresType='INTERNAL'

UNION  ALL

SELECT AttServiceID,CoPayBillCycleDuration,CoPayBillMethodCode,CoPayPmtModeCode,episodeID,attType,episodeType,GDRG_Code,Issued,Description, ServiceCode, ServiceTypeCode, CoPayPmtTypeCode, SerPlaceCode , (CoPayFee - Service_Fee) AS Service_Fee,  ServiceQty, 
ServiceQty, ReqDate, ReqTime, RequestType, OPDNo, StatusCode, DirectID, '**' As CapID, ServerTime, Pat_No, ClinicCode, PatAge, CoPayBillCategoryCode,UserID, CoPaySponsorNo, 'Yes' As CoPayed, ReqDate As AttDate, RecordID,PaidQty,RequesterID,PaymentCode,exrate,'' As Frequency, 
1 As Duration, 0 As Dosage, AllSetUpServicesView.PmtType, ReceiptNo, CoPayAmt-ServiceAmt, ReqDate,ReqTime,0,QtyGiven  FROM AllSetUpServicesView Inner Join Service_Requests On ItemID=Service_Requests.ServiceCode Where Archived='No' And RequestType='INTERNAL' and CoPayBillCategoryCode<>0 and CoPayPmtTypeCode<>0  and CoPayFee>Service_Fee

--UNION ALL

--SELECT AttServiceID,BillCycleDuration,billMethodCode,PmtModeCode,episodeID,attType,episodeType,ItemCode As GDRG_Code,'Yes' As Issued,Description, DrugCode As ServiceCode, 1 As ServiceTypeCode, PmtTypeCode, StoreID As SerPlaceCode ,P.UnitPrice AS UnitFee, QtyPrescribed As RequestedQty, D.DispensedQty-D.ReturnedQty As ServiceQty, P.PresDate As ReqDate, P.PresTime As Reqtime, PresType As RequestType, OPDNo, P.StatusCode, DirectID, '**' As CapID, D.ServerTime, Pat_No, ClinicCode, D.PatAge, BillCategoryCode, D.UserID, SponsorNo, 'No' As CoPayed, P.ReqDate As AttDate, D.RecordID,PaidQty,Prescriber As RequesterID, PaymentCode,exrate,Frequency, Duration, D.Dosage, A.PmtType, ReceiptNo, (CoPayAmt - PresAmt),D.DispensedDate As ServiceDate, D.DispensedTime FROM 
--AllSetUpServicesView A, Prescriptions P, DispensedPrescriptions D Where A.ItemID=DrugCode And P.RecordID= PresID and Archived='No' and PresType='INTERNAL' and  QtyGiven<>0

--UNION ALL

--SELECT AttServiceID,CoPayBillCycleDuration,CoPayBillMethodCode,CoPayPmtModeCode,episodeID,attType,episodeType,ItemCode As GDRG_Code,'Yes' As Issued,Description, DrugCode As ServiceCode, 1 As ServiceTypeCode, CoPayPmtTypeCode, StoreID As SerPlaceCode ,(CoPayFee - P.UnitPrice) AS UnitFee, QtyPrescribed As RequestedQty, D.DispensedQty-D.ReturnedQty As ServiceQty, P.PresDate As ReqDate, P.PresTime As Reqtime, PresType As RequestType, OPDNo, P.StatusCode, DirectID, '**' As CapID, D.ServerTime, Pat_No, ClinicCode, D.PatAge, CoPayBillCategoryCode, D.UserID, SponsorNo, 'No' As CoPayed, P.ReqDate As AttDate, D.RecordID,PaidQty,Prescriber As RequesterID, PaymentCode,exrate,Frequency, Duration, D.Dosage, A.PmtType, ReceiptNo,(CoPayAmt - PresAmt),D.DispensedDate As ServiceDate,D.DispensedTime  FROM 
--AllSetUpServicesView A, Prescriptions P, DispensedPrescriptions D Where A.ItemID=DrugCode And P.RecordID= PresID and Archived='No' and PresType='INTERNAL' and  QtyGiven<>0  and CoPayBillCategoryCode<>0 and CoPayPmtTypeCode<>0  and CoPayFee>P.UnitPrice
go

