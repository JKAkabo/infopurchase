CREATE VIEW [dbo].[NHIADuplicateEpisodesView]

AS

Select e1.IsDuplicate, e1.DiagnosticFee, e1.EpisodeFee, e1.DrugFee, e1.ClaimDiaCode, e1.NoOfVisit,e1.Archived, LastName, MiddleName, Surname, GenderCode, Died, e1.PatAge,e1.EpisodePmtType,e1.DirectID,e1.EpisodeBatchNo,e1.EpisodePrinted, e1.BeginEpisode, e1.EndEpisode, e1.Pat_No, e1.OPDNo,e1.EpisodeID,e1.AttDate, e1.Clinic_Code,e1.EpisodeSpecialityCode, e1.ServiceFee, e1.StatusCode,e1.EpisodeGDRGCode From PatientsInfo Inner Join (episode e1 inner join episode e2 on e1.opdno=e2.opdno and e1.BeginEpisode=e2.BeginEpisode and e1.EndEpisode=e2.EndEpisode) On PatientsInfo.OPDNo=e1.opdno where e1.archived='No' and e2.archived='No' and e1.EpisodeID<>e2.EpisodeID and e1.NoOfVisit>0 and e2.NoOfVisit>0 and e1.IsDuplicate='No' and e2.IsDuplicate='No'

UNION ALL

Select e2.IsDuplicate, e2.DiagnosticFee, e2.EpisodeFee, e2.DrugFee, e2.ClaimDiaCode, e2.NoOfVisit, e2.Archived, LastName, MiddleName, Surname, GenderCode, Died, e2.PatAge,e2.EpisodePmtType,e2.DirectID,e2.EpisodeBatchNo,e2.EpisodePrinted,e2.BeginEpisode, e2.EndEpisode, e2.Pat_No, e2.OPDNo,e2.EpisodeID,e2.AttDate, e2.Clinic_Code, e2.EpisodeSpecialityCode, e2.ServiceFee, e2.StatusCode,e2.EpisodeGDRGCode From PatientsInfo Inner Join (episode e1 inner join episode e2 on e1.opdno=e2.opdno and e1.BeginEpisode=e2.BeginEpisode and e1.EndEpisode=e2.EndEpisode) On PatientsInfo.OPDNo=e1.opdno where e1.archived='No' and e2.archived='No' and e1.EpisodeID<>e2.EpisodeID and e1.NoOfVisit>0 and e2.NoOfVisit>0 and e1.IsDuplicate='No' and e2.IsDuplicate='No'
go

