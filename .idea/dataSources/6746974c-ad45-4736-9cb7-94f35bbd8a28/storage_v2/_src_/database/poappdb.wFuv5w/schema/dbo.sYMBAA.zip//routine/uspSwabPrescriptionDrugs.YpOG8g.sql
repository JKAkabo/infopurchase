-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[uspSwabPrescriptionDrugs] 
	-- Add the parameters for the stored procedure here
	
AS

BEGIN

	DECLARE @presID numeric(18,0),@dispensedID numeric(18,0),@Dosage numeric(18,0),@Freq nvarchar(50),@Duration numeric(18,0),
	@PresAge int,@presQty numeric(18,2),@UnitPrice numeric(18,6),@UnitCost numeric(18,6),@itemCode nvarchar(15),@DrugCode nvarchar(15);

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Prescriptions.RecordID, Prescriptions.UnitPrice, DispensedPrescriptions.RecordID, QtyGiven, Prescriptions.PatAge, Prescriptions.UnitCost, DrugCode From Prescriptions Inner Join DispensedPrescriptions On Prescriptions.RecordID=presid Where Prescriptions.ReturnedQty=0 and (DrugCode='D000008' OR DrugCode='D000410') And (QtyPrescribed=3 Or QtyPrescribed=6) and Prescriptions.Archived='No' And PresDate>='2014-01-01' and PresDate<='2014-01-01' And Prescriptions.BillCategoryCode IN (4,11) Order by Prescriptions.RecordID Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO @presID, @UnitPrice, @dispensedID, @presQty, @PresAge, @UnitCost, @DrugCode;

  WHILE @@fetch_status = 0
    
    BEGIN
    
    set @itemCode=''
    
    if @PresAge<=7 and @DrugCode='D000008'
    
       begin     
       set @Dosage=1;
       set @Freq='BID';
       set @Duration=3;
       set @presQty=6;
       set @itemCode='D000007';
       end
       
   else if  @PresAge>=8 and @PresAge<=12 and @DrugCode='D000008'   
       
       begin     
       set @Dosage=2;
       set @Freq='BID';
       set @Duration=3;
       set @presQty=12;
       set @itemCode='D000007';
       end
       
   else if  @PresAge>12 and @DrugCode='D000410'    
       
       begin     
       set @Dosage=4;
       set @Freq='BID';
       set @Duration=3;
       set @presQty=24;
       set @itemCode='D000027';
       
       end

       --set @DisCategory=dbo.ItemDesc(@DisCategory);
       
       if @itemCode<>''
          BEGIN
		    update DispensedPrescriptions Set ItemID=@itemCode,Dosage=@Dosage,Frequency=@Freq,Duration=@Duration,UnitPrice=@UnitPrice,UnitCost=@UnitCost,DispensedQty=@presQty where RecordID=@dispensedID and ItemID=@DrugCode

		    update Prescriptions Set DrugCode=@itemCode,Units=@Dosage,Dosage=@Freq,PresDays=@Duration,UnitPrice=@UnitPrice,UnitCost=@UnitCost,QtyGiven=@presQty where RecordID=@presID and DrugCode=@DrugCode
          
          END
          
       FETCH NEXT FROM C INTO @presID, @UnitPrice, @dispensedID, @presQty, @PresAge, @UnitCost, @DrugCode;

	   END

	CLOSE C;

	DEALLOCATE C;

END
go

