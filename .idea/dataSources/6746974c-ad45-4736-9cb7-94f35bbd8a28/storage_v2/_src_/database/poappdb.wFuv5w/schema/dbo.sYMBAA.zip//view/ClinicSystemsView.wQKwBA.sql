CREATE VIEW [dbo].[ClinicSystemsView]

AS

SELECT  OrderNo, ClinicalSystems.Description, ClinicalSystems.Code, ID, GenderCode, AgeGroupCode, ClinicalSystems.IsActive, GenderGroups.Description As Gender, AgeGroups.Description As AgeGroup FROM dbo.ClinicalSystems, AgeGroups,GenderGroups where AgeGroups.Code=AgeGroupCode and GenderGroups.Code=GenderCode
go

