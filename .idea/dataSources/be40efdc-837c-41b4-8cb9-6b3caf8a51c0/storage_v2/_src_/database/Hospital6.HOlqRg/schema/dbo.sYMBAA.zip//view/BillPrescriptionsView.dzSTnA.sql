CREATE VIEW [dbo].[BillPrescriptionsView]

AS

SELECT OPDNo, Pat_No, RecordID, DrugCode As ServiceCode, ReceiptNo, UnitCost, UnitPrice As Service_Fee, UnitCost As Service_Cost, ReqDate, PresDate, PresTime, PaidAmt, PaidQty , StoresID As SerPlaceCode, PmtTypeCode, PmtModeCode, QtyGiven, QtyPrescribed, ClinicCode, DirectID  FROM dbo.Prescriptions Where Archived='No' And Refunded='No'
go

