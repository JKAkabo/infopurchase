CREATE PROCEDURE [dbo].[uspSetNHIAFees] 
	
AS

DECLARE @itemID nvarchar(15),@ItemCost numeric(18,6);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct  Code, NHIAFee From Hospital6.dbo.NHIACoreGDRGS Order by Code Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO @itemID, @ItemCost;

  WHILE @@fetch_status = 0
    BEGIN
       
       update Service_Requests Set Service_Fee=@ItemCost, Service_Cost=@ItemCost where GDRG_Code=@itemID And (BillCategoryCode=4 Or BillCategoryCode=11)  and SponsorNo<>'' And Archived='No' And PmtTypeCode<>1  and EpisodeID<>0

       update Episode Set EpisodeFee=@ItemCost where EpisodeGDRGCode=@itemID
       
       update ConsultationDiagnoses Set DiaFee=@ItemCost where GDRGCode=@itemID 

       update AdmissionCauses Set DiaFee=@ItemCost where GDRGCode=@itemID and EpisodeID<>0
       
       update NHIACoreGDRGS Set NHIAFee=@ItemCost, PrimaryFee=@ItemCost,SecondaryFee=0,CapitatedFee=0 where Code=@itemID
       
       Update Service_Types Set NHISPrice=@ItemCost Where GDRGCodeA=@itemID
       
       Update Service_Types Set NHISFeeChild=@ItemCost Where GDRGCodeC=@itemID
       
       Update Service_Types Set NHISFeeChild=@ItemCost, NHISPrice=@ItemCost Where GDRGCodeC=@itemID and upper(RIGHT(@itemid,1))='D'
       
       Update Diseases Set AdultFee=@ItemCost Where GDRGCodeA=@itemID
       
       Update Diseases Set ChildFee=@ItemCost Where GDRGCodeC=@itemID
       
       
       FETCH NEXT FROM C INTO @itemID, @ItemCost;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

