CREATE VIEW [dbo].[AccountCashServicesRefundView]

AS

SELECT
	
S.ServiceCode, S.Service_Fee *S.RefundQty as TransAmt,S.RefundDate As TransDate,J.TransTypeID, 

ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As CreditAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As CreditAcctName, 

'CREDIT' As CreditPostType,UPPER(P.Description) As ClientName,1 As ServiceTypeID, '' As TransID,'' As TypeDescription,11 As AcctTypeID,P.Code As ClientID,

J.AcctCodeJE AS DebitAcctCode,UPPER(A.Description) as DebitAcctName,'DEBIT' as DebitPostType
	      	
FROM 
	
ServicePlacesView P,Service_Types R,AccountChartServicesMapping M, AccountChartSetup A,
RefundServiceLines S, AccountsChartJournalMapping J, ServicesConfigurationSetupView V

	
WHERE 

M.ServiceTypeID=2 And S.Service_Fee>0 And S.PmtTypeCode =1 AND R.ServiceCode=S.ServiceCode AND P.Code =R.ServicePlaceCode AND J.TransTypeID=1 
And A.Code=J.AcctCodeJE  And J.TransTypeID=M.PostingType AND S.PmtTypeCode=1 And J.AcctJEPostType=2
And A.Code=M.AccountChartCode And J.AcctCodeJE=M.AccountChartCode And M.ServiceTypeID=2
And A.Code=M.AccountChartCode And J.AcctJEPostType=2  And ((V.AcctsServicesMapID=4 and M.ServiceID = R.ServicePlaceCode And M.ServiceTypeID=2) OR
(V.AcctsServicesMapID=3 and M.ServiceID = R.ServiceTypeCode And M.ServiceTypeID=2) OR (V.AcctsServicesMapID=2 and M.ServiceID = R.ServiceCode And M.ServiceTypeID=2))
go

