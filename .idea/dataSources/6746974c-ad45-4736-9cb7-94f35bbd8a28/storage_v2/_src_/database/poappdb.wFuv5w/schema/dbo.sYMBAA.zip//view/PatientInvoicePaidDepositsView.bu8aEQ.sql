CREATE VIEW [dbo].[PatientInvoicePaidDepositsView]

AS

Select ISNULL(H.PmtAmt,0) As TotalDepositsPaid , D.PaidBillRefNo As BillInvoiceNo, UPPER(D.DepReason) + ' DEPOSITS PAID' As DepositType, D.DepositDate From Deposits D, BillsPaid B, HAMSBANKPAYMENTS H 
Where B.Archived='No' And H.PatNo=D.Pat_No And D.ReceiptNo=H.InvoiceNo And Cancelled='No' And PmtAmt>0 And D.Archived='No' And D.OPDNo=B.OPDNo And PaidBillRefNo=B.ReceiptNo 



--Select ISNULL(SUM(H.PmtAmt),0) As TotalDepositsPaid , D.BillReferenceNo As BillInvoiceNo, UPPER(D.DepReason) + ' DEPOSITS PAID' As DepositType From Deposits D, BillsPaid B, HAMSBANKPAYMENTS H 
--Where B.Archived='No' And H.PatNo=D.Pat_No And D.ReceiptNo=H.InvoiceNo And Cancelled='No' And PmtAmt>0 And D.Archived='No' And D.OPDNo=B.OPDNo And BillReferenceNo=B.ReceiptNo 
--GROUP BY  BillReferenceNo, DepReason

--Select 'GHC' As DepositCurrency, BillsPaid.Pat_No As PatientID, Deposits.DepositTime , Deposits.DepositDate , Deposits.ReceiptNo As InvoiceNo,Deposits.DepositAmount, Deposits.BillReferenceNo As BillInvoiceNo, Deposits.DepReason As DepositType From Deposits Inner Join BillsPaid On (Deposits.OPDNo=BillsPaid.OPDNo And (Deposits.BillReferenceNo=BillsPaid.ReceiptNo OR Deposits.ReceiptNo=BillsPaid.ReceiptNo)) Where BillsPaid.Archived='No' and Deposits.Archived='No'
go

