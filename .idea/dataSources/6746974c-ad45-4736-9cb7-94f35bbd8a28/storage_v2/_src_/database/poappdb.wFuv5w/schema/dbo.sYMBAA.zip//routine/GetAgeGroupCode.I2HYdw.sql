CREATE FUNCTION [dbo].[GetAgeGroupCode]

(@AgeValue tinyint=0) RETURNS tinyint

AS

BEGIN

DECLARE @AgeGroupValue tinyint;
 
Select TOP 1 @AgeGroupValue=AgeGroups.Code From AgeGroupValuesView Inner Join AgeGroups On AgeGroupValuesView.AgeGroupCode=AgeGroups.Code Where GroupCode=5 AND MinAge<=@AgeValue AND MaxAge>=@AgeValue

If @@RowCount<=0
   BEGIN
	   Select TOP 1 @AgeGroupValue=AgeGroups.Code From AgeGroups Where IsActive='Yes' And MinAge<=@AgeValue AND MaxAge>=@AgeValue
	   
	   If @@RowCount>=0 and @AgeGroupValue>=4
	   
		  Set @AgeGroupValue=2
   END
   
RETURN @AgeGroupValue

END
go

