CREATE VIEW [dbo].[AccountCustomersVendorsView]

AS

SELECT  Description, Code, ID, V.MappedCode, TypeID, IsActive,
CASE WHEN TypeID=9 THEN ISNULL((Select UPPER(S.SponsorName) from Sponsors S Where S.AcctsBlocked='No' And S.SponsorNo=MappedCode),'')
ELSE ISNULL((Select UPPER(S.ContactName) from Suppliers S Where S.Archived='No' And S.SupplierID=MappedCode),'') End As HamsDescription

FROM dbo.AccountCustomersVendors V
go

