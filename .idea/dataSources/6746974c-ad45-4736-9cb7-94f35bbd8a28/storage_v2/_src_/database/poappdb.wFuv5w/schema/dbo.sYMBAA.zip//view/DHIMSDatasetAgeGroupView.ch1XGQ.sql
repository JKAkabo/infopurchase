CREATE VIEW [dbo].[DHIMSDatasetAgeGroupView]

AS

SELECT DHISCode, RecordID, convert(Nvarchar(5), RecordID) As AgeGroupLinkCode, LowerValue, UpperValue, UpperFac, LowerFac  FROM dbo.DHISDataSets inner join AgeGroupValuesView on DHISDataSets.AgeGroupCode=GroupCode Where IsActive='Yes'
go

