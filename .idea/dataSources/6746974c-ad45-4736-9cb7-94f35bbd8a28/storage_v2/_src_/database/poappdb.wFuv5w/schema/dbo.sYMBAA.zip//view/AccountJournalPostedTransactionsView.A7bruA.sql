CREATE VIEW [dbo].[AccountJournalPostedTransactionsView]

AS

SELECT A.Description, A.Code As AcctCode, A.TypeDescription, A.AcctTypeID,T.ActivityTypeID,T.RefNumber,'DEBIT' As EntryType,
T.GeneratedReferenceNo, T.TransAmt, T.TransDate,T.DebitMemo As TransMemo,T.ClientName,C.Description As TransDescription,T.RecordID,
T.TransactionID,T.EditSequence,T.TransactionLineNo,T.TransActualAmt,'**' As Cap_ID
FROM AccountInterfaceTransactions T, AccountsJournalTransactionsCombined C, AccountChatsView A 
Where A.Code=T.DebitAcctCode And C.Code=T.ActivityTypeID

Union ALL

SELECT A.Description, A.Code As AcctCode, A.TypeDescription, A.AcctTypeID,T.ActivityTypeID,T.RefNumber,'CREDIT' As EntryType,
T.GeneratedReferenceNo, T.TransAmt, T.TransDate,T.CreditMemo As TransMemo,T.ClientName,C.Description As TransDescription,T.RecordID,
T.TransactionID,T.EditSequence,T.TransactionLineNo,T.TransActualAmt,'**' As Cap_ID 
FROM AccountInterfaceTransactions T, AccountsJournalTransactionsCombined C, AccountChatsView A 
Where A.Code=T.CreditAcctCode And C.Code=T.ActivityTypeID
go

