CREATE PROCEDURE [dbo].[uspUpdateEpisodesDischargeStatus] 
	
AS

DECLARE @OPDNo nvarchar(15),@EpisodeID numeric(18,0),@RecordID numeric(18,0)

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  --admissions
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct Deaths.OPDNo, Admissions.episodeID, Admissions.RecordID From Deaths Inner Join admissions on Deaths.OPDNo=Admissions.OPDNo Where Deaths.Archived='No' And Admissions.Archived='No' And deathdate>=admdate and  deathdate<=disdate and disdate is not null and discharged='Yes' Order by Deaths.OPDNo
            
  OPEN C
  
  FETCH NEXT FROM C INTO @OPDNo, @EpisodeID, @RecordID       

  WHILE @@fetch_status = 0
    BEGIN

   update Admissions Set DischargeStatusCode=2 Where RecordID=@RecordID
   
   update Episode Set EpisodeDischargedStatus=2 Where EpisodeID=@EpisodeID and OPDNo=@OPDNo
   
  FETCH NEXT FROM C INTO @OPDNo, @EpisodeID, @RecordID        

	END

	CLOSE C;

	DEALLOCATE C;
	
	--Consulations
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct Deaths.OPDNo, Consultations.episodeID, Consultations.ConID From Deaths Inner Join Consultations On Deaths.OPDNo=Consultations.OPDNo Where Deaths.Archived='No' And Consultations.Archived='No' And Consultations.ReqDate>=deathdate Order by Deaths.OPDNo
            
  OPEN C
  
  FETCH NEXT FROM C INTO @OPDNo, @EpisodeID, @RecordID       

  WHILE @@fetch_status = 0
    BEGIN

   update Consultations Set ConOutCome=2 Where ConID=@RecordID
   
   update Episode Set EpisodeDischargedStatus=2 Where EpisodeID=@EpisodeID and OPDNo=@OPDNo
   
  FETCH NEXT FROM C INTO @OPDNo, @EpisodeID, @RecordID        

	END

	CLOSE C;

	DEALLOCATE C;

END
go

