CREATE VIEW [dbo].[AccountServiceRefundLinesView]
AS
  -------Service Cash Refund
SELECT    
             r.RecordID As TransID
            ,r.ServiceCode
            ,r.RefundQty * r.Service_Fee AS PaidAmt
			, r.RefundDate As TransDate
			, s.SerPlaceCode AS IssuerID
			, r.PmtTypeCode
			, s.SponsorNo As ReceiverID
			,A.Description  As ServiceDescription
			,P.Description As ClientName
			,'Cash Service Refunds' As SaleType
			,r.Pat_ID As OPDNo
			,'Service Cash Refund' As MoveType
FROM        
              Service_Places P Inner Join
             ( AllSetUpServicesView A INNER JOIN 
             (RefundServiceLines  As r 
             INNER JOIN dbo.Service_Requests As s 
             ON s.ServiceCode = r.ServiceCode 
             and s.RecordID =r.ServiceID )
             ON A.ItemID =R.ServiceCode )
             ON P.Code =S.SerPlaceCode 

WHERE 
             r.PmtTypeCode=1
UNION ALL
           ----Service Credit Refunds
SELECT    
             r.RecordID As TransID
            ,r.ServiceCode
            ,r.RefundQty * r.Service_Fee AS PaidAmt
			,r.RefundDate As TransDate
			,s.SerPlaceCode AS IssuerID
			,r.PmtTypeCode
			,s.SponsorNo As ReceiverID
			,A.Description  As ServiceDescription
			,(SELECT Upper(SponsorName) FROM Sponsors WHERE SponsorNo =s.SponsorNo) AS ClientName
			,'Credit Service Refunds' As SaleType
			,r.Pat_ID As OPDNo
			,'Service Credit Refund' As MoveType
FROM        
              Service_Places P Inner Join
             ( AllSetUpServicesView A INNER JOIN 
             (RefundServiceLines  As r 
             INNER JOIN dbo.Service_Requests As s 
             ON s.ServiceCode = r.ServiceCode 
             and s.RecordID =r.ServiceID )
             ON A.ItemID =R.ServiceCode )
             ON P.Code =S.SerPlaceCode 

WHERE 
             r.PmtTypeCode=2
go

