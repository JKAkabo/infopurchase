CREATE VIEW [dbo].[OPDDailyAttendanceView]
AS

Select Distinct Daily_Attendance.Insured, Daily_Attendance.AttAge, Daily_Attendance.RegStatus, Daily_Attendance.RegType, Daily_Attendance.Pat_No, Daily_Attendance.SponsorNo, Service_Requests.DirectID, AttDate, AttTime,Daily_Attendance.RecordID, Daily_Attendance.OPDNo, Daily_Attendance.AgeClassCode, Daily_Attendance.PatCategoryCode, Service_Requests.ClinicCode From Daily_Attendance Inner Join Service_Requests On (Daily_Attendance.OPDNo=Service_Requests.OPDNo And Daily_Attendance.AttDate=Service_Requests.ReqDate) Where Service_Requests.Archived='No'
go

