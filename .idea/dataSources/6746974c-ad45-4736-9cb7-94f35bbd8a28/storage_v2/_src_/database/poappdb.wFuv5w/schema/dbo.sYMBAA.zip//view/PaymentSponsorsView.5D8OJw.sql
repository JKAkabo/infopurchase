CREATE VIEW [dbo].[PaymentSponsorsView]
AS
SELECT     left(Sponsors.SponsorName, 100) As SponsorName,Sponsors.SponsorNo,Sponsors.SponsorTypeCode, Sponsors.OutBal, creditLimit
FROM       dbo.Sponsors Where SponsorTypeCode<>2

union

Select 'NATIONAL HEALTH INSURANCE AUTHORITY' As SponsorName, 'NHIA0001' as SponsorNo, 2 As SponsorTypeCode, 0 As OutBal, 0 As creditLimit   from Hosp_Info
go

