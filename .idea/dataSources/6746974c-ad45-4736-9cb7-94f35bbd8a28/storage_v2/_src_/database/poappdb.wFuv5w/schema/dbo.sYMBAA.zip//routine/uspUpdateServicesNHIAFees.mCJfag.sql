CREATE PROCEDURE [dbo].[uspUpdateServicesNHIAFees] 
	
AS

DECLARE @itemID nvarchar(15),@ItemCost numeric(18,6);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct  Code, NHIAFee From NHIACoreGDRGS Order by Code Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO @itemID, @ItemCost;

  WHILE @@fetch_status = 0
    BEGIN

       --set @DisCategory=dbo.ItemDesc(@DisCategory);
       
       update Service_Requests Set Service_Fee=@ItemCost, Service_Cost=@ItemCost where GDRG_Code=@itemID and ReqDate>='2013-10-01' and ReqDate<='2013-10-01' and  (BillCategoryCode=4 Or BillCategoryCode=11)  and SponsorNo<>'' And Archived='No' And PmtTypeCode<>1

       update AdmissionCauses Set DiaFee=@ItemCost where GDRGCode=@itemID and AdmDate>='2013-10-01' and AdmDate<='2013-10-01' and  Cancelled='No'

       update ConsultationDiagnoses Set DiaFee=@ItemCost where GDRGCode=@itemID and ReqDate>='2013-10-01' and ReqDate<='2013-10-01' and  Cancelled='No'  

       update Episode Set EpisodeFee=@ItemCost, ServiceChanged='Yes', InvestChanged='Yes' where EpisodeGDRGCode=@itemID and (BeginEpisode>='2013-10-01' And (EndEpisode<='2013-10-31' OR EndEpisode Is Null)) And Archived='No'
              
       FETCH NEXT FROM C INTO @itemID, @ItemCost;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

