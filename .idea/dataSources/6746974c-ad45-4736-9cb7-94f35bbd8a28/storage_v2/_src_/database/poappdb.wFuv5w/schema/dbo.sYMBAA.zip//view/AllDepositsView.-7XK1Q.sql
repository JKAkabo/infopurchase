CREATE VIEW [dbo].[AllDepositsView]

AS

SELECT Distinct DepReason,DepositAmount, DepositDate, Deposits.UserID, Deposits.OPDNo, Deposits.Pat_No, ClinicCode, Deposits.StatusCode, WardID, DepositTime, Deposits.ReceiptNo FROM Deposits, Admissions Where Deposits.OPDNo=Admissions.OPDNo And Deposits.Pat_No=Admissions.Pat_No And DepositDate>=AdmDate and (DisDate is null Or DepositDate<=DisDate) and Deposits.Archived='No' and Admissions.Archived='No'

Union all

SELECT Distinct DepReason,DepositAmount, DepositDate, Deposits.UserID, Deposits.OPDNo, Deposits.Pat_No, '', Deposits.StatusCode, IsNull((Select TOP 1 ClinicCode From OPD_Nos Where PatNo=Pat_No),'') , DepositTime, Deposits.ReceiptNo FROM Deposits Where Deposits.Archived='No' and ReceiptNo NOT IN 
(SELECT Deposits.ReceiptNo FROM Deposits, Admissions Where Deposits.OPDNo=Admissions.OPDNo And Deposits.Pat_No=Admissions.Pat_No And DepositDate>=AdmDate and (DisDate is null Or DepositDate<=DisDate) and Deposits.Archived='No' and Admissions.Archived='No')
go

