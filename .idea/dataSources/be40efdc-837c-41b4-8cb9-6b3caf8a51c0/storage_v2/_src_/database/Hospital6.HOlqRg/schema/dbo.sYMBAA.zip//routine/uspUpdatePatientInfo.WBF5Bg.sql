CREATE PROCEDURE [dbo].[uspUpdatePatientInfo] 
	
AS

DECLARE @surname nvarchar(100),@lastname nvarchar(100),@middlename nvarchar(100),@nationality nvarchar(100),
        @maritalstatus nvarchar(50),@TDOB nvarchar(100),@DOB datetime,@Title nvarchar(50),
        @OPDNo nvarchar(15),@homeaddrs nvarchar(100),@workaddrs nvarchar(100),@homeTel nvarchar(50),
        @worktel nvarchar(50),@emailaddrs nvarchar(100),@regStatus nvarchar(3),@regDate datetime,
        @regtime datetime,@servertime datetime,@serverdate datetime,@insured nvarchar(3),@absconded nvarchar(3),
        @sex nvarchar(50),@userid nvarchar(10)

BEGIN

Delete from PatientsInfo

declare @genderCode tinyint

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct rtrim(ltrim(surname)) As surname,rtrim(ltrim(lastname)) as lastname,rtrim(ltrim(middlename)) As middlename,
       rtrim(ltrim(nationality)) As nationality,rtrim(ltrim(marritalstatus)) As marritalstatus,TDOB,DOB,rtrim(ltrim(Title)) As Title,OPDNo,
       rtrim(ltrim(homeaddrs)) As homeaddrs,rtrim(ltrim(workaddrs)) As workaddrs,rtrim(ltrim(homeTelNo)) As homeTelNo,rtrim(ltrim(worktelNo)) As worktelNo,
       rtrim(ltrim(emailaddrs)) As emailaddrs,regStatus,regDate,regtime,servertime,serverdate,insured,absconded,rtrim(ltrim(sex)) As sex,userid From PatientsInfo1 Order by OPDNo
        
        
        
  OPEN C
  
  FETCH NEXT FROM C INTO @surname ,@lastname,@middlename,@nationality,@maritalstatus,@TDOB,@DOB,@Title,@OPDNo,@homeaddrs,@workaddrs,@homeTel,        
        @worktel,@emailaddrs,@regStatus,@regDate,@regtime,@servertime,@serverdate,@insured,@absconded,@sex,@userid;
        
        

  WHILE @@fetch_status = 0
    BEGIN

       if upper(@sex)='MALE'
          set @gendercode=2

       else
          set @gendercode=3

       insert into PatientsInfo (surname ,lastname,middlename,nationality,marritalstatus,TDOB,DOB,Title,OPDNo,HomeStreet,WorkStreet,homeTelNo,        
        worktelNo,emailaddrs,regStatus,regDate,regtime,servertime,serverdate,insured,absconded,GenderCode,userid)Values (@surname ,@lastname,@middlename,@nationality,@maritalstatus,@TDOB,@DOB,@Title,@OPDNo,@homeaddrs,@workaddrs,@homeTel,        
        @worktel,@emailaddrs,@regStatus,@regDate,@regtime,@servertime,@serverdate,@insured,@absconded,@gendercode,@userid)

  FETCH NEXT FROM C INTO @surname ,@lastname,@middlename,@nationality,@maritalstatus,@TDOB,@DOB,@Title,@OPDNo,@homeaddrs,@workaddrs,@homeTel,        
        @worktel,@emailaddrs,@regStatus,@regDate,@regtime,@servertime,@serverdate,@insured,@absconded,@sex,@userid;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

