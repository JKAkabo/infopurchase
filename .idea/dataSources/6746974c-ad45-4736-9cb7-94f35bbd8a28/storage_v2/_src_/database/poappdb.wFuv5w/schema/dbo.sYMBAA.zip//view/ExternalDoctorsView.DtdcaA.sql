CREATE VIEW [dbo].[ExternalDoctorsView]

AS

SELECT Distinct ClinicCode, DoctorName + '(' + HosName + ')' As DoctorName, ExternalDoctors.Code As DoctorID, DocRole FROM ReferralClinics Inner Join ExternalDoctors On HosID=ClinicCode Where ExternalDoctors.Archived='No'
go

