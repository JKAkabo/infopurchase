CREATE VIEW [dbo].[QBCreditServicesNhiaView]

AS

-----NHIA SERVICES

--Exempted Capitated Diagnostics
Select NHIAEpisodeServices.ServiceFee*RequiredQty As PaidAmt, ServiceCode, Description As ServiceDescription, EndEpisode As TransDate, RecordID As TransID, Episode.SponsorNo As ReceiverID, ServicePlaceID As IssuerID,'Service Credit Sale-Nhia' As MoveType, UPPER(SponsorName) As ClientName, SponsorTypeCode,EpisodeSpecialityCode From Sponsors Inner Join (Episode Inner Join (AllSetUpServicesView Inner Join NHIAEpisodeServices On ItemID=ServiceCode) On Episode.EpisodeID=NHIAEpisodeServices.EpisodeID) On Sponsors.SponsorNo=Episode.SponsorNo Where PmtType=2 and EpisodePmtType=3 And AttType<>2 and DiagnosticFee<>0 And Archived='No' and NoOfVisit>0 and NHIAEpisodeServices.ServiceTypeCode IN (4,11,12,13,14)  And UPPER(RequestType)='INTERNAL' And Episode.IsDuplicate='No' And ServiceChanged='No' And DrugChanged='No' And DiagnosisChanged='No' And InvestChanged='No' And PatInfoChanged='No' And Episode.ClaimDataProcessed='Yes' And Episode.ClaimGDRGCode<>'' And Episode.EpisodeSpecialityCode<>'' And (Episode.EpisodePrinted='Yes' Or (Episode.EpisodeBatchNo<>'' And EpisodeAllBatchNo<>''  And Episode.EpisodeBatchNo<>'None'))  and EpisodeSpecialityCode IN (Select Code From NHIAMDCS)

UNION ALL

-- Diagnostics
Select NHIAEpisodeServices.ServiceFee*RequiredQty As PaidAmt, ServiceCode, Description As ServiceDescription, EndEpisode As TransDate, RecordID As TransID, Episode.SponsorNo As ReceiverID, ServicePlaceID As IssuerID,'Service Credit Sale-Nhia' As MoveType, UPPER(SponsorName) As ClientName, SponsorTypeCode,EpisodeSpecialityCode From Sponsors Inner Join (Episode Inner Join (AllSetUpServicesView Inner Join NHIAEpisodeServices On ItemID=ServiceCode) On Episode.EpisodeID=NHIAEpisodeServices.EpisodeID) On Sponsors.SponsorNo=Episode.SponsorNo Where AttType=2 and DiagnosticFee<>0 And Archived='No' and NoOfVisit>0 and NHIAEpisodeServices.ServiceTypeCode IN (4,11,12,13,14)  And UPPER(RequestType)='INTERNAL' And Episode.IsDuplicate='No' And ServiceChanged='No' And DrugChanged='No' And DiagnosisChanged='No' And InvestChanged='No' And PatInfoChanged='No' And Episode.ClaimDataProcessed='Yes' And Episode.ClaimGDRGCode<>'' And Episode.EpisodeSpecialityCode<>'' And (Episode.EpisodePrinted='Yes' Or (Episode.EpisodeBatchNo<>'' And EpisodeAllBatchNo<>'' And Episode.EpisodeBatchNo<>'None'))  and EpisodeSpecialityCode IN (Select Code From NHIAMDCS)

UNION ALL

-- Non Diagnoses
Select Episode.ServiceFee As PaidAmt, Service_Code, Description As ServiceDescription, EndEpisode As TransDate, Episode.EpisodeID As TransID, Episode.SponsorNo As ReceiverID, ServicePlaceCode As IssuerID,'Service Credit Sale-Nhia' As MoveType , UPPER(SponsorName) As ClientName, SponsorTypeCode,EpisodeSpecialityCode From Sponsors Inner Join (AllSetUpServicesView Inner Join Episode On ItemID=Service_Code) On Sponsors.SponsorNo=Episode.SponsorNo Where AttType<>2 And Archived='No' and NoOfVisit>0 and ServiceType NOT IN (3,2) And Episode.IsDuplicate='No' And ServiceChanged='No' And DrugChanged='No' And DiagnosisChanged='No' And InvestChanged='No' And PatInfoChanged='No' And Episode.ClaimDataProcessed='Yes' And Episode.ClaimGDRGCode<>'' And Episode.EpisodeSpecialityCode<>'' And (Episode.EpisodePrinted='Yes' Or (Episode.EpisodeBatchNo<>'' And Episode.EpisodeBatchNo<>'None'))  and EpisodeSpecialityCode IN (Select Code From NHIAMDCS)

UNION ALL

-- Diagnoses
Select NHIAEpisodeServices.ServiceFee*RequiredQty As PaidAmt, ServiceCode, Description As ServiceDescription, EndEpisode As TransDate, RecordID As TransID, Episode.SponsorNo As ReceiverID, ServicePlaceID As IssuerID,'Service Credit Sale-Nhia' As MoveType , UPPER(SponsorName) As ClientName, SponsorTypeCode,EpisodeSpecialityCode From Sponsors Inner Join (Episode Inner Join (AllSetUpServicesView Inner Join NHIAEpisodeServices On ItemID=ServiceCode) On Episode.EpisodeID=NHIAEpisodeServices.EpisodeID) On Sponsors.SponsorNo=Episode.SponsorNo Where AttType<>2 And Archived='No' and NoOfVisit>0 and NHIAEpisodeServices.ServiceTypeCode = Episode.ServiceType and ServiceType IN (2) and Service_Code=NHIAEpisodeServices.ServiceCode  And UPPER(RequestType)='INTERNAL' And Episode.IsDuplicate='No' And ServiceChanged='No' And DrugChanged='No' And DiagnosisChanged='No' And InvestChanged='No' And PatInfoChanged='No' And Episode.ClaimDataProcessed='Yes' And Episode.ClaimGDRGCode<>'' And Episode.EpisodeSpecialityCode<>'' And (Episode.EpisodePrinted='Yes' Or (Episode.EpisodeBatchNo<>'' And EpisodeAllBatchNo<>'' And Episode.EpisodeBatchNo<>'None'))  and EpisodeSpecialityCode IN (Select Code From NHIAMDCS)

UNION ALL

-- Surgicals
Select NHIAEpisodeServices.ServiceFee*RequiredQty As PaidAmt, ServiceCode, Description As ServiceDescription, EndEpisode As TransDate, RecordID As TransID, Episode.SponsorNo As ReceiverID, ServicePlaceID As IssuerID,'Service Credit Sale-Nhia' As MoveType , UPPER(SponsorName) As ClientName, SponsorTypeCode,EpisodeSpecialityCode From Sponsors Inner Join (Episode Inner Join (AllSetUpServicesView Inner Join NHIAEpisodeServices On ItemID=ServiceCode) On Episode.EpisodeID=NHIAEpisodeServices.EpisodeID) On Sponsors.SponsorNo=Episode.SponsorNo Where AttType<>2 And Archived='No' and NoOfVisit>0 and NHIAEpisodeServices.ServiceTypeCode = Episode.ServiceType and ServiceType IN (3)  And UPPER(RequestType)='INTERNAL' And Episode.IsDuplicate='No' And ServiceChanged='No' And DrugChanged='No' And DiagnosisChanged='No' And InvestChanged='No' And PatInfoChanged='No' And Episode.ClaimDataProcessed='Yes' And Episode.ClaimGDRGCode<>'' And Episode.EpisodeSpecialityCode<>'' And (Episode.EpisodePrinted='Yes' Or (Episode.EpisodeBatchNo<>'' And EpisodeAllBatchNo<>'' And Episode.EpisodeBatchNo<>'None'))  and EpisodeSpecialityCode IN (Select Code From NHIAMDCS)
go

