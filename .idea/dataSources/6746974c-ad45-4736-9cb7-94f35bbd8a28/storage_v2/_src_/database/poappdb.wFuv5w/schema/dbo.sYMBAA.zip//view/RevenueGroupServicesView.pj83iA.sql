CREATE VIEW [dbo].[RevenueGroupServicesView]

AS
SELECT Distinct Description, RevenueServiceGroups.RecordID, ServicesRevenueReportData.* FROM ServicesRevenueReportData, RevenueServiceGroups, RevenueGroupServices Where  GroupSerTypeID= SerTypeID and
RevenueServiceGroups.IsActive='Yes' and RevenueServiceGroups.RecordID= GroupID and GroupSerTypeID=1 and SerTypeID=1 and ServicesRevenueReportData.ServiceCode= RevenueGroupServices.ServiceCode

UNION

SELECT Distinct Description, RevenueServiceGroups.RecordID, ServicesRevenueReportData.* FROM ServicesRevenueReportData, RevenueServiceGroups, RevenueGroupServices Where  GroupSerTypeID= SerTypeID and
RevenueServiceGroups.IsActive='Yes' and RevenueServiceGroups.RecordID= GroupID and GroupSerTypeID=2 and SerTypeID=2 and ServicesRevenueReportData.ServiceCode= RevenueGroupServices.ServiceCode

UNION

SELECT Distinct RevenueServiceGroups.Description, RevenueServiceGroups.RecordID, ServicesRevenueReportData.* FROM ServicesRevenueReportData, RevenueServiceGroups, RevenueGroupServices, AllSetUpServicesView Where  GroupSerTypeID= SerTypeID and
RevenueServiceGroups.IsActive='Yes' and RevenueServiceGroups.RecordID= GroupID and GroupSerTypeID=3 and SerTypeID=3 and ServicesRevenueReportData.ServiceCode=ItemID and Convert(nvarchar(15),ServiceTypeCode)= RevenueGroupServices.ServiceCode

UNION

SELECT Distinct Description, RevenueServiceGroups.RecordID, ServicesRevenueReportData.* FROM ServicesRevenueReportData, RevenueServiceGroups, RevenueGroupServices Where  GroupSerTypeID= SerTypeID and
RevenueServiceGroups.IsActive='Yes' and RevenueServiceGroups.RecordID= GroupID and GroupSerTypeID=4 and SerTypeID=4 and ServicesRevenueReportData.ServicePlaceCode= RevenueGroupServices.ServiceCode
go

