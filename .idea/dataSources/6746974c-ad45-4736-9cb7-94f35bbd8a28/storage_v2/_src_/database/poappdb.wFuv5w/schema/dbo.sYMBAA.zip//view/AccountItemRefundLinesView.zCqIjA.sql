CREATE VIEW [dbo].[AccountItemRefundLinesView]
AS
  -------Item Cash Refund
SELECT      
             r.RecordID As TransID
            ,r.ServiceCode
            ,r.RefundQty * r.Service_Fee AS PaidAmt
			,r.RefundDate As TransDate
			,P.StoresID  AS IssuerID
			,r.PmtTypeCode
			,P .SponsorNo As ReceiverID
			,i.Description  As ServiceDescription
			,SP.Description  AS ClientName
			,'Cash Item Refunds' As SaleType
			,r.Pat_ID As OPDNo
			,'Item Cash Refund' As MoveType
			,CONVERT(nvarchar(15),i.ItemClassCode) As ItemClassCode
FROM         
             Service_Places SP Inner Join
             (Items  i INNER JOIN
             (dbo.RefundServiceLines   AS r 
             INNER JOIN dbo.Prescriptions P   
             ON r.ServiceCode = P.DrugCode  
             and r.ServiceID =P.RecordID)
             ON i.ItemID =P.DrugCode )
             ON SP.Code =P.StoresID 
WHERE
             r.PmtTypeCode =1  
UNION ALL
           ----Items Credit Refunds
SELECT      
             r.RecordID As TransID
            ,r.ServiceCode
            ,r.RefundQty * r.Service_Fee AS PaidAmt
			,r.RefundDate As TransDate
			,P.StoresID  AS IssuerID
			,r.PmtTypeCode
			,P .SponsorNo As ReceiverID
			,i.Description  As ServiceDescription
			,(SELECT Upper(SponsorName) FROM Sponsors WHERE SponsorNo =P.SponsorNo) AS ClientName
			,'Credit Item Refunds' As SaleType
			,r.Pat_ID As OPDNo
			,'Item Credit Refund' As MoveType
		    ,CONVERT(nvarchar(15),i.ItemClassCode) As ItemClassCode

FROM         
             Service_Places SP Inner Join
             (items i INNER JOIN
             (dbo.RefundServiceLines   AS r 
             INNER JOIN dbo.Prescriptions P   
             ON r.ServiceCode = P.DrugCode  
             and r.ServiceID =P.RecordID)
             ON i.ItemID =P.DrugCode )
             ON SP.Code =P.StoresID 
WHERE
             r.PmtTypeCode =2              

UNION ALL
----Archived Credit Drugs Sales
   
   SELECT
       RecordID As TransID,DrugCode  As ServiceCode
      ,PaidAmt=( QtyGiven *UnitPrice )
      ,P.ArchivedDate As TransDate , StoresID As IssuerID
      ,P.PmtTypeCode,P.SponsorNo As ReceiverID 
      ,'ARCHIVED'+'-'+i.Description As ServiceDescription
      ,UPPER(SP.SponsorName ) AS ClientName  
      ,'Archived Credit Items' as SaleType 
      ,P.OPDNo 
      ,'Item Credit Refund' As MoveType 
      ,Convert(nvarchar(15),i.ItemClassCode) As ItemClassCode  
   FROM 
      Items i Inner Join(
      Sponsors  SP Inner Join
      dbo.Prescriptions P 
      on SP.SponsorNo  =P.SponsorNo )
      ON i.ItemID =P.DrugCode  
   Where  
      Archived= 'Yes' And Refunded='No' 
      And P.PmtTypeCode =2 And P.SponsorNo <>''
      And QtyGiven >0
      --And SP.AcctsBlocked  ='No'
go

