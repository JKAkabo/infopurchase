CREATE PROCEDURE [dbo].[uspGetServerDate] 
(@serDate datetime OUTPUT)

AS

set @serDate =GETDATE()
go

