CREATE VIEW [dbo].[AccountCostOfGoodsSoldView]

AS

--COST OF GOODS SOLD
SELECT
	
S.ItemID As ServiceCode, S.DispensedQty * S.UnitCost As TransAmt, S.DispensedDate As TransDate,J.TransTypeID, J.AcctCode AS CreditAcctCode,UPPER(A.Description) as CreditAcctName,
UPPER(T.Description) as CreditPostType,UPPER(P.Description) as Creditor,TypeDescription,A.AcctTypeID,P.Code As ClientID,

ISNULL((Select TOP 1 B.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping B, AccountChartServicesMapping X 
Where B.TransTypeID=6 AND B.AcctTypeID=13 And B.TransTypeID=J.TransTypeID AND A.Code=B.AcctCode And T.Code=B.AcctPostType AND B.AcctTypeIDJE=J.AcctTypeID And X.ServiceTypeID=1 AND 
B.AcctCodeJE=J.AcctCode And B.AcctCodeJE=X.AccountChartCode And X.PostingType=6 AND X.ServiceID=M.ServiceID And B.AcctPostType=1),'') As DebitAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping B, AccountChartServicesMapping X 
Where B.TransTypeID=6 AND B.AcctTypeID=13 And B.TransTypeID=J.TransTypeID AND A.Code=B.AcctCode And T.Code=B.AcctPostType And B.AcctTypeIDJE=J.AcctTypeID And X.ServiceTypeID=1 AND 
B.AcctCodeJE=J.AcctCode And B.AcctCodeJE=X.AccountChartCode And X.PostingType=6 AND X.ServiceID=M.ServiceID And B.AcctPostType=1),'') As DebitAcctName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping B, AccountChartServicesMapping X 
Where B.TransTypeID=6 AND B.AcctTypeID=13 And B.TransTypeID=J.TransTypeID AND A.Code=B.AcctCode And T.Code=B.AcctPostType AND B.AcctTypeIDJE=J.AcctTypeID And X.ServiceTypeID=1 AND 
B.AcctCodeJE=J.AcctCode And B.AcctCodeJE=X.AccountChartCode And X.PostingType=6 AND X.ServiceID=M.ServiceID And B.AcctPostType=1),'') As DebitPostType

, '' As TransID
	      	
FROM 
	
Service_Places P,Items R,AccountChartServicesMapping M, AccountChatsView A,AccountPostingType T,
DispensedPrescriptions S, AccountsChartJournalMappingView J, ServicesConfigurationSetupView V
	
WHERE 

R.ItemID=S.ItemID AND  J.TransTypeID=6 And A.Code=J.AcctCode And P.Code=S.StoreID And 
T.Code=J.AcctPostType And J.TransTypeID=M.PostingType And J.AcctCode=M.AccountChartCode And A.Code=M.AccountChartCode And J.AcctPostType=2  
And ((V.AcctsDrugsMapID=4 and M.ServiceID = S.StoreID  AND M.ServiceTypeID=1) OR (V.AcctsDrugsMapID=3 and M.ServiceID = 1 AND M.ServiceTypeID=1) OR 
(V.AcctsDrugsMapID=2 and M.ServiceID = R.ItemID  AND M.ServiceTypeID=1)  OR (V.AcctsDrugsMapID=5 and M.ServiceID = CONVERT(NVarchar(15),R.ItemClassCode) AND M.ServiceTypeID=1)
 OR (V.AcctsDrugsMapID=6 and M.ServiceID = CONVERT(NVarchar(15),R.ItemTypeCode) AND M.ServiceTypeID=1))
			
	
UNION ALL

--COST OF GOODS RETURNED
SELECT
	
S.ItemID As ServiceCode, S.ReturnedQty * S.UnitCost, S.ReturnedDate As TransDate, J.TransTypeID, 

ISNULL((Select TOP 1 B.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping B, AccountChartServicesMapping X 
Where B.TransTypeID=6 AND B.AcctTypeID=13 And B.TransTypeID=J.TransTypeID AND A.Code=B.AcctCode And T.Code=B.AcctPostType AND B.AcctTypeIDJE=J.AcctTypeID And X.ServiceTypeID=1 AND 
B.AcctCodeJE=J.AcctCode And B.AcctCodeJE=X.AccountChartCode And X.PostingType=6 AND X.ServiceID=M.ServiceID And B.AcctPostType=1),'') As CreditAcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping B, AccountChartServicesMapping X 
Where B.TransTypeID=6 AND B.AcctTypeID=13 And B.TransTypeID=J.TransTypeID AND A.Code=B.AcctCode And T.Code=B.AcctPostType AND B.AcctTypeIDJE=J.AcctTypeID And X.ServiceTypeID=1 AND 
B.AcctCodeJE=J.AcctCode And B.AcctCodeJE=X.AccountChartCode And X.PostingType=6 AND X.ServiceID=M.ServiceID And B.AcctPostType=1),'') As CreditAcctName,  

'CREDIT' As CreditPostType,

UPPER(P.Description) as Debitor,A.TypeDescription,A.AcctTypeID,P.Code As ClientID,J.AcctCode AS DebitAcctCode,UPPER(A.Description) as DebitAcctName,
'CREDIT' as DebitPostType, '' As TransID	
      	
FROM 
	
Service_Places P,Items R,AccountChartServicesMapping M, AccountChatsView A,
ReturnedPrescriptions S, AccountsChartJournalMappingView J, ServicesConfigurationSetupView V
	
WHERE 

R.ItemID=S.ItemID AND P.Code =S.StoreID AND J.TransTypeID=6 And A.Code=J.AcctCode And 
J.TransTypeID=M.PostingType And J.AcctCode=M.AccountChartCode And A.Code=M.AccountChartCode And J.AcctPostType=2   
And ((V.AcctsDrugsMapID=4 and M.ServiceID = S.StoreID AND M.ServiceTypeID=1) OR (V.AcctsDrugsMapID=3 and M.ServiceID = 1 AND M.ServiceTypeID=1) OR 
(V.AcctsDrugsMapID=2 and M.ServiceID = R.ItemID  AND M.ServiceTypeID=1)  OR (V.AcctsDrugsMapID=5 and M.ServiceID = CONVERT(NVarchar(15),R.ItemClassCode) AND M.ServiceTypeID=1)
 OR (V.AcctsDrugsMapID=6 and M.ServiceID = CONVERT(NVarchar(15),R.ItemTypeCode) AND M.ServiceTypeID=1))
go

