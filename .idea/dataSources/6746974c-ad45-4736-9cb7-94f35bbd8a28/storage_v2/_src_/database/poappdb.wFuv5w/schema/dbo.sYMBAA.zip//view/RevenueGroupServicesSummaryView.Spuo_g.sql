CREATE VIEW [dbo].[RevenueGroupServicesSummaryView]

AS
SELECT Distinct Description, RevenueServiceGroups.RecordID, ServicesRevenueReportSummaryData.* FROM ServicesRevenueReportSummaryData, RevenueServiceGroups, RevenueGroupServices Where  GroupSerTypeID= SerTypeID and
RevenueServiceGroups.IsActive='Yes' and RevenueServiceGroups.RecordID= GroupID and GroupSerTypeID=1 and SerTypeID=1 and ServicesRevenueReportSummaryData.ServiceCode= RevenueGroupServices.ServiceCode

UNION

SELECT Distinct Description, RevenueServiceGroups.RecordID, ServicesRevenueReportSummaryData.* FROM ServicesRevenueReportSummaryData, RevenueServiceGroups, RevenueGroupServices Where  GroupSerTypeID= SerTypeID and
RevenueServiceGroups.IsActive='Yes' and RevenueServiceGroups.RecordID= GroupID and GroupSerTypeID=2 and SerTypeID=2 and ServicesRevenueReportSummaryData.ServiceCode= RevenueGroupServices.ServiceCode

UNION

SELECT Distinct RevenueServiceGroups.Description, RevenueServiceGroups.RecordID, ServicesRevenueReportSummaryData.* FROM ServicesRevenueReportSummaryData, RevenueServiceGroups, RevenueGroupServices, AllSetUpServicesView Where  GroupSerTypeID= SerTypeID and
RevenueServiceGroups.IsActive='Yes' and RevenueServiceGroups.RecordID= GroupID and GroupSerTypeID=3 and SerTypeID=3 and ServicesRevenueReportSummaryData.ServiceCode=ItemID and Convert(nvarchar(15),ServiceTypeCode)= RevenueGroupServices.ServiceCode

UNION

SELECT Distinct Description, RevenueServiceGroups.RecordID, ServicesRevenueReportSummaryData.* FROM ServicesRevenueReportSummaryData, RevenueServiceGroups, RevenueGroupServices Where  GroupSerTypeID= SerTypeID and
RevenueServiceGroups.IsActive='Yes' and RevenueServiceGroups.RecordID= GroupID and GroupSerTypeID=4 and SerTypeID=4 and ServicesRevenueReportSummaryData.ServicePlaceCode= RevenueGroupServices.ServiceCode
go

