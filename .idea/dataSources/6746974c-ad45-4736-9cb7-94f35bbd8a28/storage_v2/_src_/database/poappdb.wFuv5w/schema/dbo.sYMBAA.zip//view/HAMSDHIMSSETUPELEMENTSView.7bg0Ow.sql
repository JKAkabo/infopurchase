CREATE VIEW [dbo].[HAMSDHIMSSETUPELEMENTSView]

AS

Select Distinct Code, Description, 'annMT9HKpPY' As DataSetCode From DiseasesView Where Disabled='No'

Union

Select Description, Code, 'xEEusBmHs9S' As DataSetCode from DHISMappingWardView

Union

Select RTRIM(LTRIM(convert(nvarchar(25), Code )))  As Code, Description, 'szF7by0DJnr' As DataSetCode FROM  UserGrades Where IsActive='Yes' 

Union

Select RTRIM(LTRIM(convert(nvarchar(25), Code ))) As Code, Description, 'vxPPZAdtefm' As DataSetCode FROM  UserGrades Where IsActive='Yes' 

Union

Select Distinct Code,Description, CASE WHEN CatID=1 THEN 'KICMlyKR6K5' WHEN CatID=4 THEN 'RZFjMllPbuZ'
WHEN CatID=15 THEN 'IUS2nwtFKuY' END As DataSetCode from TestElementsView where CatID IN (1,4,15)

Union

Select Distinct  Code, Description, 'CREiT6PbLnm' As DataSetCode From DHIMSHAMSServicesView Where ServiceTypeCode=3
go

