CREATE VIEW [dbo].[PatientTriageLinesView]

AS

Select 'E' As RecordType, Left(MeasureValue,100) As MeasureValue ,TriageID,TriageRange,PatientTriageLines.Comments, TEWSScore, TriageParametersSetup.Description, TriageParametersSetup.ParamUnit, TEWSScore As TextTag, LabTestElementRatingTypesViews.Description As RatingDesc, ParamOrder From LabTestElementRatingTypesViews Inner Join (TriageParametersSetup Inner Join PatientTriageLines On TriageParametersSetup.Code= PatientTriageLines.ParameterID) On LabTestElementRatingTypesViews.Code=PatientTriageLines.RatingID Where PatientTriageLines.Archived='No'

Union

SELECT 'N' As RecordType,'' As MeasureValue,TriageID,'' As TriageRange,'' As Comments, 0 As TEWSScore, TriageParametersSetup.Description, TriageParametersSetup.ParamUnit, 0 As TextTag, '' As RatingDesc, ParamOrder FROM TriageParametersSetup Inner Join TempPatientTriageLines On TriageParametersSetup.Code= TempPatientTriageLines.ParameterID
go

