CREATE PROCEDURE [dbo].[uspUpdateDeadPatientsStatus] 
	
AS

DECLARE @OPDNo nvarchar(15)

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct OPDNo From Deaths Where Archived='No' Order by OPDNo
            
  OPEN C
  
  FETCH NEXT FROM C INTO @OPDNo       

  WHILE @@fetch_status = 0
    BEGIN

   update PatientsInfo Set Deceased ='Yes',Died='Yes' Where OPDNo=@OPDNo
   
  FETCH NEXT FROM C INTO @OPDNo        

	END

	CLOSE C;

	DEALLOCATE C;

END
go

