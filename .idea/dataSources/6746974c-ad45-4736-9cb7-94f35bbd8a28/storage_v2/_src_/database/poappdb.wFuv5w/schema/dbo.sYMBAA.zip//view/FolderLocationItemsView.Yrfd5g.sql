CREATE VIEW [dbo].[FolderLocationItemsView]
AS
Select ClinicBlocks.ClinicCode, ClinicBlocks.Description As ClinicBlockDesc, ShelfCells.Code, ShelfCells.Description As CellDesc, ItemShelves.ID As ShelfID, ItemShelves.Description As ShelfDesc, ItemShelves.BlockCode, ItemLocations.Code As FolderLocation, ItemLocations.Status, ItemLocations.ItemID As LocItemID, StorageTypeCode As CellType From ClinicBlocks Inner Join (ItemShelves Inner Join (ShelfCells Inner Join ItemLocations On ShelfCells.Code =ItemLocations.CellID) On ItemShelves.ID=ShelfCells.ShelfCode) On ClinicBlocks.ID=ItemShelves.BlockCode
go

