
CREATE VIEW [dbo].[ServicePlacesRevenueCostView]

AS

SELECT Sum(UnitFee * ServiceQty) As SerRevenue, 0 As SerCost, ReqDate As TransDate, SerPlaceCode, PmtTypeCode, ServiceCode, 'REVENUE' AS ElementType, '**' As CapID FROM ServicesRevenueView Where BillCategoryCode=1 and PmtTypeCode=1 Group By  ReqDate, SerPlaceCode, ServiceCode, PmtTypeCode HAVING Sum(UnitFee * ServiceQty)>0

UNION ALL

SELECT Sum(UnitFee * RequiredQty) As SerRevenue, 0 As SerCost, ReqDate As TransDate, SerPlaceCode, PmtTypeCode, ServiceCode, 'REVENUE' AS ElementType, '**' As CapID FROM PrivateSponsoredServicesView Group By  ReqDate, SerPlaceCode, ServiceCode, PmtTypeCode HAVING Sum(UnitFee * RequiredQty)>0

UNION ALL

SELECT Sum(UnitFee * RequiredQty) As SerRevenue,  0 As SerCost, ReqDate As TransDate, SerPlaceCode, PmtTypeCode, ServiceCode, 'REVENUE' AS ElementType, '**' As CapID FROM NHIAServicesView Group By  ReqDate, SerPlaceCode, ServiceCode, PmtTypeCode HAVING Sum(UnitFee * RequiredQty)>0

UNION ALL

SELECT  0 As SerRevenue, Sum(AdjustQty * UnitCost) As SerCost,  MoveDate, ReceiverID, 0, ItemID, 'COST' AS ElementType, '**' As CapID FROM STOCKMOVEMENT Where 
MoveType='Orders' OR MoveType='Initial Stocks' OR MoveType='Stock Adjustments' OR (MoveType='Requisitions' and ReceiverID<>'') Group By MoveDate,ReceiverID, ItemID HAVING Sum(AdjustQty * UnitCost)<>0

UNION ALL

SELECT  0 As SerRevenue, Sum(-AdjustQty * UnitCost) As SerCost, MoveDate, IssuerID, 0, ItemID, 'COST' AS ElementType, '**' As CapID FROM STOCKMOVEMENT Where (MoveType='Requisitions' and IssuerID<>'') Group By MoveDate,IssuerID, ItemID HAVING Sum(AdjustQty * UnitCost)<>0

go

