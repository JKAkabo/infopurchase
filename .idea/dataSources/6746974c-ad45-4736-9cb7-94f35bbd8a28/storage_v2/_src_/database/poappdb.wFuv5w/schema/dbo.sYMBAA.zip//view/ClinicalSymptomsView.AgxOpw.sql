
CREATE VIEW [dbo].[ClinicalSymptomsView]

AS

SELECT Complaints.Description,CompID ,OrderNo, ClinicalSystems.Description As SystemDescription, SysID, GenderCode, AgeGroupCode, Disabled, 
GenderGroups.Description As Gender, AgeGroups.Description As AgeGroup FROM dbo.ClinicalSystems, AgeGroups,GenderGroups, Complaints
where AgeGroups.Code=AgeGroupCode and GenderGroups.Code=GenderCode and ID= SysID

go

