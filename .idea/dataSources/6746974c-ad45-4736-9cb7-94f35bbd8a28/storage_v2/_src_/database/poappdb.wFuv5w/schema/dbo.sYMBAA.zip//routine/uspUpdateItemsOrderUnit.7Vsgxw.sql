CREATE PROCEDURE [dbo].[uspUpdateItemsOrderUnit] 
	
AS

DECLARE @DisCategory nvarchar(250),@DisCatCode numeric(18,0);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT ItemID, IssueUnitCode From items Order by ItemID Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO @DisCategory, @DisCatCode;

  WHILE @@fetch_status = 0
  
    BEGIN
       
       update OrderLines Set OrderUnitID=@DisCatCode where ItemID = @DisCategory and OrderUnitID=0

       update Adjusted_Stocks Set ItemUnitID=@DisCatCode where ItemID = @DisCategory and ItemUnitID=0

       FETCH NEXT FROM C INTO @DisCategory, @DisCatCode;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

