CREATE PROCEDURE [dbo].[uspUpdateItemsPresQuantityPerIssueUnit] 
	
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
       
 update Items Set PresQuanityPerIssueUnit=convert(numeric(18,2),PrescriptionQty),IssueUnitQuantity=1 ,PresUnitQuantity=1

END
go

