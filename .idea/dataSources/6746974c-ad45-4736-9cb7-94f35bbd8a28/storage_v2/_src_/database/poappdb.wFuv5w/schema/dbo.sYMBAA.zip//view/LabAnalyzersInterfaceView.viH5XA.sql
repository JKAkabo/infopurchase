CREATE VIEW [dbo].[LabAnalyzersInterfaceView]
AS
SELECT     dbo.LabAnalyzers.RecordID, dbo.LabAnalyzers.Description, dbo.LabAnalyzers.Code, dbo.LabAnalyzers.Model, dbo.LabAnalyzers.IsActive, dbo.LabAnalyzers.TypeCode, 
                      dbo.LabAnalyzers.ConnectCode, dbo.LabAnalyzerConnectors.Description AS Connector, dbo.LabAnalyzers.ManufacCode, dbo.LabAnalyzerManufacturers.Description AS Manufacturer, 
                      dbo.ServiceCategories.Description AS Type
FROM         dbo.LabAnalyzers INNER JOIN
                      dbo.LabAnalyzerConnectors ON dbo.LabAnalyzers.ConnectCode = dbo.LabAnalyzerConnectors.Code INNER JOIN
                      dbo.LabAnalyzerManufacturers ON dbo.LabAnalyzers.ManufacCode = dbo.LabAnalyzerManufacturers.Code INNER JOIN
                      dbo.ServiceCategories ON dbo.LabAnalyzers.TypeCode = dbo.ServiceCategories.Code
go

