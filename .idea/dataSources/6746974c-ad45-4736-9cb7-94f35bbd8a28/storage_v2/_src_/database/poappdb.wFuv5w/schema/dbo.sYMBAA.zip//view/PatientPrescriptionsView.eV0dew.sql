CREATE VIEW [dbo].[PatientPrescriptionsView]

AS

Select Distinct S.OPDNo,UnitPrice, Pat_No,IsNull((Select TOP 1 Description From ClinicsView Where SPCode=ClinicCode),'') As Clinic,
IsNull((Select TOP 1 UserID From UsersView Where UserNo=S.Prescriber),'') As PrescribedBy,S.StoresID,FacAttType,Dosage,PresDays,Units,QtyGiven,Presentation,
IsNull((Select TOP 1 UserID From UsersView Where UserNo=S.UserID),'') As UserName,ServiceTypeCode,ClinicCode,SponsorNo,MediStatus,PresStatus,PreStatus,StartDate,FinishDate,
Prescriber,MemberID, S.PmtTypeCode,S.DeptID, S.RecordID, AttServiceID, ItemID As ServiceCode, A.Description,S.DrugFlag,S.Method,S.ReturnedQty,AdmissionWard,
PatientAge,Gender,DOB,CellPhoneNo,IDNo,S.StatusCode,AttType,EpisodeType,S.BillCategoryCode,EpisodeID,CoPaySponsorNo,CoPayBillCategoryCode,S.PreReason,PreRemarks,S.PatName,
IsNull((Select TOP 1 Description From PatientCategoryView Where PatientCategoryView.Code=S.BillCategoryCode Order By CatPriority),'') As BillCategory,S.PrescribeUnit,
IsNull((Select TOP 1 Description From PatientCategoryView Where PatientCategoryView.Code=S.CoPayBillCategoryCode and CoPayFee>UnitPrice Order By CatPriority),'') As COPayBillCategory,
IsNull((Select TOP 1 Description From ServicePlacesView Where Code=StoresID),'') As ServicePlace,S.ReceiptNo As AuthorizationCode, V.Description As Pharmacy,
IsNull((Select TOP 1 Description From PaymentTypessView Where Code=p.PmtTypeCode),'') As PaymentType,PaidQty,PaidAmt,Issued,PresType,
IsNull((Select TOP 1 Description From PaymentTypessView Where Code=CoPayPmtTypeCode),'') As COPayPaymentType,DespenserID,DispensedDate,S.ServerTime,
IsNull((Select TOP 1 SponsorName From SponsorsView Where SponsorsView.SponsorNo=S.SponsorNo Order By AttPriority),'') As Sponsor,
IsNull((Select TOP 1 SponsorName From SponsorsView Where SponsorsView.SponsorNo=S.CoPaySponsorNo and CoPayFee>UnitPrice Order By AttPriority),'') As COPaySponsor,
IsNull((Select SUM(UnitPrice * QtyPrescribed) From Prescriptions Where Prescriptions.OPDNo=S.OPDNo and Prescriptions.RecordID=S.RecordID and Prescriptions.Archived='No' and Prescriptions.PresType='INTERNAL'),0) As SerTotal,
IsNull((Select SUM((CoPayFee -UnitPrice) * QtyPrescribed) From Prescriptions Where CoPayFee>UnitPrice And  Prescriptions.OPDNo=S.OPDNo and Prescriptions.RecordID=S.RecordID and Prescriptions.Archived='No' and Prescriptions.PresType='INTERNAL'),0) As CoPaySerTotal,
AttRecordID,CatID,SubCatID,DirectID,PatAge,QtyPrescribed,UnitCost,S.Insured,IsNull((Select TOP 1 Description From PatientStatusView Where Code=S.StatusCode),'') As PatStatus,P.StatusCode As CurrentStatus,
CoPayPmtTypeCode,CoPayFee,S.PatCategoryCode,LastName,SurName,MiddleName,Title,Nationality,S.UserID,PresDate ,PresTime,ReqDate, GenderCode, StaffID, PBOut, CoPayAmt, CoPayPaidAmt, CoPayPaidQty, PresAmt From 
PatientInfoView P, Prescriptions S, AllSetUpServicesView A, ServicePlacesView V  Where P.PatientID=S.OPDNo And P.OPDNo=S.Pat_No And S.DrugCode=ItemID And S.Archived='No' and V.Code=S.StoresID
go

