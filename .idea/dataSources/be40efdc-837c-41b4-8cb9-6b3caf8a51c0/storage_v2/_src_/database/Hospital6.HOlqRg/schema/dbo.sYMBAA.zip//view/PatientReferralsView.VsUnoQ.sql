CREATE VIEW [dbo].[PatientReferralsView]

AS

SELECT Distinct  Referrals.ReferredDoctorID As UserID, 'INTERNAL' As DeliveryType, PatAlert, PatWalk, PatIllness, PatUrgency, PatStaff, Reasons, Comment, Referrals.RefDate As AttDate, Referrals.RefTime As AttTime, Referrals.ReferredClinicID As ClinicCode, Description As ServicePlace, Referrals.StatusCode as PatStatus, ReferredDate, Referrals.OPDNo, Referrals.Pat_No FROM Service_Points Inner Join Referrals On SPCode=ReferredClinicID Where Referrals.Archived='No' and RefType IN (11,12)

union

SELECT Distinct Referrals.ReferredDoctorID As UserID, 'INTERNAL' As DeliveryType, PatAlert, PatWalk, PatIllness, PatUrgency, PatStaff, Reasons, Comment, Referrals.RefDate As AttDate, Referrals.RefTime As AttTime, Referrals.RefClinicID As ClinicCode, Description As ServicePlace, Referrals.StatusCode as PatStatus, ReferredDate, Referrals.OPDNo, Referrals.Pat_No FROM Service_Points Inner Join Referrals On SPCode=RefClinicID Where Referrals.Archived='No' and RefType NOT IN (11,12)
go

