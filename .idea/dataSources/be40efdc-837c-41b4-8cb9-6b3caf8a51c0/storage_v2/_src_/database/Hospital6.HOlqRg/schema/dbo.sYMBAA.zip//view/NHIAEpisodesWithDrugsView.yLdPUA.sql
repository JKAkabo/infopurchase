CREATE VIEW [dbo].[NHIAEpisodesWithDrugsView]

AS

SELECT Distinct ActiveEpiID FROM NHIAEpisodesView Inner Join (Prescriptions Inner Join DispensedPrescriptions on PresID=Prescriptions.RecordID) On (EpiID=EpisodeID And PatID=Prescriptions.OPDNo) Where Archived='No' and Refunded='No' and EpisodeID<>0 and QtyGiven>0 and PmtTypeCode<>1 and SponsorNo<>''

Union

SELECT Distinct ActiveEpiID FROM NHIAEpisodesView Inner Join Prescriptions On (EpiID=EpisodeID And PatID=Prescriptions.OPDNo) Where Archived='No' and Refunded='No' and EpisodeID<>0 and QtyGiven=0 and ReturnedQty=0 and PmtTypeCode<>1 and SponsorNo<>''
go

