CREATE PROCEDURE [dbo].[uspUpdateDailyAttendancePatCatCodes] 
	
AS

DECLARE @PatCat tinyint, @OPDNo nvarchar(15);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;

  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct PatCatID, Daily_Attendance.OPDNo from PatientsInfo inner join Daily_Attendance on PatientsInfo.OPDNo=Daily_Attendance.OPDNo where Daily_Attendance.PatCategoryCode=0  Order By Daily_Attendance.OPDNo

  
  OPEN C
  
  FETCH NEXT FROM C INTO @PatCat, @OPDNo;

  WHILE @@fetch_status = 0
    BEGIN
       
       
     update Daily_Attendance Set  PatCategoryCode=@PatCat  where  Daily_Attendance.OPDNo=@OPDNo and PatCategoryCode=0 
     

     FETCH NEXT FROM C INTO @PatCat, @OPDNo;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

