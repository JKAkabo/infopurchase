




CREATE VIEW [dbo].[AgeGroupValuesView]

AS

Select Distinct AgeGroupUpperValuesView.RecordID, AgeGroupUpperValuesView.GroupCode, LowerValue, UpperValue,LowerTypeID, UpperTypeID, LowerAgeUnit, UpperAgeUnit,LowerUnitTag,UpperUnitTag,
AgeGroupUpperValuesView.ageGroupCode, AgeGroupUpperValuesView.AgeGrpDesc, UpperTypeDesc, UpperUnitDesc, LowerTypeDesc, LowerUnitDesc, AgeGroupLowerValuesView.VbConvertionFactor As LowerFac,
AgeGroupUpperValuesView.VbConvertionFactor As UpperFac From AgeGroupUpperValuesView Inner Join AgeGroupLowerValuesView On AgeGroupUpperValuesView.RecordID = AgeGroupLowerValuesView.RecordID



go

