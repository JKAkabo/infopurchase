create PROCEDURE uspUpdatePatientTransactionOPDNos 
	
AS

DECLARE @PatNo nvarchar(15), @OPDNo nvarchar(15), @ClinicCode nvarchar(15);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;

  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct PatNo, OPD_Nos.OPDNo, ClinicCode From OPD_Nos where Rtrim(Ltrim(PatNo))<>''  Order By OPD_Nos.OPDNo

  
  OPEN C
  
  FETCH NEXT FROM C INTO @PatNo, @OPDNo, @ClinicCode;

  WHILE @@fetch_status = 0
    BEGIN
           
     Update Episode Set Pat_No=@PatNo Where OPDNo=@OPDNo and Rtrim(Ltrim(Pat_No))=''

     Update Consultations Set Pat_No=@PatNo Where OPDNo=@OPDNo and Rtrim(Ltrim(Pat_No))=''

     Update Service_Requests Set Pat_No=@PatNo Where OPDNo=@OPDNo and Rtrim(Ltrim(Pat_No))=''  

     Update Admissions Set Pat_No=@PatNo Where OPDNo=@OPDNo and Rtrim(Ltrim(Pat_No))=''

     Update AdmissionCauses Set Pat_No=@PatNo Where OPDNo=@OPDNo and Rtrim(Ltrim(Pat_No))=''
     
     Update Prescriptions Set Pat_No=@PatNo Where OPDNo=@OPDNo and Rtrim(Ltrim(Pat_No))=''

     Update Daily_Attendance Set Pat_No=@PatNo Where OPDNo=@OPDNo and Rtrim(Ltrim(Pat_No))=''

     Update BillsPaid Set Pat_No=@PatNo Where OPDNo=@OPDNo and Rtrim(Ltrim(Pat_No))=''
     
     Update Deaths Set Pat_No=@PatNo Where OPDNo=@OPDNo and Rtrim(Ltrim(Pat_No))=''
     
     Update Referrals Set Pat_No=@PatNo Where OPDNo=@OPDNo and Rtrim(Ltrim(Pat_No))=''
         
     Update MortuaryAdmission Set Pat_No=@PatNo Where OPDNo=@OPDNo and Rtrim(Ltrim(Pat_No))=''
          
     FETCH NEXT FROM C INTO @PatNo, @OPDNo, @ClinicCode;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

