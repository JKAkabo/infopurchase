CREATE VIEW [dbo].[PatientLabSpecimenCollectionsView]

AS

Select Distinct L.OPDNo,L.Pat_No,IsNull((Select TOP 1 UserID From UsersView Where UserNo=CollecterID),'') As CollectedBy,Presenter,PresentedBy,PresenterDetails,CollectDate,CollectTime,Remarks,AttDate,
IsNull((Select TOP 1 UserID From UsersView Where UserNo=L.UserID),'') As UserName,SponsorNo,SpecimenCode AS CollectionID,CollecterID,ReceiverID,MemberID,L.RecordID,PatientAge,Gender,DOB,ExternalSampleID,SampleSource,
CellPhoneNo,IDNo,L.StatusCode,L.BillCategoryCode,IsNull((Select TOP 1 Description From PatientCategoryView Where PatientCategoryView.Code=L.BillCategoryCode Order By CatPriority),'') As BillCategory,L.ServerTime,
IsNull((Select TOP 1 SponsorName From SponsorsView Where SponsorsView.SponsorNo=L.SponsorNo Order By AttPriority),'') As Sponsor,IsNull((Select TOP 1 UserID From UsersView Where UserNo=ReceiverID),'') As ReceivedBy,
L.PatAge,IsNull((Select TOP 1 Description From PatientStatusView Where Code=L.StatusCode),'') As PatStatus,LastName,SurName,MiddleName,Title,Nationality,L.UserID, GenderCode, StaffID, PBOut From 
PatientInfoView P, LabSpecimenCollection L Where P.PatientID=L.OPDNo And  L.Archived='No'
go

