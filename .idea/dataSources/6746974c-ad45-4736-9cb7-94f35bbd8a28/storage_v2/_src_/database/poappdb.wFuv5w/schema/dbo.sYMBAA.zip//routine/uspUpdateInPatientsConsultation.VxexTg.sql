CREATE PROCEDURE [dbo].[uspUpdateInPatientsConsultation] 
	
AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	
SET NOCOUNT ON;

Insert Into InPatientConsultations(AdmID,EpisodeID,SponsorNo,PatCategoryCode,PmtModeCode,PmtTypeCode,BillMethodCode,BillCycleDuration,BillCategoryCode, Doctor, Insured,Pat_No,ConDate,ConTime,OPDNo,UserID,PatAge,ServerTime,ConOutCome,DirectID,Pregnant,DoctorRemarks,TreatmentPlan) Select 
DisRecID As RecordID, AdmissionDischrgesView.EpisodeID, AdmissionDischrgesView.SponsorNo, AdmissionDischrgesView.PatCategoryCode, PmtModeCode,PmtTypeCode,BillMethodCode,BillCycleDuration,AdmissionDischrgesView.BillCategoryCode,AdmissionDischrgesView.DisAuthouriser,AdmissionDischrgesView.Insured,AdmissionDischrgesView.Pat_No,AdmissionDischrgesView.DisDate,AdmissionDischrgesView.DisTime,
AdmissionDischrgesView.OPDNo,AdmissionDischrgesView.DisAuthouriser As UserID,AdmissionDischrgesView.DisAge,ServerTime, AdmissionDischrgesView.DischargeStatusCode, DirectID,'No','','' From AdmissionDischrgesView Where 
AdmissionDischrgesView.DisDate Is Not Null and AdmissionDischrgesView.DisAuthouriser Is Not Null and DisRecID Not IN (Select Distinct AdmID From InPatientConsultations)
  
END
go

