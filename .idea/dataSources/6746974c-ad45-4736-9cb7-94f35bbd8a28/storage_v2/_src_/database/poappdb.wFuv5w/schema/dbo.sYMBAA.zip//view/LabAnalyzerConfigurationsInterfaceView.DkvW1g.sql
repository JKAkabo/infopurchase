CREATE VIEW [dbo].[LabAnalyzerConfigurationsInterfaceView]
AS
SELECT     dbo.LabAnalyzers.RecordID, dbo.LabAnalyzers.Description, dbo.LabAnalyzers.Code, dbo.LabAnalyzers.Model, dbo.LabAnalyzers.IsActive, dbo.LabAnalyzers.TypeCode, 
                      dbo.ServiceCategories.Description AS Type, dbo.LabAnalyzers.ConnectCode, dbo.LabAnalyzerConnectors.Description AS Connector, dbo.LabAnalyzers.ManufacCode, 
                      dbo.LabAnalyzerManufacturers.Description AS Manufacturer, dbo.LabAnalyzers.UserID, dbo.LabAnalyzers.ServerDate, dbo.LabAnalyzers.Cap_ID, dbo.LabAnalyzers.EnforceElementsOrder, 
                      dbo.LabAnalyzerConnectorConfigSettings.ParamCode, dbo.LabAnalyzerConnectorConfigSettings.ConfigValue, dbo.LabAnalyzerConnectivityParametersSetup.Description AS Param, 
                      dbo.LabAnalyzerConnectivityParametersSetup.IsActive AS ParamActive, dbo.LabAnalyzerConnectivityParametersSetup.ParamOrder, 
                      dbo.LabAnalyzerConnectivityParametersSetup.DefaultValue
FROM         dbo.LabAnalyzers INNER JOIN
                      dbo.LabAnalyzerConnectors ON dbo.LabAnalyzers.ConnectCode = dbo.LabAnalyzerConnectors.Code INNER JOIN
                      dbo.LabAnalyzerManufacturers ON dbo.LabAnalyzers.ManufacCode = dbo.LabAnalyzerManufacturers.Code INNER JOIN
                      dbo.ServiceCategories ON dbo.LabAnalyzers.TypeCode = dbo.ServiceCategories.Code INNER JOIN
                      dbo.LabAnalyzerConnectorConfigSettings ON dbo.LabAnalyzers.RecordID = dbo.LabAnalyzerConnectorConfigSettings.AnalyzerCode INNER JOIN
                      dbo.LabAnalyzerConnectivityParametersSetup ON dbo.LabAnalyzerConnectorConfigSettings.ParamCode = dbo.LabAnalyzerConnectivityParametersSetup.Code
go

