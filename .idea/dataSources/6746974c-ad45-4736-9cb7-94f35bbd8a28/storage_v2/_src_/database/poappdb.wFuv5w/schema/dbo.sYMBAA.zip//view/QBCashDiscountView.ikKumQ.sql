CREATE VIEW [dbo].[QBCashDiscountView]
AS
SELECT    
           PmtRecordID As TransID
          ,BillsPaid.OPDNo As ServiceCode
          ,DisAmt  AS PaidAmt
          ,PmtDate As TransDate
          ,'0104' as IssuerID
          ,BillsPaid.Pat_No As ReceiverID
          ,BillsPaid.Pat_No+' '+'Cash Discount' As ServiceDescription
          ,Surname+' '+LastName As ClientName 
          ,'Cash Discount' As MoveType
FROM        
           dbo.BillsPaid Inner Join
           PatientsInfo 
           On BillsPaid.OPDNo =PatientsInfo.OPDNo 
WHERE    
          (DisAmt > 0) AND (Archived = 'No')
go

