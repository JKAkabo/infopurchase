CREATE VIEW [dbo].[ClinicsView]

AS
--
SELECT  left(Description,100) As Description, SPCode, DirectID, Type, 'INTERNAL' AS CatType, Status, CASE WHEN Type=2 THEN 2 ELSE 1 END AS TypeOrder, QueueTimeBasedOn FROM dbo.Service_Points

Union

SELECT  left(ReferralClinics.HosName,100) As Description, ReferralClinics.HosID, 1 As DirectID, 2 As Type, 'EXTERNAL' AS CatType, 'Yes' As Status,2,'' FROM ReferralClinics

Union

SELECT  '' As Description, '' As Code, 0 As DirectID, 1 As Type, 'INTERNAL' AS CatType , 'No' As Status,2,'' FROM dbo.Hosp_Info

Union

SELECT  'DRUGS DEPOSIT' As Description, 'DEPTDRG' As Code, 0 As DirectID ,1 As Type, 'INTERNAL' AS CatType , 'No' As Status,2,'' FROM dbo.Hosp_Info
Union

SELECT  'SERVICES DEPOSIT' As Description, 'DEPTSER' As Code, 0 As DirectID, 1 As Type, 'INTERNAL' AS CatType  , 'No' As Status,2,'' FROM dbo.Hosp_Info

Union

SELECT  'OTHER DEPOSIT' As Description, 'DEPTOTH' As Code, 0 As DirectID, 1 As Type, 'INTERNAL' AS CatType  , 'No' As Status,2,'' FROM dbo.Hosp_Info

Union

SELECT  'UNUSED DRUGS DEPOSIT' As Description, 'UNDEPTDRG' As Code, 0 As DirectID, 1 As Type, 'INTERNAL' AS CatType , 'No' As Status,2,'' FROM dbo.Hosp_Info
Union

SELECT  'UNUSED SERVICES DEPOSIT' As Description, 'UNDEPTSER' As Code, 0 As DirectID, 1 As Type, 'INTERNAL' AS CatType , 'No' As Status,2,'' FROM dbo.Hosp_Info

Union

SELECT  'BILLS APPROMIXATION' As Description, 'BILLAPPR' As Code, 0 As DirectID, 1 As Type, 'INTERNAL' AS CatType  , 'No' As Status,2,'' FROM dbo.Hosp_Info

Union

SELECT  'OUTSTANDING BILLS PAYMENT' As Description, 'OUTBILLPMT' As Code, 0 As DirectID, 1 As Type, 'INTERNAL' AS CatType , 'No' As Status,2,''  FROM dbo.Hosp_Info

Union

SELECT  'SERVICES OUTSTANDING BILLS PAYMENT' As Description, 'OUTBILLPMT1' As Code, 0 As DirectID, 1 As Type, 'INTERNAL' AS CatType , 'No' As Status,2,''  FROM dbo.Hosp_Info

Union

SELECT  'SPONSORS BILLS PAYMENT' As Description, 'SPSBILLPMT' As Code, 0 As DirectID, 1 As Type, 'INTERNAL' AS CatType  , 'No' As Status,2,'' FROM dbo.Hosp_Info
go

