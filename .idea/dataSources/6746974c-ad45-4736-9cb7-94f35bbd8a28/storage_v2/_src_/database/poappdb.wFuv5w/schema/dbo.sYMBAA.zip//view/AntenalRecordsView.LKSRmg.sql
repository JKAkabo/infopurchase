CREATE VIEW [dbo].[AntenalRecordsView]

AS

Select Pat_No,P.OPDNo,P.RegDate,P.Weight,Systolic,Diastolic,UrineProtein,UrineSugar,GestAge,FHeight,Pres,Descent,FH,IFATabs,Remark,P.RecordID,
P.RegTime,P.UserID,DeptID,EmpNo,PatCategoryCode,P.StatusCode,PatAge,ServerTime,SponsorNo,P.Insured,PositionID,ConjunctivaID,FoetalMovement,PelvisRelation,MidUpperArmCircum,Complaints,
I.PatientAge,I.PatientCategory,I.LastName,I.Surname,I.MiddleName,I.Gender,I.PatStatus, I.DOB, C.Description As Conjunctiva,
D.Description As PregDescent, F.Description As PregFoetalMovement, V.Description As Presentation, U.Description As PregUrineSugar,
T.Description As Position, R.Description As PregPelvisRelation, S.Description As PregUrineProtein,
IsNull((Select TOP 1 H.Para From ObstericHistory H Where H.OPDNo=P.OPDNo And H.Pat_No=P.Pat_No),0) As Para,
IsNull((Select TOP 1 H.Gravida From ObstericHistory H Where H.OPDNo=P.OPDNo And H.Pat_No=P.Pat_No),0) As Gravida,
(Select TOP 1 H.LMP From ObstericHistory H Where H.OPDNo=P.OPDNo And H.Pat_No=P.Pat_No) As LMP,
(Select TOP 1 H.EDD From ObstericHistory H Where H.OPDNo=P.OPDNo And H.Pat_No=P.Pat_No) As EDD,
IsNull((Select TOP 1 H.IAbortion From ObstericHistory H Where H.OPDNo=P.OPDNo And H.Pat_No=P.Pat_No),0) As IAbortion,
IsNull((Select TOP 1 H.SAbortion From ObstericHistory H Where H.OPDNo=P.OPDNo And H.Pat_No=P.Pat_No),0) As SAbortion,P.CAP_ID 
From Pregnancy P,PatientInfoView I, PregnancyConjunctivaView C,PregnancyDescentView D, PregnancyFoetalMovementsView F,
PregnancyPresentationView V, PregnancyUrineSetupView U, PregnancyPositionView T, PregnancyPresentationPelvisRelationView R, PregnancyUrineSetupView S
Where P.Pat_No=I.OPDNo And P.OPDNo=I.PatientID And C.Code=P.ConjunctivaID And D.Code=P.Descent And F.Code=P.FoetalMovement 
And V.Code=P.Pres And U.Code=P.UrineSugar And T.Code=P.PositionID And R.ID=P.PelvisRelation And S.Code=P.UrineProtein and P.Archived='No'
go

