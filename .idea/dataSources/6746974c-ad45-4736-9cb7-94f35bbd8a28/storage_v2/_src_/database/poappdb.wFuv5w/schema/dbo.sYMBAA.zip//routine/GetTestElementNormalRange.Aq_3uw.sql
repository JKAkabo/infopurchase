


CREATE FUNCTION [dbo].[GetTestElementNormalRange]

(@TestElementID AS Numeric(18,0),@GenderCode tinyint=0, @AgeGroup tinyint=0) RETURNS NVARCHAR(200)

AS

BEGIN

if @TestElementID = 0 RETURN ''

DECLARE @LValue NVARCHAR(100),@UValue NVARCHAR(100), @NormalRange NVARCHAR(200);

DECLARE @MaleFemaleGenderCode tinyint, @AdultChildCode tinyint

Set @MaleFemaleGenderCode = 1
Set @AdultChildCode = 3
 
Select TOP 1 @LValue=TestElementNormalValuesView.LowerValue, @UValue=TestElementNormalValuesView.UpperValue From AgeGroupValuesView Inner Join TestElementNormalValuesView On AgeGroupValuesView.RecordID=TestElementNormalValuesView.AgeGroupID Where ElementID=@TestElementID AND (GenderCode=@GenderCode Or GenderCode=@MaleFemaleGenderCode) And (TestElementNormalValuesView.AgeGroupCode=@AgeGroup Or TestElementNormalValuesView.AgeGroupCode=@AdultChildCode)

if @@RowCount>=0 

   BEGIN
   
       if @LValue<>'' and @UValue<>'' 
          SET @NormalRange= @LValue + ' - ' + @UValue
       
       else if  @LValue<>'' and @UValue=''
          SET @NormalRange=  @LValue 
       
       else if  @LValue='' and @UValue<>''
          SET @NormalRange=  @UValue 
       
       else
          SET @NormalRange=  ''
   
   END
   
else
   SET @NormalRange=  ''   


RETURN @NormalRange

END



go

