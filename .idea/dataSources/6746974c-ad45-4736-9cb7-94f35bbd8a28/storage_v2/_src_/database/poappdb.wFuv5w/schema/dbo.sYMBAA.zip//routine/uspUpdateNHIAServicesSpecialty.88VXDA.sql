CREATE PROCEDURE [dbo].[uspUpdateNHIAServicesSpecialty] 
	
AS

DECLARE @DisCategory nvarchar(15),@Specialty nvarchar(100),@DisCatCode int;

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR select Distinct  Code,S.Specialty,ID From NHIAMDCS N, NHIAGDRGSecialties S where Left(Code,6)=Left(S.GDRGCode,6)
  
  OPEN C
  
  FETCH NEXT FROM C INTO @DisCategory,@Specialty,@DisCatCode;

  WHILE @@fetch_status = 0
    BEGIN

       if UPPER(LEFT(@DisCategory,4))='ZOOM'
          update NHIAMDCS Set SpecialtyCode=UPPER(LEFT(@DisCategory,4)) where ID=@DisCatCode
          
       ELSE if UPPER(LEFT(@DisCategory,6))='OPDC12'
          update NHIAMDCS Set SpecialtyCode='RSUR' where ID=@DisCatCode
       
       ELSE
          update NHIAMDCS Set SpecialtyCode=@Specialty where ID=@DisCatCode
       
       FETCH NEXT FROM C INTO @DisCategory,@Specialty,@DisCatCode;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

