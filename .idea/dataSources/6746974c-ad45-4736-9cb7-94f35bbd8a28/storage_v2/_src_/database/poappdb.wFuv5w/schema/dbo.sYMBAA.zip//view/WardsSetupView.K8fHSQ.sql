
Create VIEW [dbo].[WardsSetupView]

AS

SELECT  Description, Code, GenderCode, AgeGroupCode,InitialBedState,WardType,NoOfBeds,SetupDate,RBTotal,VBTotal,ARBTotal,AVBTotal,'' As ServerTime FROM Wards inner join Service_Places on WardID=Code Where Status='Yes'


UNION

SELECT  Description, Code, GenderCode, AgeGroupCode,0,WardType,NoOfBeds,'',RBTotal,VBTotal,ARBTotal,AVBTotal,ServerTime FROM WardChangeLogs inner join Service_Places on WardID=Code Where Status='Yes'

go

