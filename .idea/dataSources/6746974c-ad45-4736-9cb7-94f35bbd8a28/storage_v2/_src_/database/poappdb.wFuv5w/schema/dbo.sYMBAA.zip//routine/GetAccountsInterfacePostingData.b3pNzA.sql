-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetAccountsInterfacePostingData] 
	-- Add the parameters for the stored procedure here

	@PostingType tinyint, @DataType nvarchar(50),@FromDate datetime,@ToDate datetime,
	@RefNo nvarchar(15) ='',@ClientID nvarchar(15)='',@TransTypeID tinyint=0
	
AS
--1,15,16,17,18
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


if @DataType='NEW AND UNPROCESSED'
   if @PostingType=1
        if @TransTypeID=0
			Select SUM(TransAmt) As TransAmt, TransDate, DebitAcctCode, DebitAcctName, A.DebitPostType, TransID,C.Code, ClientName, CreditAcctCode, CreditAcctName,CreditPostType,ClientID,
			ISNULL((Select TOP 1 T.RecordID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate  And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),0) As RecordID,
			ISNULL((Select TOP 1 T.TransactionID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As TransactionID,
			ISNULL((Select TOP 1 T.EditSequence From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As EditSequence,
			ISNULL((Select TOP 1 T.DebitTransLineID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As DebitTransLineID,
			ISNULL((Select TOP 1 T.CreditTransLineID From AccountInterfaceTransactions T Where T.CreditAcctCode=CreditAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As CreditTransLineID,
			ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.DebitAcctCode),0) As DebitAcctTypeID, 
			ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.CreditAcctCode),0) As CreditAcctTypeID
			From AccountCashCreditTransactionsView A, AccountsJournalTransactionsCombined C , AccountsJournalTransactions J 
			Where C.Code=J.InterfacePostTypeID And J.Code=A.TransTypeID And C.IsActive='Yes' And J.IsActive='Yes' And TransDate>=@FromDate And TransDate<=@ToDate And C.Code=@PostingType And ((@ClientID<>'' And ClientID=@ClientID) OR @ClientID='')
			Group By C.Code, ClientName, ClientID, TransID, DebitAcctCode, DebitAcctName, A.DebitPostType, CreditAcctCode, CreditAcctName, CreditPostType, TransDate          
        
        else if @TransTypeID=1
			Select SUM(TransAmt) As TransAmt, TransDate, DebitAcctCode, DebitAcctName, A.DebitPostType, TransID,C.Code, ClientName, CreditAcctCode, CreditAcctName,CreditPostType,ClientID,
			ISNULL((Select TOP 1 T.RecordID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate  And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),0) As RecordID,
			ISNULL((Select TOP 1 T.TransactionID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As TransactionID,
			ISNULL((Select TOP 1 T.EditSequence From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As EditSequence,
			ISNULL((Select TOP 1 T.DebitTransLineID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As DebitTransLineID,
			ISNULL((Select TOP 1 T.CreditTransLineID From AccountInterfaceTransactions T Where T.CreditAcctCode=CreditAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As CreditTransLineID,
			ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.DebitAcctCode),0) As DebitAcctTypeID, 
			ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.CreditAcctCode),0) As CreditAcctTypeID
			From AccountCashServicesView A, AccountsJournalTransactionsCombined C , AccountsJournalTransactions J 
			Where C.Code=J.InterfacePostTypeID And J.Code=A.TransTypeID And C.IsActive='Yes' And J.IsActive='Yes' And TransDate>=@FromDate And TransDate<=@ToDate And C.Code=@PostingType And ((@ClientID<>'' And ClientID=@ClientID) OR @ClientID='')
			Group By C.Code, ClientName, ClientID, TransID, DebitAcctCode, DebitAcctName, A.DebitPostType, CreditAcctCode, CreditAcctName, CreditPostType, TransDate          
        
        else if @TransTypeID=15
			Select SUM(TransAmt) As TransAmt, TransDate, DebitAcctCode, DebitAcctName, A.DebitPostType, TransID,C.Code, ClientName, CreditAcctCode, CreditAcctName,CreditPostType,ClientID,
			ISNULL((Select TOP 1 T.RecordID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate  And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),0) As RecordID,
			ISNULL((Select TOP 1 T.TransactionID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As TransactionID,
			ISNULL((Select TOP 1 T.EditSequence From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As EditSequence,
			ISNULL((Select TOP 1 T.DebitTransLineID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As DebitTransLineID,
			ISNULL((Select TOP 1 T.CreditTransLineID From AccountInterfaceTransactions T Where T.CreditAcctCode=CreditAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As CreditTransLineID,
			ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.DebitAcctCode),0) As DebitAcctTypeID, 
			ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.CreditAcctCode),0) As CreditAcctTypeID
			From AccountCashDrugsView A, AccountsJournalTransactionsCombined C , AccountsJournalTransactions J 
			Where C.Code=J.InterfacePostTypeID And J.Code=A.TransTypeID And C.IsActive='Yes' And J.IsActive='Yes' And TransDate>=@FromDate And TransDate<=@ToDate And C.Code=@PostingType And ((@ClientID<>'' And ClientID=@ClientID) OR @ClientID='')
			Group By C.Code, ClientName, ClientID, TransID, DebitAcctCode, DebitAcctName, A.DebitPostType, CreditAcctCode, CreditAcctName, CreditPostType, TransDate          

        else if @TransTypeID=16
			Select SUM(TransAmt) As TransAmt, TransDate, DebitAcctCode, DebitAcctName, A.DebitPostType, TransID,C.Code, ClientName, CreditAcctCode, CreditAcctName,CreditPostType,ClientID,
			ISNULL((Select TOP 1 T.RecordID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate  And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),0) As RecordID,
			ISNULL((Select TOP 1 T.TransactionID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As TransactionID,
			ISNULL((Select TOP 1 T.EditSequence From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As EditSequence,
			ISNULL((Select TOP 1 T.DebitTransLineID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As DebitTransLineID,
			ISNULL((Select TOP 1 T.CreditTransLineID From AccountInterfaceTransactions T Where T.CreditAcctCode=CreditAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As CreditTransLineID,
			ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.DebitAcctCode),0) As DebitAcctTypeID, 
			ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.CreditAcctCode),0) As CreditAcctTypeID
			From AccountCashServicesRefundView A, AccountsJournalTransactionsCombined C , AccountsJournalTransactions J 
			Where C.Code=J.InterfacePostTypeID And J.Code=A.TransTypeID And C.IsActive='Yes' And J.IsActive='Yes' And TransDate>=@FromDate And TransDate<=@ToDate And C.Code=@PostingType And ((@ClientID<>'' And ClientID=@ClientID) OR @ClientID='')
			Group By C.Code, ClientName, ClientID, TransID, DebitAcctCode, DebitAcctName, A.DebitPostType, CreditAcctCode, CreditAcctName, CreditPostType, TransDate          

        else if @TransTypeID=17
			Select SUM(TransAmt) As TransAmt, TransDate, DebitAcctCode, DebitAcctName, A.DebitPostType, TransID,C.Code, ClientName, CreditAcctCode, CreditAcctName,CreditPostType,ClientID,
			ISNULL((Select TOP 1 T.RecordID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate  And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),0) As RecordID,
			ISNULL((Select TOP 1 T.TransactionID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As TransactionID,
			ISNULL((Select TOP 1 T.EditSequence From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As EditSequence,
			ISNULL((Select TOP 1 T.DebitTransLineID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As DebitTransLineID,
			ISNULL((Select TOP 1 T.CreditTransLineID From AccountInterfaceTransactions T Where T.CreditAcctCode=CreditAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As CreditTransLineID,
			ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.DebitAcctCode),0) As DebitAcctTypeID, 
			ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.CreditAcctCode),0) As CreditAcctTypeID
			From AccountCashDrugsRefundView A, AccountsJournalTransactionsCombined C , AccountsJournalTransactions J 
			Where C.Code=J.InterfacePostTypeID And J.Code=A.TransTypeID And C.IsActive='Yes' And J.IsActive='Yes' And TransDate>=@FromDate And TransDate<=@ToDate And C.Code=@PostingType And ((@ClientID<>'' And ClientID=@ClientID) OR @ClientID='')
			Group By C.Code, ClientName, ClientID, TransID, DebitAcctCode, DebitAcctName, A.DebitPostType, CreditAcctCode, CreditAcctName, CreditPostType, TransDate          

        else if @TransTypeID=18
			Select SUM(TransAmt) As TransAmt, TransDate, DebitAcctCode, DebitAcctName, A.DebitPostType, TransID,C.Code, ClientName, CreditAcctCode, CreditAcctName,CreditPostType,ClientID,
			ISNULL((Select TOP 1 T.RecordID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate  And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),0) As RecordID,
			ISNULL((Select TOP 1 T.TransactionID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As TransactionID,
			ISNULL((Select TOP 1 T.EditSequence From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As EditSequence,
			ISNULL((Select TOP 1 T.DebitTransLineID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As DebitTransLineID,
			ISNULL((Select TOP 1 T.CreditTransLineID From AccountInterfaceTransactions T Where T.CreditAcctCode=CreditAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As CreditTransLineID,
			ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.DebitAcctCode),0) As DebitAcctTypeID, 
			ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.CreditAcctCode),0) As CreditAcctTypeID
			From AccountCashOtherTransactionsView A, AccountsJournalTransactionsCombined C , AccountsJournalTransactions J 
			Where C.Code=J.InterfacePostTypeID And J.Code=A.TransTypeID And C.IsActive='Yes' And J.IsActive='Yes' And TransDate>=@FromDate And TransDate<=@ToDate And C.Code=@PostingType And ((@ClientID<>'' And ClientID=@ClientID) OR @ClientID='')
			Group By C.Code, ClientName, ClientID, TransID, DebitAcctCode, DebitAcctName, A.DebitPostType, CreditAcctCode, CreditAcctName, CreditPostType, TransDate          
        
        
   if @PostingType=2
		Select SUM(TransAmt) As TransAmt, TransDate, DebitAcctCode, DebitAcctName, A.DebitPostType, TransID,C.Code,Debtor As ClientName, CreditAcctCode, CreditAcctName,CreditPostType,ClientID,
		ISNULL((Select TOP 1 T.RecordID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate  And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),0) As RecordID,
		ISNULL((Select TOP 1 T.TransactionID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As TransactionID,
		ISNULL((Select TOP 1 T.EditSequence From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As EditSequence,
		ISNULL((Select TOP 1 T.DebitTransLineID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As DebitTransLineID,
		ISNULL((Select TOP 1 T.CreditTransLineID From AccountInterfaceTransactions T Where T.CreditAcctCode=CreditAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As CreditTransLineID,
		ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.DebitAcctCode),0) As DebitAcctTypeID, 
		ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.CreditAcctCode),0) As CreditAcctTypeID
		From AccountInsuredTransactionsView A, AccountsJournalTransactionsCombined C , AccountsJournalTransactions J 
		Where C.Code=J.InterfacePostTypeID And J.Code=A.TransTypeID And C.IsActive='Yes' And J.IsActive='Yes' And TransDate>=@FromDate And TransDate<=@ToDate And C.Code=@PostingType  And ((@RefNo<>'' And TransID<>'' And TransID=@RefNo and C.AutoGenerateRefNo=0) OR C.AutoGenerateRefNo=1 OR @RefNo='') And ((@ClientID<>'' And ClientID=@ClientID) OR @ClientID='')
		Group By C.Code, Debtor, ClientID, TransID, DebitAcctCode, DebitAcctName, A.DebitPostType, CreditAcctCode, CreditAcctName, CreditPostType, TransDate
   
   if @PostingType=3
		Select SUM(TransAmt) As TransAmt, TransDate, DebitAcctCode, DebitAcctName, A.DebitPostType, TransID, C.Code, Creditor As ClientName, CreditAcctCode, CreditAcctName, CreditPostType, ClientID,
		ISNULL((Select TOP 1 T.RecordID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate  And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),0) As RecordID,
		ISNULL((Select TOP 1 T.TransactionID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As TransactionID,
		ISNULL((Select TOP 1 T.EditSequence From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As EditSequence,
		ISNULL((Select TOP 1 T.DebitTransLineID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As DebitTransLineID,
		ISNULL((Select TOP 1 T.CreditTransLineID From AccountInterfaceTransactions T Where T.CreditAcctCode=CreditAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As CreditTransLineID,
		ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.DebitAcctCode),0) As DebitAcctTypeID, 
		ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.CreditAcctCode),0) As CreditAcctTypeID
		From AccountPurchaseOrdersView A, AccountsJournalTransactionsCombined C , AccountsJournalTransactions J 
		Where C.Code=J.InterfacePostTypeID And J.Code=A.TransTypeID And C.IsActive='Yes' And J.IsActive='Yes' And TransDate>=@FromDate And TransDate<=@ToDate And C.Code=@PostingType And ((@RefNo<>'' And TransID<>'' And TransID=@RefNo and C.AutoGenerateRefNo=0) OR C.AutoGenerateRefNo=1 OR @RefNo='') And ((@ClientID<>'' And ClientID=@ClientID) OR @ClientID='')
		Group By C.Code, Creditor, ClientID, TransID, DebitAcctCode, DebitAcctName, A.DebitPostType, CreditAcctCode, CreditAcctName, CreditPostType, TransDate
   
   if @PostingType=4
		Select SUM(TransAmt) As TransAmt, TransDate, DebitAcctCode, DebitAcctName, A.DebitPostType, TransID,C.Code,Creditor As ClientName, CreditAcctCode, CreditAcctName,CreditPostType, ClientID,
		ISNULL((Select TOP 1 T.RecordID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate  And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),0) As RecordID,
		ISNULL((Select TOP 1 T.TransactionID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As TransactionID,
		ISNULL((Select TOP 1 T.EditSequence From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As EditSequence,
		ISNULL((Select TOP 1 T.DebitTransLineID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As DebitTransLineID,
		ISNULL((Select TOP 1 T.CreditTransLineID From AccountInterfaceTransactions T Where T.CreditAcctCode=CreditAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As CreditTransLineID,
		ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.DebitAcctCode),0) As DebitAcctTypeID, 
		ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.CreditAcctCode),0) As CreditAcctTypeID
		From AccountCostOfGoodsSoldView A, AccountsJournalTransactionsCombined C , AccountsJournalTransactions J 
		Where C.Code=J.InterfacePostTypeID And J.Code=A.TransTypeID And C.IsActive='Yes' And J.IsActive='Yes' And TransDate>=@FromDate And TransDate<=@ToDate And C.Code=@PostingType And ((@ClientID<>'' And ClientID=@ClientID) OR @ClientID='')
		Group By C.Code, Creditor, ClientID, TransID, DebitAcctCode, DebitAcctName, A.DebitPostType, CreditAcctCode, CreditAcctName, CreditPostType, TransDate
   
   if @PostingType=5
		Select SUM(TransAmt) As TransAmt, TransDate, DebitAcctCode, DebitAcctName, A.DebitPostType, TransID,C.Code,Creditor As ClientName, CreditAcctCode, CreditAcctName,CreditPostType, ClientID,
		ISNULL((Select TOP 1 T.RecordID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate  And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),0) As RecordID,
		ISNULL((Select TOP 1 T.TransactionID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As TransactionID,
		ISNULL((Select TOP 1 T.EditSequence From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As EditSequence,
		ISNULL((Select TOP 1 T.DebitTransLineID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As DebitTransLineID,
		ISNULL((Select TOP 1 T.CreditTransLineID From AccountInterfaceTransactions T Where T.CreditAcctCode=CreditAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As CreditTransLineID,
		ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.DebitAcctCode),0) As DebitAcctTypeID, 
		ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.CreditAcctCode),0) As CreditAcctTypeID
		From AccountStocksAdjustmentView A, AccountsJournalTransactionsCombined C , AccountsJournalTransactions J 
		Where C.Code=J.InterfacePostTypeID And J.Code=A.TransTypeID And C.IsActive='Yes' And J.IsActive='Yes' And TransDate>=@FromDate And TransDate<=@ToDate And C.Code=@PostingType And ((@ClientID<>'' And ClientID=@ClientID) OR @ClientID='')
		Group By C.Code, Creditor, ClientID, TransID, DebitAcctCode, DebitAcctName, A.DebitPostType, CreditAcctCode, CreditAcctName, CreditPostType, TransDate
   
   if @PostingType=6
		Select SUM(TransAmt) As TransAmt, TransDate, DebitAcctCode, DebitAcctName, A.DebitPostType, TransID,C.Code,Debtor As ClientName, CreditAcctCode, CreditAcctName,CreditPostType, ClientID,
		ISNULL((Select TOP 1 T.RecordID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate  And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),0) As RecordID,
		ISNULL((Select TOP 1 T.TransactionID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As TransactionID,
		ISNULL((Select TOP 1 T.EditSequence From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As EditSequence,
		ISNULL((Select TOP 1 T.DebitTransLineID From AccountInterfaceTransactions T Where T.DebitAcctCode=DebitAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As DebitTransLineID,
		ISNULL((Select TOP 1 T.CreditTransLineID From AccountInterfaceTransactions T Where T.CreditAcctCode=CreditAcctCode And T.TransDate=A.TransDate And C.Code=T.ActivityTypeID And T.RefNumber=A.TransID),'') As CreditTransLineID,
		ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.DebitAcctCode),0) As DebitAcctTypeID, 
		ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=A.CreditAcctCode),0) As CreditAcctTypeID
		From AccountNHIATransactionsView A, AccountsJournalTransactionsCombined C , AccountsJournalTransactions J 
		Where C.Code=J.InterfacePostTypeID And J.Code=A.TransTypeID And C.IsActive='Yes' And J.IsActive='Yes' And TransDate>=@FromDate And TransDate<=@ToDate And C.Code=@PostingType And ((@RefNo<>'' And TransID<>'' And TransID=@RefNo and C.AutoGenerateRefNo=0) OR C.AutoGenerateRefNo=1 OR @RefNo='') And ((@ClientID<>'' And ClientID=@ClientID) OR @ClientID='')
		Group By C.Code, Debtor, ClientID, TransID, DebitAcctCode, DebitAcctName, A.DebitPostType, CreditAcctCode, CreditAcctName, CreditPostType, TransDate
 
Else
   if @DataType='PROCESSED'
	  Select RecordID, DebitAcctCode, CreditAcctCode, DebitAcctName, CreditAcctName, DebitAcctTypeID, CreditAcctTypeID, TransAmt, TransActualAmt, DebitMemo, EditSequence, TransChanged, CreditMemo,
	  ActivityTypeID, DebitTransLineID, CreditTransLineID, GeneratedReferenceNo, TransactionID, TransDate, RefNumber As TransID, ClientName, ClientID From AccountJournalPostedTransactionsDetailView
	  Where ActivityTypeID=@PostingType And TransactionID='' And ((TransDate >=@FromDate And TransDate <=@ToDate and @RefNo='' ) OR (@RefNo<>'' And RefNumber=@RefNo)) And ((ClientID=@ClientID And @ClientID<>'') OR @ClientID='')
   
   else
	  Select RecordID, DebitAcctCode, CreditAcctCode, DebitAcctName, CreditAcctName, DebitAcctTypeID, CreditAcctTypeID, TransAmt, TransActualAmt, DebitMemo, EditSequence, TransChanged, CreditMemo,
	  ActivityTypeID, DebitTransLineID, CreditTransLineID, GeneratedReferenceNo, TransactionID, TransDate, RefNumber As TransID, ClientName, ClientID From AccountJournalPostedTransactionsDetailView
	  Where ActivityTypeID=@PostingType And TransactionID<>'' And ((TransDate >=@FromDate And TransDate <=@ToDate And @RefNo='') OR (@RefNo<>'' And RefNumber=@RefNo)) And ((ClientID=@ClientID And @ClientID<>'') OR @ClientID='')
   
END
go

