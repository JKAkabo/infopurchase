Create FUNCTION [dbo].[GetCategoryOptionCode]

(@CatOptionQuery AS NVARCHAR(Max)) RETURNS NVARCHAR(100)

AS

BEGIN

if @CatOptionQuery='' RETURN 'Joer6DI3Xaf'

DECLARE @CatOption NVARCHAR(100);

Set @CatOption=''

set @CatOption=dbo.uspGetCategoryOptionCode(@CatOptionQuery)

Return @CatOption
 
END
go

