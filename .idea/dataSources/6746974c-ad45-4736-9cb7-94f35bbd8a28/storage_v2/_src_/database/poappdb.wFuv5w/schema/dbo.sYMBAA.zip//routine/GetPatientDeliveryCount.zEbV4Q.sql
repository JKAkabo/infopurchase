create FUNCTION [dbo].[GetPatientDeliveryCount]

(@BirthRecordID AS Numeric(18,0),@CountType tinyint=0) RETURNS tinyint

AS

BEGIN

Declare @DeliveryCount tinyint=0

if @CountType=0
   SELECT @DeliveryCount=Isnull(Count(Delivery.RecordID),0) FROM BirthRegistry Inner Join Delivery On BirthRegistry.RecordID=BirthRecordID Where BirthStatusCode=@CountType And Delivery.Archived='No' and BirthRegistry.Archived='No' and BirthRegistry.RecordID=@BirthRecordID

else
   SELECT @DeliveryCount=Isnull(Count(Delivery.RecordID),0) FROM BirthRegistry Inner Join Delivery On BirthRegistry.RecordID=BirthRecordID Where BirthStatusCode=@CountType And Delivery.Archived='No' and BirthRegistry.Archived='No' and BirthRegistry.RecordID=@BirthRecordID


RETURN @DeliveryCount

END
go

