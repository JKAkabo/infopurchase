CREATE PROCEDURE [dbo].[uspUpdateClaimsGDRGCodes] 
	
AS

DECLARE @DisCode nvarchar(15), @GDRGCode nvarchar(15);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;

  DECLARE C CURSOR FAST_FORWARD FOR SELECT DISTINCT DisCode, CASE When GDRGCodeA IS Not Null And GDRGCodeA<>'' THEN GDRGCodeA WHEN GDRGCodeC IS Not Null And GDRGCodeC<>'' THEN GDRGCodeC ELSE ''  END AS GDRGCode   From Diseases Where Disabled='No' and ((GDRGCodeC IS Not Null And GDRGCodeC<>'') OR (GDRGCodeA IS Not Null And GDRGCodeA<>'')) and Left(GDRGCodeA,4) IN ('MEDI','PAED')  and Left(GDRGCodeC,4) IN ('MEDI','PAED') order By DisCode
  
  OPEN C
  
  FETCH NEXT FROM C INTO @DisCode, @GDRGCode;

  WHILE @@fetch_status = 0
    BEGIN

       update ConsultationDiagnoses Set GDRGCode=left(@GDRGCode,6) + RIGHT(GDRGCode,1) Where DisCode=@DisCode
       
       update AdmissionCauses Set GDRGCode=left(@GDRGCode,6) + RIGHT(GDRGCode,1) Where DisCode=@DisCode
       
       FETCH NEXT FROM C INTO @DisCode, @GDRGCode;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

