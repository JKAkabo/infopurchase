CREATE PROCEDURE [dbo].[uspUpdateItemsBaseID] 
	
AS

DECLARE @DisCategory nvarchar(15);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
     
   update Items Set BaseItemID=ItemID where ItemID <>'' and BaseItemID=''

   update StockedItems Set BaseItemID=ItemID where ItemID <>'' and BaseItemID=''
   
   update ItemsChangeLogs Set BaseItemID=ItemID where ItemID <>'' and BaseItemID=''

END
go

