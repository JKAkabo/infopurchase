CREATE VIEW [dbo].[DiseaseCategoryView]

AS

SELECT     left(Description,100) Description, CatCode FROM dbo.MOHDiseaseCategories

Union

SELECT  TOP 1 '' As Description,  0 As CatCode FROM Hosp_Info

Union

SELECT  TOP 1 'TOTAL NEW CASES' As Description,  100 As CatCode FROM Hosp_Info
go

