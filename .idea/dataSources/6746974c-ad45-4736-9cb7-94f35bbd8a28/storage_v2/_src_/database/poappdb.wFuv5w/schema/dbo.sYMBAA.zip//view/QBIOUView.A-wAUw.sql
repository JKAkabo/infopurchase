CREATE VIEW [dbo].[QBIOUView]
AS
SELECT    
           IOURecordID As TransID
          ,IOUS.OPDNo  As ServiceCode
          ,IOUAmt   AS PaidAmt
          ,IOUDate   As TransDate
          ,'0104' as IssuerID
          ,Pat_No As ReceiverID
          ,Pat_No+' '+'Poor And Sick IOU' As ServiceDescription
          ,Surname+' '+LastName As ClientName 
          ,'Cash IOU' As MoveType
FROM        
           dbo.IOUS   Inner Join
           PatientsInfo 
           On IOUS.OPDNo =PatientsInfo.OPDNo 
WHERE    
          (IOUAmt  > 0 And Received ='Yes')
go

