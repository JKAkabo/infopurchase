-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetFoldersDueForArchiving] 
	-- Add the parameters for the stored procedure here

	@folderClinic nvarchar(15),@folderType nvarchar(50)='',@minDate datetime
	
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
 if @folderType<>''
	   SELECT Distinct PatientFolder.RecordID, PatientFolder.UserID As RegUserID, PatientFolder.ServerTime As FolderTime, PatientFolder.OPDNo, PatientFolder.Pat_No, LocationClinic, LastAccessedDate, LastAccessedTime, GenderCode, Surname, LastName, MiddleName, TDOB, IsNull(Died,'No') As Died , IsNull(BillCategoryCode,1) As BillCategoryCode,PatientsInfo.StatusCode, PatientFolder.StateCode As folderState, PatientsInfo.StatusCode As folderStatus, LocationNo FROM 
    PatientsInfo Inner Join (PatientFolder Inner Join FoldersDueForArchiveView On (PatientFolder.OPDNo = FoldersDueForArchiveView.OPDNo and PatientFolder.Pat_No = FoldersDueForArchiveView.Pat_No)) 
    On PatientsInfo.OPDNo=PatientFolder.OPDNo Where LocationClinic=@folderClinic And PatientFolder.OPDNo Not IN (Select Distinct OPDNo From FoldersDueForArchiveView Where AttDate>=@minDate ) and BasedOn=@folderType

else
	   SELECT Distinct PatientFolder.RecordID, PatientFolder.UserID As RegUserID, PatientFolder.ServerTime As FolderTime, PatientFolder.OPDNo, PatientFolder.Pat_No, LocationClinic, LastAccessedDate, LastAccessedTime, GenderCode, Surname, LastName, MiddleName, TDOB, IsNull(Died,'No') As Died, IsNull(BillCategoryCode,1) As BillCategoryCode,PatientsInfo.StatusCode, PatientFolder.StateCode As folderState, PatientsInfo.StatusCode As folderStatus, LocationNo FROM 
    PatientsInfo Inner Join (PatientFolder Inner Join FoldersDueForArchiveView On (PatientFolder.OPDNo = FoldersDueForArchiveView.OPDNo and PatientFolder.Pat_No = FoldersDueForArchiveView.Pat_No)) 
    On PatientsInfo.OPDNo=PatientFolder.OPDNo Where  LocationClinic=@folderClinic And PatientFolder.OPDNo Not IN (Select Distinct OPDNo From FoldersDueForArchiveView Where AttDate>=@minDate)

END
go

