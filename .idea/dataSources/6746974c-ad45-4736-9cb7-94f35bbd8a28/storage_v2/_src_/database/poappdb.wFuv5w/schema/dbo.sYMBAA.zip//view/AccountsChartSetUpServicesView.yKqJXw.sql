CREATE VIEW [dbo].[AccountsChartSetUpServicesView]

AS

SELECT I.ItemID As ServiceCode, AcctsDrugsMapID As ServiceMapID, 1 As ServiceTypeCode,
CASE WHEN AcctsDrugsMapID=1 THEN I.ItemID WHEN AcctsDrugsMapID=4 THEN K.StoreID  
WHEN AcctsDrugsMapID=3 THEN '1' WHEN AcctsDrugsMapID=5 THEN Convert(Nvarchar(15),I.ItemClassCode)
WHEN AcctsDrugsMapID=6 THEN Convert(Nvarchar(15),I.ItemTypeCode) END As ServiceID 
FROM ITEMS I,ServicesConfigurationSetupView S, StockedItems K Where I.ItemID<>''  and I.ItemID=K.ItemID And S.CAPID=I.CAP_ID 

UNION ALL

SELECT FEEID, S.AcctsServicesMapID, 2, CASE WHEN AcctsServicesMapID=2 THEN M.FeeID WHEN AcctsServicesMapID=4 THEN M.MorID 
WHEN AcctsServicesMapID=3 THEN  '6'  END As ServiceID 
FROM MORTUARYFEES M,ServicesConfigurationSetupView S Where FEEID<>'' and FEETYPE<>''  And S.CAPID=M.CAP_ID 

UNION ALL

SELECT FEEID, S.AcctsServicesMapID, 2, CASE WHEN AcctsServicesMapID=2 THEN M.FeeID WHEN AcctsServicesMapID=4 THEN M.WardID 
WHEN AcctsServicesMapID=3 THEN  Convert(Nvarchar(15),M.ServiceTypeCode) END As ServiceID 
FROM WardFees M,ServicesConfigurationSetupView S Where FEEID<>'' and FEETYPE<>''  And S.CAPID=M.CAP_ID 

UNION ALL

SELECT ServiceCode, S.AcctsServicesMapID, 2, CASE WHEN AcctsServicesMapID=2 THEN M.ServiceCode WHEN AcctsServicesMapID=4 THEN M.ServicePlaceCode 
WHEN AcctsServicesMapID=3 THEN  Convert(Nvarchar(15),M.ServiceTypeCode) END As ServiceID 
FROM Service_Types M,ServicesConfigurationSetupView S Where ServiceCode<>''  And S.CAPID=M.CAP_ID 


UNION ALL

SELECT DisCode, S.AcctsServicesMapID, 2, CASE WHEN AcctsServicesMapID=2 THEN M.DisCode WHEN AcctsServicesMapID=4 THEN R.SerPlaceCode 
WHEN AcctsServicesMapID=3 THEN  '2'  END As ServiceID 
FROM Diseases M, ServicesConfigurationSetupView S, Service_Requests R Where DisCode<>'' And M.DisCode=R.ServiceCode And S.CAPID=M.CAP_ID 

UNION ALL

SELECT Convert(Nvarchar(15),Code), CASE WHEN Code=12 THEN 17 WHEN Code=3 THEN 13 WHEN Code=4 THEN 14 WHEN Code=8 THEN 14 WHEN Code=9 THEN 16
WHEN Code=7 THEN 15 END As ServiceMapID, 2, Convert(Nvarchar(15),Code)
FROM AccountsJournalTransactions Where IsActive='Yes'
go

