CREATE VIEW [dbo].[PatientSystemsReviewView]

AS

SELECT Distinct SystemID, SystemDescription,Remarks, DoctorID, OPDNo, PatNo, PatAge, ClinicCode, PatStatus,ConsultationID,SymptomID, QueAnswer,Description As CompDescription,C.CompID, U.UserID As DoctorUserID,
OrderNo, RecordID, AttDate, AttTime, P.ServerTime,P.UserID, CASE WHEN QueAnswer=1 THEN 'Yes' WHEN QueAnswer=2 OR QueAnswer=0 THEN 'No' ELSE '' END As QuetionAnswer FROM ClinicalSymptomsView C, PatientSystemsReview P, UsersView U  Where 
C.SysID= SystemID and C.CompID=P.SymptomID  And P.Archived='No' and U.UserNo=DoctorID
go

