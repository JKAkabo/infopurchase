
CREATE VIEW [dbo].[ViewHamsAccessLevel2]
AS
SELECT     left(Description,100)As Description,Code,RefCode,LevelType
FROM         dbo.HAMS_ACCESS_LEVELS where LevelType=2

go

