CREATE VIEW [dbo].[ServiceSubCategoriesView]

AS

SELECT Description, Code FROM dbo.ServiceSubCategories

Union

Select '' As Description, 0 as Code from Hosp_Info
go

