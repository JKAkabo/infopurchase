CREATE VIEW [dbo].[ItemsOrdersItemTypesView]

AS

SELECT  distinct  OrderLines.OrderID  As OrderNo, ItemTypeCode, Archived, OrderLineStatus, Items.ItemID, OrderLines.OrderQty, OrderLines.OrderQtyReceived, UnitCost FROM  dbo.Items Inner join OrderLines on Items.ItemID=OrderLines.ItemID where Archived='No'
go

