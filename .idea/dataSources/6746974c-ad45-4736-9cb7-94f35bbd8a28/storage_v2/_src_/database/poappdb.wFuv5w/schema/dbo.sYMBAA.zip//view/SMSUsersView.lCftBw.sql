CREATE VIEW [dbo].[SMSUsersView]

AS

Select Distinct Users.UserID AS UserID, UserName, UserNo, CatID, UserGender, UserTitle, CONVERT(Date, UserTDOB) AS DOB,
CASE WHEN (LEN(RTRIM(ltrim(PrimaryCellNo)))=10 OR ((LEN(RTRIM(ltrim(PrimaryCellNo)))=13 OR LEN(RTRIM(ltrim(PrimaryCellNo)))=12) And LEFT(RTRIM(ltrim(PrimaryCellNo)),3)='233' )) THEN '233' + RIGHT(RTRIM(ltrim(PrimaryCellNo)),9) WHEN LEN(RTRIM(ltrim(PrimaryCellNo)))=13 THEN  RTRIM(ltrim(PrimaryCellNo)) ELSE '' END As PrimaryCellNo
From  Users where Upper(Archived)='NO' And Rtrim(Ltrim(PrimaryCellNo))<>'' And PrimaryCellNo Is Not Null And (Len(Rtrim(Ltrim(PrimaryCellNo)))=10 Or Len(Rtrim(Ltrim(PrimaryCellNo)))=12 Or Len(Rtrim(Ltrim(PrimaryCellNo)))=13)
go

