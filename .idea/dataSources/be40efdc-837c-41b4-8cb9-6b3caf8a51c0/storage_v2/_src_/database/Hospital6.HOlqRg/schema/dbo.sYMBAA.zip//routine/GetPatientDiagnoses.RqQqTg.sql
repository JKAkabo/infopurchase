

CREATE FUNCTION [dbo].[GetPatientDiagnoses]

(@OPDNo AS NVARCHAR(15),@DateFrom DateTime,@DateTo DateTime,@IsPrincipal NVARCHAR(3)) RETURNS NVARCHAR(MAX)

AS

BEGIN

Declare @ServicesRequested NVARCHAR(MAX),@ServiceDescription nvarchar(250),@DiaFee numeric(18,6)

Set @ServicesRequested=''

--SELECT Distinct ClinicCode, AdmissionCauses.DisCode, DiaFee as UnitFee, Admissions.AdmDate As ReqDate, IsNull(Diseases.ICDCode,'') As ICDCOde, Admissions.EpisodeID, Admissions.OPDNo, 3 As PatStatus, Principal As IsPrincipal, Admissions.DisDate As ConDate, Admissions.SponsorNo, 1 As DiaType, DoctorID, 'INP' As AttType, Admissions.AdmAge As PatAge, Admissions.Insured, Admissions.DischargeStatusCode, DiaCatID, AdmissionCauses.DiaManagement, Admissions.AdmTime,'' AS DoctorRemarks,MainDiseaseCode, Diseases.DisDescription As DiaDesc  FROM Diseases Inner Join (Admissions Inner Join AdmissionCauses On Admissions.RecordID=AdmissionCauses.AdmRecordID) On Diseases.DisCode=AdmissionCauses.DisCode Where Admissions.Archived='No' and Cancelled='No'

DECLARE C CURSOR FAST_FORWARD FOR SELECT TOP 1 DisDescription, DiaFee FROM Diseases Inner Join (Admissions Inner Join AdmissionCauses On Admissions.RecordID=AdmissionCauses.AdmRecordID) On Diseases.DisCode=AdmissionCauses.DisCode Where Admissions.OPDNo=@OPDNo And Principal=@IsPrincipal And Admissions.AdmDate>=@DateFrom And DisDate<=@DateTo and Admissions.Archived='No' and Cancelled='No' Order By DiaFee Desc, DisDescription Asc


OPEN C

FETCH NEXT FROM C INTO @ServiceDescription, @DiaFee;

WHILE @@fetch_status = 0

	BEGIN
                IF LTRIM(RTRIM(@ServicesRequested))<>''
				   Set @ServicesRequested=@ServicesRequested + ',' + @ServiceDescription 
				   
				else		
				   Set @ServicesRequested= @ServiceDescription 
								
	  FETCH NEXT FROM C INTO @ServiceDescription,@DiaFee;
	       
	END    
                      
    CLOSE C;

	DEALLOCATE C;		  


RETURN @ServicesRequested

END



go

