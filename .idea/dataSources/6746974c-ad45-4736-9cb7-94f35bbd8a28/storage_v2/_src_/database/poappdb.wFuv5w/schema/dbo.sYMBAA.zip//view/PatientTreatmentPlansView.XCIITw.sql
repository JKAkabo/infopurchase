CREATE VIEW [dbo].[PatientTreatmentPlansView]

AS

Select Distinct TreatmentPlan, Doctor, ConTime, UsersView.UserID As DoctorName, OPDNo, RecordID ,AdmID, 3 As PatStatus,I.UserID From InPatientConsultations I, UsersView 
Where UserNo=Doctor And I.Archived='No' and RTRIM(LTRIM(TreatmentPlan))<>'' And TreatmentPlan  Is Not Null
 
UNION  ALL

Select Distinct TreatmentPlan, Doctor, ConTime, UsersView.UserID As DoctorName,OPDNo,ConID,ConID,2,I.UserID From Consultations I, UsersView Where UserNo=Doctor And I.Archived='No' And RTRIM(LTRIM(TreatmentPlan))<>'' And TreatmentPlan Is Not Null
go

