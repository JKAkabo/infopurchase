CREATE VIEW [dbo].[AccountJournalPostedTransactionsDetailView]

AS

SELECT DebitAcctCode,CreditAcctCode, T.ActivityTypeID, T.RefNumber,T.GeneratedReferenceNo, T.TransAmt, T.TransDate,T.DebitMemo, ClientID, 
T.CreditMemo, T.ClientName,C.Description As TransDescription,T.RecordID,T.TransactionID,T.EditSequence,T.TransactionLineNo,T.TransActualAmt,
'**' As Cap_ID,T.CreateUserID, T.UpdateUserID, T.CreateServerTime,T.UpdateServerTime,T.TransChanged,T.DebitTransLineID,T.CreditTransLineID,
ISNULL((Select TOP 1 S.Description From AccountChartSetup S Where S.Code=T.DebitAcctCode),'') As DebitAcctName,FromDate,ToDate, 
ISNULL((Select TOP 1 S.Description From AccountChatsView S Where S.Code=T.CreditAcctCode),'') As CreditAcctName,
ISNULL((Select TOP 1 S.AcctTypeID From AccountChartSetup S Where S.Code=T.DebitAcctCode),0) As DebitAcctTypeID, 
ISNULL((Select TOP 1 S.AcctTypeID From AccountChatsView S Where S.Code=T.CreditAcctCode),0) As CreditAcctTypeID,
ISNULL((Select TOP 1 S.TypeDescription From AccountChatsView S Where S.Code=T.DebitAcctCode),'') As DebitAcctType, 
ISNULL((Select TOP 1 S.TypeDescription From AccountChatsView S Where S.Code=T.CreditAcctCode),'') As CreditAcctType

FROM AccountInterfaceTransactions T, AccountsJournalTransactionsCombined C
Where C.Code=T.ActivityTypeID And Deleted='No'
go

