-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetItemPrices] 
	-- Add the parameters for the stored procedure here

	@ItemID nvarchar(15)
	
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    Select Distinct TOP 1 I.ItemID, CashPrice As CashPrice , NHIAMarkUp,
   CreditPrice As CreditPrice , ChMarkup, CtMarkup, NGMarkup,NHIACoPayFee,
    NHISPrice, NGPrice  As NGPrice, I.AveUnitCost As UnitCost,FFee ,FFeeMarkup 
    From Items I Inner Join Packs P ON I.ItemID=P.ItemID where I.ItemID = @ItemID  And I.ItemID=I.BaseItemID and Unit_Type ='Base' 

END
go

