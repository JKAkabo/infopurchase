CREATE VIEW [dbo].[AllDebtorsView]

AS

SELECT Distinct PatientsInfo.OPDNo As SponsorNo, PBOut As OutBal, Surname + ' ' + MiddleName + ' ' + LastName As DebtorName, EmailAddrs As EmailAdrs, CellPhoneNo AS ContactNo, PatNo as DebtorCode,'PRIVATE CASH' AS DebtorType
, '**' As Cap_ID FROM PatientsInfo inner join OPD_Nos on PatientsInfo.OPDNo=OPD_Nos.OPDNo Where PBOut>0 and PatNo IN (Select TOP 1 PatNo From OPD_Nos Where OPDNo=PatientsInfo.OPDNo)

Union

Select Distinct SponsorNo, Sponsors.OutBal, SponsorName As DebtorName, EmailAddrs As EmailAdrs, TelNo AS ContactNo, SponsorNo as DebtorCode, UPPER(Description) As DebtorType, '**' As Cap_ID From SponsorTypes Inner Join Sponsors On SponsorTypes.Code=SponsorTypeCode Where OutBal>0 and SponsorTypeCode<>2
go

