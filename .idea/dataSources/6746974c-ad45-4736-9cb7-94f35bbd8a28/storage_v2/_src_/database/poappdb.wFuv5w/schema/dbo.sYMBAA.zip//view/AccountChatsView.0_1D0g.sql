CREATE VIEW [dbo].[AccountChatsView]

AS

SELECT  AccountChartSetup.*, AccountTypesView.Description As TypeDescription, AccountSubCategoriesView.Description As SubCatDescription, AccountCategoriesView.Description As CatDescription, CatLinkedServicesQuery, SubLinkedServicesQuery, AccountCategoriesView.TypeID FROM AccountTypesView Inner Join (AccountCategoriesView Inner Join (AccountSubCategoriesView Inner Join dbo.AccountChartSetup On AccountSubCategoriesView.ID= SubCategoryID) On AccountCategoriesView.ID=CategoryID) ON AccountTypesView.ID=AccountCategoriesView.TypeID Where AccountChartSetup.Archived='No'
go

