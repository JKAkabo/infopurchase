-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[uspGetPatientSponsorhipTypes]
	-- Add the parameters for the stored procedure here
	 @patID nvarchar(15)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	Select AttendAutheCode, InsurePolicyNo, BillCatType, ValidDateMemberID, EnforceSponsorshipExpiry, SponsorCategory, StaffNoFormat, AllowCoPay, 
	CoPayAmt, AllowsCoPayments, PatCategoryCode, PmtTypeCode, PmtModeCode, BillMethodCode, SponsorTypeCode, BillCycleDuration, 
	Isnull(IDNo,'') as IDNo, DateFrom, DateTo, SponsorName, SponsoredPatients.SponsorNo, pType, isnull(OutBal,0) as OutBal,RelationCode, 
	isnull(DepAgeLimit,0) as DepAgeLimit, sPriority, AcctsBlocked,PatReceipt, EmpNo, DeptID, ISNULL(pStatus,'') As pStatus,InsurancePoliciesView.Description as InsurancePolicy 
	From Sponsors, SponsoredPatients, InsurancePoliciesView Where OPDNo =@patID  and SponsoredPatients.Archived ='No' AND Sponsors.AcctsBlocked='No' and 
	BillCatType='DIRECT' AND InsurancePoliciesView.RecordID=InsurePolicyNo AND Sponsors.SponsorNo = SponsoredPatients.SponsorNo Order By AcctsBlocked Desc, sPriority Asc

END
go

