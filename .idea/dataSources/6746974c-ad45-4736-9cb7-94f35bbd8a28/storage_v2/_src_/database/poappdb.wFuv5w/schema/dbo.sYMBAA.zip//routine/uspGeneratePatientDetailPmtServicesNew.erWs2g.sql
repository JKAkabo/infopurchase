CREATE PROCEDURE [dbo].[uspGeneratePatientDetailPmtServicesNew]

	@User_ID nvarchar(15), @selectionCriteria nvarchar(3000)=''
	
AS

DECLARE @UserID nvarchar(15),  @SerDesc nvarchar(1), @selectionCriteria1 nvarchar(3000)=''

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.

set @UserID	=@User_ID
set @SerDesc=''

Delete from PatientReceiptServices where UserID=@User_ID or UserID=ltrim(CONVERT(nvarchar(15),CONVERT(int,@UserID)))

SET NOCOUNT ON;
  if @selectionCriteria=''
	 Set @selectionCriteria1='Insert into PatientReceiptServices (SerID, PaidQty, UnitFee, PmtTypeCode, SponsorNo,ReceiptNo,serPlace ,reqDate,cashier,pmtDate,UserID,FromDate,ToDate) ' +
	 'SELECT ServiceLinePayments.ServiceCode,ServiceLinePayments.PaidQty,ServiceLinePayments.Service_Fee,ServiceLinePayments.PmtTypeCode,ServiceLinePayments.SponsorNo,ServiceLinePayments.ReceiptNo,Prescriptions.StoresID As SerPlaceCode,PresDate,ServiceLinePayments.PmtUserID,ServiceLinePayments.PmtDate,' + CONVERT(nvarchar(15),@UserID) + ', ReqDate As FrmDate,ReqDate As ToDate From Prescriptions Inner Join ServiceLinePayments On (Prescriptions.RecordID=ServiceLinePayments.ServiceID And Prescriptions.DrugCode=ServiceLinePayments.ServiceCode)'

  else
	 Set @selectionCriteria1='Insert into PatientReceiptServices (SerID, PaidQty, UnitFee, PmtTypeCode, SponsorNo,ReceiptNo,serPlace ,reqDate,cashier,pmtDate,UserID,FromDate,ToDate) ' +
	 'SELECT ServiceLinePayments.ServiceCode,ServiceLinePayments.PaidQty,ServiceLinePayments.Service_Fee,ServiceLinePayments.PmtTypeCode,ServiceLinePayments.SponsorNo,ServiceLinePayments.ReceiptNo,Prescriptions.StoresID As SerPlaceCode,PresDate,ServiceLinePayments.PmtUserID,ServiceLinePayments.PmtDate,' + CONVERT(nvarchar(15),@UserID) + ', ReqDate As FrmDate,ReqDate As ToDate From Prescriptions Inner Join ServiceLinePayments On (Prescriptions.RecordID=ServiceLinePayments.ServiceID And Prescriptions.DrugCode=ServiceLinePayments.ServiceCode)' +
	 @selectionCriteria
  
  exec (@selectionCriteria1)
	
  if @selectionCriteria=''
  
	Set @selectionCriteria1='Insert into PatientReceiptServices (SerID, PaidQty, UnitFee, PmtTypeCode, SponsorNo,ReceiptNo,serPlace ,reqDate,cashier,pmtDate,UserID,FromDate,ToDate) ' + 
	'SELECT ServiceLinePayments.ServiceCode,ServiceLinePayments.PaidQty,ServiceLinePayments.Service_Fee,ServiceLinePayments.PmtTypeCode,ServiceLinePayments.SponsorNo,ServiceLinePayments.ReceiptNo,SerPlaceCode,ReqDate,ServiceLinePayments.PmtUserID,ServiceLinePayments.PmtDate,' +  CONVERT(nvarchar(15),@UserID) +' , ReqDate As FrmDate,ReqDate As ToDate  From  ' +
	' AllSetUpServicesView Inner Join (Service_Requests Inner Join ServiceLinePayments On (Service_Requests.ServiceCode=ServiceLinePayments.ServiceCode And Service_Requests.RecordID=ServiceLinePayments.ServiceID)) On ItemID=ServiceLinePayments.ServiceCode'
  
  else
     
	Set @selectionCriteria1='Insert into PatientReceiptServices (SerID, PaidQty, UnitFee, PmtTypeCode, SponsorNo,ReceiptNo,serPlace ,reqDate,cashier,pmtDate,UserID,FromDate,ToDate) ' + 
	'SELECT ServiceLinePayments.ServiceCode,ServiceLinePayments.PaidQty,ServiceLinePayments.Service_Fee,ServiceLinePayments.PmtTypeCode,ServiceLinePayments.SponsorNo,ServiceLinePayments.ReceiptNo,SerPlaceCode,ReqDate,ServiceLinePayments.PmtUserID,ServiceLinePayments.PmtDate,' +  CONVERT(nvarchar(15),@UserID) +' , ReqDate As FrmDate,ReqDate As ToDate  From  ' +
	' AllSetUpServicesView Inner Join (Service_Requests Inner Join ServiceLinePayments On (Service_Requests.ServiceCode=ServiceLinePayments.ServiceCode And Service_Requests.RecordID=ServiceLinePayments.ServiceID)) On ItemID=ServiceLinePayments.ServiceCode ' + @selectionCriteria
    
  exec (@selectionCriteria1)
  
END
go

