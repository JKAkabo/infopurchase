CREATE PROCEDURE [dbo].[uspUpdateItemsPricing] 
	
AS

DECLARE @Code nvarchar(15),@itemdescription nvarchar(100),@UnitCost numeric(18,6),@CashPx numeric(18,6),@CreditPx numeric(18,6),@PrivateInsurancePx numeric(18,6),@NonGhanaianPx numeric(18,6);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct  Code, itemdescription,UnitCost, CashPx,CreditPx,PrivateInsurancePx ,NonGhanaianPx from ItemsPriceUpdate  Order by Code Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO  @Code,@itemdescription,@UnitCost,@CashPx,@CreditPx,@PrivateInsurancePx,@NonGhanaianPx ;

  WHILE @@fetch_status = 0
    BEGIN

       --set @DisCategory=dbo.ItemDesc(@DisCategory);
       
       update Items Set AveUnitCost=@UnitCost where itemID=@Code
       update Packs Set UnitCost=@UnitCost,CashPrice=@CashPx,CreditPrice=@CreditPx,NGPrice=@PrivateInsurancePx,NHISPrice=@NonGhanaianPx where itemID=@Code

       FETCH NEXT FROM C INTO  @Code,@itemdescription,@UnitCost,@CashPx,@CreditPx,@PrivateInsurancePx,@NonGhanaianPx;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

