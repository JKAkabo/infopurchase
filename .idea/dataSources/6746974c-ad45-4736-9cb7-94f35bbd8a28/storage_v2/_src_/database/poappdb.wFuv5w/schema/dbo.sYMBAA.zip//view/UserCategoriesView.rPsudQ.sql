CREATE VIEW [dbo].[UserCategoriesView]

AS

SELECT Description, CatID FROM dbo.UserCategories

Union

SELECT '' AS Description, 0 As CatID FROM dbo.Hosp_Info
go

