-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[CreateWelcomeMsg]
   ON [dbo].[PatientsInfo]
   AFTER  INSERT
AS 

 if NOT EXISTS(SELECT ActivateSMS FROM Hosp_Info WHERE ActivateSMS='Yes' )
    RETURN
    
   DECLARE @Consent nvarchar(3);
   DECLARE @msgTypeID tinyint;
   DECLARE @includePatName nvarchar(3);
   DECLARE @msgContent nvarchar(200); 
   DECLARE @msgType nvarchar(100);
   DECLARE @msgStartTime datetime;
   DECLARE @patOPDNo nvarchar(15);
   DEClARE @patSurName nvarchar(100);
   DECLARE @MsgFreqID tinyint;
   DECLARE @TimeToSent datetime;
   DECLARE @OnceFreq tinyint;
   DEClARE @patCellNo nvarchar(50);

   set @OnceFreq=6;
   set @msgTypeID=5;

 select @msgType=h.Description, @msgContent=s.MsgContent,@Consent=s.EnforceConsent,@includePatName = s.includeRPT, @msgStartTime=s.StartTime, @MsgFreqID=FreqCode FROM HamsMessageTypes h Inner Join HamsSMSSetup s On h.Code=s.TypeCode WHERE s.TypeCode=@msgTypeID And s.Active='Yes'
 IF @@RowCount<=0 
    RETURN 
    
 SELECT @patOPDNo=s.OPDNo, @patSurName=(s.Title + '.' + s.Surname),@patCellNo=Rtrim(Ltrim(s.CellPhoneNo)) FROM Inserted i, SMSPatientInfoView s WHERE i.OPDNo=s.OPDNo And upper(regstatus)='NEW' And ((@Consent='Yes' And s.ExpiryAlert='Yes') or @Consent='No')  And Rtrim(Ltrim(s.CellPhoneNo))<>'' And s.CellPhoneNo Is Not Null 
 IF @@RowCount<=0 OR @patCellNo=''
    RETURN 
     
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
   DEClARE @msgOutID numeric(18,0);
   --Set Patient registration message code
      
   IF @includePatName='Yes'
      set @msgContent ='Dear' + ' ' + @patSurName + ', ' + @msgContent
               
   ELSE
      set @msgContent= @msgContent
          
   insert into bulksms_db.dbo.sending_queue([From],[To],message,queue_time,status)
   select 'System',@patCellNo,@msgContent,getdate(),'Queued' 
   
END
go

