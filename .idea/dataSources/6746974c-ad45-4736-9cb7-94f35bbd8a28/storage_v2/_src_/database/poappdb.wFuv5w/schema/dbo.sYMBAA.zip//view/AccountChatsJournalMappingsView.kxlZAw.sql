CREATE VIEW [dbo].[AccountChatsJournalMappingsView]

AS

SELECT left(A.Description,100) As AcctDescription, A.ID As AcctID, J.AcctCode, J.AcctCodeJE, J.AcctTypeID, J.AcctPostType As AcctPostTypeID ,J.AcctTypeIDJE,left(S.Description,100) As InterfacePostingType,left(Y.Description,100) As AcctType, 
J.AcctJEPostType As AcctJEPostTypeID, J.TransTypeID, left(P.Description,100) As AcctPostType, ISNULL((Select left(T.Description,100) From AccountPostingType T  Where T.Code=J.AcctJEPostType),'') As AcctJEPostType,'**' As CAP_ID,
ISNULL((Select left(T.Description,100) From AccountTypes T  Where T.ID=J.AcctTypeIDJE),'') As AcctTypeJE,ISNULL((Select left(T.Description,100) From AccountChartSetup T Where T.Code=J.AcctCodeJE),'') As AcctJEDescription
 From AccountChatsView A, AccountsChartJournalMapping J, AccountPostingType P, AccountsJournalTransactions S, AccountTypes Y  Where Y.ID=J.AcctTypeID And A.Code=J.AcctCode And P.Code=J.AcctPostType And S.Code=J.TransTypeID
go

