



CREATE VIEW [dbo].[LabAnalyzerInvalidTestsView]

AS

Select Distinct TestID, LACI.* From TestElementsView Inner Join LabAnalyzerInvalidCollectionIDsView LACI On TestElementsView.ElementID=LACI.ElementID Where LACI.SpecimenID<>'' And LACI.ElementID IN (Select Distinct Code From PatientLabRequestTestElementsView Where TestElementsView.TestID=TestCode And OPDNo<>'' And TestCode<>'' and SpecimenID NOT IN (Select SpecimenCode From LabTests Where Archived='No'))



go

