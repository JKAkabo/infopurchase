CREATE VIEW [dbo].[WardTypesView]

AS

SELECT  Description, ID, WardTypes.WardMappingCode As Code, GenderCode, AgeGroupCode, IsActive FROM WardTypes

Union

SELECT  Description, ID, '' As Code, 1, 3, IsActive FROM WardTypeSetups

Union

SELECT  '' As Description, 0 As ID, '' As Code, 1 As GenderCode, 3 As AgeGroupCode, 'No' As IsActive FROM dbo.Hosp_Info
go

