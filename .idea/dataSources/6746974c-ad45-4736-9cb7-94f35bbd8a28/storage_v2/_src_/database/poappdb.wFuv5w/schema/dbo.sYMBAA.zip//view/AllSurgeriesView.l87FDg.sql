
CREATE VIEW [dbo].[AllSurgeriesView]

AS

Select Distinct Service_Requests.OPDNo, Service_Requests.Pat_No,RequestType As DeliveryType, SurgeDate As AttDate, SurgStartTime As AttTime, SurgStartTime, SurgEndTime, SurgeEndDate As EndDate, [Procedure], Findings, SurgeonID As UserID, Surgeries.AttServiceID, SurgOutCome, SurgType, ServiceType, Service_Places.Description As ServicePlace, ClinicCode, Surgeries.StatusCode As PatStatus From Service_Places Inner Join (Service_Types Inner Join (Service_Requests Inner Join Surgeries On Service_Requests.RecordID=ServiceReqID) On Service_Types.ServiceCode=Surgeries.AttServiceID) On Code = Service_Requests.SerPlaceCode Where Surgeries.Archived='No' And Service_Requests.Archived='No'

Union ALL

Select Distinct Service_Requests.OPDNo, Service_Requests.Pat_No, RequestType As DeliveryType, Service_Requests.ReqDate As AttDate, Service_Requests.ReqTime As AttTime, Service_Requests.ReqTime As SurgStartTime, Service_Requests.ReqTime As SurgEndTime, ReqDate As EndDate, '' As [Procedure], '' As Findings, Service_Requests.RequesterID As UserID, Service_Requests.RecordID As AttServiceID, '' As SurgOutCome, '' As SurgType, ServiceType, Service_Places.Description As ServicePlace, ClinicCode, Service_Requests.StatusCode As PatStatus From Service_Places Inner Join (Service_Types Inner Join Service_Requests  On Service_Types.ServiceCode = Service_Requests.ServiceCode) On 
Code = Service_Requests.SerPlaceCode Where Service_Requests.Archived='No' And Service_Types.ServiceTypeCode=3 And Service_Requests.RecordID NOT IN (Select ServiceReqID From Surgeries Where Archived='No')

go

