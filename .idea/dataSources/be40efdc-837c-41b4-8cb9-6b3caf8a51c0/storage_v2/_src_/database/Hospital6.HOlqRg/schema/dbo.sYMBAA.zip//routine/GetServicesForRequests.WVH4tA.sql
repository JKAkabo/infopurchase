-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetServicesForRequests]
	-- Add the parameters for the stored procedure here
--	@patSex tinyint, @patMaleFemalSex tinyint,@patAgeGroup tinyint,@patAdultChildAgeGroup tinyint,
--	@patStatus tinyint,@patOutInStatus tinyint,@SerDescription nvarchar(150),@SerPlace nvarchar(15)='',
--    @SerCatID tinyint =0,@IsDirectService nvarchar(3)=''
    @selectionString nvarchar(4000)

AS

 
 
BEGIN
--   set @selectionString='Select Distinct CatID,ServiceType, ServiceCode,NHISPrice,CreditPrice,CashPrice,ServicePlaceCode,Service_Places.Description As ServicePlace,ServiceTypeCode From Service_Places Inner Join Service_Types
--             On Service_PLaces.Code = Service_Types.ServicePlaceCode Where Service_Types.Disabled=' + 'No' + '  
--             And (Service_Types.GenderCode =' + convert(nvarchar(25),@patSex)  + ' Or Service_Types.GenderCode =' + convert(nvarchar(25),@patMaleFemalSex) + ') And (Service_Types.ageGroupCode =' + convert(nvarchar(25),@patAgeGroup) + ' Or Service_Types.ageGroupCode =' + convert(nvarchar(25),@patAdultChildAgeGroup) + ') 
--               And (Service_Types.StatusCode =' + convert(nvarchar(25),@patStatus) + ' Or Service_Types.StatusCode =' + convert(nvarchar(25),@patOutInStatus) + ') And upper(ServiceType) Like ' + @SerDescription + '%' + ' And Service_Places.Description<>' + 'MEDICAL'
--  
--if @SerCatID<>0
--     set @selectionString=@selectionString + ' And Service_Types.CatID =' + convert(nvarchar(25),@SerCatID)
--
--if @SerPlace<>''
--     set @selectionString=@selectionString + ' And Service_Types.ServicePlaceCode =' + @SerPlace
--
--if @IsDirectService<>''
--     set @selectionString=@selectionString + ' And Service_PLaces.IsDirectService=' + 'Yes'

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.

exec (@selectionString)

	SET NOCOUNT ON;

    
END
go

