CREATE VIEW [dbo].[QBItemsUsageLinesView]

AS

Select UsageLineID As TransID, UnitCost, UsageQty As MoveQty, ItemsUsageLines.ItemID, UsageDate As TransDate, ItemsUsage.StoreID As IssuerID, ItemsUsageLines.UserID As ReceiverID,'Internal Item Usage' As MoveType,UPPER(Service_Places.Description) As ClientName, Items.Description As ServiceDescription, Items.ItemID As ServiceCode, Convert(Nvarchar(15),ItemClassCode) As ItemClassCode 
From Service_Places Inner Join (ItemsUsage Inner Join (Items Inner Join ItemsUsageLines On Items.ItemID=ItemsUsageLines.ItemID) ON UsageNo=UsageID) On Code=ItemsUsage.StoreID Where UPPER(Service_Places.Status)='YES' And ItemsUsageLines.ItemID IN 
(Select Items.ItemID From Items Inner Join QBAcctsMappingView ON Convert(Nvarchar(15),ItemClassCode)=ServiceID)
go

