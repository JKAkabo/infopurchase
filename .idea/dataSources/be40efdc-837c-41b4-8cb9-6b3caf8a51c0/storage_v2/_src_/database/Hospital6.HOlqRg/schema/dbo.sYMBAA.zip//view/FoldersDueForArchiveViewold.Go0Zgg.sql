create VIEW FoldersDueForArchiveViewold as select null as Col1
go

