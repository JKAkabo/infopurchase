CREATE VIEW [dbo].[InPatientFluidOutputLinesView]

AS

Select L.RecordID, OutputColour, OutputType, L.Type, L.OutputTime,IntakeAmt,OutputAmt,L.ItemID,L.OutputRecordID,
I.Description, E.Description As Colour, D.Description As Output, U.UserID As Nurse, L.CAP_ID,L.ServerTime,L.Remarks,L.UserID 
From IntakeFluidsView I,  DrugOutputTypes D, DrugOutputElements E,Users U, InPatientFluidOutputLines L 
Where U.UserNo=L.UserID And E.Code=OutputColour and L.Archived ='No' and D.Code=OutputType And I.ItemID = L.ItemID
go

