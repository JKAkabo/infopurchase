CREATE VIEW [dbo].[EyeFrameMaterialsView]

AS

Select EyeFrameDesigns.Code As DesignCode, EyeFrameMaterials.Code As MaterialCode, EyeFrameMaterials.Description  As MaterialDesc From EyeFrameMaterials Inner Join EyeFrameDesigns On  EyeFrameMaterials.Code=EyeFrameDesigns.Code
go

