CREATE VIEW [dbo].[StockInventoryParametersView]

AS

SELECT Distinct ItemID, StoreID, ReorderLevel, LeadTime, Demand, EOQ, MinLevel, MaxLevel,
Quantity, BatchNo, BaseQty, BaseUnit, PrescriptionQty

FROM Stocks 

Union ALL

SELECT Distinct ItemID, StoreID, 0 As ReorderLevel, 0 As LeadTime, 0 As Demand, 0 As EOQ, 0 As MinLevel, 0 As MaxLevel, 0 As Quantity, '' As BatchNo,
0 As BaseQty, '' As BaseUnit, 0 As PrescriptionQty
FROM  stockeditems where Isnull(ItemID + StoreID,'') NOT IN (Select Isnull(ItemID + StoreID,'') From Stocks)
go

