CREATE VIEW [dbo].[DuplicatePatientsView]

AS

Select COUNT(OPDNo) OPDNoCount, OPDNo from PatientsInfo group by OPDNo Having COUNT(OPDNo)>1
go

