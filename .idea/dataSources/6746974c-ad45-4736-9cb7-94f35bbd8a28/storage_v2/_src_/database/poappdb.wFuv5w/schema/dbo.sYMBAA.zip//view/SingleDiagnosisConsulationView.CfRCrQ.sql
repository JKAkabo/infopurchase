
CREATE VIEW [dbo].[SingleDiagnosisConsulationView]

AS

Select COUNT(discode) as DisCount, AttServiceID From Consultations Inner Join ConsultationDiagnoses On Consultations.ConID=ConsultationDiagnoses.ConID WHERE Consultations.Archived='No' Group By AttServiceID having COUNT(discode)=1

go

