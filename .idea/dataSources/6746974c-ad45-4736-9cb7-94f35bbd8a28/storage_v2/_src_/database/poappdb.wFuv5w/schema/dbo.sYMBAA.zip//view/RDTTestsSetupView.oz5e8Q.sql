CREATE VIEW [dbo].[RDTTestsSetupView]

AS

SELECT Description As CatDescription, ServiceCode, CatID, ServiceType As ServiceDescription,
IsNull((Select TOP 1 TestCode From RDTTestsSetup Where TestCode=ServiceCode),'') As TestCode 
FROM Service_Types S, ServiceCategoriesView C Where S.Disabled='No' And C.Code=S.CatID and ServiceTypeCode=11
go

