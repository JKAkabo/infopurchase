CREATE VIEW [dbo].[LabAnalyzersView]

AS

SELECT Distinct IsActive, left(Description,100) As Description,  Code, LabAnalyzers.EnforceElementsOrder, RecordID From LabAnalyzers 

Union


SELECT TOP 1 'Yes' As IsActive,'' As Description, '' As Code, '' As EnforceElementsOrder, 0 As RecordID From Hosp_Info
go

