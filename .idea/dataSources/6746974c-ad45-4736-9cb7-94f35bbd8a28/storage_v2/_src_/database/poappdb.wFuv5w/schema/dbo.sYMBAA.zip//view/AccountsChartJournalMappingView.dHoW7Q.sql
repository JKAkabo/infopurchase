CREATE VIEW [dbo].[AccountsChartJournalMappingView]

AS

SELECT Distinct A.AcctCodeJE As AcctCode, A.AcctTypeIDJE As AcctTypeID, A.AcctJEPostType As AcctPostType, TransTypeID  FROM dbo.AccountsChartJournalMapping A

Union All

SELECT Distinct AcctCode, AcctTypeID, AcctPostType, TransTypeID FROM dbo.AccountsChartJournalMapping Where TransTypeID=2

Union All

SELECT Distinct AcctCode, AcctTypeID, AcctPostType, TransTypeID FROM dbo.AccountsChartJournalMapping Where TransTypeID=5

Union All

SELECT Distinct AcctCode, AcctTypeID, AcctPostType, TransTypeID FROM dbo.AccountsChartJournalMapping Where TransTypeID=11

Union All

SELECT Distinct AcctCode, AcctTypeID, AcctPostType, TransTypeID FROM dbo.AccountsChartJournalMapping Where TransTypeID=10

Union All

SELECT Distinct AcctCode, AcctTypeID, AcctPostType, TransTypeID FROM dbo.AccountsChartJournalMapping Where TransTypeID=13
go

