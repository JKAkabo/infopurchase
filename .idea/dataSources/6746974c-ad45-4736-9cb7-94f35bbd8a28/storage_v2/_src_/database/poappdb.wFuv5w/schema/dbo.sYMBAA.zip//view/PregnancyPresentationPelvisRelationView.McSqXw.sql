CREATE VIEW [dbo].[PregnancyPresentationPelvisRelationView]

AS

SELECT  Description,ID, Code FROM dbo.PregnancyPresentationPelvisRelation

Union

SELECT  '', 0,''  FROM dbo.Hosp_Info
go

