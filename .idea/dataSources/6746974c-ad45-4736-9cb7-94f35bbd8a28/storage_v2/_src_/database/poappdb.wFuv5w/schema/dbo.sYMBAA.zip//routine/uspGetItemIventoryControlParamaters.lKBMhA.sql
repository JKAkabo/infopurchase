-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[uspGetItemIventoryControlParamaters] 
	-- Add the parameters for the stored procedure here

	@ItemID nvarchar(15), @StoreID nvarchar(15)
	
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
  Select Distinct Service_Places.Description As StoreDesc, Items.Description As ItemDesc, Stocks.StoreID, LeadTime, EOQ, ReOrderlevel, Demand, MinLevel, MaxLevel, Stocks.ItemID From 
  Service_Places Inner Join (Items Inner Join Stocks On Items.ItemID = Stocks.ItemID) On Service_Places.Code = Stocks.StoreID Where Stocks.ItemID=@ItemID and Stocks.StoreID=@StoreID


END
go

