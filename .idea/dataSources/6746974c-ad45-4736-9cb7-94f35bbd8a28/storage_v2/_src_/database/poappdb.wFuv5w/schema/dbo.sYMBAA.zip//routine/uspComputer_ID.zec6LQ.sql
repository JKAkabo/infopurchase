CREATE PROCEDURE [dbo].[uspComputer_ID] 
(@com_ID nvarchar(100) OUTPUT)

AS

set @com_ID =Host_ID()
go

