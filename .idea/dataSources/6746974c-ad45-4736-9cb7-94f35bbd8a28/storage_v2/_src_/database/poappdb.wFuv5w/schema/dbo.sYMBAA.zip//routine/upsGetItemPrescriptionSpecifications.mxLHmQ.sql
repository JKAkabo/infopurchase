-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[upsGetItemPrescriptionSpecifications] 
	-- Add the parameters for the stored procedure here

	@ItemID nvarchar(15)
	
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    Select Distinct PrescriptionSpecifications.*, PrescriptionFrequencies.Description
    As Frequency, CoversionFactor From PrescriptionFrequencies Inner Join PrescriptionSpecifications On 
    PrescriptionFrequencies.Code=PrescriptionSpecifications.FreqCode Where ItemCode= @ItemID 


END
go

