CREATE PROCEDURE [dbo].[AddNewEpisode] 

@MaxVisitsNo int,@PatAge int,@EpisodeSpecialityCode nvarchar(15),@LastVisitDate datetime,@OPDNo nvarchar(15),
@PatNo nvarchar(15),@BeginEpisode datetime,@EndEpisode datetime=NULL,@NoOfVisit int,@UserID nvarchar(15),@AttDate datetime,
@SponsorNo nvarchar(15),@Status nvarchar(3),@EpisodeType int,@EpisodeGDRGCode nvarchar(15),@EpisodeFee decimal(18,6),
@ServiceType int ,@EpisodeDuration int,@AttType int

AS

declare @EpisodeID bigint
declare @ErrorCode int
declare @AffectedRows int 

BEGIN
    if  ISDATE(@EndEpisode)=0 
		Insert Episode(MaxVisitsNo,PatAge,EpisodeSpecialityCode,LastVisitDate,OPDNo,Pat_No,BeginEpisode,NoOfVisit,UserID,AttDate,SponsorNo,[Status],EpisodeType,EpisodeGDRGCode,EpisodeFee,ServiceType,EpisodeDuration,AttType)
		Values(@MaxVisitsNo ,@PatAge ,@EpisodeSpecialityCode ,@LastVisitDate, @OPDNo ,@PatNo,@BeginEpisode,@NoOfVisit,@UserID,@AttDate,@SponsorNo,@Status,@EpisodeType,@EpisodeGDRGCode,@EpisodeFee,@ServiceType,@EpisodeDuration,@AttType)
	
    else
        BEGIN
			Insert Episode(MaxVisitsNo,PatAge,EpisodeSpecialityCode,LastVisitDate,OPDNo,Pat_No,BeginEpisode,EndEpisode,NoOfVisit,UserID,AttDate,SponsorNo,[Status],EpisodeType,EpisodeGDRGCode,EpisodeFee,ServiceType,EpisodeDuration,AttType)
			Values(@MaxVisitsNo ,@PatAge ,@EpisodeSpecialityCode ,@LastVisitDate, @OPDNo ,@PatNo,@BeginEpisode,@EndEpisode,@NoOfVisit,@UserID,@AttDate,@SponsorNo,@Status,@EpisodeType,@EpisodeGDRGCode,@EpisodeFee,@ServiceType,@EpisodeDuration,@AttType)
        END
    

    Set @ErrorCode=@@error
	set @EpisodeID=@@identity
	set @AffectedRows=@@rowcount


	Select @EpisodeID, @AffectedRows, @ErrorCode

END
go

