





CREATE VIEW [dbo].[AgeGroupLowerValuesView]

AS

Select Distinct RecordID, GroupCode, LowerValue, LowerTypeID, LowerAgeUnit, ageGroupCode, AgeGroups.Description As AgeGrpDesc, LimitComparisonValuesViews.Description As LowerTypeDesc, AgeUnitValuesViews.DescriptionTag As LowerUnitDesc,  AgeUnitValuesViews.Description As LowerUnitTag, VbConvertionFactor From AgeGroups Inner Join (LimitComparisonValuesViews Inner Join (AgeUnitValuesViews Inner Join AgeGroupsClassification On AgeUnitValuesViews.Code=LowerAgeUnit) On LimitComparisonValuesViews.Code = LowerTypeID) On AgeGroups.Code = AgeGroupCode



go

