Create VIEW [dbo].[LabTestCasesView]
AS

Select TestCode, LabTests.AgeClassCode, PatientsInfo.GenderCode, TestDate, AgeClassDescription, Service_Types.ServiceType as TestDesc From PatientsInfo Inner Join (Service_Types Inner join (ReportsAgeClassification Inner Join LabTests On ReportsAgeClassification.AgeClassCode=LabTests.AgeClassCode) On Service_Types.ServiceCode=TestCode) On PatientsInfo.OPDNo=LabTests.OPDNo Where LabTests.Archived='No'
go

