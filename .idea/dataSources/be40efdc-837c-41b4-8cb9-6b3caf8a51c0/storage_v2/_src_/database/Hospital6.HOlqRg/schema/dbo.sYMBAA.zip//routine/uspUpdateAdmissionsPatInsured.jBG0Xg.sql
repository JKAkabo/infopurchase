create PROCEDURE uspUpdateAdmissionsPatInsured 
	
AS

DECLARE @RecordID numeric(18,0);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;

  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct RecordID from Admissions where (PatCategoryCode=4 Or PatCategoryCode=11) And Archived='No' and Insured <>'Yes' Order By RecordID

  
  OPEN C
  
  FETCH NEXT FROM C INTO @RecordID;

  WHILE @@fetch_status = 0
    BEGIN
       
       
     update Admissions Set Insured='Yes' Where RecordID=@RecordID
     

     FETCH NEXT FROM C INTO @RecordID;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

