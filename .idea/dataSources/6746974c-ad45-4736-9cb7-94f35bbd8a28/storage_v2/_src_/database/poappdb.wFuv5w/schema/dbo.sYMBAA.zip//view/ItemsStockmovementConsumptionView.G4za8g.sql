



CREATE VIEW [dbo].[ItemsStockmovementConsumptionView]

AS

Select Round(IsNull(abs(Sum(AdjustQty)),0),0) As ConsumptionAmt, ItemID, StoreID, MoveType, ServerDate, MoveCat From StocksConsumptionMovementView
Group By MoveCat, StoreID, ItemID, MoveType, ServerDate



go

