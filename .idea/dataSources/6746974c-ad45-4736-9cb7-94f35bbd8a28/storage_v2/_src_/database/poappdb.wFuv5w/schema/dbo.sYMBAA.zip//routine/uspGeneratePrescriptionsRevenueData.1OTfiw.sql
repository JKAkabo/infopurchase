CREATE PROCEDURE [dbo].[uspGeneratePrescriptionsRevenueData] 

@selectionCriteria nvarchar(4000),@frmDate datetime, @toDate datetime,@frmTime nvarchar(50)='', 
@toTime nvarchar(50)='',@user_ID nvarchar(10),@Dispensory nvarchar(150),@sponsor nvarchar(15)
	
AS

DECLARE @serplace nvarchar(15),@ItemID nvarchar(15),@serAmt numeric(18,6),
        @patCat tinyint,@patCount int,@selectionString nvarchar(4000);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
 
 Delete From PrescriptionsRevenue --Where UserID=@user_ID
 
 if @sponsor<>''
    set @selectionString =@selectionCriteria + ' And SponsorNo=@sponsor'
  
 else
    set @selectionString =@selectionCriteria

 set @selectionString ='DECLARE C CURSOR FAST_FORWARD FOR SELECT isnull(sum(Quantity*UnitPrice),0) As SerAmt, DrugCode,BillCategoryCode,  Count(Distinct OPDNo) As PatCount From AllPrescriptionsView ' +  
                       @selectionString + ' And (PmtTypeCode=2 Or (PmtTypeCode=1 And PaidQty>0)) Group By DrugCode,BillCategoryCode '


 execute (@selectionString)

 OPEN C

 FETCH NEXT FROM C INTO @serAmt,@ItemID,@patCat,@patCount;

	WHILE @@fetch_status = 0

     BEGIN
	   Insert into PrescriptionsRevenue(ItemID, CatCost, CatCount, PatCategory, FromDate, ToDate, FromTime, ToTime,UserID,Dispensory)values 
	                                   (@ItemID, @serAmt, @patCount, @patCat, @frmDate, @toDate, @frmTime, @toTime,@user_ID,@Dispensory)

     
       FETCH NEXT FROM C INTO @serAmt,@ItemID,@patCat,@patCount;

    END

 CLOSE C;

 DEALLOCATE C;
  
 if @sponsor<>''
    set @selectionString =@selectionCriteria + ' And SponsorNo=@sponsor'
 
 else
    set @selectionString =@selectionCriteria
 
 set @selectionString ='DECLARE C CURSOR FAST_FORWARD FOR SELECT isnull(sum(Quantity*UnitPrice),0) As SerAmt, DrugCode,BillCategoryCode,  Count(Distinct OPDNo) As PatCount From AllPrescriptionsView ' +  
                       @selectionString + ' And PmtTypeCode=1 And PaidQty=0 Group By DrugCode,BillCategoryCode '


 execute (@selectionString)

 OPEN C;

 FETCH NEXT FROM C INTO @serAmt,@ItemID,@patCat,@patCount;

	WHILE @@fetch_status = 0

     BEGIN

       set @patCat=12;

	   Insert into PrescriptionsRevenue(ItemID, CatCost, CatCount, PatCategory, FromDate, ToDate, UserID,Dispensory)values 
	                                   (@ItemID, @serAmt, @patCount, @patCat, @frmDate, @toDate, @user_ID,@Dispensory)

     
       FETCH NEXT FROM C INTO @serAmt,@ItemID,@patCat,@patCount;

    END

 CLOSE C;

 DEALLOCATE C;

 DECLARE C CURSOR FAST_FORWARD FOR SELECT TOP 1 ItemID, PatCategory, FromDate, ToDate,FromTime, ToTime, UserID From PrescriptionsRevenue  Order By ItemID;
 
 OPEN C;

 FETCH NEXT FROM C INTO @ItemID, @patCat, @frmDate, @toDate, @frmTime, @toTime, @user_ID
    WHILE @@fetch_status = 0

    begin	   
       DECLARE PatCats CURSOR FAST_FORWARD FOR SELECT Code From PatientCategoryTypes Where (ActiveStatus='Yes' Or Code=12) Order By Code;

		 OPEN PatCats;

		 FETCH NEXT FROM PatCats INTO @patCat;
			WHILE @@fetch_status = 0
			  BEGIN 
				 update PrescriptionsRevenue set CatCost=CatCost,CatCount=CatCount Where ItemID=@ItemID and PatCategory=@patCat and 
                 FromDate=@frmDate and ToDate=@toDate and FromTime=@frmTime and ToTime=@toTime and UserID=@user_ID;

                 if @@rowcount=0
				   Insert into PrescriptionsRevenue(ItemID, CatCost, CatCount, PatCategory, FromDate, ToDate, FromTime, ToTime,UserID,Dispensory)values 
												   (@ItemID, 0, 0, @patCat, @frmDate, @toDate,@frmTime, @toTime, @user_ID,@Dispensory);
                          
				 FETCH NEXT FROM PatCats INTO @patCat;
		         

			  END
		CLOSE PatCats;

		DEALLOCATE PatCats;

    end

CLOSE C;

DEALLOCATE C;

END
go

