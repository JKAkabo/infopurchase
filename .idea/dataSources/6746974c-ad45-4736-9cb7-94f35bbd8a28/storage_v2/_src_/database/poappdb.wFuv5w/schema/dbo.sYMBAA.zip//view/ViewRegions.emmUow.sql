CREATE VIEW [dbo].[ViewRegions]
AS
SELECT     Description,Code,ID,IsActive,ZoneID
FROM         dbo.Regions

union

Select 'NOT AVAILABLE' As Description, '' as Code, 0 As ID ,'Yes' As IsActive, 1 as ZoneID from Hosp_Info
go

