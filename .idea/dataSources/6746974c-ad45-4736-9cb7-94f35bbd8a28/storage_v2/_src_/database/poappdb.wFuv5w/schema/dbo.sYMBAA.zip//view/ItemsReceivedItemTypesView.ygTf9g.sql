CREATE VIEW [dbo].[ItemsReceivedItemTypesView]

AS

SELECT  distinct  OrderLinesReceived.OrderNo , ItemTypeCode FROM  dbo.Items Inner join OrderLinesReceived on Items.ItemID=OrderLinesReceived.ItemID where Archived='No'
go

