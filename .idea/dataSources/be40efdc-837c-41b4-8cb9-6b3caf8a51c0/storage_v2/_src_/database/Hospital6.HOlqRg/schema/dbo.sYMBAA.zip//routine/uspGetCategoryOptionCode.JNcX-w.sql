

CREATE PROCEDURE [dbo].[uspGetCategoryOptionCode]
    @selectionString nvarchar(max)

AS

BEGIN

execute(@selectionString)

SET NOCOUNT ON;
   
END


go

