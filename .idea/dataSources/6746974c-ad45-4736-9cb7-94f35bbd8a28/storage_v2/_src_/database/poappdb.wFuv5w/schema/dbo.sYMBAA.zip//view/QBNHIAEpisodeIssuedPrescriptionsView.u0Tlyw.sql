CREATE VIEW [dbo].[QBNHIAEpisodeIssuedPrescriptionsView]

AS

SELECT Distinct StoresID    ,DispensedPrescriptions.RecordID, Left(ITEMS.Description,100)  As ServiceDescription,Frequency, DispensedPrescriptions.Duration, Prescriptions.Units As Dosage, ITEMS.ItemID As ServiceCode, 1 As ServiceTypeCode, PmtTypeCode, 'MEDICINES' As ServicePlace , Prescriptions.UnitPrice AS UnitFee, DispensedPrescriptions.DispensedQty-DispensedPrescriptions.ReturnedQty As ServiceQty, ReqDate, Items.NHISCode As GDRDCode, EpisodeID, PresType As RequestType, OPDNo, 'Yes' As ServiceIssued, Prescriptions.StatusCode As PatStatus, IsRefill, DispensedPrescriptions.DispensedDate As ServiceDate, PresDate, DirectID , LevelOrder, '**' As CapID,  Prescriptions.ServerTime, DispensedPrescriptions.UnitPrice*(DispensedPrescriptions.DispensedQty-DispensedPrescriptions.ReturnedQty) As IssuedAmount, 0 As UnIssuedAmount, SponsorNo FROM NHIAPrescriptionLevels Inner Join (ITEMS inner Join (Prescriptions Inner Join DispensedPrescriptions On PresID=Prescriptions.RecordID) On Items.ItemID=DrugCode) On NHIAPrescriptionLevels.ID = PresLevel Where ITEMS.ItemID<>'' and Archived='No' and Refunded='No' and EpisodeID<>0 and QtyGiven>0 and PmtTypeCode<>1 and SponsorNo<>'' and PresLevel<>0  and BillCategoryCode IN (4,11) And ReqDate<=Prescriptions.ServerTime
go

