CREATE PROCEDURE [dbo].[uspUpdateServicePlacesTypes] 
	
AS

DECLARE @RecordID nvarchar(15),@IsStore nvarchar(3),@IsWard nvarchar(3),@PlaceType tinyint=0,
@IsMorgue nvarchar(3),@IsDirectService nvarchar(3),@StoreFunction tinyint=0,@PlaceDesc nvarchar(150);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct Code,IsStore,IsWard,IsMorgue,IsDirectService,StoreFunction, Description From dbo.Service_Places Where Status='Yes' Order by Code Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO @RecordID,@IsStore,@IsWard,@IsMorgue,@IsDirectService,@StoreFunction,@PlaceDesc;

  WHILE @@fetch_status = 0
    BEGIN
       if upper(@IsStore)='YES'
         begin
												set @PlaceType=2;
												Insert Into ServicePlacesTypes(ServicePlaceCode,TypeCode) Values( @RecordID,@PlaceType)
         end
         
       if upper(@IsWard)='YES'
         begin
												set @PlaceType=1;
												Insert Into ServicePlacesTypes(ServicePlaceCode,TypeCode) Values( @RecordID,@PlaceType)
         end
         
       if upper(@IsMorgue)='YES'
         begin
												set @PlaceType=11;
												Insert Into ServicePlacesTypes(ServicePlaceCode,TypeCode) Values( @RecordID,@PlaceType)
         end
       if upper(@IsDirectService)='YES'  and CHARINDEX(@PlaceDesc,'XRAY',1)<>0
         begin
												set @PlaceType=6;
												Insert Into ServicePlacesTypes(ServicePlaceCode,TypeCode) Values( @RecordID,@PlaceType)
         end
         
       if upper(@IsDirectService)='YES'  and CHARINDEX(@PlaceDesc,'ECG',1)<>0
         begin
												set @PlaceType=7;
												Insert Into ServicePlacesTypes(ServicePlaceCode,TypeCode) Values( @RecordID,@PlaceType)
         end
         
       if upper(@IsDirectService)='YES'  and CHARINDEX(@PlaceDesc,'LABORATORY',1)<>0
         begin
												set @PlaceType=5;
												Insert Into ServicePlacesTypes(ServicePlaceCode,TypeCode) Values( @RecordID,@PlaceType)
         end
         
       if upper(@IsDirectService)='YES'  and CHARINDEX(@PlaceDesc,'ULTRA SOUND',1)<>0
         begin
												set @PlaceType=8;
												Insert Into ServicePlacesTypes(ServicePlaceCode,TypeCode) Values( @RecordID,@PlaceType)
         end
         
       if @StoreFunction=2
         begin
												set @PlaceType=4;
												Insert Into ServicePlacesTypes(ServicePlaceCode,TypeCode) Values( @RecordID,@PlaceType)
         end
         
       if @StoreFunction=3
         begin
												set @PlaceType=3;
												Insert Into ServicePlacesTypes(ServicePlaceCode,TypeCode) Values( @RecordID,@PlaceType)
         end
       
       FETCH NEXT FROM C INTO @RecordID,@IsStore,@IsWard,@IsMorgue,@IsDirectService,@StoreFunction,@PlaceDesc;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

