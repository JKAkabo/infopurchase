
CREATE VIEW [dbo].[ConsultationOutcomesView]

AS

SELECT Description, Code FROM dbo.ConsultationOutComesSetup

Union

Select '' As Description, 0 as Code from Hosp_Info

go

