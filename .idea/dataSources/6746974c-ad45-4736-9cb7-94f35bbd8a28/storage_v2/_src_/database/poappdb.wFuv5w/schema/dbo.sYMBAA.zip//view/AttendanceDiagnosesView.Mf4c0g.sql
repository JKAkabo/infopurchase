CREATE VIEW [dbo].[AttendanceDiagnosesView]

AS

SELECT Distinct ClinicCode, ConsultationDiagnoses.DisCode,  DiaFee as UnitFee, Consultations.ReqDate, IsNull(Diseases.ICDCode,'') As ICDCOde, Consultations.EpisodeID, Consultations.OPDNo,  2 As PatStatus, Principal As IsPrincipal, Consultations.ReqDate As ConDate, Consultations.SponsorNo, DiaType, Doctor  As DoctorID, 'OPD' As AttType, PatAge, Insured, ConsultationDiagnoses.DiaOutcome, ConsultationDiagnoses.DiaCatID, ConsultationDiagnoses.DiaManagement, Consultations.ConTime As ReqTime, DoctorRemarks,MainDiseaseCode, Diseases.DisDescription As DiaDesc FROM Diseases Inner Join (Consultations Inner Join ConsultationDiagnoses On Consultations.ConID=ConsultationDiagnoses.ConID) On Diseases.DisCode=ConsultationDiagnoses.DisCode Where Consultations.Archived='No' And Cancelled='No'

Union ALL

SELECT Distinct ClinicCode, AdmissionCauses.DisCode, DiaFee as UnitFee, AdmissionCauses.AdmDate As ReqDate, IsNull(Diseases.ICDCode,'') As ICDCOde, Admissions.EpisodeID, Admissions.OPDNo, 3 As PatStatus, Principal As IsPrincipal, Admissions.DisDate As ConDate, Admissions.SponsorNo, 1 As DiaType, DoctorID, 'INP' As AttType, Admissions.AdmAge As PatAge, Admissions.Insured, Admissions.DischargeStatusCode, DiaCatID, AdmissionCauses.DiaManagement, Admissions.AdmTime,'' AS DoctorRemarks,MainDiseaseCode, Diseases.DisDescription As DiaDesc  FROM Diseases Inner Join (Admissions Inner Join AdmissionCauses On Admissions.RecordID=AdmissionCauses.AdmRecordID) On Diseases.DisCode=AdmissionCauses.DisCode Where Admissions.Archived='No' and Cancelled='No'

Union ALL

SELECT Distinct ClinicCode, DeathCauses.DisCode, DiaFee as UnitFee, DeathCauses.DisDate As ReqDate, IsNull(Diseases.ICDCode,'') As ICDCOde, Deaths.EpisodeID, Deaths.OPDNo, Deaths.StatusCode As PatStatus, Principal As IsPrincipal, Deaths.DeathDate As ConDate, Deaths.SponsorNo, 1 As DiaType, DoctorID, 'DEA' As AttType, DeathAge As PatAge, Deaths.Insured,DiaOutCome, DeathCauses.DeathType, DeathCauses.DiaManagement, Deaths.DeathTime,'' AS DoctorRemarks,MainDiseaseCode, Diseases.DisDescription As DiaDesc FROM Diseases Inner Join (Deaths Inner Join DeathCauses On Deaths.OPDNo=DeathCauses.OPDNo) On Diseases.DisCode=DeathCauses.DisCode Where Deaths.Archived='No'and Cancelled='No'

Union ALL

SELECT Distinct Referrals.RefClinicID As ClinicCode, ReferralCauses.DisCode, DiaFee as UnitFee, ReferralCauses.RefDate As ReqDate,IsNull(Diseases.ICDCode,'') As ICDCOde, Referrals.EpisodeID, Referrals.OPDNo, Referrals.StatusCode As PatStatus, Principal As IsPrincipal, Referrals.RefDate As ConDate, Referrals.SponsorNo, 1 AS DiaType, Referrals.ReferralDoctorID As DoctorID, 'REF' As AttType, Referrals.RefAge as PatAge, Referrals.Insured, DiaOutCome, DiaCatID, ReferralCauses.DiaManagement, Referrals.RefTime,'' AS DoctorRemarks,MainDiseaseCode, Diseases.DisDescription As DiaDesc FROM Diseases Inner Join (Referrals Inner Join ReferralCauses On Referrals.RecordID=ReferralCauses.RefID) On Diseases.DisCode=ReferralCauses.DisCode Where Referrals.Archived='No' and Referrals.RefType IN (3,4,9,13)  and Cancelled='No'
go

