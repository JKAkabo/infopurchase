





CREATE VIEW [dbo].[PatientLabRequestTestElementsView]

AS

Select Distinct PatientLabSpecimens.ReqID,TestElements.Description , TestElements.Code,  PatientLabSpecimens.SpecimenID, SerCode As TestCode, LabSpecimenCollection.SpecimenCode, ServiceType As TestDescription, OPDNo, LabSpecimenCollection.RecordID As CollectionID, PatientLabSpecimens.SpecimenCode As Specimen, PatientLabSpecimens.ServerTime AS SampleTime From Service_Types Inner Join ( TestElements Inner Join (LabTestElements Inner Join (LabSpecimenCollection Inner join PatientLabSpecimens on LabSpecimenCollection.RecordID=collectid ) On TestID=sercode) On  TestElements.Code=LabTestElements.Code) On Service_Types.ServiceCode=TestID Where PatientLabSpecimens.Archived='No' And LabSpecimenCollection.Archived='No'



go

