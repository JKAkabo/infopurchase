CREATE VIEW [dbo].[PatientLaboratoryTestsView]

AS

Select Distinct S.OPDNo,Service_Fee, L.Pat_No,IsNull((Select TOP 1 Description From ClinicsView Where SPCode=ClinicCode),'') As Clinic,
IsNull((Select TOP 1 UserID From UsersView Where UserNo=S.RequesterID),'') As RequestedBy,S.SerPlaceCode,FacAttType,Voluntary,TestDate,TestTime,Comments,LabTechID,
IsNull((Select TOP 1 UserID From UsersView Where UserNo=S.UserID),'') As UserName,ServiceTypeCode,ClinicCode,SponsorNo,SpecimenCode,SpecimenID,L.Analyzer_ID,L.RecordType,
RequesterID,MemberID, S.PmtTypeCode,S.DeptID, S.RecordID, AttServiceID, ItemID As ServiceCode, A.Description AS ServiceDescription,L.RecordID As TestID,Verified,VerifiedID,
PatientAge,Gender,DOB,CellPhoneNo,IDNo,S.StatusCode,AttType,EpisodeType,S.BillCategoryCode,EpisodeID,CoPaySponsorNo,CoPayBillCategoryCode,LS.Description AS Specimen,
IsNull((Select TOP 1 Description From PatientCategoryView Where PatientCategoryView.Code=S.BillCategoryCode Order By CatPriority),'') As BillCategory,
IsNull((Select TOP 1 Description From PatientCategoryView Where PatientCategoryView.Code=S.CoPayBillCategoryCode and CoPayFee>Service_Fee Order By CatPriority),'') As COPayBillCategory,
IsNull((Select TOP 1 Description From ServicePlacesView Where Code=SerPlaceCode),'') As ServicePlace,S.ReceiptNo As AuthorizationCode,IsNull((Select TOP 1 Description From ServiceCategoriesView Where Code=CatID),'') As Department,
IsNull((Select TOP 1 Description From PaymentTypessView Where Code=S.PmtTypeCode),'') As PaymentType,PaidQty,PaidAmt,Issued,RequestType,IsNull((Select TOP 1 UserID From UsersView Where UserNo=L.UserID),'') As LabUserName,
IsNull((Select TOP 1 Description From PaymentTypessView Where Code=CoPayPmtTypeCode),'') As COPayPaymentType,ServicerID,ServiceDate,S.ServerTime,
IsNull((Select TOP 1 SponsorName From SponsorsView Where SponsorsView.SponsorNo=S.SponsorNo Order By AttPriority),'') As Sponsor,IsNull((Select TOP 1 UserID From UsersView Where UserNo=LabTechID),'') As LabTech,
IsNull((Select TOP 1 SponsorName From SponsorsView Where SponsorsView.SponsorNo=S.CoPaySponsorNo and CoPayFee>Service_Fee Order By AttPriority),'') As COPaySponsor,
IsNull((Select SUM(Service_Fee * ServiceQty) From Service_Requests Where Service_Requests.OPDNo=S.OPDNo and ReqTime=S.ReqTime and Service_Requests.Archived='No' and RequestType='INTERNAL'),0) As SerTotal,
IsNull((Select SUM((CoPayFee -Service_Fee) * ServiceQty) From Service_Requests Where CoPayFee>Service_Fee And  Service_Requests.OPDNo=S.OPDNo and ReqTime=S.ReqTime and Service_Requests.Archived='No' and RequestType='INTERNAL'),0) As CoPaySerTotal,
AttRecordID,CatID,SubCatID,DirectID,L.PatAge,ServiceQty,Service_Cost,S.Insured,IsNull((Select TOP 1 Description From PatientStatusView Where Code=S.StatusCode),'') As PatStatus,
CoPayPmtTypeCode,CoPayFee,S.PatCategoryCode,LastName,SurName,MiddleName,Title,Nationality,S.UserID, ReqTime,ReqDate, GenderCode, StaffID, PBOut, CoPayAmt, CoPayPaidAmt, CoPayPaidQty, ServiceAmt From 
PatientInfoView P, Service_Requests S, AllSetUpServicesView A, LabTests L, LabTestSpecimens LS Where L.RequestID=S.RecordID And P.PatientID=S.OPDNo And S.ServiceCode=ItemID And S.Archived='No' and ServiceTypeCode=11 and L.Archived='No' and SpecimenID=LS.Code
go

