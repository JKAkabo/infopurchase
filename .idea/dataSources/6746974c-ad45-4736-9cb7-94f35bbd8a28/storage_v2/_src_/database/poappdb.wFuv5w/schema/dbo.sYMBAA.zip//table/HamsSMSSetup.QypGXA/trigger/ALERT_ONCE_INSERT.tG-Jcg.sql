CREATE TRIGGER [dbo].[ALERT_ONCE_INSERT]

ON [dbo].[HamsSMSSetup]

AFTER INSERT

AS

IF NOT EXISTS(SELECT ActivateSMS FROM Hosp_Info WHERE ActivateSMS='Yes')
   RETURN
--print 'One'

DECLARE @MsgFreqID tinyint;
DECLARE @MsgTypeID tinyint;
DECLARE @AgeGroup tinyint;
DECLARE @GenderGroup tinyint;
DECLARE @OnceFreq tinyint;
DECLARE @msgContent nvarchar(max);
DECLARE @Consent nvarchar(3);
DECLARE @msgType nvarchar(100);
DECLARE @allAgeGroup tinyint;
DECLARE @allGenderGroup tinyint;
DECLARE @childAgeLimit tinyint;
DECLARE @adultAgeLimit tinyint;
DECLARE @allAgeLimit tinyint;
DECLARE @includePatName nvarchar(3);
DECLARE @ReligionCode tinyint;
DECLARE @ClinicCode nvarchar(50);
DECLARE @UserTypeCode Tinyint;
DECLARE @StartTime nvarchar(50);

set @OnceFreq=6; 
set @allAgeGroup=3; 
set @allGenderGroup=1;
set @childAgeLimit=11
set @adultAgeLimit=12;
set @allAgeLimit=120;
set @UserTypeCode=0;
 

--Make sure status was changed
--IF NOT UPDATE(ServerTime)
--   RETURN

----Determine if regular msg status was changed to deleted

SELECT @MsgTypeID=a.TypeCode,@msgContent=a.MsgContent,@Consent=a.EnforceConsent,@AgeGroup=a.AgeGroupCode,
@GenderGroup=a.GenderCode,@includePatName=a.includeRPT,@StartTime=a.StartTime,@ReligionCode=a.ReligionCode,@ClinicCode=a.ClinicCode,@UserTypeCode=a.UserTypeCode  
FROM  inserted a 
WHERE a.Active='Yes' and  a.TypeCode >= 8 and a.TypeCode<=15

If @@RowCount>0 
   RETURN
   
BEGIN  

--STAFF_ANNOUNCEMENT= 8
	if @MsgTypeID = 8 
				insert into bulksms_db.dbo.schedule_messges([From],[To],message,schedule_time,status) 
				select Distinct 'System',PrimaryCellNo,@msgContent,@StartTime,'schedule' 
				FROM SMSUsersView WHERE Rtrim(Ltrim(PrimaryCellNo))<>'' And PrimaryCellNo is not null And (CatID=@UserTypeCode OR @UserTypeCode=0)
					 		  
	--EASTER CELEBRATION=9,EID-UL-FITR=10,EID-UL-ADHA=11,FATHER'S DAY=12,MOTHER'S DAY=13,FESTIVE_EVENT=14,CLIENT-ANNOUNCEMENTS=15--
	if @MsgTypeID>=9 AND @MsgTypeID<=15							
				insert into bulksms_db.dbo.schedule_messges([From],[To],message,schedule_time,status) 
				select Distinct 'System',CellPhoneNo,@msgContent,@StartTime,'schedule' FROM SMSPatientInfoView, Daily_Attendance d WHERE ((@GenderGroup=@allGenderGroup) OR (GenderCode=@GenderGroup)) And 
				Rtrim(Ltrim(CellPhoneNo))<>'' And CellPhoneNo Is Not Null  And ((@Consent='Yes' And ExpiryAlert='Yes') or @Consent='No')	And (@ReligionCode=0 OR ReligionID=@ReligionCode) And SMSPatientInfoView.OPDNo=d.OPDNo AND 
			 ((datediff(year,DOB,GETDATE())<=@childAgeLimit and @AgeGroup=1) OR (datediff(year,DOB,GETDATE())>=@adultAgeLimit and @AgeGroup=2) OR @AgeGroup=3) 	And (@ClinicCode='' OR ClinicCode=@ClinicCode)
				

END
go

