





CREATE VIEW [dbo].[DHIMSBedsUntilizationView]

AS

Select AllAdmissionsView.OPDNo, ElementID, DataSetID, RecordSerialNo, AdmDate, DisDate, WardID, HAMSCode, WardCode From DHIMSMappedDataElementsView Inner Join ( DHIMSMappedWardTypes Inner Join (PatientsInfo Inner Join  AllAdmissionsView On PatientsInfo.OPDNo=AllAdmissionsView.OPDNo) On HamsWardCode=WardID) On MappedCode = WardCode Where ((PatientsInfo.GenderCode=WardGenderCode and DHIMSMappedDataElementsView.GenderCode<>1 and WardGenderCode<>1) Or (DHIMSMappedDataElementsView.GenderCode=1 And WardGenderCode=1))



go

