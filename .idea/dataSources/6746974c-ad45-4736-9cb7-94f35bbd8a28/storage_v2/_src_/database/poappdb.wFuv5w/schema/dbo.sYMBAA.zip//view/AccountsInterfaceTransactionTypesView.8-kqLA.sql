CREATE VIEW [dbo].[AccountsInterfaceTransactionTypesView]

AS

SELECT '' AS PostMsg, C.Code As ActivityID, AcctTypeID, C.Description, '' As DebitAcctQuery, '' As CreditAcctQuery,'' As AcctQuery,
A.Description As AcctTypeDescription, 0 As AutoGenerateRefNo , P.Description As PostType, P.Code As PostTypeID, InterfacePostTypeID
FROM AccountsJournalTransactionsDetail C, AccountTypes A, AccountPostingType P 
Where C.IsActive='Yes' And A.ID=C.AcctTypeID and P.Code=C.PostType
go

