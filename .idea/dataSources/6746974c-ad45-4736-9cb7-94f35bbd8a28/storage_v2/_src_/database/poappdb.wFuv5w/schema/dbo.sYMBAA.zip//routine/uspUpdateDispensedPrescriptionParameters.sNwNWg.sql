-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[uspUpdateDispensedPrescriptionParameters] 
	-- Add the parameters for the stored procedure here
	
AS

BEGIN

	DECLARE @presID numeric(18,0),@dispensedID numeric(18,0),@batchNo nvarchar(25),@Dosage numeric(18,0),@Freq nvarchar(50),@Duration numeric(18,0),@StartDate Datetime,@EndDate Datetime;

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Prescriptions.BatchNo, DispensedPrescriptions.RecordID, Units, Prescriptions.Dosage, PresDays, StartDate, FinishDate From Prescriptions Inner Join DispensedPrescriptions On Prescriptions.RecordID=presid Where Prescriptions.BatchNo<>'' and (DispensedPrescriptions.BatchNo='' or Frequency ='' or Frequency is null) and archived='No' Order by Prescriptions.BatchNo Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO @batchNo, @dispensedID,@Dosage ,@Freq ,@Duration ,@StartDate, @EndDate;

  WHILE @@fetch_status = 0
    BEGIN

       --set @DisCategory=dbo.ItemDesc(@DisCategory);
       
       update DispensedPrescriptions Set BatchNo=@batchNo,Dosage=@Dosage,Frequency=@Freq,Duration=@Duration,EndDate=@EndDate,BeginDate=@StartDate where RecordID=@dispensedID

       FETCH NEXT FROM C INTO @batchNo, @dispensedID,@Dosage ,@Freq ,@Duration ,@StartDate, @EndDate;

	   END

	CLOSE C;

	DEALLOCATE C;

END
go

