
CREATE VIEW [dbo].[DHIMSMorbidityExternalDeathsView]

AS

Select Deaths.OPDNo , convert(NVARCHAR(5),  PatientsInfo.GenderCode) As GenderCode, Deaths.Insured, 'annMT9HKpPY' As DataSetID, Deaths.DeathDate As AttDate, TDOB, Deaths.ClinicCode, '00002887' As HamsID  From PatientsInfo Inner Join Deaths On PatientsInfo.OPDNo=Deaths.OPDNo Where Deaths.DiedInHospital='No' And Archived='No'



go

