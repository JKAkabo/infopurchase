CREATE VIEW [dbo].[MedicalConditionsView]

AS

SELECT Distinct Description, rtrim(ltrim(Convert(nvarchar(15),Code))) As Code, 10 As ServiceTypeCode, Type, RequiresValue, IsActive FROM ExistingMedicalConditions 

--UNION

--SELECT Distinct DisDescription, rtrim(ltrim(Convert(nvarchar(15),DisCode))) As Code, 2 As ServiceTypeCode, 12 As Type, 'No' As RequiresValue FROM Diseases

--UNION

--SELECT Distinct DisDescription, rtrim(ltrim(Convert(nvarchar(15),DisCode))) As Code, 2 As ServiceTypeCode, 13 As Type, 'No' As RequiresValue FROM Diseases

--UNION

--SELECT Distinct DisDescription, rtrim(ltrim(Convert(nvarchar(15),DisCode))) As Code, 2 As ServiceTypeCode, 14 As Type, 'No' As RequiresValue FROM Diseases

--UNION

--SELECT Distinct DisDescription, rtrim(ltrim(Convert(nvarchar(15),DisCode))) As Code, 2 As ServiceTypeCode, 15 As Type, 'No' As RequiresValue FROM Diseases

--UNION

--SELECT Distinct Description, ItemID As Code, ServiceTypeCode, 8 As Type, 'No' As RequiresValue, case when Disabled='Yes'  then 'No' else 'Yes' End As IsActive FROM AllSetUpServicesView Where ServiceTypeCode=3

--UNION

--SELECT Distinct Description, ItemID As Code, ServiceTypeCode,9 As Type, 'No' As RequiresValue FROM AllServicesView Where ServiceTypeCode=1 And ItemID NOT IN (Select ItemID From Items Where ItemTypeCode<>1)
go

