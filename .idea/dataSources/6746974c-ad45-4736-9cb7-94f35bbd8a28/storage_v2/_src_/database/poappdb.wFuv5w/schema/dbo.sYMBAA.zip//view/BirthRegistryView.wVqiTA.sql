create VIEW [dbo].[BirthRegistryView]

AS

Select BirthRegistry.RegDate,BirthRegistry.BillCategoryCode, BirthRegistry.OPDNo, PatAge, BirthRegistry.RecordID, BirthRegistry.Pat_No, SurName, LastName, MiddleName, TDOB, BirthRegistry.Insured, OccupationsView.Description As OccupDesc, EducationalLevelsView.Description As EducDesc, Parity, DurationOfPreg, UPPER(PregnancyDeliveryTypes.Description) As DeliveryType, EpisodeID, AdmDate, DisDate, DischargeStatusCode From PregnancyDeliveryTypes Inner Join 
	   (EducationalLevelsView Inner Join (OccupationsView Inner Join (PatientsInfo inner Join (BirthRegistry Inner Join AdmissionDischrgesView On (BirthRegistry.OPDNo=AdmissionDischrgesView.OPDNo And BirthRegistry.RegDate>= AdmissionDischrgesView.AdmDate And BirthRegistry.RegDate<= AdmissionDischrgesView.DisDate)) On PatientsInfo.OPDNo=BirthRegistry.OPDNo) On OccupationsView.Code=OccupationID) On EducationalLevelsView.ID=EducationLevel) 
	   On PregnancyDeliveryTypes.Code=TypeofDeliveryCode Where BirthRegistry.Archived='No' And HospitalBirth='Yes'
go

