CREATE FUNCTION [dbo].[ItemDesc]

(@desc AS NVARCHAR(4000)) RETURNS NVARCHAR(4000)

AS

BEGIN

DECLARE @strg nVARCHAR(4000),@y int,@x int,@w int,@strg1 nVARCHAR(4000),@strg2 nVARCHAR(4000);

set @strg = rtrim(lTrim(@desc));

If @strg = '' RETURN @strg
   

If charindex('''', @strg, 1) = 0 RETURN @strg
   

set @y = Len(@strg)

set @x = 0

while @x < @y
  begin
	   If charindex('''', @strg, @x)<>0
		  begin
			  set @w = charindex('''', @strg, @x+1)
			  If @w = @y 
				 begin
					 set @strg = @strg + ''''
					 return @strg
				 end

			  If substring(@strg, @w + 1, 1) <> ''''
				   begin
					   set @strg2 = Right(@strg, Len(@strg) - @w)
					   set @strg1 = substring(@strg, 1, @w)
					   set @strg = @strg1 + '''' + @strg2
					   set @x = @w + 1

				   end
		  end

		  set @x = @x+1
  end

If Right(@strg, 1) = ''''
   begin
	   If substring(@strg, Len(@strg) - 1, 1) <> ''''
		  set @strg = @strg + ''''
      
    end

RETURN @strg;

END
go

