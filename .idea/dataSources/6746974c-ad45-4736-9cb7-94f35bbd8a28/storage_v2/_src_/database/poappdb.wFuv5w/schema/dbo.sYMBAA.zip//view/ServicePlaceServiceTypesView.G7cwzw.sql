CREATE VIEW [dbo].[ServicePlaceServiceTypesView]

AS

SELECT Distinct SerType, ServicePlaceCode FROM dbo.ServicePlaceServiceTypes

Union

SELECT  Code As SerType, '' As ServicePlaceCode FROM dbo.ServiceTypes Where Code<>0 and Code Not In (Select Distinct SerType FROM dbo.ServicePlaceServiceTypes)
go

