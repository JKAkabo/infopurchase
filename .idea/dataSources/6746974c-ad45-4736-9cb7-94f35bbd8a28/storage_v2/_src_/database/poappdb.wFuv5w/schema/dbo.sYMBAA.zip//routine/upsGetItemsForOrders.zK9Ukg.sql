-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[upsGetItemsForOrders] 
	-- Add the parameters for the stored procedure here

	@ItemDescription nvarchar(250) ,@itemStore nvarchar(15),@itemType tinyint =0,
	@itemUnitType tinyint =1,@item_ClassCode smallint=0,@StockTransType tinyint=1
	
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
Select Distinct Items.Description, ItemsUOMView.TypeCode, ItemTypeCode, ManufacturerCode, PresentationCode,Expirable,Items.DefaultMethodCode,PresQuanityPerIssueUnit,PresSpecType, AllowCoPay,ItemManufacturers.Description as ItemManufacturer,ItemTypes.Description As ItemType,ItemPresentations.Description As ItemPresentation,
ItemsUOMView.IssueUnitQuantity,PresUnitQuantity,PresUnitCode,Items.AgeGroupCode,Items.GenderCode, ItemsUOMView.UnitCode As IssueUnitCode, ItemsUOMView.UOM As Unit_Name , Items.ItemID, PresLevel, StockType, items.AveUnitCost As UnitCost, IsNull(Items.ItemNo,'') As ItemNo,Demand,ReorderLevel,EOQ,MinLevel,MaxLevel,LeadTime,ItemCost, 
Isnull((Select sum(StockLevel) From StockedItemsView Where ItemCode=Items.ItemID And (((IsDate(ExpiryDate)=1 And ItemExpirable ='Yes') And ((Year(ExpiryDate)> Year(Getdate())) OR (Year(ExpiryDate)= Year(Getdate()) And Month(ExpiryDate)>= Month(Getdate())))) Or (IsDate(ExpiryDate)=0 OR ItemExpirable ='No')) Group By ItemCode),0) As StockLevel, 
Isnull((Select sum(StockLevel) From StockedItemsView Where ItemCode=Items.ItemID And ServicePlaceCode=@ItemStore And (((IsDate(ExpiryDate)=1 And ItemExpirable ='Yes') And ((Year(ExpiryDate)> Year(Getdate())) OR (Year(ExpiryDate)= Year(Getdate()) And Month(ExpiryDate)>= Month(Getdate())))) Or (IsDate(ExpiryDate)=0 OR ItemExpirable ='No')) Group By ServicePlaceCode),0) As StoreStockLevel
From ItemsUOMView , Items, ItemManufacturers, ItemTypes, ItemPresentations, Service_Places, StockInventoryParametersView Where ItemsUOMView.ItemCode = Items.ItemID and Items.Description Like @ItemDescription + '%' And ((ItemTypeCode=@ItemType And @ItemType<>0) OR (@ItemType=0)) And  ((ItemClassCode=@item_ClassCode And @item_ClassCode<>0) OR (@item_ClassCode=0)) 
And ItemTypes.Code=ItemTypeCode And ItemPresentations.Code=PresentationCode  And ItemManufacturers.Code=ManufacturerCode  And Items.Disabled ='No' and Service_Places.Code = @ItemStore And StockInventoryParametersView.ItemID=Items.ItemID And Service_Places.Code=StockInventoryParametersView.StoreID and StockInventoryParametersView.StoreID=@itemStore and ItemsUOMView.UnitCode=items.IssueUnitCode Order by Items.Description Asc
 
--Select Distinct Items.Description, ItemsUOMView.TypeCode, ItemTypeCode, ManufacturerCode, PresentationCode,Expirable,Items.DefaultMethodCode,PresQuanityPerIssueUnit,PresSpecType, AllowCoPay,ItemManufacturers.Description as ItemManufacturer,ItemTypes.Description As ItemType,ItemPresentations.Description As ItemPresentation,
--ItemsUOMView.IssueUnitQuantity,PresUnitQuantity,PresUnitCode,Items.AgeGroupCode,Items.GenderCode, ItemsUOMView.UnitCode As IssueUnitCode, ItemsUOMView.UOM As Unit_Name , Items.ItemID, PresLevel, StockType, items.AveUnitCost As UnitCost, IsNull(Items.ItemNo,'') As ItemNo,Demand,ReorderLevel,EOQ,MinLevel,MaxLevel,LeadTime,ItemCost, 
--Isnull((Select sum(StockLevel) From StockedItemsView Where ItemCode=Items.ItemID And (((IsDate(ExpiryDate)=1 And ItemExpirable ='Yes') And ((Year(ExpiryDate)> Year(Getdate())) OR (Year(ExpiryDate)= Year(Getdate()) And Month(ExpiryDate)>= Month(Getdate())))) Or (IsDate(ExpiryDate)=0 OR ItemExpirable ='No')) Group By ItemCode),0) As StockLevel, 
--Isnull((Select sum(StockLevel) From StockedItemsView Where ItemCode=Items.ItemID And ServicePlaceCode=@ItemStore And (((IsDate(ExpiryDate)=1 And ItemExpirable ='Yes') And ((Year(ExpiryDate)> Year(Getdate())) OR (Year(ExpiryDate)= Year(Getdate()) And Month(ExpiryDate)>= Month(Getdate())))) Or (IsDate(ExpiryDate)=0 OR ItemExpirable ='No')) Group By ServicePlaceCode),0) As StoreStockLevel
--From ItemsUOMView , Items, ItemManufacturers, ItemTypes, ItemPresentations, Service_Places, StockInventoryParametersView Where ItemsUOMView.ItemCode = Items.ItemID and Items.Description Like @ItemDescription + '%' And ((ItemTypeCode=@ItemType And @ItemType<>0) OR (@ItemType=0)) And  ((ItemClassCode=@item_ClassCode And @item_ClassCode<>0) OR (@item_ClassCode=0)) And ItemTypes.Code=ItemTypeCode And ItemPresentations.Code=PresentationCode  And ItemManufacturers.Code=ManufacturerCode  And
--Items.Disabled ='No' and Service_Places.Code = @ItemStore And ((@StockTransType=1 And ((Service_Places.OrderUnitID = @itemUnitType) OR (Service_Places.OrderUnitID <> @itemUnitType and Service_Places.Code + ItemCode + convert(Nvarchar(15),ItemsUOMView.TypeCode) IN (Select ServicePlaceCode + ItemCode + convert(Nvarchar(15),TypeCode) From StockedItemsView Where ItemCode=Items.ItemID And ServicePlaceCode=@ItemStore)))) OR 
--(@StockTransType=2 And ((Service_Places.IssueUnitID = @itemUnitType) OR (Service_Places.IssueUnitID <> @itemUnitType and Service_Places.Code + ItemCode + convert(Nvarchar(15),ItemsUOMView.TypeCode) IN (Select ServicePlaceCode + ItemCode + convert(Nvarchar(15),TypeCode) From StockedItemsView Where ItemCode=Items.ItemID And ServicePlaceCode=@ItemStore))))) 
-- And StockInventoryParametersView.ItemID=Items.ItemID And Service_Places.Code=StockInventoryParametersView.StoreID and StockInventoryParametersView.StoreID=@itemStore Order by Items.Description Asc
  
 
 
END
go

