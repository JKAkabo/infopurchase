


CREATE VIEW [dbo].[DHIMSOutPatientView]

AS

Select Daily_Attendance.OPDNo , convert(NVARCHAR(5),  PatientsInfo.GenderCode) As GenderCode, Daily_Attendance.RegType, Daily_Attendance.Insured, 'bYPgExf4Gqo' As DataSetID, AttDate, TDOB, ClinicCode, convert(NVARCHAR(5),  FacilityAttendanceType.Code) As TransType From PatientsInfo Inner Join (Service_Points Inner Join (FacilityAttendanceType Inner Join  Daily_Attendance On FacilityAttendanceType.Description=RegType) On SPCode=ClinicCode) On PatientsInfo.OPDNo=Daily_Attendance.OPDNo Where Service_Points.Type Not IN (3,4,16,17)


go

