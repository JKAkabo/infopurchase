CREATE VIEW [dbo].[StoreItemsStockLevelView]

AS

SELECT IsNull(Sum(StockLevel),0) As StockLevel, ItemID, StoreID FROM Service_Places Inner Join StockedItems ON  Code=StoreID Where StockLevel>=0 And UPPER(Service_Places.Status)='YES' Group By StoreID, ItemID


--SELECT CASE WHEN TypeCode=1 THEN IsNull(Sum(StockLevel),0) ELSE IsNull(Sum(StockLevel/ItemsUOMView.IssueUnitQuantity),0) END As StockLevel, ItemCode As ItemID, TypeCode, Code As StoreID , NoPerBaseUnit, UnitCode, UOM, BatchNo, ExpiryDate, ItemExpirable,ItemsUOMView.Description As ItemDescription, Service_Places.Description As ItemStore, ItemsUOMView.IssueUnitQuantity As UOMQty, Service_Places.OrderUnitID As OrderUnitType,Service_Places.IssueUnitID As IssueUnitType,  
--CASE WHEN TypeCode=1 THEN BaseCost ELSE BaseCost*ItemsUOMView.IssueUnitQuantity END As UnitBaseCost FROM Service_Places Inner Join (ItemsUOMView Inner Join StockedItems On ItemCode=ItemID) On Code=StoreID Where StockLevel>=0 And UPPER(Service_Places.Status)='YES' And TypeCode=1 Group By Code, Service_Places.Description, ItemCode, ItemsUOMView.Description, BatchNo, ExpiryDate, TypeCode, UnitCode, UOM , NoPerBaseUnit, IssueUnitQuantity, IssueUnitID,OrderUnitID, ItemExpirable,BaseCost
go

