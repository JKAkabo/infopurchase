



CREATE VIEW [dbo].[StocksView]

AS

SELECT Distinct ItemID, StoreID, ReorderLevel, LeadTime, Demand, EOQ, MinLevel, MaxLevel,
Quantity, BatchNo, BaseQty, BaseUnit, PrescriptionQty,
Isnull((Select sum(StockLevel) From StockedItemsView Where TypeCode=1 And ItemCode=Stocks.ItemID
And (((IsDate(ExpiryDate)=1 And ItemExpirable ='Yes') And ((Year(ExpiryDate)> Year(Getdate())) OR 
(Year(ExpiryDate)= Year(Getdate()) And Month(ExpiryDate)>= Month(Getdate())))) Or 
(IsDate(ExpiryDate)=0 OR ItemExpirable ='No')) Group By ItemCode),0) As StockLevel, 

Isnull((Select sum(StockLevel) From StockedItemsView Where TypeCode=1 And ItemCode=Stocks.ItemID
And NOT ((((IsDate(ExpiryDate)=1 And ItemExpirable ='Yes') And ((Year(ExpiryDate)> Year(Getdate())) OR 
(Year(ExpiryDate)= Year(Getdate()) And Month(ExpiryDate)>= Month(Getdate())))) Or 
(IsDate(ExpiryDate)=0 OR ItemExpirable ='No'))) Group By ItemCode),0) As ExpiredStockLevel,

Isnull((Select sum(StockLevel) From StockedItemsView Where TypeCode=1 And ItemCode=Stocks.ItemID And 
ServicePlaceCode=StoreID And (((IsDate(ExpiryDate)=1 And ItemExpirable ='Yes') And 
((Year(ExpiryDate)> Year(Getdate())) OR (Year(ExpiryDate)= Year(Getdate()) And 
Month(ExpiryDate)>= Month(Getdate())))) Or (IsDate(ExpiryDate)=0 OR ItemExpirable ='No')) Group By ServicePlaceCode),0) As StoreItemStockLevel,

Isnull((Select sum(StockLevel) From StockedItemsView Where TypeCode=1 And ItemCode=Stocks.ItemID And 
ServicePlaceCode=StoreID And NOT((((IsDate(ExpiryDate)=1 And ItemExpirable ='Yes') And 
((Year(ExpiryDate)> Year(Getdate())) OR (Year(ExpiryDate)= Year(Getdate()) And 
Month(ExpiryDate)>= Month(Getdate())))) Or (IsDate(ExpiryDate)=0 OR ItemExpirable ='No'))) Group By ServicePlaceCode),0) As ExpiredStoreItemStockLevel  

FROM Stocks 

Union ALL

SELECT Distinct ItemID, StoreID, 0 As ReorderLevel, 0 As LeadTime, 0 As Demand, 0 As EOQ, 0 As MinLevel, 0 As MaxLevel, 0 As Quantity, '' As BatchNo,
0 As BaseQty, '' As BaseUnit, 0 As PrescriptionQty, 
Isnull((Select sum(StockLevel) From StockedItemsView Where TypeCode=1 And ItemCode=ItemID
And (((IsDate(ExpiryDate)=1 And ItemExpirable ='Yes') And ((Year(ExpiryDate)> Year(Getdate())) OR 
(Year(ExpiryDate)= Year(Getdate()) And Month(ExpiryDate)>= Month(Getdate())))) Or 
(IsDate(ExpiryDate)=0 OR ItemExpirable ='No')) Group By ItemCode),0) As StockLevel, 

Isnull((Select sum(StockLevel) From StockedItemsView Where TypeCode=1 And ItemCode=ItemID
And NOT ((((IsDate(ExpiryDate)=1 And ItemExpirable ='Yes') And ((Year(ExpiryDate)> Year(Getdate())) OR 
(Year(ExpiryDate)= Year(Getdate()) And Month(ExpiryDate)>= Month(Getdate())))) Or 
(IsDate(ExpiryDate)=0 OR ItemExpirable ='No'))) Group By ItemCode),0) As ExpiredStockLevel,

Isnull((Select sum(StockLevel) From StockedItemsView Where TypeCode=1 And ItemCode=ItemID And 
ServicePlaceCode=StoreID And (((IsDate(ExpiryDate)=1 And ItemExpirable ='Yes') And 
((Year(ExpiryDate)> Year(Getdate())) OR (Year(ExpiryDate)= Year(Getdate()) And 
Month(ExpiryDate)>= Month(Getdate())))) Or (IsDate(ExpiryDate)=0 OR ItemExpirable ='No')) Group By ServicePlaceCode),0) As StoreItemStockLevel,

Isnull((Select sum(StockLevel) From StockedItemsView Where TypeCode=1 And ItemCode=ItemID And 
ServicePlaceCode=StoreID And NOT((((IsDate(ExpiryDate)=1 And ItemExpirable ='Yes') And 
((Year(ExpiryDate)> Year(Getdate())) OR (Year(ExpiryDate)= Year(Getdate()) And 
Month(ExpiryDate)>= Month(Getdate())))) Or (IsDate(ExpiryDate)=0 OR ItemExpirable ='No'))) Group By ServicePlaceCode),0) As ExpiredStoreItemStockLevel  


FROM  stockeditems where ItemID + StoreID NOT IN (Select Isnull(ItemID + StoreID,'') From Stocks)



go

