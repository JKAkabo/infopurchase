

CREATE VIEW [dbo].[PatientInvoiceDepositsView]

AS

Select 'GHC' As DepositCurrency, BillsPaid.Pat_No As PatientID, Deposits.DepositTime , Deposits.DepositDate , Deposits.ReceiptNo As InvoiceNo,Deposits.DepositAmount, Deposits.BillReferenceNo As BillInvoiceNo, Deposits.DepReason As DepositType From Deposits Inner Join BillsPaid On (Deposits.OPDNo=BillsPaid.OPDNo And Deposits.ReceiptNo=BillsPaid.ReceiptNo) Where BillsPaid.Archived='No' and Deposits.Archived='No'

--Select 'GHC' As DepositCurrency, BillsPaid.Pat_No As PatientID, Deposits.DepositTime , Deposits.DepositDate , Deposits.ReceiptNo As InvoiceNo,Deposits.DepositAmount, Deposits.BillReferenceNo As BillInvoiceNo, Deposits.DepReason As DepositType From Deposits Inner Join BillsPaid On (Deposits.OPDNo=BillsPaid.OPDNo And (Deposits.BillReferenceNo=BillsPaid.ReceiptNo OR Deposits.ReceiptNo=BillsPaid.ReceiptNo)) Where BillsPaid.Archived='No' and Deposits.Archived='No'


go

