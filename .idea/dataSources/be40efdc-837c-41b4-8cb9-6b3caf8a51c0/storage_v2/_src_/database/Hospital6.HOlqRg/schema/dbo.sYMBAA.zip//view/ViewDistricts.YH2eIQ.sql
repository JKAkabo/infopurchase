CREATE VIEW [dbo].[ViewDistricts]
AS
SELECT     Description,Code,ID,IsActive,RegionID
FROM         dbo.Districts

union

Select 'NOT AVAILABLE' As Description, '' as Code, 0 As ID ,'Yes' As IsActive, 0 as RegionID from Hosp_Info
go

