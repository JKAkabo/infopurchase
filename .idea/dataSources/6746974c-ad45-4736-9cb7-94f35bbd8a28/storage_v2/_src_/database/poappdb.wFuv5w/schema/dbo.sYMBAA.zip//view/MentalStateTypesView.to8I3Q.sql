CREATE VIEW [dbo].[MentalStateTypesView]

AS

SELECT OrderNo, M.Description As StateType, M.Code, ID, GenderCode, M.IsActive, G.Description As Gender FROM
dbo.MentalStateGroups M, GenderGroups G where G.Code=GenderCode
go

