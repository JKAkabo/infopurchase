CREATE PROCEDURE [dbo].[uspConsultationsAgeClassCodes] 
	
AS

DECLARE @MinPatAge int,@MaxPatAge int, @AgeClassCode tinyint;

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;

  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct  AgeClassCode , MinAge, MaxAge From ReportsAgeClassification Order by AgeClassCode Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO @AgeClassCode, @MinPatAge, @MaxPatAge;

  WHILE @@fetch_status = 0
    BEGIN

       --set @DisCategory=dbo.ItemDesc(@DisCategory);
       
       update Consultations Set AgeClassCode=@AgeClassCode where PatAge>=@MinPatAge And PatAge<=@MaxPatAge

       FETCH NEXT FROM C INTO @AgeClassCode, @MinPatAge, @MaxPatAge;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

