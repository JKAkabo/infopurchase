



CREATE VIEW [dbo].[BillPaidServicesView]

AS

SELECT Distinct ServiceLinePayments.PmtDate, ServiceLinePayments.PmtTime, ServiceLinePayments.RecordID, DrugCode As ServiceCode, 1 As ServiceTypeCode, ServiceLinePayments.PmtTypeCode, StoresID As SerPlaceCode , ServiceLinePayments.Service_Fee AS UnitFee, QtyPrescribed As ServiceQty, PresType As RequestType, BillsPaid.OPDNo, Prescriptions.StatusCode As PatStatus, ServiceLinePayments.PaidAmt, DirectID, ServiceLinePayments.PaidQty, '**' As CapID, Prescriptions.ServerTime, BillsPaid.Pat_No, ServiceLinePayments.ReceiptNo, Prescriptions.ClinicCode, ServiceLinePayments.PatAge, Prescriptions.BillCategoryCode As PatCategoryCode, BillsPaid.UserID, 'DRUG' As RecType,Prescriber As RequesterID, Prescriptions.PresDate As ReqDate, Prescriptions.PresTime As Reqtime,CoPayed, ServiceLinePayments.SponsorNo,BillsPaid.PmtModeCode FROM Prescriptions Inner Join (BillsPaid Inner Join ServiceLinePayments On BillsPaid.ReceiptNo =ServiceLinePayments.ReceiptNo) On (DrugCode=ServiceCode and Prescriptions.RecordID=ServiceID) Where ServiceLinePayments.Archived='No'

UNION ALL

SELECT Distinct ServiceLinePayments.PmtDate, ServiceLinePayments.PmtTime, ServiceLinePayments.RecordID, ServiceLinePayments.ServiceCode, ServiceTypeCode, ServiceLinePayments.PmtTypeCode, SerPlaceCode , ServiceLinePayments.Service_Fee AS UnitFee,  ServiceQty, RequestType, BillsPaid.OPDNo, Service_Requests.StatusCode As PatStatus, ServiceLinePayments.PaidAmt, DirectID, ServiceLinePayments.PaidQty, '**' As CapID, Service_Requests.ServerTime, BillsPaid.Pat_No, ServiceLinePayments.ReceiptNo, Service_Requests.ClinicCode, ServiceLinePayments.PatAge, Service_Requests.BillCategoryCode As PatCategoryCode,BillsPaid.UserID, 'SERVICE' As RecType,RequesterID, ReqDate, Reqtime,CoPayed, ServiceLinePayments.SponsorNo,BillsPaid.PmtModeCode FROM AllSetUpServicesView Inner Join (Service_Requests Inner Join (BillsPaid Inner Join ServiceLinePayments On BillsPaid.ReceiptNo =ServiceLinePayments.ReceiptNo) On (Service_Requests.ServiceCode=ServiceLinePayments.ServiceCode and Service_Requests.RecordID=ServiceID)) On ItemID=Service_Requests.ServiceCode Where ServiceLinePayments.Archived='No'



go

