CREATE VIEW [dbo].[AgeGroupUpperValuesView]

AS

Select Distinct RecordID, GroupCode, UpperValue, UpperTypeID, UpperAgeUnit, ageGroupCode, AgeGroups.Description As AgeGrpDesc, LimitComparisonValuesViews.Description As UpperTypeDesc, AgeUnitValuesViews.DescriptionTag As UpperUnitDesc,  AgeUnitValuesViews.Description As UpperUnitTag, VbConvertionFactor From AgeGroups Inner Join (LimitComparisonValuesViews Inner Join (AgeUnitValuesViews Inner Join AgeGroupsClassification On AgeUnitValuesViews.Code=UpperAgeUnit) On LimitComparisonValuesViews.Code = UpperTypeID) On AgeGroups.Code = AgeGroupCode
go

