CREATE VIEW [dbo].[AccountInsuredTransactionsView]

AS

--SERVICES CREDIT SALE  - NON NHIA
SELECT
	
S.ServiceCode As ServiceCode, S.UnitFee * S.RequiredQty As TransAmt,C.EndDate As TransDate,J.TransTypeID, J.AcctCode AS CreditAcctCode,UPPER(A.Description) as CreditAcctName,
UPPER(T.Description) as CreditPostType,
ISNULL((Select TOP 1 UPPER(N.Description) From AccountCustomersVendors N Where P.SponsorNo=N.MappedCode and N.TypeID=9),'') as Debtor,
P.SponsorNo As ClientID, M.ServiceTypeID,P.SponsorTypeCode,

ISNULL((B.AcctCode),'') As DebitAcctCode, ISNULL(UPPER(G.Description),'') As DebitAcctName, ISNULL(UPPER(K.Description),'') As DebitPostType
, '' As TransID
	      	
FROM 
	
Sponsors P,AccountChartServicesMapping M, AccountChartSetup A,AccountPostingType T, AccountChartSetup G,AccountPostingType K,AccountsChartJournalMapping B,
PrivateClaimsServices S, AccountsChartJournalMappingView J, ServicesConfigurationSetupView V, PrivateClaimsDetail C, AccountChartServicesMapping X
	
WHERE 

M.ServiceTypeID=2 And J.AcctTypeID=1 And P.SponsorNo =S.SponsorID AND J.TransTypeID=2 And A.Code=J.AcctCode  And S.PatCatCode NOT IN (1,4,11)  And C.SponsorID=S.SponsorID And P.SponsorTypeCode<>2 And 
T.Code=J.AcctPostType And J.TransTypeID=M.PostingType And J.AcctCode=M.AccountChartCode And C.ClaimEventID=S.ClaimEventID And C.BeginDate=S.BeginDate And C.EndDate=S.EndDate And C.OPDNo=S.OPDNo 
And A.Code=M.AccountChartCode And J.AcctPostType=2  And (((V.AcctsServicesMapID=4 and M.ServiceID = S.HWCode AND M.ServiceTypeID=2) OR
(V.AcctsServicesMapID=3 AND M.ServiceTypeID=2) OR (V.AcctsServicesMapID=2 And M.ServiceID=S.ServiceCode AND M.ServiceTypeID=2))) and S.UnitFee>0  AND
B.TransTypeID=2 AND B.AcctTypeID=9 And G.Code=B.AcctCode And B.TransTypeID=J.TransTypeID AND B.AcctTypeIDJE=J.AcctTypeID And X.ServiceTypeID=4 AND 
B.AcctCodeJE=J.AcctCode And B.AcctCode=X.AccountChartCode And X.PostingType=2 AND X.ServiceID=P.SponsorNo AND K.Code=B.AcctPostType And B.AcctPostType=1


--R.ItemID=S.ServiceCode AND J.AcctTypeID=1 And P.SponsorNo =S.SponsorID AND J.TransTypeID=2 And A.Code=J.AcctCode  And S.PatCatCode NOT IN (1,4,11)  And C.SponsorID=S.SponsorID  And 
--T.Code=J.AcctPostType And J.TransTypeID=M.PostingType And J.AcctCode=M.AccountChartCode And C.ClaimEventID=S.ClaimEventID And C.BeginDate=S.BeginDate And C.EndDate=S.EndDate And C.OPDNo=S.OPDNo 
--And A.Code=M.AccountChartCode And J.AcctPostType=2  And (((V.AcctsServicesMapID=4 and M.ServiceID = S.HWCode AND M.ServiceTypeID=2 And R.ServiceTypeCode<>1) OR
--(V.AcctsServicesMapID=3 and M.ServiceID = R.ServiceTypeCode AND M.ServiceTypeID=2 And R.ServiceTypeCode<>1) OR (V.AcctsServicesMapID=2 and M.ServiceID = R.ItemID AND M.ServiceTypeID=2 And R.ServiceTypeCode<>1))
--OR ((M.ServiceTypeID = R.ServiceTypeCode AND V.AcctsDrugsMapID=4 and M.ServiceID = S.HWCode  AND M.ServiceTypeID=1) OR
--(M.ServiceTypeID = R.ServiceTypeCode AND V.AcctsDrugsMapID=3 and M.ServiceID = 1  AND M.ServiceTypeID=1) OR (M.ServiceTypeID = R.ServiceTypeCode AND V.AcctsDrugsMapID=2 and M.ServiceID = R.ItemID  AND M.ServiceTypeID=1 )
-- OR (V.AcctsDrugsMapID=5 and M.ServiceID = CONVERT(NVarchar(15),R.SubCatID) AND M.ServiceTypeID=1)  OR (V.AcctsDrugsMapID=6 and M.ServiceID = CONVERT(NVarchar(15),R.CatID) AND M.ServiceTypeID=1))) and S.UnitFee>0


UNION ALL


SELECT
	
S.ServiceCode As ServiceCode, S.UnitFee * S.RequiredQty As TransAmt,C.EndDate As TransDate,J.TransTypeID, J.AcctCode AS CreditAcctCode,UPPER(A.Description) as CreditAcctName,
UPPER(T.Description) as CreditPostType,
ISNULL((Select TOP 1 UPPER(N.Description) From AccountCustomersVendors N Where P.SponsorNo=N.MappedCode and N.TypeID=9),'') as Debtor,
P.SponsorNo As ClientID, M.ServiceTypeID,P.SponsorTypeCode,

ISNULL((B.AcctCode),'') As DebitAcctCode, ISNULL(UPPER(G.Description),'') As DebitAcctName, ISNULL(UPPER(K.Description),'') As DebitPostType
, '' As TransID
	      	
FROM 
	
Sponsors P,AccountChartServicesMapping M, AccountChartSetup A,AccountPostingType T, AccountChartSetup G,AccountPostingType K,AccountsChartJournalMapping B,
PrivateClaimsServices S, AccountsChartJournalMappingView J, ServicesConfigurationSetupView V, PrivateClaimsDetail C, AccountChartServicesMapping X, Items R
	
WHERE 

M.ServiceTypeID=1 And R.ItemID=S.ServiceCode AND J.AcctTypeID=1 And P.SponsorNo =S.SponsorID AND J.TransTypeID=2 And A.Code=J.AcctCode  And S.PatCatCode NOT IN (1,4,11)  And C.SponsorID=S.SponsorID And P.SponsorTypeCode<>2 And 
T.Code=J.AcctPostType And J.TransTypeID=M.PostingType And J.AcctCode=M.AccountChartCode And C.ClaimEventID=S.ClaimEventID And C.BeginDate=S.BeginDate And C.EndDate=S.EndDate And C.OPDNo=S.OPDNo 
And A.Code=M.AccountChartCode And J.AcctPostType=2  And (((V.AcctsDrugsMapID=4 and M.ServiceID = S.HWCode  AND M.ServiceTypeID=1) OR
(V.AcctsDrugsMapID=3 and M.ServiceID = 1 AND M.ServiceTypeID=1) OR (V.AcctsDrugsMapID=2 and M.ServiceID = S.ServiceCode AND M.ServiceTypeID=1)
 OR (V.AcctsDrugsMapID=5 AND M.ServiceTypeID=1 and M.ServiceID = CONVERT(NVarchar(15),R.ItemClassCode)) OR (V.AcctsDrugsMapID=6 AND M.ServiceTypeID=1 and M.ServiceID = CONVERT(NVarchar(15),R.ItemTypeCode)))) and S.UnitFee>0  AND
B.TransTypeID=2 AND B.AcctTypeID=9 And G.Code=B.AcctCode And B.TransTypeID=J.TransTypeID AND B.AcctTypeIDJE=J.AcctTypeID And X.ServiceTypeID=4 AND 
B.AcctCodeJE=J.AcctCode And B.AcctCode=X.AccountChartCode And X.PostingType=2 AND X.ServiceID=P.SponsorNo AND K.Code=B.AcctPostType And B.AcctPostType=1
go

