


CREATE VIEW [dbo].[ItemsStockLevelAtDateView]

AS

SELECT IsNull(Sum(StockLevel),0) As StockLevel, ItemID FROM Service_Places Inner Join ItemsStockLevels ON  Code=StoreID Where StockLevel>=0 And UPPER(Service_Places.Status)='YES' Group By ItemID



go

