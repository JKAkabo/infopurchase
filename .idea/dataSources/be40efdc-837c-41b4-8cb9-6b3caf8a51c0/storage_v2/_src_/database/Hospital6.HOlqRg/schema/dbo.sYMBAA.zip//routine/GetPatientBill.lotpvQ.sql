
CREATE FUNCTION [dbo].[GetPatientBill]

(@OPDNo AS NVARCHAR(15),@DateFrom DateTime,@DateTo DateTime, @PatCat Tinyint, @PatStatus TinyInt,@EpisodeID Numeric(18,0)) RETURNS numeric(18,6)

AS

BEGIN

Declare @PatBill Numeric(18,6),@PatBill1 Numeric(18,6)

Set @PatBill=0
Set @PatBill1=0

If (@PatCat = 4 Or @PatCat = 11) And @EpisodeID <> 0
    BEGIN
						Select @PatBill1=ServiceFee + DrugFee + DiagnosticFee From Episode Where EndEpisode Is Not Null And Archived='No' And EpisodeID = @EpisodeID
		    
						Set @PatBill=@PatBill+@PatBill1
		     
						Select @PatBill1=IsNull(Sum(Service_Fee * ServiceQty),0) From Service_Requests Where (Not (BillCategoryCode=4 Or BillCategoryCode=11)) And OPDNo = @OPDNo And Archived ='No' and Refunded ='No' And UPPER(RequestType)='INTERNAL' And PaymentCode='P' And ReqDate >= @DateFrom And ReqDate <=@DateTo
		    
    END
    
else
    Select @PatBill1=IsNull(Sum(Service_Fee * ServiceQty),0) From Service_Requests Where OPDNo = @OPDNo And Archived ='No' and Refunded ='No' And UPPER(RequestType)='INTERNAL' And PaymentCode='P' And ReqDate >= @DateFrom And ReqDate <=@DateTo

Set @PatBill=@PatBill+@PatBill1

Select @PatBill1=IsNull(Sum((CoPayFee-Service_Fee) * ServiceQty),0) From Service_Requests Where OPDNo = @OPDNo And Archived ='No' and Refunded ='No' And CoPayFee-Service_Fee>0 And UPPER(RequestType)='INTERNAL' And ReqDate >= @DateFrom And ReqDate <=@DateTo

Set @PatBill=@PatBill+@PatBill1

Select @PatBill1=IsNull(Sum(UnitPrice * QtyPrescribed),0) From Prescriptions Where OPDNo = @OPDNo And QtyGiven =0 And ReturnedQty=0 And Archived ='No' and Refunded ='No' And UPPER(PresType)='INTERNAL' And PaymentCode='P' And PresDate >= @DateFrom And PresDate <=@DateTo

Set @PatBill=@PatBill+@PatBill1

Select @PatBill1=IsNull(Sum(UnitPrice * QtyGiven),0) From Prescriptions Where OPDNo = @OPDNo And QtyGiven <>0 And Archived ='No' and Refunded ='No' And UPPER(PresType)='INTERNAL' And PaymentCode='P' And PresDate >= @DateFrom And PresDate <=@DateTo

Set @PatBill=@PatBill+@PatBill1

Select @PatBill1=IsNull(Sum((CoPayFee-UnitPrice) * QtyPrescribed),0) From Prescriptions Where OPDNo = @OPDNo And QtyGiven =0 And (CoPayFee-UnitPrice)>0 And ReturnedQty=0 And Archived ='No' and Refunded ='No' And UPPER(PresType)='INTERNAL' And PaymentCode='P' And PresDate >= @DateFrom And PresDate <=@DateTo

Set @PatBill=@PatBill+@PatBill1

Select @PatBill1=IsNull(Sum((CoPayFee-UnitPrice) * QtyGiven),0) From Prescriptions Where OPDNo = @OPDNo And QtyGiven <>0 And(CoPayFee-UnitPrice)>0 And Archived ='No' and Refunded ='No' And UPPER(PresType)='INTERNAL' And PaymentCode='P' And PresDate >= @DateFrom And PresDate <=@DateTo

Set @PatBill=@PatBill+@PatBill1

RETURN @PatBill

END


go

