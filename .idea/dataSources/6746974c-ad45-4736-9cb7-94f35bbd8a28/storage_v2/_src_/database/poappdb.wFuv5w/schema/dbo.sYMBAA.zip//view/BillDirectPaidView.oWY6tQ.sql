CREATE VIEW [dbo].[BillDirectPaidView]

AS

SELECT Distinct Deposits.DepositDate As PmtDate, Deposits.DepositTime  As Pmtime, 0 As RecordID, 'DEPTDRG' As ServiceCode, 1 AS ServiceTypeCode, 1 As PmtTypeCode, 'DEPTDRG' AS SerPlaceCode , DepositAmount AS UnitFee,  1 AS ServiceQty, Deposits.DepositDate AS ReqDate, 'INTERNAL' AS RequestType, OPDNo, Deposits.StatusCode As PatStatus, Deposits.DepositAmount AS PaidAmt,0 AS DirectID, 1 AS PaidQty, '**' As CapID, Deposits.DepositTime  As PmtTime, Pat_No, Deposits.ReceiptNo, 'DEPTDRG' AS ClinicCode, Deposits.PatAge, 1 As PatCategoryCode, Deposits.UserID, 'DRUG DEPOSIT' As RecType, Received, PmtModeCode FROM Deposits Where Archived='No' and Deposits.DepReason='DRUGS'

UNION ALL

SELECT Distinct Deposits.DepositDate, Deposits.DepositTime, 0 As RecordID, 'DEPTSER' As ServiceCode, 10 AS ServiceTypeCode, 1 As PmtTypeCode, 'DEPTSER' AS SerPlaceCode , DepositAmount AS UnitFee,  1 AS ServiceQty, Deposits.DepositDate AS ReqDate, 'INTERNAL' AS RequestType, OPDNo, Deposits.StatusCode As PatStatus, Deposits.DepositAmount AS PaidAmt,0 AS DirectID, 1 AS PaidQty, '**' As CapID, Deposits.DepositTime, Pat_No, Deposits.ReceiptNo, 'DEPTSER' AS ClinicCode, Deposits.PatAge, 1 As PatCategoryCode,Deposits.UserID, 'SERVICE DEPOSIT' As RecType, Received, PmtModeCode FROM Deposits Where Archived='No' and Deposits.DepReason='SERVICES'

UNION ALL

SELECT Distinct Deposits.DepositDate, Deposits.DepositTime, 0 As RecordID, 'DEPTOTH' As ServiceCode, 10 AS ServiceTypeCode, 1 As PmtTypeCode, 'DEPTOTH' AS SerPlaceCode , DepositAmount AS UnitFee,  1 AS ServiceQty, Deposits.DepositDate AS ReqDate, 'INTERNAL' AS RequestType, OPDNo, Deposits.StatusCode As PatStatus, Deposits.DepositAmount AS PaidAmt,0 AS DirectID, 1 AS PaidQty, '**' As CapID, Deposits.DepositTime, Pat_No, Deposits.ReceiptNo, 'DEPTOTH' AS ClinicCode, Deposits.PatAge, 1 As PatCategoryCode,Deposits.UserID, 'OTHER DEPOSIT' As RecType, Received, PmtModeCode FROM Deposits Where Archived='No' and Deposits.DepReason=  'OTHERS'

UNION ALL

--SELECT Distinct Deposits.DepositDate As PmtDate, Deposits.DepositTime  As Pmtime, 0 As RecordID, 'UNDEPTDRG' As ServiceCode, 1 AS ServiceTypeCode, 1 As PmtTypeCode, 'UNDEPTDRG' AS SerPlaceCode , DepositAmount AS UnitFee,  1 AS ServiceQty, Deposits.DepositDate AS ReqDate, 'INTERNAL' AS RequestType, OPDNo, Deposits.StatusCode As PatStatus, Deposits.DepositAmount AS PaidAmt,0 AS DirectID, 1 AS PaidQty, '**' As CapID, Deposits.DepositTime  As PmtTime, Pat_No, Deposits.ReceiptNo, 'UNDEPTDRG' AS ClinicCode, Deposits.PatAge, 1 As PatCategoryCode, Deposits.UserID, 'DRUG DEPOSIT' As RecType, Received, 1 As PmtModeCode FROM Deposits Where Archived='No' and Received='No' and Deposits.DepReason='DRUGS'

--UNION ALL

--SELECT Distinct Deposits.DepositDate, Deposits.DepositTime, 0 As RecordID, 'UNDEPTSER' As ServiceCode, 10 AS ServiceTypeCode, 1 As PmtTypeCode, 'UNDEPTSER' AS SerPlaceCode , DepositAmount AS UnitFee,  1 AS ServiceQty, Deposits.DepositDate AS ReqDate, 'INTERNAL' AS RequestType, OPDNo, Deposits.StatusCode As PatStatus, Deposits.DepositAmount AS PaidAmt,0 AS DirectID, 1 AS PaidQty, '**' As CapID, Deposits.DepositTime, Pat_No, Deposits.ReceiptNo, 'UNDEPTSER' AS ClinicCode, Deposits.PatAge, 1 As PatCategoryCode,Deposits.UserID, 'SERVICE DEPOSIT' As RecType, Received, 1 As PmtModeCode FROM Deposits Where Archived='No' and Received='No' and Deposits.DepReason<>'DRUGS'

--UNION ALL

SELECT Distinct PmtDate, PmtTime, 0 As RecordID, 'SPSBILLPMT' As ServiceCode, 10 AS ServiceTypeCode, 1 As PmtTypeCode, 'SPSBILLPMT' AS SerPlaceCode , AmtPaid AS UnitFee,  1 AS ServiceQty, PmtDate AS ReqDate, 'INTERNAL' AS RequestType, Sponsors_Payments.SponsorNo as  OPDNo, 2 As PatStatus, AmtPaid AS PaidAmt,0 AS DirectID, 1 AS PaidQty, '**' As CapID, PmtTime, Sponsors_Payments.SponsorNo AS Pat_No, ReceiptNo, 'SPSBILLPMT' AS ClinicCode, 0 As PatAge, Sponsors.SponsorTypeCode AS BillCategoryCode,Sponsors_Payments.UserID, 'SPO' As RecType, 'Yes', 1 As PmtModeCode FROM Sponsors Inner Join Sponsors_Payments On Sponsors.SponsorNo=Sponsors_Payments.SponsorNo Where Sponsors_Payments.Archived='No' And AmtPaid>0 

UNION ALL

SELECT Distinct BillsPaid.PmtDate, BillsPaid.PmtTime, 0 As RecordID, 'OUTBILLPMT' As ServiceCode, 10 AS ServiceTypeCode, 1 As PmtTypeCode, 'OUTBILLPMT' AS SerPlaceCode , AmtPaid AS UnitFee,  1 AS ServiceQty, BillsPaid.PmtDate AS ReqDate, 'INTERNAL' AS RequestType, OPDNo, BillsPaid.StatusCode As PatStatus, BillsPaid.AmtPaid AS PaidAmt,0 AS DirectID, 1 AS PaidQty, '**' As CapID, BillsPaid.PmtTime, Pat_No, BillsPaid.ReceiptNo, 'OUTBILLPMT' AS ClinicCode, BillsPaid.PatAge, 1 As BillCategoryCode,BillsPaid.UserID, 'OUT' As RecType, 'Yes',BillsPaid.PmtModeCode FROM BillsPaid Where Archived='No' And BillsPaid.AmtPaid>0 AND BillsPaid.RefAmtRequested=0 And ReceiptNo Not IN (Select Distinct ReceiptNo FROM Deposits) And ReceiptNo Not IN (Select Distinct ReceiptNo FROM ServiceLinePayments)

--UNION ALL

--SELECT Distinct BillsPaid.PmtDate, BillsPaid.PmtTime, 0 As RecordID, 'OUTBILLPMT1' As ServiceCode, 10 AS ServiceTypeCode, 1 As PmtTypeCode, 'OUTBILLPMT1' AS SerPlaceCode , CASE WHEN AmtPaid>0 And AmtPaid> BillOut + IOUAmt - (DepAmt +DisAmt) THEN AmtPaid-((BillOut + IOUAmt) - (DepAmt +DisAmt)) ELSE 0 End As UnitFee,  
--1 AS ServiceQty, BillsPaid.PmtDate AS ReqDate, 'INTERNAL' AS RequestType, OPDNo, BillsPaid.StatusCode As PatStatus, BillsPaid.AmtPaid AS PaidAmt,0 AS DirectID, 1 AS PaidQty, '**' As CapID, BillsPaid.PmtTime, Pat_No, BillsPaid.ReceiptNo, 'OUTBILLPMT1' AS ClinicCode, BillsPaid.PatAge, 1 As BillCategoryCode,BillsPaid.UserID, 'OUT' As RecType, 'Yes',BillsPaid.PmtModeCode FROM BillsPaid Where Archived='No' And BillsPaid.AmtPaid>0 AND BillsPaid.RefAmtRequested=0 And ReceiptNo Not IN (Select Distinct ReceiptNo FROM Deposits) And ReceiptNo Not IN (Select Distinct ReceiptNo FROM ServiceLinePayments)
go

