CREATE VIEW [dbo].[ReligionsView]

AS

SELECT Description, Code FROM dbo.Religions

Union

Select 'NOT AVAILABLE' As Description, 0 as Code from Hosp_Info
go

