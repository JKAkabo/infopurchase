
CREATE VIEW [dbo].[StocksConsumptionMovementView]

AS

SELECT abs(AdjustQty) As AdjustQty, ItemID, IssuerID As StoreID, 'DispensedDrugsOnly' As MoveType, ServerDate, 'DISPENSED DRUGS' As MoveCat FROM  dbo.STOCKMOVEMENT Where MoveType IN ('Prescriptions') 

Union all

SELECT abs(AdjustQty) As AdjustQty, ItemID, IssuerID As StoreID, 'RequisitionsOnly' As MoveType, ServerDate, 'DISPENSED DRUGS' As MoveCat FROM  dbo.STOCKMOVEMENT Where MoveType IN ('Requisitions','Return Inwards','Return Outward','Internal Item Usage') 

Union all

SELECT QtyPrescribed, DrugCode, StoresID, 'PrescriptionsOnly' As MoveType, convert(Date, ServerTime) As ServerDate, 'PRESCRIBED DRUGS' As MoveCat FROM dbo.Prescriptions Where PresType IN ('INTERNAL','EXTERNAL OUT') And Archived='No' 

Union all

Select Distinct 0, ItemID, ReceiverID, Null, Null, '' As MoveCat From STOCKMOVEMENT Where MoveType Not IN ('Requisitions','Prescriptions','Return Inwards','Return Outward','Internal Item Usage')

go

