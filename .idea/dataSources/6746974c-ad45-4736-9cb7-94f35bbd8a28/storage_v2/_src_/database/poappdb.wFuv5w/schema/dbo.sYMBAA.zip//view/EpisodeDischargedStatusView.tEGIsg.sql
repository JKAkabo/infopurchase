CREATE VIEW [dbo].[EpisodeDischargedStatusView]

AS

SELECT Distinct ConOutCome As DischargeStatusCode, 2 as PatStatus, Consultations.EpisodeID, Consultations.OPDNo, ReqDate FROM PatientNHIAActiveEpisodesView Inner Join dbo.Consultations On PatientNHIAActiveEpisodesView.EpisodeID=Consultations.EpisodeID And PatientNHIAActiveEpisodesView.OPDNo=Consultations.OPDNo Where EndEpisode Is Not Null And Consultations.Archived='No' and Consultations.StatusCode=2

Union

Select Distinct DischargeStatusCode, 3 as PatStatus, Admissions.EpisodeID, Admissions.OPDNo, DisTime As ReqDate From PatientNHIAActiveEpisodesView Inner Join dbo.Admissions On PatientNHIAActiveEpisodesView.EpisodeID=Admissions.EpisodeID And PatientNHIAActiveEpisodesView.OPDNo=Admissions.OPDNo Where EndEpisode Is Not Null And Admissions.Archived='No' and DisDate Is Not Null

Union

SELECT Distinct 1 As DischargeStatusCode, PatientNHIAActiveEpisodesView.EpisodeStatus as PatStatus, PatientNHIAActiveEpisodesView.EpisodeID, PatientNHIAActiveEpisodesView.OPDNo, EndEpisode As ReqDate FROM PatientNHIAActiveEpisodesView Where EndEpisode Is Not Null And PatientNHIAActiveEpisodesView.EpisodeID Not IN (Select Distinct EpisodeID From Consultations Where EndEpisode Is Not Null And Consultations.Archived='No' And Consultations.StatusCode=2 And EpisodeID<>0

Union Select Distinct EpisodeID From Admissions Where Admissions.Archived='No' And EpisodeID<>0 and DisDate Is Not Null)
go

