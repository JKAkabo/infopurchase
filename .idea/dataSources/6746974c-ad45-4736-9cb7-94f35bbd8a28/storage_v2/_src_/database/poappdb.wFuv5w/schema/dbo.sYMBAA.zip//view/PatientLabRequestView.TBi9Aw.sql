CREATE VIEW [dbo].[PatientLabRequestView]

AS

Select Distinct UsersView.UserID As RequesterBy, Service_Requests.OPDNo, Service_Requests.Pat_No, ReqTime, ReqDate, LastName + ' ' + MiddleName+ ' ' + Surname As PatName ,GenderGroups.Description As Gender, CONVERT(nvarchar(10),Service_Requests.PatAge) As PatAge,Service_Requests.ServiceCode,Service_Requests.RecordID, PatientLabSpecimens.RecordID AS OrderID, SpecimenID, SpecimenCode From GenderGroups Inner Join (PatientsInfo Inner Join (Service_Types Inner Join (UsersView Inner Join (Service_Requests Inner Join PatientLabSpecimens On (Service_Requests.RecordID=ReqID And Service_Requests.ServiceCode=PatientLabSpecimens.SerCode)) On UsersView.UserNo=Service_Requests.RequesterID) On Service_Types.ServiceCode=Service_Requests.ServiceCode) On PatientsInfo.OPDNo=Service_Requests.OPDNo) On GenderGroups.Code=PatientsInfo.GenderCode where ServiceTypeCode=11 and Service_Requests.Archived='No' and PatientLabSpecimens.Archived='No'
go

