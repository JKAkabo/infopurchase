CREATE PROCEDURE [dbo].[uspCancelOrders] 
	
AS

DECLARE @DisCatCode numeric(18,0);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct OrderNo From Orders Where OrderType=1 AND Archived='No' and OrderStatus IN (1) Order by OrderNo Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO  @DisCatCode;

  WHILE @@fetch_status = 0
  
    BEGIN
      
       Update Orders set OrderStatus=3, Archived ='Yes',ArchivedDate =CONVERT(date, getdate()), ArchivedTime =getdate(),ArchiverID ='00001' Where OrderNo = @DisCatCode
       
       Update OrderLines set OrderLineStatus=5, Archived ='Yes',ArchivedDate =CONVERT(date, getdate()), ArchivedTime =getdate(),ArchiverID ='00001' Where OrderID = @DisCatCode

       Insert Into OrdersChangeLogs(OrderNo,OrderType,ExpectedDate,OrderTime,OrderDate,ServerTime,OrderStoreID,ProformaNo,OrdererID,SupplierID,UserID,TotalValue,LinesTotal,OrderID,LogType,LogTime,LoggerID)Select 
       OrderNo,OrderType,ExpectedDate,OrderTime,OrderDate,ServerTime,OrderStoreID,ProformaNo,OrdererID,SupplierID,UserID,TotalValue,LinesTotal,OrderID,'DELETE',getdate(),'00001' From Orders Where OrderNo = @DisCatCode
       
       
	   Insert Into OrderLinesChangeLogs(OrderLineID,Base_No,OrderID,OrderQty,OrderUnit,UnitCost,ItemID,StockLevel,ReorderLevel,OrderUnitID,LogType,LogTime,LoggerID)Select
		OrderLineID,Base_No,OrderID,OrderQty,OrderUnit,UnitCost,ItemID,StockLevel,ReorderLevel,OrderUnitID,'DELETE',getdate(),'00001' From OrderLines Where OrderID = @DisCatCode

       FETCH NEXT FROM C INTO  @DisCatCode;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

