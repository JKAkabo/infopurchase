




CREATE VIEW [dbo].[LastAdmissionWardTransfersView]
AS

SELECT  RecordID, Admissions.OPDNo, Pat_No, ClinicCode, DisDate, DisTime, WardID, AdmAge, DisAge, DisAuthouriser AS DisDoctor, DischargeStatusCode, PatCategoryCode, BedNo, BedType, DoctorID FROM dbo.Admissions Inner Join WardTransfers on RecordID=NewAdmRecordID 
where Transfered='No' And Admissions.Archived='No' and WardTransfers.Archived='No' and DisDate Is Not Null



go

