CREATE VIEW [dbo].[ClinicalHistoriesView]

AS

SELECT OrderNo, ClinicalHistories.Description, ClinicalHistories.Code, ID, GenderCode, AgeGroupCode, ClinicalHistories.IsActive, GenderGroups.Description As Gender, AgeGroups.Description As AgeGroup FROM dbo.ClinicalHistories, AgeGroups,GenderGroups where AgeGroups.Code=AgeGroupCode and GenderGroups.Code=GenderCode
go

