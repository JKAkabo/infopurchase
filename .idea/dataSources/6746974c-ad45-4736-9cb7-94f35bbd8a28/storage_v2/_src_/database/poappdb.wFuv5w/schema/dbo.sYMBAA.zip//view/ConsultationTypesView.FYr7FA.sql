CREATE VIEW [dbo].[ConsultationTypesView]

AS

SELECT  Description, Code FROM ConsultationTypes

Union

SELECT  'ALL' As Description, 3 As Code FROM dbo.Hosp_Info

Union

SELECT  'REFERRAL' As Description, 4 As Code FROM dbo.Hosp_Info
go

