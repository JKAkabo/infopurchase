

CREATE VIEW [dbo].[DHIMSHAMSServicesView]

AS

Select Distinct left(GDRGCodeA,6) As Code, ServiceType As Description, AgeGroupCode As AgeGroupID, GenderCode, ServiceTypeCode, ServiceCode from Service_Types where ServiceTypeCode IN (3,11,12,13,14) and Disabled='No' and  GDRGCodeA<>'' and GDRGCodeC<>''  and  GDRGCodeA Is Not Null and GDRGCodeC  Is Not Null

Union

Select Distinct left(GDRGCodeA,6) As Code, ServiceType As Description, AgeGroupCode As AgeGroupID, GenderCode, ServiceTypeCode, ServiceCode from Service_Types where ServiceTypeCode IN (3,11,12,13,14) and Disabled='No' and  GDRGCodeA<>''  and  GDRGCodeA Is Not Null and (GDRGCodeC='' Or  GDRGCodeC Is  Null)

Union

Select Distinct left(GDRGCodeC,6) As Code, ServiceType As Description, AgeGroupCode As AgeGroupID, GenderCode, ServiceTypeCode, ServiceCode from Service_Types where ServiceTypeCode IN (3,11,12,13,14) and Disabled='No' and  GDRGCodeC<>''  and  GDRGCodeC Is Not Null and (GDRGCodeA='' Or  GDRGCodeA Is  Null)

Union

Select Distinct ServiceCode As Code, ServiceType As Description, AgeGroupCode As AgeGroupID, GenderCode, ServiceTypeCode, ServiceCode from Service_Types where ServiceTypeCode IN (3,11,12,13,14) and Disabled='No' and  (GDRGCodeC=''  Or  GDRGCodeC Is Null) and (GDRGCodeA='' Or  GDRGCodeA Is  Null)


go

