-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[uspUpdateDispensedPrescriptions] 
	-- Add the parameters for the stored procedure here
	
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
  INSERT INTO NewHamsDB.[dbo].[DispensedPrescriptions]
      ([PresID]
      ,[ItemID]
      ,[StatusCode]
      ,[PatAge]
      ,[UnitCost]
      ,[UnitPrice]
      ,[BatchNo]
      ,[ExpiryDate]
      ,[DispensedQty]
      ,[DispenserID]
      ,[DispensedDate]
      ,[DispensedTime]
      ,[StoreID]
      ,[DeptID]
      ,[EmpNo]
      ,[Returned]
      ,[ReturnedDate]
      ,[ReturnedTime]
      ,[ReturnerID]
      ,[ReturnedQty]
      ,[UserID]
      ,[CAP_ID]
      ,[ServerTime]
      , Dosage
       ,Frequency, Duration, BeginDate, EndDate)

SELECT [RecordID]
      ,[DrugCode]
      ,[StatusCode]
      ,[PatAge]
      ,[UnitCost]
      ,[UnitPrice]
      ,[BatchNo]
      ,[ExpiryDate]
      ,QtyGiven
      ,[DespenserID]
      ,[DispensedDate]
      ,[DispensedTime]
      ,[StoresID]
      ,[DeptID]
      ,[EmpNo]
      ,[Returned]
      ,[ReturnedDate]
      ,[ReturnedTime]
      ,[ReturnerID]
      ,[ReturnedQty]
      ,[UserID]
      ,[CAP_ID]
      ,[ServerTime]
      , Units
       ,Dosage, PresDays, StartDate, FinishDate 
  FROM NewHamsDB.[dbo].[Prescriptions] Where Issued='Yes' and DispensedDate is not null and Archived='No' Order By RecordID Asc



END
go

