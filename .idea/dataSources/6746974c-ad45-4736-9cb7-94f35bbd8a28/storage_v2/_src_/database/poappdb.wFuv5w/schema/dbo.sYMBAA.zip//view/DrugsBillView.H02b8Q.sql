CREATE VIEW [dbo].[DrugsBillView]

AS

SELECT PatAge, OPDNo, Pat_No, RecordID, DrugCode, UnitCost, UnitPrice, PresDate, PresTime, PaidAmt, PaidQty, StoresID As ServicePlaceID, PmtTypeCode, PmtModeCode, BillCategoryCode, PatCategoryCode, QtyGiven, QtyPrescribed, ClinicCode, DirectID, PaymentCode, Prescriptions.DeptID, EmpNo, SponsorNo, 1 As ServiceTypeCode, StatusCode, 'No' As CoPayed, Left(Description,100) As Drug, ReturnedQty FROM Items Inner Join dbo.Prescriptions On ItemID=DrugCode Where Archived='No' And UPPER(PresType)='INTERNAL'

UNION

SELECT PatAge, OPDNo, Pat_No, RecordID, DrugCode, 0 As UnitCost, CoPayFee-UnitPrice As UnitPrice, PresDate, PresTime,  CoPayPaidAmt, CoPayPaidQty , StoresID, CoPayPmtTypeCode, CoPayPmtModeCode, CoPayBillCategoryCode, PatCategoryCode, QtyGiven, QtyPrescribed, ClinicCode, DirectID, PaymentCode, Prescriptions.DeptID, EmpNo, CoPaySponsorNo, 1 As ServiceTypeCode, StatusCode, 'Yes' As CoPayed, Left(Description,100) As Drug, ReturnedQty FROM Items Inner Join dbo.Prescriptions On ItemID=DrugCode Where Archived='No' And CoPayFee-UnitPrice>0 And UPPER(PresType)='INTERNAL'
go

