CREATE VIEW [dbo].[DHISDataSetsView]

AS

SELECT  Description, ID, Code, DHISCode, cat1, cat2, cat3, cat4, DataElementSource,CatOptionQuery, GenderCode, AgeGroupCode, PatientType, TransTypeQuery FROM DHISDataSets Where IsActive='Yes'

Union

SELECT  'MONTHLY RETURNS ON DELIVERIES' As Description, 0 As ID, '' As Code, 'DELIVERY1' AS DHISCode, '' AS cat1, '' AS cat2, '' AS cat3, '' AS cat4, '' AS DataElementSource,'' AS CatOptionQuery, 0 AS GenderCode, 0 As AgeGroupCode, 0 As PatientType, '' AS TransTypeQuery FROM dbo.Hosp_Info
go

