
CREATE VIEW [dbo].[AllAttendanceView]

AS

Select DisRecID As RecordID, OPDNo, Pat_No, ClinicCode, 3 As PatStatus, AdmDate As FromDate, DisDate As ToDate ,DischargeStatusCode as OutCome, DoctorID, DoctorRemarks As AttRemarks, DisWardID As SerPlaceID, DisAuthouriser As DisDoctorID, ReviewDate, TreatmentPlan, Description As ServicePlace,'Yes' As Discharged  
, Isnull((Select TOP 1 LocationNo From PatientFolder C where Archived='No' ORDER BY ServerTime),'') As FolderLocation From AdmissionDischrgesView, ServicePlacesView where Code=WardID 

Union  All

Select Distinct RecordID, OPDNo, Pat_No, ClinicCode, 3 As PatStatus, CASE WHEN (SELECT TOP 1 AdmDate FROM Admissions A, WardTransfers W WHERE A.RecordID=OldAdmRecordID AND Admissions.RecordID=NewAdmRecordID AND A.Archived='No' AND W.Archived='No' Order By AdmDate Asc) IS NULL  Then AdmDate
else (SELECT TOP 1 AdmDate FROM Admissions A, WardTransfers W WHERE A.RecordID=OldAdmRecordID AND Admissions.RecordID=NewAdmRecordID AND A.Archived='No' AND W.Archived='No' Order By AdmDate Asc) END As FromDate, CONVERT(Date,Getdate()) As ToDate ,DischargeStatusCode as OutCome, DoctorID, 
Isnull((Select TOP 1 DoctorRemarks From InPatientConsultations C where Archived='No' And (C.ConDate>=Admissions.AdmDate And C.ConDate<=GetDate()) ORDER BY ServerTime),'') As AttRemarks, 
WardID, DoctorID, Null, Isnull((Select TOP 1 TreatmentPlan From InPatientConsultations C where Archived='No' And (C.ConDate>=Admissions.AdmDate And C.ConDate<=GetDate()) ORDER BY ServerTime),'') As TreatmentPlan, Description As ServicePlace,Discharged 
, Isnull((Select TOP 1 LocationNo From PatientFolder C where Archived='No' ORDER BY ServerTime),'') As FolderLocation
From Admissions, ServicePlacesView where Code=WardID  And Archived='No' and Discharged='No' And DisDate Is Null

Union ALL

SELECT Distinct Consultations.ConID As RecordID, Consultations.OPDNo, Consultations.Pat_No, Consultations.ClinicCode, 2 As PatStatus, ReqDate As FromDate, ReqDate As ToDate, ConOutCome, Doctor As DoctorID, Consultations.DoctorRemarks,
convert(Nvarchar(15),Consultations.ConRoomID) As SerPlaceID,Doctor, (Select TOP 1 ReviewTime From ConsultationReviews C where Cancelled='No' And C.ConID=Consultations.ConID And StatusCode=2 Order By ReviewTime Desc) As ReviewDate, '', Description As ServicePlace,'Yes' As Discharged
, Isnull((Select TOP 1 LocationNo From PatientFolder C where Archived='No' ORDER BY ServerTime),'') As FolderLocation
FROM Consultations, ConsultingRooms Where ConRoomID=Code And Archived='No' and ConID NOT IN (Select ConID from Consultations C, AdmissionDischrgesView A Where Archived='No' And C.OPDNo = A.OPDNo and C.ReqDate >=AdmDate And ReqDate<=DisDate) And 
ConID NOT IN (Select ConID from Consultations C, Admissions A Where A.Archived='No' And C.Archived='No' and Discharged='No' And C.OPDNo = A.OPDNo and C.ReqDate >=AdmDate And C.ReqDate<=CONVERT(Date,GetDate()))

Union ALL

SELECT Distinct RecordID, OPDNo, Pat_No, ClinicCode, 2 As PatStatus, AttDate As FromDate, AttDate As ToDate, 1 OutCome, '' As DoctorID, '' As AttRemarks,'' As SerPlaceID,'', Null,'' , '' As ServicePlace,'Yes' As Discharged
, Isnull((Select TOP 1 LocationNo From PatientFolder C where Archived='No' ORDER BY ServerTime),'') As FolderLocation
FROM Daily_Attendance where RecordID NOT IN (Select RecordID from Daily_Attendance C, AdmissionDischrgesView A Where C.OPDNo = A.OPDNo and C.AttDate >=AdmDate And AttDate<=DisDate)
And RecordID NOT IN (Select RecordID from Daily_Attendance C, Consultations A Where C.OPDNo = A.OPDNo and C.AttDate=ReqDate and Archived='No') And 
RecordID NOT IN (Select C.RecordID from Daily_Attendance C, Admissions A Where A.Archived='No' and Discharged='No' And C.OPDNo = A.OPDNo and C.AttDate >=AdmDate And AttDate<=CONVERT(Date,GetDate()))



go

