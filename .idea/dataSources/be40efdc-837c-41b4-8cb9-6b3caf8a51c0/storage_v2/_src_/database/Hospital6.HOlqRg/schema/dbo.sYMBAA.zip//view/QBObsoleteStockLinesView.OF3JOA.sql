CREATE VIEW [dbo].[QBObsoleteStockLinesView]

AS

Select ItemSerNo As TransID, UnitCost, OldQty-ReqQty As MoveQty, Adjusted_Stocks.ItemID, ApproveDate As TransDate, StockAdjustmentApprovals.StoreID As IssuerID, StockAdjustmentApprovals.UserID As ReceiverID,'Obsolete Stocks' As MoveType,UPPER(Service_Places.Description) As ClientName, Items.Description As ServiceDescription, Items.ItemID As ServiceCode, Convert(Nvarchar(15),ItemClassCode) As ItemClassCode 
From Service_Places Inner Join (StockAdjustmentApprovals Inner Join (Items Inner Join Adjusted_Stocks On Items.ItemID=Adjusted_Stocks.ItemID) ON StockAdjustmentApprovals.ApproveID=Adjusted_Stocks.ApproveID) On Code=StockAdjustmentApprovals.StoreID Where UPPER(Service_Places.Status)='YES' And OldQty-ReqQty>0 And ReasonCode=9 And Approved='Yes' And Adjusted_Stocks.Archived='No' And StockAdjustmentApprovals.Archived='No' And Adjusted_Stocks.ItemID IN 
(Select Items.ItemID From Items Inner Join QBAcctsMappingView ON Convert(Nvarchar(15),ItemClassCode)=ServiceID)
go

