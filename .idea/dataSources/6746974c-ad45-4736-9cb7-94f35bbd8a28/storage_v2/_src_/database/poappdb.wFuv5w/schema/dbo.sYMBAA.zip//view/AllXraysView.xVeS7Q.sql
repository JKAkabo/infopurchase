CREATE VIEW [dbo].[AllXraysView]

AS

Select Distinct Service_Requests.OPDNo, Service_Requests.Pat_No, RequestType As DeliveryType, Service_Requests.StatusCode As PatStatus, ReqTime As AttTime, ReqDate As AttDate, '' As Remarks, ServiceType, Service_Places.Description As ServicePlace, Service_Requests.RequesterID as UserID, ClinicCode From Service_Places Inner Join (Service_Types Inner Join Service_Requests On Service_Types.ServiceCode=Service_Requests.ServiceCode) On Code = Service_Requests.SerPlaceCode Where Service_Requests.Archived='No' And Service_Types.ServiceTypeCode=12 And Service_Requests.RecordID NOT IN (Select RecordID From XrayTests Where XrayTests.Archived='No')

Union ALL

Select Distinct Service_Requests.OPDNo, Service_Requests.Pat_No, RequestType As DeliveryType, Service_Requests.StatusCode As PatStatus, XrayTests.TestTime As AttTime, XrayTests.TestDate As AttDate, XrayTests.Remarks, ServiceType, Service_Places.Description As ServicePlace, Service_Requests.RequesterID as UserID, ClinicCode From Service_Places Inner Join (Service_Types Inner Join (Service_Requests Inner Join XrayTests On Service_Requests.RecordID=XrayTests.RecordID) On Service_Types.ServiceCode=Service_Requests.ServiceCode) On Code = Service_Requests.SerPlaceCode Where Service_Requests.Archived='No' And XrayTests.Archived='No'
go

