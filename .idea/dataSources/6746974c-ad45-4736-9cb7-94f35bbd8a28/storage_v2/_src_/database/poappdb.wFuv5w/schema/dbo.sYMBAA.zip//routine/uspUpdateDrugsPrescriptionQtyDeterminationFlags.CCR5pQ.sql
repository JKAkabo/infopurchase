CREATE PROCEDURE [dbo].[uspUpdateDrugsPrescriptionQtyDeterminationFlags] 
	
AS

DECLARE @DisCatCode nvarchar(15);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT itemID From UnitMeasures, Items Where UnitMeasures.Code=IssueUnitCode And (UnitMeasures.Description NOT IN ('TUBE', 'BOTL', 'BOTTLE', 'PKT', 'PACKET', 'SAT', 'BAG', 'ROLL', 'BOX', 'UNIT ITEM', 'GAL', 'EXPENDABLE', 'NEBULE', 'OTHER')) And ItemTypeCode IN (1)  Order by ItemID Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO @DisCatCode;

  WHILE @@fetch_status = 0
    BEGIN

       --set @DisCategory=dbo.ItemDesc(@DisCategory);
       
       update Items Set DeterminePresQty='Yes' where ItemID=@DisCatCode
       
       FETCH NEXT FROM C INTO @DisCatCode;

	END

	CLOSE C;

	DEALLOCATE C;
    
END
go

