

CREATE VIEW [dbo].[PatientInvoiceDiscountsView]

AS

Select 'GHC' As DepositCurrency, Bill_Discounts.DisTime As DiscountTime , Bill_Discounts.DisDate As DiscountDate , Bill_Discounts.RefNo As ReferenceNo,Bill_Discounts.DisAmt As DiscountAmount, Bill_Discounts.BillReferenceNo As BillInvoiceNo From Bill_Discounts Inner Join BillsPaid On (Bill_Discounts.OPDNo=BillsPaid.OPDNo And Bill_Discounts.BillReferenceNo=BillsPaid.ReceiptNo ) Where BillsPaid.Archived='No' and Bill_Discounts.Archived='No'



go

