CREATE VIEW [dbo].[AccountMapTypesView]

AS

SELECT 1 As ServiceMapType, ItemID, AcctsDrugsMapID, CASE WHEN AcctsDrugsMapID=1  and ServiceTypeCode=1 THEN A.ItemID END As ServiceMapID, Description 
FROM dbo.AllSetUpServicesView A, ServicesConfigurationSetupView S Where A.ItemID=A.ItemID and ServiceTypeCode IN (1) And A.Disabled='No' And A.CAPID=S.CAPID and AcctsDrugsMapID IN (1)

Union All

SELECT  2,ItemID, AcctsServicesMapID, CASE WHEN AcctsServicesMapID=2  and ServiceTypeCode NOT IN (1,2) THEN A.ItemID END As ServiceMapID, Description 
FROM dbo.AllSetUpServicesView A, ServicesConfigurationSetupView S Where A.Disabled='No' and ServiceTypeCode NOT IN (1,2) And A.CAPID=S.CAPID and AcctsServicesMapID IN (2)

Union All

SELECT 2,ItemID, AcctsServicesMapID, CASE WHEN AcctsServicesMapID=3  and ServiceTypeCode NOT IN (1,2) THEN Convert(nvarchar(15),ServiceTypeCode) END As ServiceMapID,I.Description 
FROM dbo.AllSetUpServicesView A, ServicesConfigurationSetupView S, ServiceTypes I Where Code=ServiceTypeCode and ServiceTypeCode NOT IN (1,2) And A.Disabled='No' And A.CAPID=S.CAPID and AcctsServicesMapID IN (3)

Union All

SELECT 1, ItemID, AcctsDrugsMapID, CASE WHEN AcctsDrugsMapID=3  and ServiceTypeCode=1 THEN Convert(nvarchar(15),ServiceTypeCode) END As ServiceMapID,I.Description 
FROM dbo.AllSetUpServicesView A, ServicesConfigurationSetupView S, ServiceTypes I Where Code=ServiceTypeCode and ServiceTypeCode IN (1) And A.Disabled='No' And A.CAPID=S.CAPID and AcctsDrugsMapID IN (3)

Union All

SELECT 5, ItemID, AcctsDignosisMapID, CASE WHEN AcctsDignosisMapID=3  and ServiceTypeCode=2 THEN Convert(nvarchar(15),ServiceTypeCode) END As ServiceMapID,I.Description 
FROM dbo.AllSetUpServicesView A, ServicesConfigurationSetupView S, ServiceTypes I Where Code=ServiceTypeCode and ServiceTypeCode IN (2) And Disabled='No' And A.CAPID=S.CAPID and AcctsDignosisMapID IN (3)

Union All

SELECT 2, ItemID, AcctsServicesMapID , CASE WHEN AcctsServicesMapID=4  and ServiceTypeCode NOT IN (1,2) THEN ServicePlaceCode END As ServiceMapID,I.Description 
FROM dbo.AllSetUpServicesView A, ServicesConfigurationSetupView S, ServicePlacesView I Where UPPER(Status)='YES' and ServiceTypeCode NOT IN (1,2) And Code=ServicePlaceCode And A.Disabled='No' And A.CAPID=S.CAPID and AcctsServicesMapID IN (4)

Union All

SELECT 1, ItemID, AcctsDrugsMapID, CASE WHEN AcctsDrugsMapID=4  and ServiceTypeCode IN (1) THEN ServicePlaceCode END As ServiceMapID,I.Description 
FROM dbo.AllSetUpServicesView A, ServicesConfigurationSetupView S, ServicePlacesView I Where UPPER(Status)='YES' and ServiceTypeCode IN (1) And Code=ServicePlaceCode And A.Disabled='No' And A.CAPID=S.CAPID and AcctsDrugsMapID IN (4)

Union All

SELECT 5 , ServiceCode, AcctsDignosisMapID, CASE WHEN AcctsDignosisMapID=4  and ServiceTypeCode IN (2) THEN SerPlaceCode END As ServiceMapID,I.Description 
FROM dbo.ServiceRequestsView A, ServicesConfigurationSetupView S, ServicePlacesView I Where UPPER(Status)='YES' and ServiceTypeCode IN (2) And Code=SerPlaceCode And A.CAPID=S.CAPID  and AcctsDignosisMapID IN (4)

Union All

SELECT 1, ItemID, AcctsDrugsMapID, CASE WHEN AcctsDrugsMapID=5  and ServiceTypeCode=1 THEN Convert(nvarchar(15),SubCatID) END As ServiceMapID,I.Description 
FROM dbo.AllSetUpServicesView A, ServicesConfigurationSetupView S, ItemClasses I Where Code=SubCatID and ServiceTypeCode IN (1) And A.Disabled='No' And A.CAPID=S.CAPID and AcctsDrugsMapID IN (5)

Union All

SELECT 1, ItemID, AcctsDrugsMapID, CASE WHEN AcctsDrugsMapID=6  and ServiceTypeCode=1 THEN Convert(nvarchar(15),CatID) END As ServiceMapID,I.Description 
FROM dbo.AllSetUpServicesView A, ServicesConfigurationSetupView S, ItemTypes I Where Code=CatID and ServiceTypeCode IN (1) And A.Disabled='No' And A.CAPID=S.CAPID and AcctsDrugsMapID IN (6)

Union All

SELECT 2, ItemID, AcctsServicesMapID, CASE WHEN AcctsServicesMapID=7  and ServiceTypeCode NOT IN (1,2) THEN Convert(nvarchar(15),SubCatID) END As ServiceMapID,I.Description 
FROM dbo.AllSetUpServicesView A, ServicesConfigurationSetupView S, ServiceCategoriesView I Where Code=CatID and ServiceTypeCode NOT IN (1,2) And A.Disabled='No' And A.CAPID=S.CAPID and AcctsServicesMapID IN (7)

Union All

SELECT 5, ServiceCode, AcctsDignosisMapID, CASE WHEN AcctsDignosisMapID=8 and ServiceTypeCode IN (2) THEN ClinicCode END As ServiceMapID, V.Description FROM ClinicsView V, 
dbo.ServiceRequestsView A, ServicesConfigurationSetupView S Where AcctsDignosisMapID=8 and ServiceTypeCode IN (2) And A.CAPID=S.CAPID And ClinicCode=SPCode

Union All

SELECT 2, ItemID, AcctsServicesMapID, CASE WHEN AcctsServicesMapID=8 and ServiceTypeCode NOT IN (1,2) THEN ClinicCode END As ServiceMapID, V.Description FROM ClinicServicePlaces C,ClinicsView V, 
dbo.AllSetUpServicesView A, ServicesConfigurationSetupView S Where AcctsServicesMapID=8 and ServiceTypeCode NOT IN (1,2) And Disabled='No' And A.CAPID=S.CAPID And ClinicCode=SPCode and C.ServicePlaceCode=A.ServicePlaceCode

Union All

SELECT 1, ItemID, AcctsDrugsMapID, CASE WHEN AcctsDrugsMapID=8 and ServiceTypeCode IN (1) THEN ClinicCode END As ServiceMapID, V.Description FROM ClinicServicePlaces C,ClinicsView V, 
dbo.AllSetUpServicesView A, ServicesConfigurationSetupView S Where AcctsDrugsMapID=8 and ServiceTypeCode IN (1) And Disabled='No' And A.CAPID=S.CAPID And ClinicCode=SPCode and C.ServicePlaceCode=A.ServicePlaceCode

Union All

SELECT 5, ServiceCode, AcctsDignosisMapID, CASE WHEN AcctsDignosisMapID=9 and ServiceTypeCode IN (2) THEN Convert(nvarchar(15),DirectID) END As ServiceMapID, D.Description FROM DirectoratesView D,
dbo.ServiceRequestsView A, ServicesConfigurationSetupView S Where AcctsDignosisMapID=9 and ServiceTypeCode IN (2) And A.CAPID=S.CAPID And DirectID<>0 and D.ID=DirectID

Union All

SELECT 2, ItemID, AcctsServicesMapID, CASE WHEN AcctsServicesMapID=9 and ServiceTypeCode NOT IN (1,2) THEN Convert(nvarchar(15),DirectID) END As ServiceMapID, D.Description FROM ClinicServicePlaces C, ClinicsView V,DirectoratesView D,
dbo.AllSetUpServicesView A, ServicesConfigurationSetupView S Where AcctsServicesMapID=9 and ServiceTypeCode NOT IN (1,2) And Disabled='No' And A.CAPID=S.CAPID And SPCode<>'' and C.ServicePlaceCode=A.ServicePlaceCode And V.SPCode=ClinicCode And D.ID=DirectID

Union All

SELECT 1, ItemID, AcctsDrugsMapID, CASE WHEN AcctsDrugsMapID=9 and ServiceTypeCode IN (1) THEN Convert(nvarchar(15),DirectID) END As ServiceMapID, D.Description FROM ClinicServicePlaces C, ClinicsView V,DirectoratesView D,
dbo.AllSetUpServicesView A, ServicesConfigurationSetupView S Where AcctsDrugsMapID=9 and ServiceTypeCode IN (1) And Disabled='No' And A.CAPID=S.CAPID And SPCode<>'' and C.ServicePlaceCode=A.ServicePlaceCode And V.SPCode=ClinicCode And D.ID=DirectID

Union All

SELECT 5, ItemID, AcctsDignosisMapID, CASE WHEN AcctsDignosisMapID=12  and ServiceTypeCode=2 THEN A.ItemID END As ServiceMapID, Description 
FROM dbo.AllSetUpServicesView A, ServicesConfigurationSetupView S Where A.Disabled='No' and ServiceTypeCode IN (2) And A.CAPID=S.CAPID and AcctsDignosisMapID IN (12)

Union All

SELECT Distinct 4, SponsorNo, 11 As MapID, SponsorNo, SponsorName FROM dbo.Sponsors S Where S.AcctsBlocked='No'
Union All

SELECT Distinct 3, S.SupplierID, 10 As MapID, S.SupplierID,ContactName FROM dbo.Suppliers S, ReceivedOrders R Where S.Disable='No' And S.Archived='No' And S.SupplierID=R.SupplierID And OrderType=2 And R.Archived='No'

Union All

SELECT  6, ItemID, 13 As MapID, ItemID, Description FROM dbo.AllSetUpServicesView where ItemID IN ('DEPTDRG','DEPTSER','DEPTOTH')
Union All

SELECT ServiceMapTypeID, Code, M.MapTypeID, Code,Description FROM dbo.HamsSpecialAccounts H, HamsQBMappedAcctTypes M where H.ServiceMapTypeID=M.MapElementType And IsActive='Yes' And ServiceMapTypeID IN (7,8,9)
go

