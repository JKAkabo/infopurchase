create FUNCTION GetPatientDeliveryMethod

(@BirthRecordID AS Numeric(18,0)) RETURNS NVARCHAR(MAX)

AS

BEGIN

Declare @BirthComplication NVARCHAR(MAX),@ServiceDescription NVARCHAR(MAX)

Set @BirthComplication=''

DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct Description FROM DeliveryMethods Inner Join (BirthRegistry Inner Join Delivery On BirthRegistry.RecordID=BirthRecordID) On Code=MethodofDeliveryCode Where Delivery.Archived='No' and BirthRegistry.Archived='No' and BirthRegistry.RecordID=@BirthRecordID  Order By Description Asc


OPEN C

FETCH NEXT FROM C INTO @ServiceDescription;

WHILE @@fetch_status = 0

	BEGIN
    
    if @BirthComplication=''  
       Set @BirthComplication=@ServiceDescription 
      
    else        
				   Set @BirthComplication=@BirthComplication + ',' + @ServiceDescription 
														
	  FETCH NEXT FROM C INTO @ServiceDescription;
	       
	END    
                      
    CLOSE C;

	DEALLOCATE C;		  


RETURN @BirthComplication

END
go

