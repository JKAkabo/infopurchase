CREATE PROCEDURE [dbo].[uspUpdateAdmissionCausesGDRGCodes] 
	
AS

DECLARE @GDRGCodeA nvarchar(15),@GDRGCodeC nvarchar(15), @AdmID numeric(18,0),@ChildAgeLimit smallint=12,@PatAge smallint;

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;

set @ChildAgeLimit=12

  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct  RecordID, IsNull(GDRGCodeA,'') As GDRGCodeA, IsNull(GDRGCodeC,'') As GDRGCodeC, AdmAge From Diseases Inner Join AdmissionCauses On Diseases.DisCode = AdmissionCauses.DisCode Order by RecordID Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO @AdmID, @GDRGCodeA, @GDRGCodeC, @PatAge;

  WHILE @@fetch_status = 0
    BEGIN       
       
       if @PatAge<@ChildAgeLimit
          Update AdmissionCauses Set GDRGCode=@GDRGCodeC Where RecordID=@AdmID
       
       else
          Update AdmissionCauses Set GDRGCode=@GDRGCodeA Where RecordID=@AdmID
       
       FETCH NEXT FROM C INTO @AdmID, @GDRGCodeA, @GDRGCodeC, @PatAge;

	END

	CLOSE C;
	
    DEALLOCATE C;

END
go

