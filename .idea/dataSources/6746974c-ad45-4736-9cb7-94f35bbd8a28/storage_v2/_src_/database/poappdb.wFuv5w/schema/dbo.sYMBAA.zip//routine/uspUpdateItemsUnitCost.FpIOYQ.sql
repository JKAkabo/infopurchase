CREATE PROCEDURE [dbo].[uspUpdateItemsUnitCost] 
	
AS

DECLARE @itemID nvarchar(15),@ItemCost numeric(18,6);

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct  ItemID, UnitCost from packs where unit_type='Base' Order by ItemID Asc
  
  OPEN C
  
  FETCH NEXT FROM C INTO @itemID, @ItemCost;

  WHILE @@fetch_status = 0
    BEGIN

       --set @DisCategory=dbo.ItemDesc(@DisCategory);
       
       update Items Set AveUnitCost=@ItemCost where itemID=@itemID

       FETCH NEXT FROM C INTO @itemID, @ItemCost;

	END

	CLOSE C;

	DEALLOCATE C;

END
go

