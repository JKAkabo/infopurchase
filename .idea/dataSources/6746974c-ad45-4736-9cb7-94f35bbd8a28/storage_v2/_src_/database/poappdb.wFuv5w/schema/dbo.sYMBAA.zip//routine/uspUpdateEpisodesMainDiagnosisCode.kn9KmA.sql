CREATE PROCEDURE [dbo].[uspUpdateEpisodesMainDiagnosisCode] 

@StartDate datetime,@EndDate Datetime
	
AS

DECLARE @OPDNo nvarchar(15),@EpisodeID numeric(18,0),@RecordID numeric(18,0),@DisCode nvarchar(15),@DisDesc nvarchar(250),@ClaimICDCode nvarchar(15), @AdmTime datetime

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
SET NOCOUNT ON;
  
  --Consultations
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct Consultations.OPDNo, Consultations.episodeID, Consultations.ConID From Episode Inner Join (Consultations Inner Join ConsultationDiagnoses on Consultations.ConID=ConsultationDiagnoses.ConID) On (Episode.EpisodeID=Consultations.EpisodeID And Episode.OPDNo=Consultations.OPDNo ) Where ClaimDiaCode='' And Consultations.Archived='No' And Episode.Archived='No'  And Consultations.EpisodeID<>0 And Consultations.ReqDate>=@StartDate and  Consultations.ReqDate<=@EndDate Order by Consultations.episodeID
            
  OPEN C
  
  FETCH NEXT FROM C INTO @OPDNo, @EpisodeID, @RecordID       

  WHILE @@fetch_status = 0
    BEGIN
   
     DECLARE D CURSOR FAST_FORWARD FOR SELECT TOP 1  Left(DisDescription,100), Diseases.DisCode, IsNull(ICDCode,'') As ICDCode From Diseases Inner Join ConsultationDiagnoses On Diseases.DisCode=ConsultationDiagnoses.Discode Where ConID=@RecordID Order By Principal Desc, DiaFee Desc, AdultFee Desc, ChildFee Desc
     
     OPEN D
     
     FETCH NEXT FROM D INTO @DisDesc, @DisCode, @ClaimICDCode
     
     WHILE @@fetch_status = 0
     
		 BEGIN
			 update Episode Set ClaimDiaCode=@DisCode, ClaimICDCode=@ClaimICDCode, ClaimDiaDesc=left(@DisDesc,100) Where EpisodeID=@EpisodeID and OPDNo=@OPDNo
		   
			 FETCH NEXT FROM D INTO @DisDesc, @DisCode, @ClaimICDCode
	     
		 END
	     
	 CLOSE D;
     
     DEALLOCATE D;
     
  FETCH NEXT FROM C INTO @OPDNo, @EpisodeID, @RecordID        

	END

	CLOSE C;

	DEALLOCATE C;
	
	--Admissions
  DECLARE C CURSOR FAST_FORWARD FOR SELECT Distinct Admissions.OPDNo, Admissions.episodeID, Admissions.AdmTime From Episode Inner Join ( Admissions Inner Join AdmissionCauses on (Admissions.OPDNo=AdmissionCauses.OPDNo and Admissions.AdmTime=AdmissionCauses.AdmTime)) On (Episode.EpisodeID=Admissions.EpisodeID And Episode.OPDNo=Admissions.OPDNo ) Where ClaimDiaCode='' And Episode.EndEpisode=DisDate And Admissions.Archived='No'  And Episode.Archived='No'  And Admissions.EpisodeID<>0 And DisDate>=@StartDate and  DisDate<=@EndDate And DisDate Is Not Null And Admissions.Discharged='Yes' Order by Admissions.episodeID
            
  OPEN C
  
  FETCH NEXT FROM C INTO @OPDNo, @EpisodeID, @AdmTime       

  WHILE @@fetch_status = 0
    BEGIN
   
     DECLARE D CURSOR FAST_FORWARD FOR SELECT TOP 1  Left(DisDescription,100), Diseases.DisCode, IsNull(ICDCode,'') As ICDCode From Diseases Inner Join AdmissionCauses On Diseases.DisCode=AdmissionCauses.Discode Where AdmTime=@AdmTime And OPDNo=@OPDNo Order By Principal Desc, DiaFee Desc, AdultFee Desc, ChildFee Desc
     
     OPEN D
     
     FETCH NEXT FROM D INTO @DisDesc, @DisCode, @ClaimICDCode
     
     WHILE @@fetch_status = 0
     
		 BEGIN
			 update Episode Set ClaimDiaCode=@DisCode, ClaimICDCode=@ClaimICDCode, ClaimDiaDesc=left(@DisDesc,100) Where EpisodeID=@EpisodeID and OPDNo=@OPDNo
		   
			 FETCH NEXT FROM D INTO @DisDesc, @DisCode, @ClaimICDCode
	     
		 END
	     
	 CLOSE D;
     
     DEALLOCATE D;
     
  FETCH NEXT FROM C INTO @OPDNo, @EpisodeID, @AdmTime        

	END

	CLOSE C;

	DEALLOCATE C;


END
go

