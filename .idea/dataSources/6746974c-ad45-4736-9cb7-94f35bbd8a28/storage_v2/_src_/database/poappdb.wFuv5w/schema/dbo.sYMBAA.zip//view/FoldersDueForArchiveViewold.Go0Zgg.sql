create VIEW [dbo].[FoldersDueForArchiveViewold] as select null as Col1
go

