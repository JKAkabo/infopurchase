CREATE VIEW [dbo].[TestElementsView]

AS

SELECT Distinct TestElements.IsActive, LabTestElements.RecordID as LabTestElementID, 
TestID, TestElements.Description, TestElements.Code As ElementID, UnitMeasure, ResultValueType, 
ValueOptional, ViewType, ElementOrder, ServiceType as TestDescription, CatID, SubCatID, 
RTRIM(LTRIM(convert(nvarchar(25), TestElements.Code))) As Code,LabTestElements.IsActive As ElementIsActive 
From Service_Types, TestElements, LabTestElements where TestElements.Code=LabTestElements.Code and
ServiceCode=TestID
go

