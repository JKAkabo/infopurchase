CREATE VIEW [dbo].[DiagnosticsRequestsView]

AS

--SELECT Distinct Service_Requests.*, Description as ServiceDescription, ServiceTypeCode, CatID, SubCatID,'**' As CAPID From AllSetUpServicesView Inner Join Service_Requests On ItemID=ServiceCode Where Archived='No'

SELECT S.*, A.Description as ServiceDescription, P.Description as ServicePlace,I.StatusCode As PatStatusCode,U.UserID As DoctorName,Y.Description As ServiceType,Q.UserID As RequestedBy,
ServiceTypeCode, A.CatID, A.SubCatID,'**' As CAPID, T.Description as PmtType, C.Description As Clinic,I.Weight,Nationality ,U.UserCategory,H.Description As PatCategory,
CASE WHEN U.UserCategory IN ('DOCTORS','DOCTOR','MEDICAL ASSISTANTS','PHYSICIAN ASSISTANTS','MEDICAL ASSISTANT','PHYSICIAN ASSISTANT','LOCUM DOCTORS','MIDWIVES','MIDWIVE') OR RequestType<>'INTERNAL' THEN RequesterID Else '' End As RequestedDoc,
CASE WHEN ServiceTypeCode =11  THEN ISNULL((Select TOP 1 RecordID From LabTests Where Archived='No' And RequestID=S.RecordID),0) 
WHEN ServiceTypeCode =12  THEN ISNULL((Select TOP 1 XrayTests.RecordID From XrayTests Where Archived='No' And XrayTests.RecordID=S.RecordID and S.ServiceCode=XrayTests.ServiceCode),0) 
WHEN ServiceTypeCode IN (13,14) THEN ISNULL((Select TOP 1 UltrasoundScan.RecordID From UltrasoundScan Where Archived='No' And UltrasoundScan.RecordID=S.RecordID and S.ServiceCode=UltrasoundScan.ServiceCode),0) Else 0 End As TestID,
V.Description As PatStatus,LastName,  MiddleName,  Surname, G.Description As Gender, Title, GenderCode, CONVERT(Date, TDOB) AS DOB, CONVERT(date,getdate()) as TodayDate,
CASE WHEN Year(CONVERT(Date, TDOB))=Year(getdate()) Then 0 WHEN Month(getdate())>Month(CONVERT(Date, TDOB)) Or (Month(getdate())=Month(CONVERT(Date, TDOB)) And day(getdate())>=day(CONVERT(Date, TDOB))) Then 
DateDiff(M,  CONVERT(Date, TDOB), getdate())/12 Else DateDiff(YYYY,  CONVERT(Date, TDOB), getdate()) - 1 END As PatientAge
From AllSetUpServicesView A, Service_Requests S, ServicePlacesView P, PaymentTypessView T, PatientCategoryView H, ServiceTypes Y,
ClinicsView C, PatientsInfo I, GenderGroups G, PatientStatusView V, UsersView U, UsersView Q Where S.Archived='No' and H.Code=S.BillCategoryCode and Q.UserNo=S.UserID
and ItemID=ServiceCode and P.Code=ServicePlaceCode and T.Code=S.PmtTypeCode and C.SPCode=ClinicCode and U.UserNo=RequesterID  and Y.Code=ServiceTypeCode
and G.Code=GenderCode and I.OPDNo=S.OPDNo and I.StatusCode=V.Code and ServiceTypeCode IN (11,12,13,14)
go

