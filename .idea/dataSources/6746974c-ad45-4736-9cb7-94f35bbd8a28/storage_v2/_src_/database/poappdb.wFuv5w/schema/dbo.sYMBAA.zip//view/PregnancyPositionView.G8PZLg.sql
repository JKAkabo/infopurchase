CREATE VIEW [dbo].[PregnancyPositionView]

AS

SELECT  Description, Code FROM dbo.PregnancyPosition

Union

SELECT  '', 0  FROM dbo.Hosp_Info
go

