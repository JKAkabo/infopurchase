create VIEW [dbo].[ServicesUnPaidRevenueView]

AS

SELECT Distinct DrugCode As ServiceCode, 1 As ServiceTypeCode, PmtTypeCode, StoresID As SerPlaceCode ,UnitPrice AS UnitFee, QtyPrescribed As ServiceQty, QtyGiven, Prescriptions.PresDate As ReqDate, Prescriptions.PresTime As Reqtime, PresType As RequestType, OPDNo, StatusCode, DirectID, '**' As CapID, ServerTime, Pat_No, ClinicCode, PatAge, BillCategoryCode, UserID, SponsorNo, 'No' As CoPayed FROM Prescriptions Where  DrugFlag='0' And Archived='No' and PresType='INTERNAL' and RecordID NOT IN (Select Prescriptions.RecordID FROM Prescriptions Inner Join ServiceLinePayments On (DrugCode=ServiceCode and Prescriptions.RecordID=ServiceID) Where CoPayed='No')

UNION ALL

SELECT Distinct ServiceCode, ServiceTypeCode, PmtTypeCode, SerPlaceCode , Service_Fee,  ServiceQty, ServiceQty, ReqDate, ReqTime, RequestType, OPDNo, StatusCode, DirectID, '**' As CapID, ServerTime, Pat_No, ClinicCode, PatAge, BillCategoryCode,Service_Requests.UserID, SponsorNo, 'No' As CoPayed FROM AllSetUpServicesView Inner Join Service_Requests On ItemID=Service_Requests.ServiceCode Where Archived='No' And RequestType='INTERNAL'  and RecordID NOT IN (Select Service_Requests.RecordID FROM Service_Requests Inner Join ServiceLinePayments On (Service_Requests.ServiceCode=ServiceLinePayments.ServiceCode and Service_Requests.RecordID=ServiceID) Where CoPayed='No')

UNION ALL

SELECT Distinct DrugCode As ServiceCode, 1 As ServiceTypeCode, CoPayPmtTypeCode, StoresID As SerPlaceCode , (CoPayFee - UnitPrice) AS UnitFee, QtyPrescribed As ServiceQty, QtyGiven, Prescriptions.PresDate As ReqDate, Prescriptions.PresTime As Reqtime, PresType As RequestType, OPDNo, StatusCode, DirectID, '**' As CapID, ServerTime, Pat_No, ClinicCode, PatAge, CoPayBillCategoryCode, UserID, CoPaySponsorNo, 'Yes' As CoPayed FROM Prescriptions Where DrugFlag='0' And Archived='No' and CoPayBillCategoryCode<>0 and CoPayPmtTypeCode<>0  and CoPayFee>UnitPrice and PresType='INTERNAL' and RecordID NOT IN (Select Prescriptions.RecordID FROM Prescriptions Inner Join ServiceLinePayments On (DrugCode=ServiceCode and Prescriptions.RecordID=ServiceID) Where CoPayed='Yes')


UNION  ALL

SELECT Distinct ServiceCode, ServiceTypeCode, CoPayPmtTypeCode, SerPlaceCode , (CoPayFee - Service_Fee) AS Service_Fee,  ServiceQty, ServiceQty, ReqDate, ReqTime, RequestType, OPDNo, StatusCode, DirectID, '**' As CapID, ServerTime, Pat_No, ClinicCode, PatAge, CoPayBillCategoryCode,UserID, CoPaySponsorNo, 'Yes' As CoPayed FROM AllSetUpServicesView Inner Join Service_Requests On ItemID=Service_Requests.ServiceCode Where Archived='No' And RequestType='INTERNAL' and CoPayBillCategoryCode<>0 and CoPayPmtTypeCode<>0  and CoPayFee>Service_Fee  and RecordID NOT IN (Select Service_Requests.RecordID FROM Service_Requests Inner Join ServiceLinePayments On (Service_Requests.ServiceCode=ServiceLinePayments.ServiceCode and Service_Requests.RecordID=ServiceID) Where CoPayed='Yes')
go

