-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[upsGetRequisitionItems] 
	-- Add the parameters for the stored procedure here

	@ItemDescription nvarchar(250) ,@OrderStore nvarchar(15) ,@IssueStore nvarchar(15),@itemType tinyint =0,
	@itemUnitType tinyint =1,@item_ClassCode smallint=0,@StockTransType tinyint=1
	
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

--ItemsUOMView.UnitCode=items.IssueUnitCode
	
Select Distinct Items.Description, U.TypeCode, ItemTypeCode, ManufacturerCode, PresentationCode,Expirable,Items.DefaultMethodCode,PresQuanityPerIssueUnit,PresSpecType, AllowCoPay,ItemManufacturers.Description as ItemManufacturer,ItemTypes.Description As ItemType,ItemPresentations.Description As ItemPresentation,
U.IssueUnitQuantity,PresUnitQuantity,PresUnitCode,Items.AgeGroupCode,Items.GenderCode, U.UnitCode As IssueUnitCode, U.UOM As Unit_Name , Items.ItemID, PresLevel, StockType, items.AveUnitCost As UnitCost, IsNull(Items.ItemNo,'') As ItemNo,Demand,ReorderLevel,EOQ,MinLevel,MaxLevel,LeadTime,ItemCost, 
Isnull((Select sum(StockLevel) From StockedItemsView Where ItemCode=Items.ItemID And ServicePlaceCode=@IssueStore And (((IsDate(ExpiryDate)=1 And ItemExpirable ='Yes') And ((Year(ExpiryDate)> Year(Getdate())) OR (Year(ExpiryDate)= Year(Getdate()) And Month(ExpiryDate)>= Month(Getdate())))) Or (IsDate(ExpiryDate)=0 OR ItemExpirable ='No')) Group By ItemCode),0) As IssuerStockLevel, 
Isnull((Select sum(StockLevel) From StockedItemsView Where ItemCode=Items.ItemID And ServicePlaceCode=@OrderStore  And ServicePlaceCode=S.Code And (IssueUnitType=U.TypeCode OR IssueUnitType=0) And (((IsDate(ExpiryDate)=1 And ItemExpirable ='Yes') And ((Year(ExpiryDate)> Year(Getdate())) OR (Year(ExpiryDate)= Year(Getdate()) And Month(ExpiryDate)>= Month(Getdate())))) Or (IsDate(ExpiryDate)=0 OR ItemExpirable ='No')) Group By ServicePlaceCode),0) As OrdererStockLevel,
Isnull((Select TOP 1 MaxLevel From StockInventoryParametersView S Where S.ItemID=Items.ItemID And S.StoreID=@OrderStore),0) AS OrderStoreMaxLevel,Isnull((Select TOP 1 MinLevel From StockInventoryParametersView S Where S.ItemID=Items.ItemID And S.StoreID=@OrderStore),0) AS OrderStoreMinLevel
From ItemsUOMView U , Items, ItemManufacturers, ItemTypes, ItemPresentations, Service_Places S, StockInventoryParametersView Where U.ItemCode = Items.ItemID and Items.Description Like @ItemDescription + '%' And ((ItemTypeCode=@ItemType And @ItemType<>0) OR (@ItemType=0)) And  ((ItemClassCode=@item_ClassCode And @item_ClassCode<>0) OR (@item_ClassCode=0)) 
And ItemTypes.Code=ItemTypeCode And ItemPresentations.Code=PresentationCode  And ItemManufacturers.Code=ManufacturerCode  And Items.Disabled ='No' and S.Code = @IssueStore And StockInventoryParametersView.ItemID=Items.ItemID And S.Code=StockInventoryParametersView.StoreID and StockInventoryParametersView.StoreID=@IssueStore and (S.IssueUnitID=U.TypeCode OR S.IssueUnitID=0) Order by Items.Description Asc  
 
 
END
go

