CREATE VIEW [dbo].[AccountCashDebitTransactionsView]

AS
--SERVICES AND DRUGS CASH PAYMENTS
SELECT
	
SUM(AmtPaid) as TransAmt,R.PmtDate As TransDate,1 AS TransTypeID,
ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctsName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=1 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As PostType
, '' As TransID

FROM 
BillsPaid R WHERE R.AmtPaid >0 And R.Archived ='No' and R.ReceiptNo NOT IN (SELECT D.ReceiptNo FROM Deposits D WHERE Archived='No')
			
GROUP BY 

R.PmtDate

UNION ALL

--CASH DEPOSITS
SELECT
	
SUM(AmtPaid) as PaidAmt,R.PmtDate,3 AS TransTypeID,
ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctsName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeID=11 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As PostType
, '' As TransID

FROM 
BillsPaid R WHERE R.AmtPaid >0 And R.Archived ='No' and R.ReceiptNo IN (SELECT D.ReceiptNo FROM Deposits D WHERE Archived='No')
			
GROUP BY 

R.PmtDate
	
UNION ALL

-- IOUS
SELECT
	
SUM(R.IOUAmt) as PaidAmt,R.PmtDate,8 AS TransTypeID,
ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=8 AND J.AcctTypeID=9 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=8 AND J.AcctTypeID=9 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctsName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=8 AND J.AcctTypeID=9 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As PostType

, '' As TransID

FROM 
BillsPaid R, IOUS I WHERE R.IOUAmt >0 And R.Archived ='No' and R.ReceiptNo=I.ReceiptNo
			
GROUP BY 

R.PmtDate

UNION ALL

-- DISCOUNTS
SELECT
	
SUM(R.DisAmt) as PaidAmt,R.PmtDate,9 AS TransTypeID,
ISNULL((Select TOP 1 J.AcctCode From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=9 AND J.AcctTypeID=2 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=9 AND J.AcctTypeID=2 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As AcctsName, 

ISNULL((Select TOP 1 UPPER(T.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=9 AND J.AcctTypeID=2 And A.Code=J.AcctCode And T.Code=J.AcctPostType And J.AcctPostType=1),'') As PostType

, '' As TransID

FROM 
BillsPaid R WHERE R.DisAmt >0 And R.Archived ='No'
			
GROUP BY 

R.PmtDate

UNION ALL

--SERICES REFUND
SELECT
	
SUM(S.Service_Fee *S.RefundQty) as PaidAmt,S.RefundDate,J.TransTypeID, J.AcctCodeJE AS AcctsCode,UPPER(A.Description) as AcctsName,
'DEBIT' as PostType, '' As TransID
	      	
FROM 
	
ServicePlacesView P,AllSetUpServicesView R,AccountChartServicesMapping M, AccountChartSetup A,
RefundServiceLines S, AccountsChartJournalMapping J, ServicesConfigurationSetupView V
	
WHERE 

S.PmtTypeCode =1 AND R.ItemID=S.ServiceCode AND P.Code =R.ServicePlaceCode AND J.TransTypeID=1 
And A.Code=J.AcctCodeJE  And J.TransTypeID=M.PostingType AND S.PmtTypeCode=1 And J.AcctJEPostType=2
And A.Code=M.AccountChartCode And J.AcctCodeJE=M.AccountChartCode And M.ServiceTypeID=2
And A.Code=M.AccountChartCode And J.AcctJEPostType=2  And ((V.AcctsServicesMapID=4 and M.ServiceID = R.ServicePlaceCode) OR
(V.AcctsServicesMapID=3 and M.ServiceID = R.ServiceTypeCode) OR (V.AcctsServicesMapID=2 and M.ServiceID = R.ItemID))
			
GROUP BY 

J.AcctCodeJE,UPPER(A.Description),J.TransTypeID,S.RefundDate


UNION ALL

--DRUGS REFUND
SELECT
	
SUM(S.Service_Fee *S.RefundQty) as PaidAmt,S.RefundDate,J.TransTypeID, J.AcctCodeJE AS AcctsCode,UPPER(A.Description) as AcctsName,
'DEBIT' as PostType, '' As TransID
	      	
FROM 
	
ServicePlacesView P,Prescriptions R,AccountChartServicesMapping M, AccountChartSetup A,
RefundServiceLines S, AccountsChartJournalMapping J, ServicesConfigurationSetupView V
	
WHERE 

S.PmtTypeCode =1 AND R.DrugCode=S.ServiceCode And R.RecordID=S.ServiceID AND P.Code =R.StoresID AND J.TransTypeID=1 
And A.Code=J.AcctCodeJE  And J.TransTypeID=M.PostingType AND S.PmtTypeCode=1 And J.AcctJEPostType=2
And A.Code=M.AccountChartCode And J.AcctCodeJE=M.AccountChartCode AND V.AcctsDrugsMapID<>0  And M.ServiceTypeID=1
And A.Code=M.AccountChartCode And J.AcctCodeJE=M.AccountChartCode  AND M.ServiceTypeID=1 And ((V.AcctsDrugsMapID=4 and M.ServiceID = R.StoresID) OR
(V.AcctsDrugsMapID=3 and M.ServiceID = 1) OR (V.AcctsDrugsMapID=2 and M.ServiceID = R.DrugCode ))
			
GROUP BY 

J.AcctCodeJE,UPPER(A.Description),J.TransTypeID,S.RefundDate

UNION ALL

--DEPOSITS REFUND
SELECT
	
SUM(R.AmtPaid-L.RefundAmt) as PaidAmt,R.PmtDate,7 AS TransTypeID,
ISNULL((Select TOP 1 J.AcctCodeJE From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctsName, 

'DEBIT' As PostType, '' As TransID

FROM 

BillsRefunds R, ReceiptNoRefundServiceLinesView L WHERE  R.AmtPaid-L.RefundAmt >0 And R.Archived ='No'  and R.ReceiptNo=L.RefundReceiptNo
			
GROUP BY 

R.PmtDate

UNION ALL

--DEPOSITS REFUND --2
SELECT
	
SUM(R.AmtPaid) as PaidAmt,R.PmtDate,7 AS TransTypeID,
ISNULL((Select TOP 1 J.AcctCodeJE From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctCode, 

ISNULL((Select TOP 1 UPPER(A.Description) From AccountChartSetup A,AccountPostingType T,AccountsChartJournalMapping J 
Where J.TransTypeID=3 AND J.AcctTypeIDJE=8 And A.Code=J.AcctCodeJE And T.Code=J.AcctJEPostType And J.AcctJEPostType=2),'') As AcctsName, 

'DEBIT' As PostType, '' As TransID

FROM 

BillsRefunds R WHERE  R.AmtPaid>0 And R.Archived ='No' AND R.ReceiptNo NOT IN (Select L.RefundReceiptNo from RefundServiceLines L)
			
GROUP BY 

R.PmtDate
go

