CREATE VIEW [dbo].[BillsPaidView]
AS
SELECT ReceiptNo, PmtDate, PmtTime, PmtModeCode, PmtTypeCode, PayerType, TAmtPaid As PaidAmt, UserID, OPDNo As PayeeID, Isnull((Select SUM(R.AmtPaid) From BillsRefunds R Where B.UserID=R.UserID and B.ReceiptNo=R.BillReceiptNo and B.OPDNo=R.OPDNo),0) As RefundAmt, 
Pat_No As PayerNo, TBill, CAP_ID, DepAmt,DepAmtUsed,BillApprox,BillOut,IouAmtPaid,IOUAmt,RefAmtRequested,RefAmt, ServerTime,Isnull((Select SUM(R.DollarAmtPaid) From BillsRefunds R Where B.UserID=R.UserID and R.BillReceiptNo=B.ReceiptNo and R.OPDNo=B.OPDNo),0) As CreditRefundAmt,  
LEFT(BankName,100) As BankName, MMAmt,MMNetwork,MMTken,MMWalletNo,MMTransID  FROM dbo.BillsPaid B Where Archived='No'

Union All

Select ReceiptNo, PmtDate, PmtTime, PmtModeCode, 2 As PmtTypeCode, 'S' As PayerType, AmtPaid As PaidAmt, ReceiverID As UserID, SponsorNo As PayeeID, 0 As RefundAmt,
 SponsorNo As PayerNo, AmtDue As TBill, CAP_ID, 0,0,0,0,0,0,0,0, ServerTime,0,'', 0,'','','','' From Sponsors_Payments Where Archived='No'
go

