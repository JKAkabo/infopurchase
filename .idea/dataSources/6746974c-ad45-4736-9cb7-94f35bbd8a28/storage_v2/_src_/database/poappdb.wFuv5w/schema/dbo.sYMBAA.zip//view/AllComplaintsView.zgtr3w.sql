CREATE VIEW [dbo].[AllComplaintsView]

AS

SELECT Distinct P.Complaints, P.DoctorID AS UserID, C.OPDNo, C.Pat_No, ClinicCode, 2 As PatStatus, C.ConDate As AttDate, C.ConTime As AttTime, C.ConID As RecordID, 
'Date=' + CONVERT(nvarchar(50),C.ConTime) + ' | ' +  'Complaint=' + P.Complaints As Description
FROM Consultations C,PatientPresentingComplaints P Where Cancelled='No' AND C.ConID=P.PatConID and P.PatStatus=2

Union ALL

SELECT Distinct P.Complaints, I.Doctor As UserID, I.OPDNo, I.Pat_No, A.ClinicCode, 3 As PatStatus, I.ConDate As AttDate, I.ConTime As AttTime, I.RecordID As RecordID, 
'Date=' + CONVERT(nvarchar(50),I.ConTime)  + ' | ' +   'Complaint=' + P.Complaints
FROM Admissions A, PatientPresentingComplaints P, InPatientConsultations I Where Cancelled='No' AND A.RecordID=I.AdmID and I.OPDNo=A.OPDNo  and I.RecordID=P.PatConID and PatStatus=3


--SELECT Distinct Complaint, Consultations.Doctor AS UserID, Consultations.OPDNo, Consultations.Pat_No, ClinicCode, 2 As PatStatus, Consultations.ConDate As AttDate, Consultations.ConTime As AttTime, Consultations.ConID As RecordID, 
--'Date=' + CONVERT(nvarchar(50),ConComplaints.ConTime) + ' | ' +  'Complaint=' + Complaint As Description
--FROM Consultations,ConComplaints Where Cancelled='No' AND Consultations.ConID=ConComplaints.ConID and Isnumeric(Complaint)=0

--Union ALL

--SELECT Distinct Complaint, Admissions.DoctorID As UserID, Admissions.OPDNo, Admissions.Pat_No, ClinicCode, 3 As PatStatus, Admissions.AdmDate As AttDate, Admissions.AdmTime As AttTime, Admissions.RecordID As RecordID, 
--'Date=' + CONVERT(nvarchar(50),InPatientComplaints.AdmTime)  + ' | ' +   'Complaint=' + Complaint
--FROM Admissions, InPatientComplaints Where Cancelled='No' AND Admissions.RecordID=InPatientComplaints.AdmID  and Isnumeric(Complaint)=0
go

