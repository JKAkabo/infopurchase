--SET ANSI_PADDING ON
--SET ANSI_WARNINGS ON
--SET CONCAT_NULL_YIELDS_NULL ON
--SET NUMERIC_ROUNDABORT OFF
--SET QUOTED_IDENTIFIER ON
--SET ARITHABORT ON
--SET ANSI_NULLS ON

--GO

CREATE VIEW [dbo].[AllSetUpServicesView] 
--WITH SCHEMABINDING

AS

SELECT Distinct left(dbo.Items.Description,100) As Description, dbo.Items.ItemID, 1 As ServiceTypeCode, 2 As PmtType, OrderID As ServicePlaceCode , CashPrice AS CashFee, CreditPrice AS CreditFee, NGPrice AS NGFee,NHISPrice AS NHISFee, FFee, NHISCode as ItemCode, NHISCode as AdultCode, NHISCode as ChildCode,NHIS,'No' AS IsMorgue,1 As MinDay,1 As MaxDay, 6 As FeeFreq, Disabled, ItemTypeCode As ServiceBillType, ItemTypeCode As CatID, ItemClassCode as SubCatID, '**' As CAPID, NHIACoPayFee,ItemStockType.Description AS DeliveryType FROM dbo.Items, dbo.ItemStockType, dbo.Packs Where ItemStockType.Code=StockType and dbo.Items.ItemID=dbo.Packs.ItemID and  dbo.Items.ItemID<>'' and dbo.ItemStockType.Description<>''

UNION

SELECT Distinct left(FeeType,100) As Description, FEEID, 6 As ServiceTypeCode, PmtType, MorID  As ServicePlaceCode, CashFee, CreditFee, NGFee, NHISFee, FFee, ServiceCode as ItemCode, ServiceCode as AdultCode, ServiceCode as ChildCode,NHIS,'Yes' AS IsMorgue,MinDay,MaxDay, PmtFreq,Disabled, 2 As ServiceBillType, 0 As CatID, 0 as SubCatID, '**' As CAPID, 0 As NHIACoPayFee,'INTERNAL' AS DeliveryType  FROM MORTUARYFEES Where FEEID<>'' and FEETYPE<>''

UNION

SELECT Distinct left(FeeType,100) As Description, FEEID, ServiceTypeCode,PmtType, WardID  As ServicePlaceCode,  CashFee, CreditFee, NGFee, NHISFee, FFee, ServiceCode as ItemCode, ServiceCode as AdultCode, ServiceCode as ChildCode,NHIS,'No' AS IsMorgue,1 As MinDay,1 As MaxDay, PmtFreq,Disabled, 2 As ServiceBillType, 0 As CatID, 0 as SubCatID, '**' As CAPID, 0 AS NHIACoPayFee,'INTERNAL' AS DeliveryType  FROM WARDFEES Where FEEID<>'' and FEETYPE<>''

UNION

SELECT Distinct left(SERVICETYPE,100) As Description, SERVICECODE, ServiceTypeCode, PmtType, ServicePlaceCode ,CashPrice AS CashFee, CreditPrice AS CreditFee,  NGFee, NHISPrice As NHISFee, FFee, IsNull(Fee_Category,'') as ItemCode, ISNULL(GDRGCodeA,'') as AdultCode, ISNULL(GDRGCodeC,'') as ChildCode, NHIS,'No' AS IsMorgue,1 As MinDay,1 As MaxDay,6 As FeeFreq, Disabled, 2 As ServiceBillType,  CatID, SubCatID, '**' As CAPID, NHIACoPayFee,DeliveryType  FROM Service_Types Where SERVICECODE<>'' and SERVICETYPE<>''

UNION

SELECT Distinct left(DisDescription,100) As Description, DisCode, 2 As ServiceTypeCode, PmtType, '' AS ServicePlaceCode ,0  AS CashFee, 0 AS CreditFee, 0 As NGFee, 0  As NHISFee, 0 As FFee, '' as ItemCode, ISNULL(GDRGCodeA,'') as AdultCode, ISNULL(GDRGCodeC,'') as ChildCode, NHIACovered As NHIS,'No' AS IsMorgue,1 As MinDay,1 As MaxDay,6 As FeeFreq,Disabled, 2 As ServiceBillType, ClassCode As CatID, 0 as SubCatID, '**' As CAPID, 0 As NHIACoPayFee,'INTERNAL' AS DeliveryType   FROM Diseases Where DisCode<>'' 

UNION

SELECT TOP 1 '' As Description, '' As SERVICECODE, 4 As ServiceTypeCode, 2 As PmtType, '' As ServicePlaceCode ,0 AS CashFee, 0 AS CreditFee, 0 As NGFee, 0 As NHISFee, 0 As FFee, '' as ItemCode, '' as AdultCode, '' as ChildCode, NHIS,'No' AS IsMorgue,1 As MinDay,1 As MaxDay, 6 As FeeFreq, 'Yes' As Disabled, 2 As ServiceBillType,  CatID, SubCatID, '**' As CAPID, 0 As NHIACoPayFee,'INTERNAL' AS DeliveryType  FROM Service_Types Where SERVICECODE<>'' and SERVICETYPE<>''

UNION

SELECT TOP 1 'DRUGS DEPOSIT' As Description, 'DEPTDRG' As SERVICECODE, 1 As ServiceTypeCode, 2 As PmtType, 'DEPTDRG' As ServicePlaceCode ,0 AS CashFee, 0 AS CreditFee, 0 As NGFee, 0 As NHISFee, 0 As FFee, '' as ItemCode, '' as AdultCode, '' as ChildCode, NHIS,'No' AS IsMorgue,1 As MinDay,1 As MaxDay, 6 As FeeFreq, 'Yes' As Disabled, 2 As ServiceBillType,  CatID, SubCatID, '**' As CAPID, 0 As NHIACoPayFee,'INTERNAL' AS DeliveryType  FROM Service_Types Where SERVICECODE<>'' and SERVICETYPE<>''
UNION

SELECT TOP 1 'SERVICES DEPOSIT' As Description, 'DEPTSER' As SERVICECODE, 10 As ServiceTypeCode, 2 As PmtType, 'DEPTSER' As ServicePlaceCode ,0 AS CashFee, 0 AS CreditFee, 0 As NGFee, 0 As NHISFee, 0 As FFee, '' as ItemCode, '' as AdultCode, '' as ChildCode, NHIS,'No' AS IsMorgue,1 As MinDay,1 As MaxDay, 6 As FeeFreq, 'Yes' As Disabled, 2 As ServiceBillType,  CatID, SubCatID, '**' As CAPID, 0 As NHIACoPayFee,'INTERNAL' AS DeliveryType  FROM Service_Types Where SERVICECODE<>'' and SERVICETYPE<>''
UNION

SELECT TOP 1 'OTHER DEPOSIT' As Description, 'DEPTOTH' As SERVICECODE, 10 As ServiceTypeCode, 2 As PmtType, 'DEPTOTH' As ServicePlaceCode ,0 AS CashFee, 0 AS CreditFee, 0 As NGFee, 0 As NHISFee, 0 As FFee, '' as ItemCode, '' as AdultCode, '' as ChildCode, NHIS,'No' AS IsMorgue,1 As MinDay,1 As MaxDay, 6 As FeeFreq, 'Yes' As Disabled, 2 As ServiceBillType,  CatID, SubCatID, '**' As CAPID, 0 As NHIACoPayFee,'INTERNAL' AS DeliveryType  FROM Service_Types Where SERVICECODE<>'' and SERVICETYPE<>''
UNION

SELECT TOP 1 'UNUSED DRUGS DEPOSIT' As Description, 'UNDEPTDRG' As SERVICECODE, 1 As ServiceTypeCode, 2 As PmtType, 'UNDEPTDRG' As ServicePlaceCode ,0 AS CashFee, 0 AS CreditFee, 0 As NGFee, 0 As NHISFee, 0 As FFee, '' as ItemCode, '' as AdultCode, '' as ChildCode, NHIS,'No' AS IsMorgue,1 As MinDay,1 As MaxDay, 6 As FeeFreq, 'Yes' As Disabled, 2 As ServiceBillType,  CatID, SubCatID, '**' As CAPID, 0 As NHIACoPayFee,'INTERNAL' AS DeliveryType  FROM Service_Types Where SERVICECODE<>'' and SERVICETYPE<>''
UNION

SELECT TOP 1 'UNUSED SERVICES DEPOSIT' As Description, 'UNDEPTSER' As SERVICECODE, 10 As ServiceTypeCode, 2 As PmtType, 'UNDEPTSER' As ServicePlaceCode ,0 AS CashFee, 0 AS CreditFee, 0 As NGFee, 0 As NHISFee, 0 As FFee, '' as ItemCode, '' as AdultCode, '' as ChildCode, NHIS,'No' AS IsMorgue,1 As MinDay,1 As MaxDay, 6 As FeeFreq, 'Yes' As Disabled, 2 As ServiceBillType,  CatID, SubCatID, '**' As CAPID, 0 As NHIACoPayFee,'INTERNAL' AS DeliveryType  FROM Service_Types Where SERVICECODE<>'' and SERVICETYPE<>''
UNION

SELECT TOP 1 'BILLS APPROMIXATION' As Description, 'BILLAPPR' As SERVICECODE, 10 As ServiceTypeCode, 2 As PmtType, 'BILLAPPR' As ServicePlaceCode ,0 AS CashFee, 0 AS CreditFee, 0 As NGFee, 0 As NHISFee, 0 As FFee, '' as ItemCode, '' as AdultCode, '' as ChildCode, NHIS,'No' AS IsMorgue,1 As MinDay,1 As MaxDay, 6 As FeeFreq, 'Yes' As Disabled, 2 As ServiceBillType,  CatID, SubCatID, '**' As CAPID, 0 As NHIACoPayFee,'INTERNAL' AS DeliveryType  FROM Service_Types Where SERVICECODE<>'' and SERVICETYPE<>''
UNION

SELECT TOP 1 'OUTSTANDING BILLS PAYMENT' As Description, 'OUTBILLPMT' As SERVICECODE, 10 As ServiceTypeCode, 2 As PmtType, 'OUTBILLPMT' As ServicePlaceCode ,0 AS CashFee, 0 AS CreditFee, 0 As NGFee, 0 As NHISFee, 0 As FFee, '' as ItemCode, '' as AdultCode, '' as ChildCode, NHIS,'No' AS IsMorgue,1 As MinDay,1 As MaxDay, 6 As FeeFreq, 'Yes' As Disabled, 2 As ServiceBillType,  CatID, SubCatID, '**' As CAPID, 0 As NHIACoPayFee,'INTERNAL' AS DeliveryType  FROM Service_Types Where SERVICECODE<>'' and SERVICETYPE<>''
UNION

SELECT TOP 1 'SERVICES OUTSTANDING BILLS PAYMENT' As Description, 'OUTBILLPMT1' As SERVICECODE, 10 As ServiceTypeCode, 2 As PmtType, 'OUTBILLPMT1' As ServicePlaceCode ,0 AS CashFee, 0 AS CreditFee, 0 As NGFee, 0 As NHISFee, 0 As FFee, '' as ItemCode, '' as AdultCode, '' as ChildCode, NHIS,'No' AS IsMorgue,1 As MinDay,1 As MaxDay, 6 As FeeFreq, 'Yes' As Disabled, 2 As ServiceBillType,  CatID, SubCatID, '**' As CAPID, 0 As NHIACoPayFee,'INTERNAL' AS DeliveryType  FROM Service_Types Where SERVICECODE<>'' and SERVICETYPE<>''
UNION

SELECT TOP 1 'SPONSORS BILLS PAYMENT' As Description, 'SPSBILLPMT' As SERVICECODE, 10 As ServiceTypeCode, 2 As PmtType, 'SPSBILLPMT' As ServicePlaceCode ,0 AS CashFee, 0 AS CreditFee, 0 As NGFee, 0 As NHISFee, 0 As FFee, '' as ItemCode, '' as AdultCode, '' as ChildCode, NHIS,'No' AS IsMorgue,1 As MinDay,1 As MaxDay, 6 As FeeFreq, 'Yes' As Disabled, 2 As ServiceBillType,  CatID, SubCatID, '**' As CAPID, 0 As NHIACoPayFee,'INTERNAL' AS DeliveryType  FROM Service_Types Where SERVICECODE<>'' and SERVICETYPE<>''
go

