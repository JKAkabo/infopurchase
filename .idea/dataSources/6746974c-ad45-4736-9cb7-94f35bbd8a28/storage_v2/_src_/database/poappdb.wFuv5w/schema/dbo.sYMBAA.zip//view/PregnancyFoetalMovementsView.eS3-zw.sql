CREATE VIEW [dbo].[PregnancyFoetalMovementsView]

AS

SELECT  Description, Code FROM dbo.PregnancyFoetalMovements

Union

SELECT  '', 0  FROM dbo.Hosp_Info
go

