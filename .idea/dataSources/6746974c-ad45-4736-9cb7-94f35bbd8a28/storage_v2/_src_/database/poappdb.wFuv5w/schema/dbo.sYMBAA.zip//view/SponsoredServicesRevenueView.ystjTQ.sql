
CREATE VIEW [dbo].[SponsoredServicesRevenueView]

AS

---ALL PRIVATE SPONSORED DRUGS

SELECT DISTINCT ServiceCode,SponsorNo,RequiredQty,UnitFee,ReqDate,PrivateClaimsServices.BeginDate,PrivateClaimsServices.EndDate,ServiceTypeCode,2 As PmtTypeCode, PrivateClaimsDetail.PatCatCode  
,SponsorTypeCode, ServicePlaceCode,PrivateClaimsDetail.OPDNo,RequesterID,PrivateClaimsServices.ClinicCode 
FROM Sponsors, AllSetUpServicesView, PrivateClaimsServices, PrivateClaimsDetail WHERE ItemID = ServiceCode And PrivateClaimsServices.PatCatCode NOT IN (0,1,4,11) And Sponsors.SponsorNo =PrivateClaimsServices.SponsorID
And UnitFee>0 AND RequiredQty >0 And Sponsors.SponsorTypeCode <>2 and PrivateClaimsDetail.ClaimEventID=PrivateClaimsServices.ClaimEventID and PrivateClaimsDetail.OPDNo=PrivateClaimsServices.OPDNo And
PrivateClaimsDetail.EndDate=PrivateClaimsServices.EndDate and PrivateClaimsDetail.BeginDate=PrivateClaimsServices.BeginDate

UNION

--Exempted Capitated Diagnostics
Select ServiceCode,Episode.SponsorNo,RequiredQty,NHIAEpisodeServices.ServiceFee, ReqDate,BeginEpisode, EndEpisode,NHIAEpisodeServices.ServiceTypeCode,EpisodePmtType,BillCtategoryCode,  
SponsorTypeCode,ServicePlaceCode,Episode.OPDNo, Episode.UserID, Clinic_Code From Sponsors Inner Join (Episode Inner Join (AllSetUpServicesView Inner Join NHIAEpisodeServices On ItemID=ServiceCode) On Episode.EpisodeID=NHIAEpisodeServices.EpisodeID) On Sponsors.SponsorNo=Episode.SponsorNo 
Where PmtType=2 and EpisodePmtType=3 And AttType<>2 and DiagnosticFee<>0 And Archived='No' and NoOfVisit>0 and NHIAEpisodeServices.ServiceTypeCode IN (4,11,12,13,14)  And UPPER(RequestType)='INTERNAL'  And Episode.IsDuplicate='No' And Episode.ClaimDataProcessed='Yes' 
And Episode.ClaimGDRGCode<>'' And Episode.EpisodeSpecialityCode<>'' And (Episode.EpisodePrinted='Yes' Or (Episode.EpisodeBatchNo<>'' And Episode.EpisodeBatchNo<>'None'))  and EpisodeSpecialityCode IN (Select Code From NHIAMDCS)

UNION ALL

-- Diagnostics
Select ServiceCode,Episode.SponsorNo,RequiredQty,NHIAEpisodeServices.ServiceFee, ReqDate,BeginEpisode, EndEpisode,NHIAEpisodeServices.ServiceTypeCode,EpisodePmtType,BillCtategoryCode,  
SponsorTypeCode,ServicePlaceCode,Episode.OPDNo, Episode.UserID, Clinic_Code From Sponsors Inner Join (Episode Inner Join (AllSetUpServicesView Inner Join NHIAEpisodeServices On ItemID=ServiceCode) On Episode.EpisodeID=NHIAEpisodeServices.EpisodeID) On Sponsors.SponsorNo=Episode.SponsorNo 
Where AttType=2 and DiagnosticFee<>0 And Archived='No' and NoOfVisit>0 and NHIAEpisodeServices.ServiceTypeCode IN (4,11,12,13,14)  And UPPER(RequestType)='INTERNAL'  And Episode.IsDuplicate='No' And Episode.ClaimDataProcessed='Yes' And Episode.ClaimGDRGCode<>'' And Episode.EpisodeSpecialityCode<>'' 
And (Episode.EpisodePrinted='Yes' Or (Episode.EpisodeBatchNo<>'' And Episode.EpisodeBatchNo<>'None'))  and EpisodeSpecialityCode IN (Select Code From NHIAMDCS)

UNION ALL

-- Non Diagnoses
Select ServiceCode,Episode.SponsorNo,RequiredQty,NHIAEpisodeServices.ServiceFee, ReqDate,BeginEpisode, EndEpisode,NHIAEpisodeServices.ServiceTypeCode,EpisodePmtType,BillCtategoryCode,  
SponsorTypeCode,ServicePlaceCode,Episode.OPDNo, Episode.UserID, Clinic_Code From Sponsors Inner Join (Episode Inner Join (AllSetUpServicesView Inner Join NHIAEpisodeServices On ItemID=ServiceCode) On Episode.EpisodeID=NHIAEpisodeServices.EpisodeID) On Sponsors.SponsorNo=Episode.SponsorNo 
Where AttType<>2 And Archived='No' and NoOfVisit>0 and ServiceType NOT IN (3,2) And Episode.IsDuplicate='No' And Episode.ClaimDataProcessed='Yes' And Episode.ClaimGDRGCode<>'' And Episode.EpisodeSpecialityCode<>'' And (Episode.EpisodePrinted='Yes' Or (Episode.EpisodeBatchNo<>'' And Episode.EpisodeBatchNo<>'None'))  
and EpisodeSpecialityCode IN (Select Code From NHIAMDCS)

UNION ALL

-- Diagnoses
Select ServiceCode,Episode.SponsorNo,RequiredQty,NHIAEpisodeServices.ServiceFee, ReqDate,BeginEpisode, EndEpisode,NHIAEpisodeServices.ServiceTypeCode,EpisodePmtType,BillCtategoryCode,  
SponsorTypeCode,ServicePlaceCode,Episode.OPDNo, Episode.EpisodeDoctor, Clinic_Code From Sponsors Inner Join (Episode Inner Join (AllSetUpServicesView Inner Join NHIAEpisodeServices On ItemID=ServiceCode) On Episode.EpisodeID=NHIAEpisodeServices.EpisodeID) On Sponsors.SponsorNo=Episode.SponsorNo 
Where AttType<>2 And Archived='No' and NoOfVisit>0 and NHIAEpisodeServices.ServiceTypeCode = Episode.ServiceType and ServiceType IN (2) and Service_Code=NHIAEpisodeServices.ServiceCode  And UPPER(RequestType)='INTERNAL'  And Episode.IsDuplicate='No' And Episode.ClaimDataProcessed='Yes' And Episode.ClaimGDRGCode<>'' 
And Episode.EpisodeSpecialityCode<>'' And (Episode.EpisodePrinted='Yes' Or (Episode.EpisodeBatchNo<>'' And Episode.EpisodeBatchNo<>'None'))  and EpisodeSpecialityCode IN (Select Code From NHIAMDCS)

UNION ALL

-- Surgicals
Select ServiceCode,Episode.SponsorNo,RequiredQty,NHIAEpisodeServices.ServiceFee, ReqDate,BeginEpisode, EndEpisode,NHIAEpisodeServices.ServiceTypeCode,EpisodePmtType,BillCtategoryCode, 
SponsorTypeCode,ServicePlaceCode,Episode.OPDNo, Episode.EpisodeDoctor, Clinic_Code From Sponsors Inner Join (Episode Inner Join (AllSetUpServicesView Inner Join NHIAEpisodeServices On ItemID=ServiceCode) On Episode.EpisodeID=NHIAEpisodeServices.EpisodeID) On Sponsors.SponsorNo=Episode.SponsorNo 
Where AttType<>2 And Archived='No' and NoOfVisit>0 and NHIAEpisodeServices.ServiceTypeCode = Episode.ServiceType and ServiceType IN (3)  And UPPER(RequestType)='INTERNAL'	 And Episode.IsDuplicate='No' And Episode.ClaimDataProcessed='Yes' And Episode.ClaimGDRGCode<>'' And Episode.EpisodeSpecialityCode<>'' And 
(Episode.EpisodePrinted='Yes' Or (Episode.EpisodeBatchNo<>'' And Episode.EpisodeBatchNo<>'None'))  and EpisodeSpecialityCode IN (Select Code From NHIAMDCS)

go

