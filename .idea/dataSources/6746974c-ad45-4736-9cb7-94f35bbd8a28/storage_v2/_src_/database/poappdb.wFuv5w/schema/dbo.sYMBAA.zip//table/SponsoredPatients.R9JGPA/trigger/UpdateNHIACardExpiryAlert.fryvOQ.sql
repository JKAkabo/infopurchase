CREATE TRIGGER [dbo].[UpdateNHIACardExpiryAlert]

ON [dbo].[SponsoredPatients]

AFTER UPDATE 

AS

--Make sure DateTo really changed
IF NOT UPDATE(DateTo) OR EXISTS (SELECT a.OPDNo FROM inserted a JOIN deleted b ON a.OPDNo=b.OPDNo WHERE a.DateTo=b.DateTo)
   RETURN	   
   
--Checking if SMS is enabled in HAMS
if NOT EXISTS(SELECT ActivateSMS FROM Hosp_Info WHERE ActivateSMS='Yes' )
   RETURN
   
DECLARE @msgTypeID tinyint;
DECLARE @msgContent nvarchar(200); 
DECLARE @Consent nvarchar(3);
DECLARE @msgType nvarchar(50);
DECLARE @msgStartTime datetime;
DECLARE @patOPDNo nvarchar(15);
DEClARE @patSurName nvarchar(100);
DECLARE @MsgFreqID tinyint;
DECLARE @TimeToSent datetime;
DECLARE @includePatName nvarchar(3);
DEClARE @CellPhoneNo nvarchar(100);
DECLARE @DaysToExpiry tinyint
DECLARE @patCellNo nvarchar(50)

set @msgTypeID=2

--Checking if NHIA Card Expiry SMS Alert is enabled in HAMS
 select @msgType=h.Description, @msgContent=s.MsgContent,@Consent=s.EnforceConsent,@includePatName = s.includeRPT, @msgStartTime=s.StartTime, @MsgFreqID=FreqCode FROM HamsMessageTypes h Inner Join HamsSMSSetup s On h.Code=s.TypeCode WHERE s.TypeCode=@msgTypeID And s.Active='Yes' And s.StartTime<=getdate()
 IF @@RowCount<=0 
    RETURN 

--Checking if Patient is a NHIA SPONSORED    		
SELECT @patOPDNo=i.OPDNo, @patSurName=(Title + '.' + Surname),@patCellNo=Rtrim(Ltrim(CellPhoneNo)) FROM SMSPatientInfoView p, Inserted i WHERE p.OPDNo=i.OPDNo And i.patcategoryCode in (4,11) and (datediff(day,getdate(),dateto)=14 or datediff(day,getdate(),dateto)=3 ) and i.Archived='No' And ((@Consent='Yes' And i.ExpiryAlert='Yes') or @Consent='No')  and Rtrim(Ltrim(CellPhoneNo))<>'' And CellPhoneNo Is Not Null  
IF @@RowCount<=0 OR @patCellNo=''
   RETURN 
    		
IF @includePatName='Yes'   
  insert into bulksms_db.dbo.sending_queue([from],[to],Message,queue_time,status) 
  select 'System',@patCellNo, @patSurName + ', according to our records your NHIA CARD EXPIRES in ' + Convert(nvarchar(5),datediff(day,getdate(),dateto))  + ' DAYS TIME.',getdate(),'Sent'
  FROM Inserted i
  
ELSE      		
  insert into bulksms_db.dbo.sending_queue([from],[to],Message,queue_time,status) 
  select 'System',@patCellNo,'Dear Client, according to our records your NHIA CARD EXPIRES in ' + Convert(nvarchar(5),datediff(day,getdate(),dateto))  + ' DAYS TIME.',getdate(),'Sent' 
  FROM Inserted i
go

