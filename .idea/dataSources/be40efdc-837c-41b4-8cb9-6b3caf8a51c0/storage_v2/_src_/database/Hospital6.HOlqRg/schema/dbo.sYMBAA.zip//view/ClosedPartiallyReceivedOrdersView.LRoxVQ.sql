create VIEW ClosedPartiallyReceivedOrdersView

AS

SELECT  distinct Orders.*  FROM Orders Inner join OrderLines on Orders.OrderNo=OrderLines.OrderID Where OrderLines.Archived='No' and Orders.Archived='No' and (OrderLines.OrderQty-OrderLines.OrderQtyReceived)>0 And Orders.OrderStatus IN (3,4)
go

