


CREATE VIEW [dbo].[ItemsConsumptionFreqValueView]

AS

select TOP 1 ItemsConsumpFreq, case when ItemsConsumpFreq=1 then datediff(D,StartDate,EndDate) 
when ItemsConsumpFreq=2 then datediff(WW,StartDate,EndDate) 
when ItemsConsumpFreq=3 then datediff(M,StartDate,EndDate)
when ItemsConsumpFreq=4 then datediff(M,StartDate,EndDate)
when ItemsConsumpFreq=5 then datediff(YYYY,StartDate,EndDate) end as FreqValue

from ItemsConsumptionParametersView



go

