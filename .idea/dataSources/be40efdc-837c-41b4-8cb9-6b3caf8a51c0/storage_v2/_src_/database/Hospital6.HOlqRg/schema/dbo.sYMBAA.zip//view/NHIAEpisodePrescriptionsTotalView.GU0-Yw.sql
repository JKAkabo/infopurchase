CREATE VIEW [dbo].[NHIAEpisodePrescriptionsTotalView]

AS

SELECT  IsNull(sum(IssuedAmount),0) As IssuedDrugsTotal, IsNull(sum(UnIssuedAmount),0) As UnIssuedDrugsTotal, ActiveEpiID FROM NHIAEpisodesView Inner Join NHIAEpisodePrescriptionsView on EpiID=EpisodeID Group By ActiveEpiID 


Union 

SELECT  0 As IssuedDrugsTotal, 0 As UnIssuedDrugsTotal, ActiveEpiID FROM NHIAEpisodesView Where ActiveEpiID Not In(
Select Distinct EpisodeID FROM NHIAEpisodePrescriptionsView)  Group By ActiveEpiID
go

